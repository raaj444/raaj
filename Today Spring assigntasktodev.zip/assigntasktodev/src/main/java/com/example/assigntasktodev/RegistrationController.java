package com.example.assigntasktodev;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="*")
@RestController
public class RegistrationController {

	@Autowired
	RegistrationRule registrationRule;
	
	@RequestMapping(value="/assigndata",method=RequestMethod.POST)
	  public SampleRegist getCommonData(@RequestBody SampleRegist tModel)
	 	{
			return registrationRule.getRegisrtaionData(tModel);
		}
	
	@RequestMapping(value="/retrivedata",method=RequestMethod.POST)
	  public List<SampleRegist> getCommonData()
	 	{
			return registrationRule.retrivedata();
		}

}
