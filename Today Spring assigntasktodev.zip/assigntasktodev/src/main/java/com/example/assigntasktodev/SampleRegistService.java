package com.example.assigntasktodev;

import java.util.List;

public interface SampleRegistService 
{
	public SampleRegist getRisterData(SampleRegist tModel);
	public List<SampleRegist> retrivedata();
}
