 package com.example.assigntasktodev;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface SampleRegistRepo extends JpaRepository<SampleRegist,Long> 
{
	public SampleRegist findByprojectname(String projectname);

	
}
