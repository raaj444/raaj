package com.example.assigntasktodev;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;




@Component
public class RegistrationRule
{
	@Autowired 
	SampleRegistService samplregisservice;
	
	public SampleRegist getRegisrtaionData(SampleRegist tModel)
	{
		return samplregisservice.getRisterData(tModel);
	}
	
	public List<SampleRegist> retrivedata()
	{
		List<SampleRegist> sav=samplregisservice.retrivedata();
		return sav;
	}	
}
