package com.example.assigntasktodev;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;




@Service
@Transactional
public class SampleRegistServiceImpl implements SampleRegistService  {

	@Autowired
	SampleRegistRepo regisRepo;

	@Override
	public SampleRegist getRisterData(SampleRegist tModel) 
	
	{
	
		return regisRepo.save(tModel);

	}
	@Override
	public List<SampleRegist> retrivedata() {	
	return regisRepo.findAll();
	}

}