package com.example.assigntasktodev;


import java.io.Serializable;
import javax.persistence.*;

@Entity()
@Table(name="taskassigntodev")
public class SampleRegist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue

	@Column(name="id")
	private Long Id;

	@Column(name="projectname")
	private String projectname;
	
	@Column(name="projectmodule")
	private String projectmodule;

	@Column(name="submodule")
	private String submodule;
	
	@Column(name="description")
	private String description;
	
	@Column(name="assign")
	private String assign;
	
	@Column(name="duration")
	private String duration;

	@Column(name="start1")	
	private String start1;
	
	@Column(name="end1")
	private String end1;
	

		public Long getId() {
		return Id;
	}


	public void setId(Long id) {
		Id = id;
	}


		public String getProjectname() {
		return projectname;
	}


	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}


		public String getProjectmodule() {
		return projectmodule;
	}


	public void setProjectmodule(String projectmodule) {
		this.projectmodule = projectmodule;
	}


		public String getSubmodule() {
		return submodule;
	}


	public void setSubmodule(String submodule) {
		this.submodule = submodule;
	}


		public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


		public String getAssign() {
		return assign;
	}


	public void setAssign(String assign) {
		this.assign = assign;
	}


		public String getDuration() {
		return duration;
	}


	public void setDuration(String duration) {
		this.duration = duration;
	}


		public String getStart1() {
		return start1;
	}


	public void setStart1(String start1) {
		this.start1 = start1;
	}


		public String getEnd1() {
		return end1;
	}


	public void setEnd1(String end1) {
		this.end1 = end1;
	}


		public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
		