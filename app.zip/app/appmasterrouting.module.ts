import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ListvaluemasterComponent } from './setup/listvaluemaster/listvaluemaster.component';
import { ApplicationcontroldataComponent } from './master/applicationcontroldata/applicationcontroldata.component';
import { InterfacelinkComponent } from './master/interfacelink/interfacelink.component';
import { DenominationmasterComponent } from './setup/denominationmaster/denominationmaster.component';
import { GeographymasterComponent } from './setup/geographymaster/geographymaster.component';
import { TakeovermasterComponent } from './setup/takeovermaster/takeovermaster.component';
import { DocumentmastersComponent } from "./setup/documentmasters/documentmasters.component";
import { TermsandconditionmasterComponent } from './setup/termsandconditionmaster/termsandconditionmaster.component';
import { OrganizationlevelComponent } from './setup/organizationlevel/organizationlevel.component';
import { OrganizationComponent } from './setup/organization/organization.component';
import { UsersgroupComponent } from './setup/usersgroup/usersgroup.component';
import { UsersComponent } from './setup/users/users.component';
import { UserClassComponent } from './setup/userclass/userclass.component';
import { LocationmappingComponent } from './setup/locationmapping/locationmapping.component';
import { MailtemplateComponent } from './setup/mailtemplate/mailtemplate.component';
import { EmailtemplatemappingComponent } from "./setup/emailtemplatemapping/emailtemplatemapping.component";
import { TalukmasterComponent } from './setup/talukmaster/talukmaster.component';
@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'listvaluemaster', component: ListvaluemasterComponent },
         { path: 'applicationcontroldata', component: ApplicationcontroldataComponent },
         { path: 'interfacelink', component: InterfacelinkComponent},
         { path: 'denomination',component:DenominationmasterComponent},
         { path: 'geographymaster', component: GeographymasterComponent },
         { path: 'takeovermaster', component: TakeovermasterComponent },
         { path: 'documentmasters', component: DocumentmastersComponent },
   { path: 'Terms', component: TermsandconditionmasterComponent },

         { path: 'organizationlevel', component: OrganizationlevelComponent },
         { path: 'mailtemplate', component: MailtemplateComponent },
 { path: 'organization', component: OrganizationComponent },
 { path: 'users', component: UsersComponent },
 { path: 'usersgroup', component: UsersgroupComponent },
 { path: 'locationmapping', component: LocationmappingComponent},
 { path: 'userclass', component: UserClassComponent },
{ path: 'emailtemplatemapping', component: EmailtemplatemappingComponent },
{ path: 'talukmaster', component: TalukmasterComponent },
 

    
    ])
  ],
  exports: [
    RouterModule
]
})
export class AppmasterroutingModule { 


 
}
