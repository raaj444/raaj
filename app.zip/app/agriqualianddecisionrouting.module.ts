import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ExistingcustrefComponent } from './agri/existingcustref/existingcustref.component';
import { ExistingkccrepaymentComponent } from './agri/existingkccrepayment/existingkccrepayment.component';
import { WorkflowComponent } from './common/workflow/workflow.component';
import { AgriscorecardComponent } from './agri/agriscorecard/agriscorecard.component';




@NgModule({
  imports: [ RouterModule.forChild([
    { path: 'exicustref', component: ExistingcustrefComponent},
    { path: 'existingkccrepayment', component: ExistingkccrepaymentComponent },
    { path: 'workflow', component: WorkflowComponent},
    { path: 'agriscorecard', component: AgriscorecardComponent },
    
  ])


    
  ],
  exports: [RouterModule]
})
export class AgriqualianddecisionroutingModule { }
