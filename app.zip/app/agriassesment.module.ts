import { NgModule } from '@angular/core';
import { SharedModule } from './shared.module';
import { AgriassesmentroutingModule } from './agriassesmentrouting.module';
import { KccassessmentComponent } from './agri/kccassessment/kccassessment.component';
import { AgritermloanComponent } from './agri/agritermloan/agritermloan.component';
import { KkrpremiumComponent } from './agri/kkrpremium/kkrpremium.component';
import { ValuationandcollateralComponent } from "./agri/valuationandcollateral/valuationandcollateral.component";
import { CropsurrogatetermComponent } from './agri/cropsurrogateterm/cropsurrogateterm.component';
import { KccacuntmaturityComponent } from './agri/kccacuntmaturity/kccacuntmaturity.component';
import { KccService } from './util/service/agriservices/kcc.service';
import { AgritermloanService } from './util/service/agriservices/agritermloan.service';
import { ValuationandcollateralService } from './util/service/agriservices/valuationandcollateral.service';
import { CropsurrogatetermService } from './util/service/agriservices/cropsurrogateterm.service';
import { KccacuntmaturityService } from './util/service/agriservices/kccacuntmaturity.service';
import { DscrassessmentComponent } from './agri/dscrassessment/dscrassessment.component';
import { DscrService } from './util/service/agriservices/dscr.service';


@NgModule({
  imports: [
        SharedModule,
        AgriassesmentroutingModule
  ],
  declarations: [KccassessmentComponent,AgritermloanComponent,ValuationandcollateralComponent,CropsurrogatetermComponent,
    KccacuntmaturityComponent,DscrassessmentComponent],
  providers:[KccService,AgritermloanService,ValuationandcollateralService,CropsurrogatetermService,KccacuntmaturityService,
    DscrService],
})
export class AgriassesmentModule { }
