import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserNamePipe } from './setup/workflowmaster/workflowmasterpipe.pipe';
import { SecuritymasterComponent } from "./setup/securitymaster/securitymaster.component";
import { CmaformulamasterComponent } from './setup/cmaformulamaster/cmaformulamaster.component';
import { CmaFinmasterComponent } from './setup/cmamaster/cmamaster.component';
import { AssessmentComponent } from './setup/assessment/assessment.component';
import { AnnexuremasterComponent } from "./setup/annexuremaster/annexuremaster.component";
import { CranmasterComponent } from './setup/cranmaster/cranmaster.component';
import { DeviationmasterComponent } from './setup/deviationmaster/deviationmaster.component';
import { WorkflowmasterComponent } from './setup/workflowmaster/workflowmaster.component';
import { FacilitydetailsComponent } from "./setup/facilitydetails/facilitydetails.component";
import { SchememasterComponent } from './setup/schememaster/schememaster.component';
import { ProductsearchComponent } from "./setup/productsearch/productsearch.component";
import { ScorecardmasterComponent } from './setup/scorecardmaster/scorecardmaster.component';
import { QualitativemasterComponent } from "./setup/qualitativemaster/qualitativemaster.component";
import { PSLLovMasterComponent } from './master/psllovmaster/psllovmaster.component';
import { PSLMasterComponent } from './setup/pslmaster/pslmaster.component';
import { SofmasterComponent } from './master/sofmaster/sofmaster.component';
import { ScorecardbusinessruleComponent } from "./setup/agriscorecardbusinessrule/agriscorecardbusinessrule.component";
import { AgrisofdeviationComponent } from './agri/agrisofdeviation/agrisofdeviation.component';
import { AgrileaselanddeviationComponent } from './agri/agrileaselanddeviation/agrileaselanddeviation.component';
import { StlvehincdeviationComponent } from './agri/stlvehincdeviation/stlvehincdeviation.component';
import { MclrmasterComponent } from './master/mclrmaster/mclrmaster.component';
import { PslclassificationmastComponent } from './master/pslclassificationmast/pslclassificationmast.component';
import { CommunitymasterComponent } from './agri/communitymaster/communitymaster.component';
import { AtlfacpurposemasterComponent } from './agri/atlfacpurposemaster/atlfacpurposemaster.component';
import { PslautomationComponent } from './agri/pslautomation/pslautomation.component';
import { HolidaymasterComponent } from "./setup/holidaymaster/holidaymaster.component";
import { SltemplatemasterComponent } from "./setup/sltemplatemaster/sltemplatemaster.component";
import { AssessmentconfigComponent } from './setup/assessmentconfig/assessmentconfig.component';
import { FlowpointComponent } from './setup/flowpoint/flowpoint.component';
import { ChargesComponent } from "./setup/charges/charges.component";
import { InterestrateComponent } from "./setup/interestrate/interestrate.component";
import { LpyieldmasterComponent } from './master/lpyieldmaster/lpyieldmaster.component';
import { CmaformulamasterService } from './util/service/setupservices/cmaformulamaster.service';
import { CmamasterService } from "./util/service/setupservices/cmamaster.service";
import { AssessmentService } from "./util/service/setupservices/assessment.service";
import { AnnexuremasterService } from "./util/service/setupservices/annexuremaster.service";
import { CranmasterService } from "./util/service/setupservices/cranmaster.service";
import { DeviationmasterService } from "./util/service/setupservices/deviationmaster.service";
import { WorkflowmasterService } from "./util/service/setupservices/workflowmaster.service";
import { FlowpointService } from "./util/service/setupservices/flowpoint.service";
import { FacilitydetailService } from "./util/service/setupservices/facilitydetail.service";
import { SchememasterService } from "./util/service/setupservices/schememaster.service";
import { ScorecardmasterService } from "./util/service/setupservices/scorecardmaster.service";
import { QualitativemasterService } from "./util/service/setupservices/qualitativemaster.service";
import { PSLLovMasterService } from "./util/service/masterservices/psllovmaster.service";
import { PSLMasterService } from "./util/service/setupservices/pslmaster.service";
import { SofmasterService } from "./util/service/masterservices/sofmaster.service";
import { Fieldvalidation } from "./util/helper/fieldvalidation";
import { BusisetuproutingModule } from './busisetuprouting.module';
import { PagelistComponent } from './setup/pagelist/pagelist.component';
import { DelegationmasterComponent } from './setup/delegationmaster/delegationmaster.component';
import { BusinessdelegationComponent } from './setup/businessdelegation/businessdelegation.component';
import { LpyieldmasterService } from './util/service/masterservices/lpyieldmaster.service';
import { AgriscorecardbusinessruleService } from "./util/service/setupservices/agriscorecardbusinessrule.service";
import { AgrisofdeviationService } from './util/service/agriservices/agrisofdeviation.service';
import { AgrileasedeviationService } from './util/service/agriservices/agrileasedeviation.service';
import { StlvehincdeviationService } from './util/service/agriservices/stlvehincdeviation.service';
import { MclrmasterService } from './util/service/masterservices/mclrmaster.service';
import { PslclassificationmastService } from './util/service/masterservices/pslclassificationmast.service';
import { CommunitymasterService } from './util/service/agriservices/communitymaster.service';
import { AtlfacpurposemasterService } from './util/service/agriservices/atlfacpurposemaster.service';
import { PslautomationService } from './util/service/agriservices/pslautomation.service';
import { HolidaymasterService } from "./util/service/setupservices/holidaymaster.service";
import { AssessmentconfigService } from "./util/service/setupservices/assessmentconfig.service";
import { PagelistService } from "./util/service/setupservices/pagelist.service";
import { DelegationmasterService } from "./util/service/setupservices/delegationmaster.service";
import { BusinessdelegationService } from "./util/service/setupservices/businessdelegation.service";
import { ChargesService } from "./util/service/setupservices/charges.service";
import { InterestrateService } from './util/service/setupservices/interestrate.service';
import { FlowpointsearchComponent } from './setup/flowpointsearch/flowpointsearch.component';
import { SharedModule } from './shared.module';
import { BrowserModule } from '@angular/platform-browser';
import { FlowPtDescNamePipe } from './setup/workflowmaster/workflowmasterpipe.pipe';
import { SchemetermsComponent } from './setup/schemeterms/schemeterms.component';
import { SchemedocumentComponent } from './setup/schemedocument/schemedocument.component';
import { SchemedocumentService } from './util/service/setupservices/schemedocument.service';
import { SchemetermsService } from './util/service/setupservices/schemeterms.service';
import { ShowFormulaNameByIdPipe } from './setup/cmamaster/cmamasterpipe.pipe';
import { ShowPSLCategoryNameByIdPipe } from './setup/pslmaster/pslmasterpipe.pipe';
import { FlowpointsearchService } from './util/service/setupservices/flowpointsearch.service';
import { ProductsearchService } from './util/service/setupservices/productsearch.service';
import { ProducttabnavigationComponent } from './setup/producttabnavigation/producttabnavigation.component';
import { ProductComponent } from './setup/product/product.component';
import { ProductdocumentComponent } from './setup/productdocument/productdocument.component';
import { ProducttermsComponent } from './setup/productterms/productterms.component';
import { ProductassessmentComponent } from './setup/productassessment/productassessment.component';
import { ProductassessmentService } from './util/service/setupservices/productassessment.service';
import { PrdassearchComponent } from './common/prdassearch/prdassearch.component';
import { ProducttermsService } from './util/service/setupservices/productterms.service';
import { ProductdocumentService } from './util/service/setupservices/productdocument.service';
import { StgeographymasterService } from './util/service/setupservices/stgeographymaster.service';
import { UdfmasterComponent } from './setup/udfmaster/udfmaster.component';
import { InternalratingmasterComponent } from './setup/internalratingmaster/internalratingmaster.component';
import { InternalratingmasterService } from './util/service/setupservices/internalratingmaster.service';
import { UdfmasterService } from './util/service/masterservices/udfmaster.service';
import { ApprovaldelegationComponent } from "./setup/approvaldelegation/approvaldelegation.component";
import { ApprovaldelegationService } from "./util/service/setupservices/approvaldelegation.service";
import { PeercomparisonorderingComponent } from './setup/peercomparisonordering/peercomparisonordering.component';
import { PeercomparisonorderingService } from './util/service/setupservices/peercomparisonordering.service';
import { ManualdopComponent } from './common/manualdop/manualdop.component';
import { ManualdopService } from './util/service/commonservices/manualdop.service';

@NgModule({
  imports: [

    BusisetuproutingModule,
    SharedModule,


  ],
  declarations: [SecuritymasterComponent,
    CmaformulamasterComponent, CmaFinmasterComponent, AssessmentComponent, AnnexuremasterComponent, CranmasterComponent
    , DeviationmasterComponent, WorkflowmasterComponent,
    FacilitydetailsComponent,
    SchememasterComponent, ProductsearchComponent
    , ScorecardmasterComponent,
    QualitativemasterComponent,
    PSLLovMasterComponent,
    PSLMasterComponent,
    SofmasterComponent,
    ScorecardbusinessruleComponent,
    AgrisofdeviationComponent, FlowPtDescNamePipe,
    AgrileaselanddeviationComponent,
    StlvehincdeviationComponent, MclrmasterComponent, PslclassificationmastComponent,
    CommunitymasterComponent, AtlfacpurposemasterComponent,
    PslautomationComponent, HolidaymasterComponent, SltemplatemasterComponent,
    AssessmentconfigComponent, PagelistComponent, UserNamePipe, ShowFormulaNameByIdPipe, ShowPSLCategoryNameByIdPipe,
    DelegationmasterComponent, BusinessdelegationComponent, ChargesComponent, InterestrateComponent, FlowpointComponent, FlowpointsearchComponent, SchemetermsComponent, SchemedocumentComponent,
    ProducttabnavigationComponent, ProductComponent, ProductdocumentComponent, ProducttermsComponent, ProductassessmentComponent, PrdassearchComponent, LpyieldmasterComponent, UdfmasterComponent,
    InternalratingmasterComponent, ApprovaldelegationComponent, PeercomparisonorderingComponent,ManualdopComponent
  ],
  providers: [CmaformulamasterService, CmamasterService, AssessmentService, AnnexuremasterService, CranmasterService,
    DeviationmasterService, WorkflowmasterService, FlowpointService, FacilitydetailService, SchememasterService, ScorecardmasterService, PSLLovMasterService, PSLMasterService,
    SofmasterService, LpyieldmasterService, AgriscorecardbusinessruleService, AgrisofdeviationService, AgrileasedeviationService, StlvehincdeviationService,
    MclrmasterService, PslclassificationmastService, CommunitymasterService, AtlfacpurposemasterService, PslautomationService, HolidaymasterService, AssessmentconfigService, PagelistService,
    DelegationmasterService, BusinessdelegationService, ChargesService, InterestrateService, SchemedocumentService, SchemetermsService
    , FlowpointsearchService, ProductsearchService, QualitativemasterService, ProductassessmentService, ProducttermsService, ProductdocumentService,
    StgeographymasterService, InternalratingmasterService, UdfmasterService, ApprovaldelegationService,PeercomparisonorderingService,ManualdopService
  ]
})
export class BusisetupModule { }
