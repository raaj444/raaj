import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { LoginComponent } from './common/login/login.component';
import { IplettermailformatComponent } from './corporate/iplettermailformat/iplettermailformat.component';
import { SlmailformatComponent } from './common/slmailformat/slmailformat.component';
import { AddendumslmailformatComponent } from './common/slmailformat/addendumslmailformat/addendumslmailformat.component';
import { CranmailformatComponent } from './common/slmailformat/cranmailformat/cranmailformat.component';

@NgModule({
imports: [
  RouterModule.forRoot([
      {path: 'login', component: LoginComponent },
      {path: 'ipletter/:propno/:custid/:setid', component: IplettermailformatComponent },
      {path: 'sanctionletter/:propno/:custid', component: SlmailformatComponent },
      {path: 'addendumsl/:propno/:custid/:cnversion', component: AddendumslmailformatComponent },
      {path: 'cran/:propno/:custid/:setid/:crantype', component: CranmailformatComponent },
      {path: 'home', loadChildren: 'app/home.module#HomeModule'},
      { path: '**', redirectTo: '/login' }
  ])
],
exports: [
  RouterModule
]
})
export class ApproutingModule { }
