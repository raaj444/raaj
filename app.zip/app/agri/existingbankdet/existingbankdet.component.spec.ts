import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingbankdetComponent } from './existingbankdet.component';

describe('ExistingbankdetComponent', () => {
  let component: ExistingbankdetComponent;
  let fixture: ComponentFixture<ExistingbankdetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingbankdetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingbankdetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
