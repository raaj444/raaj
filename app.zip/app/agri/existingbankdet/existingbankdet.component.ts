import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { Sales26asgstService } from '../../util/service/corporateservices/sales26asgst.service'
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ExistingbankdetService } from '../../util/service/agriservices/existingbankdet.service';
import { Router } from '@angular/router';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
declare var customStatus: any
declare var $: any;

@Component({
  selector: 'lp-existingbankdet',
  templateUrl: './existingbankdet.component.html',
  styleUrls: ['./existingbankdet.component.css']
})
export class ExistingbankdetComponent extends Validator implements OnInit {
  data: any;
  model: any = {};
  partiesCRNList = [];
  bankNames = [];
  bankAccountType = [];
  optionsModel: any = {};
  editDisabled: boolean = true;
  saveDisabled: boolean = true;
  cancelDisabled: boolean = true;
  addnewDisabled: boolean = true;
  deleteDisabled: boolean = true;
  Salesgstlist: any = [];
  disableFields: boolean = true;
  validation: boolean;
  pageAccess: any;
  disableFlag: boolean;
  ControllList: any = ['sel_lebdCustId', 'sel_lebdPartyType', 'sel_lebdBankAccountType', 'txt_lebdBankAccNo', 'sel_lebdBankName'
    , 'txt_lebdBranchName', 'txt_lebdAccBalance'];
  modelForChngNote: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private existingbankdetService: ExistingbankdetService, private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    loadingStatus()
    this.model.existingbankdetails = [];
    this.partiesCRNList = [];
    this.existingbankdetService.getExistingBankDetails(this.model)
      .subscribe(data => {
        this.data = data;
        if (this.data.success) {
          this.model.existingbankdetails = this.data.ExistingBankDetails;
          this.pageAccess = this.data.pageAccess;
          this.partiesCRNList = this.data.responseData.LpcomCustInfoApplist;
          this.bankNames = this.data.responseData.bankNames;
          this.bankAccountType = this.data.responseData.bankaccounttype;

          if (this.model.existingbankdetails.length < 1) {
            this.model.existingbankdetails.push({
              lebdRowId: 0, lebdOrderNo: 0, lebdPartyType: 's',
              lebdBankAccountType: 's', lebdBankName: 's', lebdCustId: 's'
            });
            this.disableButton(false, true, false, false, false);
            this.disableFields = false;
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }
          if (this.pageAccess == 'R') {
            this.disableButton(true, true, true, true, true);
            this.disableFields = true;
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
        } else {
        }
      },
      error => {
      });
    this.disableButton(true, false, true, true, true);

    hide()
  }
  disableButton(addnew: boolean, edit: boolean, save: boolean, btndelete: boolean, cancel: boolean) {
    if (this.pageAccess != "R") {
      this.addnewDisabled = addnew;
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.deleteDisabled = btndelete;
      this.cancelDisabled = cancel;
    }
    else {
      this.addnewDisabled = true;
      this.editDisabled = true;
      this.saveDisabled = true;
      this.deleteDisabled = true;
      this.cancelDisabled = true;
    }
  }
  addNewDetails() {

    this.disableFields = false;
    // this.addnewDisabled = false;
    // this.editDisabled = true;
    // this.saveDisabled = false;
    // this.deleteDisabled = false;
    // this.cancelDisabled = false;
    this.disableButton(false, true, false, false, false);
    var maxid = "";
    if (this.model.existingbankdetails.length < 10) {
      var existingbankdetailsmax = JSON.parse(JSON.stringify(this.model.existingbankdetails));
      this.model.existingbankdetailsmax = [];
      existingbankdetailsmax.forEach(field => {

        maxid = field.lebdOrderNo;

      })
      this.model.existingbankdetails.push({
        lebdRowId: 0, 'lebdOrderNo': maxid + 1, lebdPartyType: 's',
        lebdBankAccountType: 's', lebdBankName: 's', lebdCustId: 's'
      });
    }
  }
  deleteDetails(lebdOrderNo: number) {

    if (confirm("Do you want to Delete?")) {

      if (this.model.existingbankdetails.length <= 1) {
        customStatus("Please Maintain Atleast One Row");
      }
      else {
        var existingbankdetailsTemp = JSON.parse(JSON.stringify(this.model.existingbankdetails));
        this.model.existingbankdetails = [];
        existingbankdetailsTemp.forEach(field => {
          if (field.lebdRowId != 0 && field.lebdOrderNo == lebdOrderNo) {
            var rowid = "";
            this.model.SeqId = field.lebdOrderNo;
            this.existingbankdetService.deleteExistingBankDetails(this.model, field.lebdOrderNo)
              .subscribe(
              data => {
                this.data = data;
                this.getData(data);
              },
              error => {
              });
          }
          else {
            if (field.lebdOrderNo != lebdOrderNo) {
              this.model.existingbankdetails.push(field);
            }
          }
        });
      }
    }

  }
  dosave() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.existingbankdetails.length, this.ControllList)) {
        this.changenoteComponent.onSave();
      }
      this.validation = this.fieldvalidation.multipleFieldValidation(this.model.existingbankdetails.length, this.ControllList);
      if (this.validation == true) {
        progressStatus()
        this.existingbankdetService.saveExistingBankDetails(this.model).subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
              this.disableFields = true;
              successStatus()
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }

            else {
              failedStatus()
            }
          }
          ,
          error => {
            failedStatus()
          });
        this.disableButton(false, false, true, true, true);
      }
    }
  }

  doedit() {
    this.disableButton(false, true, false, false, false);
    this.disableFields = false;
    // this.addnewDisabled = false;
    // this.editDisabled = true;
    // this.saveDisabled = false;
    // this.deleteDisabled = false;
    // this.cancelDisabled = false;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  dodelete() {

    if (confirm("Do you want to Delete?")) {
      this.existingbankdetService.deleteAllData(this.model)
        .subscribe(
        data => {
          this.data = data;
          this.ngOnInit();
        },
        error => {
        });
      this.deleteDisabled = true;
      this.disableFields = true;
    }

  }

  docancel() {
    this.ngOnInit();
    sessionStorage.setItem("editMode", "N");
    $('input,select,textarea').removeClass('ng-dirty');
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.ngOnInit();
    }
    this.disableFields = true;
  }
  getData(data: any) {

    this.existingbankdetService.getExistingBankDetails(this.model)
      .subscribe(data => {
        this.data = data;
        this.model.existingbankdetails = this.data.ExistingBankDetails;
        if (this.model.existingbankdetails.length < 1) {
          this.model.existingbankdetails.push({
            lebdRowId: 0, lebdOrderNo: 0, lebdPartyType: 's',
            lebdBankAccountType: 's', lebdBankName: 's', lebdCustId: 's'
          });
        }
      });
    this.disableButton(true, false, true, true, true);

  }
  toFixedOnBlur(e: any) {
    if (e.target.value != "") {
      var value = parseFloat(e.target.value).toFixed(2);
      $('#' + e.target.id).val(value);
    }
  }
}

