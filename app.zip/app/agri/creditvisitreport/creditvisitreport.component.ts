import { Component, OnInit, ViewChild } from '@angular/core';
import { CreditvisitreportService } from "../../util/service/agriservices/creditvisitreport.service";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Validator } from '../../util/helper/validator';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
declare var $: any;
@Component({
  selector: 'lp-creditvisitreport',
  templateUrl: './creditvisitreport.component.html',
  styleUrls: ['./creditvisitreport.component.css']
})
export class CreditvisitreportComponent extends Validator implements OnInit {
  data: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private creditvisitreportService: CreditvisitreportService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService
  ) {
    super();
    this.minDate = new Date(1899, 12, 1);
    this.minDate.setDate(this.minDate.getDate());
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
  }
  propNo: any;
  cvrAnnxMasterList: any = [];
  private cvrAnnxList: Array<any> = [];
  cvrAnnxContentList: any = [];
  model: any = {};
  editDisabled: boolean;
  cancelDisabled: boolean;
  saveDisabled: boolean;
  fieldDisable: boolean;
  heading: boolean = false;
  content: boolean = false;
  pageAccess: any;
  nameDisable: boolean;
  deleteDisabled: boolean;
  flag: boolean;
  idvalueList = ['lcrVisitdate', 'lcrMetwith','lcrCreditempName'];
  minDate: Date;
  maxDate: Date;
  modelForChngNote: any;

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.model.cvrAnnxHeadingList = [];
    this.model.cvrAnnxContentListObject = {};
    this.cvrAnnxList = [];
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    loadingStatus()
    this.creditvisitreportService.getPropNo()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          this.propNo = this.data.responseData[0];
          this.model.lcrCreditempName = this.data.userName;
          this.nameDisable = true;
          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess == "R")
            this.disableButton(true, true, true, true, true);
          else
            this.disableButton(true, false, true, true, true);

          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
          //this.disableButton(true,false,true,true,true);
          if (this.propNo != null) {
            this.creditvisitreportService.getCvrAnnex()
              .subscribe(
              data => {
                this.data = data;
                if (this.data.success) {

                  this.data.responseData.CvrAnnx.forEach(annx => {

                    if (annx.lcrParentId == 0)
                      this.model.cvrAnnxHeadingList.push({ lcrDescription: annx.lcrDescription, lcrRemarks: " ", lcrParentId: annx.lcrParentId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
                    else {
                      if (this.model.cvrAnnxContentListObject[annx.lcrParentId] == undefined) {
                        this.model.cvrAnnxContentListObject[annx.lcrParentId] = [];
                        this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrPropId: annx.lcrPropId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
                      }
                      else {
                        this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrPropId: annx.lcrPropId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });

                      }
                    }
                    if (annx.lcrVisitdate != "" && annx.lcrVisitdate != undefined) {
                      var visitdate = annx.lcrVisitdate;
                      var date = visitdate.split("-");
                      this.model.lcrVisitdate = date[2] + '/' + date[1] + '/' + date[0];
                    }
                    this.model.lcrMetwith = annx.lcrMetwith;
                    if(annx.lcrCreditempName!= null || annx.lcrCreditempName!= undefined)
                    this.model.lcrCreditempName = annx.lcrCreditempName;
                  });
                }
              },
              error => {

              });


          }
          else {
            this.creditvisitreportService.getCvrAnnexList()
              .subscribe(
              data => {
                this.data = data;

                if (this.data.success == true) {
                  // this.disableButton(true, false, true, true, true);

                  this.disableButton(false, true, false, false, false);
                  if (this.modelForChngNote.changeMode == "Y") {
                    this.changenoteComponent.onEdit(false);
                  }
                  this.data.responseData.CvrList.forEach(annx => {

                    if (annx.lamParentId == 0)
                      this.model.cvrAnnxHeadingList.push({ lcrDescription: annx.lamDescription, lcrRemarks: " ", lcrParentId: annx.lamParentId, lcrOrderNo: annx.lamRowId });
                    else {
                      if (this.model.cvrAnnxContentListObject[annx.lamParentId] == undefined) {
                        this.model.cvrAnnxContentListObject[annx.lamParentId] = [];
                        this.model.cvrAnnxContentListObject[annx.lamParentId].push({ lcrDescription: annx.lamDescription, lcrRemarks: "", lcrParentId: annx.lamParentId, lcrOrderNo: annx.lamRowId });

                      }
                      else {
                        this.model.cvrAnnxContentListObject[annx.lamParentId].push({ lcrDescription: annx.lamDescription, lcrRemarks: "", lcrParentId: annx.lamParentId, lcrOrderNo: annx.lamRowId });
                      }
                    }

                  });
                }

              },
              error => {

              });

          }
        }

      },
      error => {

      });


    hide()
  }

  editCvrAnnx() {
    this.disableButton(false, true, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  saveCvrAnnx() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }

    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.validateField(this.idvalueList)
      if (this.flag == true) {
        this.model.lcrVisitdate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lcrVisitdate);
        progressStatus()

        this.creditvisitreportService.saveCreditVisitReport(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {

              this.model.cvrAnnxHeadingList = [];
              this.model.cvrAnnxContentListObject = {};

              this.cvrAnnxList = this.data.responseData.CvrAnnx;
              this.cvrAnnxList.forEach(annx => {

                if (annx.lcrParentId == 0)
                  this.model.cvrAnnxHeadingList.push({ lcrDescription: annx.lcrDescription, lcrRemarks: " ", lcrParentId: annx.lcrParentId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
                else {
                  if (this.model.cvrAnnxContentListObject[annx.lcrParentId] == undefined) {
                    this.model.cvrAnnxContentListObject[annx.lcrParentId] = [];
                    this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId, });
                  }
                  else {
                    this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
                  }
                }

              });
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              successStatus()
              this.disableButton(true, false, true, true, true);
              if (this.modelForChngNote.changeMode == "Y") {
                this.changenoteComponent.onEdit(false);
              }
            }
          },
          error => {
            failedStatus()
          });
      }
    }
  }
  cancelButton() {

    if (confirm("Do you want to cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
      $('input,select,textarea').removeClass('ng-dirty');
    }
    else
      return false;
  }


  disableButton(field: boolean, edit: boolean, save: boolean, cancel: boolean, delete1: boolean) {

    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.editDisabled = true;
      this.saveDisabled = true;
      this.deleteDisabled = true;
      this.cancelDisabled = true;

    }
    else {
      this.fieldDisable = field;
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.deleteDisabled = delete1;
      this.cancelDisabled = cancel;
    }
  }

  deleteCvrAnnx() {
    if (confirm("Do you want to Delete?")) {
      this.creditvisitreportService.deleteall(this.model)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.model = {};
            this.ngOnInit();

          }
        },
        error => {

        });
    }
    else {
      this.ngOnInit();
    }
  }


  validatefuturedate(event) {
    if (event != null && event != "") {
      this.fieldvalidation.validatefuturedate(event.target.id);
    }
  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }

}



