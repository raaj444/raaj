import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditvisitreportComponent } from './creditvisitreport.component';

describe('CreditvisitreportComponent', () => {
  let component: CreditvisitreportComponent;
  let fixture: ComponentFixture<CreditvisitreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditvisitreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditvisitreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
