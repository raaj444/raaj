import { Component, OnInit, ViewChild } from '@angular/core';
import { FleetandloandetailsService } from "../../util/service/agriservices/fleetandloandetails.service";
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;

@Component({
  selector: 'lp-fleetandloandetails',
  templateUrl: './fleetandloandetails.component.html',
  styleUrls: ['./fleetandloandetails.component.css']
})
export class FleetandloandetailsComponent extends Validator implements OnInit {
  data: any;
  model: any = {};
  private fleetdetails: Array<any> = [];
  private installmentFreqList: Array<any> = [];
  disableFields: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  disableInstlFields: boolean = true;
  idvalueList = ['afdOwnerId', 'afdBorrRelation', 'afdYearMfgr', 'afdMake', 'afdModel'];
  borrowerType = [];
  modelForChngNote: any;
  relationwithBorrwerList = [];
  pageAccess: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private fleetandloandetailsService: FleetandloandetailsService, private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.validators();
    this.installmentFreqList = [];
    // this.model.fleetdetails = [{ afdOwnerId: '', afdBorrRelation: 's', afdMake: '', afdModel: '', afdYearMfgr: '', afdRtoRegNo: '', afdFinanced: 'N', afdFinancedBy: '', afdInstallCount: '', afdInstallAmt: '', afdInstallFreq: '', afdRcAvailable: '', afdInstallPaid: '', afdRepayStatus: 's', afdInstallLiability: '', afdMarketValue: '', afdDocVerified: '', afdConsiderJcb: 'N', afdConsiderStl: 'N', afdRemarks: '' }];
    this.disableInstlFields = true;
    this.get();
  }

  onClickDeleteButton(row: any, id: any, i: any) {
    if (id == '' || id == undefined) {
      this.model.fleetdetails.splice(i, 1);

    }
    else {
      this.fleetandloandetailsService.deleteAgriFleetDetails(row)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.get();
          }
         
        },
        error => {
          // this.alertService.error(error);
        });
    }
  }

  saveFleetDetails() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.fleetdetails.length, this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      let resultFlag = this.fieldvalidation.multipleFieldValidation(this.model.fleetdetails.length, this.idvalueList);
      if (resultFlag) {

        this.fleetandloandetailsService.saveAgriFleetDetails(this.model.fleetdetails)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.get();
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }

          },
          error => {
            failedStatus();
            // this.alertService.error(error);
          });
      }
    }
  }

  addRow() {
    this.model.fleetdetails.push({ afdOwnerId: 's', afdBorrRelation: 's', afdMake: '', afdModel: '', afdYearMfgr: '', afdRtoRegNo: '', afdFinanced: 'N', afdFinancedBy: '', afdInstallCount: '', afdInstallAmt: '', afdInstallFreq: 's', afdRcAvailable: '', afdInstallPaid: '', afdRepayStatus: 's', afdInstallLiability: '', afdMarketValue: '', afdDocVerified: '', afdConsiderJcb: 'N', afdConsiderStl: 'N', afdRemarks: '' });
    var i = this.model.fleetdetails.length;
    $("#" + 'afdFinancedBy' + i).prop("disabled", true);
    $("#" + 'afdInstallCount' + i).prop("disabled", true);
    $("#" + 'afdInstallAmt' + i).prop("disabled", true);
    $("#" + 'afdInstallFreq' + i).prop("disabled", true);
    this.disableButtons(false, false, true, false, false, false);
  }

  onClickDeleteAllButton() {
    this.fleetandloandetailsService.deleteAllAgriFleetDetails(this.model.fleetdetails)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          this.ngOnInit();
        }
      
      },
      error => {
        // this.alertService.error(error);
      });
  }


  get() {
    this.installmentFreqList = [];
    this.disableButtons(true, true, false, true, true, true);
    this.fleetandloandetailsService.getAgriFleetDetails(this.model)
      .subscribe(
      data => {
        this.data = data;

        if (this.data.success == true) {
          this.disableButtons(true, true, false, true, true, true);
          this.model.fleetdetails = this.data.lpagriFleetDetList;
          this.installmentFreqList = this.data.installmentFreq;
          this.relationwithBorrwerList = this.data.relationwithBorrwerList;
          this.model.fleetdetails.forEach(element => {
            element.afdInstallAmt = this.toFixCall(element.afdInstallAmt);
            element.afdInstallLiability = this.toFixCall(element.afdInstallLiability);
            element.afdMarketValue = this.toFixCall(element.afdMarketValue);

          });
          this.borrowerType = this.data.ownerNameList;
          if (this.model.fleetdetails.length < 1) {
            this.model.fleetdetails.push({ afdOwnerId: 's', afdBorrRelation: 's', afdMake: '', afdModel: '', afdYearMfgr: '', afdRtoRegNo: '', afdFinanced: 'N', afdFinancedBy: '', afdInstallCount: '', afdInstallAmt: '', afdInstallFreq: 's', afdRcAvailable: '', afdInstallPaid: '', afdRepayStatus: 's', afdInstallLiability: '', afdMarketValue: '', afdConsiderJcb: 'N', afdDocVerified: '', afdConsiderStl: 'N', afdRemarks: '' });
            this.disableButtons(false, false, true, false, false, false);
            var i = 0;
            var financed = "N";
            this.disableInstallment(financed, i);
            // $("#" + 'afdFinancedBy' + i).prop("disabled", true);
            // $("#" + 'afdInstallCount' + i).prop("disabled", true);
            // $("#" + 'afdInstallAmt' + i).prop("disabled", true);
            // $("#" + 'afdInstallFreq' + i).prop("disabled", true);
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }
          if (this.data.pageAccess) {
            this.disableButtons(true, true, true, true, true, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
        }

      },
      error => {
        // this.alertService.error(error);
      });
  }

  onClickEditButton() {
    this.disableButtons(false, false, true, false, false, false);
    this.model.fleetdetails.forEach((element, i) => {
      this.disableInstallment(element.afdFinanced, i);
      this.disableConsiderStl(element.afdConsiderJcb, i)
    });
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }

  disableConsiderStl(value: any, i: number) {
    if (value == "N") {
      $("#" + 'afdConsiderStl' + i).prop("disabled", true);
      $("#" + 'afdConsiderStl1' + i).prop("disabled", true);
      this.model.fleetdetails[i].afdConsiderStl = "N";
    }
    else {
      $("#" + 'afdConsiderStl' + i).prop("disabled", false);
      $("#" + 'afdConsiderStl1' + i).prop("disabled", false);

    }
  }
  disableInstallment(value: any, i: number) {

    if (value == "N") {
      $("#" + 'afdFinancedBy' + i).prop("disabled", true);
      $("#" + 'afdInstallCount' + i).prop("disabled", true);
      $("#" + 'afdInstallAmt' + i).prop("disabled", true);
      $("#" + 'afdInstallFreq' + i).prop("disabled", true);
    }
    else {
      $("#" + 'afdFinancedBy' + i).prop("disabled", false);
      $("#" + 'afdInstallCount' + i).prop("disabled", false);
      $("#" + 'afdInstallAmt' + i).prop("disabled", false);
      $("#" + 'afdInstallFreq' + i).prop("disabled", false);
    }


  }
  disableButtons(field: boolean, add: boolean, edit: boolean, save: boolean, deleteAll: boolean, cancel: boolean) {
    this.disableFields = field;
    this.disableNewButton = add;
    this.disableEditButton = edit;
    this.disableSaveButton = save;
    this.disableCancelButton = cancel;
    this.disableDeleteAllButton = deleteAll;
  }
}
