import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgridroplinedetailsComponent } from './agridroplinedetails.component';

describe('AgridroplinedetailsComponent', () => {
  let component: AgridroplinedetailsComponent;
  let fixture: ComponentFixture<AgridroplinedetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgridroplinedetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgridroplinedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
