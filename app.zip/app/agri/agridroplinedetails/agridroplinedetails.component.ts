import { Component, OnInit, ViewChild } from '@angular/core';
import { AgridroplinedetailsService } from "../../util/service/agriservices/agridroplinedetails.service";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Validator } from '../../util/helper/validator';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
declare var callEditorbyId: any;
@Component({
  selector: 'lp-agridroplinedetails',
  templateUrl: './agridroplinedetails.component.html',
  styleUrls: ['./agridroplinedetails.component.css']
})
export class AgridroplinedetailsComponent extends Validator implements OnInit {
  data: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;


  constructor(private agridroplinedetailsService: AgridroplinedetailsService, private fieldvalidation: Fieldvalidation, private changenoteService: ChangenoteService,
  ) {
    super();
    this.minDate = new Date(1899, 12, 1);
    this.minDate.setDate(this.minDate.getDate());
    // this.maxDate = new Date();
    // this.maxDate.setDate(this.maxDate.getDate());
  }

  FacilityList: any = [];
  FacilityTypeList: any = [];
  lpagriDropLineODDetails: any = [];
  pageAccess: any;
  ApproveFlowFlag: boolean;
  editDisabled: boolean;
  saveDisabled: boolean;
  cancelDisabled: boolean;
  fieldDisable: boolean;
  undoFlag: boolean;
  undodropFlag: boolean;
  idvalueList = ['ldFrequency', 'ldDropamt', 'ldLimitDate'];
  model: any = {};
  editorFlag = true;
  flag: any;
  comments: any;
  undocomment: boolean;
  dropCmt: boolean;
  cmtHistory: boolean;
  commentList: any;
  approve: boolean;
  viewDisabled: boolean;
  editCmt: boolean;
  saveCmt: boolean;
  closeCmt: boolean;
  minDate: Date;
  maxDate: Date;
  dropScheduleList: any = [];
  tempField: any = [];
  finalclsBalance: any;
  modelForChngNote: any;

  ngOnInit() {
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.ApproveFlowFlag = true;
    this.fieldDisable = true;
    this.undoFlag = true;
    this.undodropFlag = true;
    this.undocomment = true;
    this.dropCmt = true;
    this.cmtHistory = true;
    this.approve = false;
    this.viewDisabled = true;
    this.model.ldcExistTerms = '';
    $("#existingCondn").val('');
    $('#repaySchedule').modal('hide');
    $('#repaySchedule').hide();
    this.agridroplinedetailsService.getAgriDropLineODDetails()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.FacilityList = this.data.responseData.FacilityList;
          this.FacilityTypeList = this.data.responseData.FacilityTypeList;
          this.lpagriDropLineODDetails = this.data.responseData.lpagriDropLineODDetails;
          var i = 0;

          if (this.lpagriDropLineODDetails.length == 0) {
            this.lpagriDropLineODDetails.push({
              ldRowId: 0, lpcomProposal: 0, ldCreatedBy: null, ldCreatedOn: null, ldModifiedBy: null, ldModifiedOn: null, ldCustid: 0,
              ldDlodid: 0, ldDlodamt: 0, ldTenor: 0, ldFrequency: null, ldDropamt: 0, ldApprovedby: null, ldApprovedon: null, ldLimitDate: null
            });
          }
          this.FacilityList.forEach(element => {
            this.FacilityList[i].Type = this.FacilityTypeList[i].Type;
            this.FacilityList[i].BorrowerName = this.FacilityTypeList[i].BorrowerName;
            this.FacilityList[i].ldCustid = this.FacilityTypeList[i].ldCustid;
            this.FacilityList[i].ldFrequency = "s";
            this.FacilityList[i].ldDropamt = "";
            this.FacilityList[i].ldFacno = this.FacilityTypeList[i].lfFacNo;
            this.FacilityList[i].lfFacLevel = this.FacilityTypeList[i].lfFacLevel;
            i++;
          });

          //   Remove Loan Type
          for (var h = 0; h < this.FacilityList.length; h++) {
            if (this.FacilityList[h].ldDlodid <= 4) {
              this.FacilityList.splice(h, 1);
              h--;
            }

          }

          for (var j = 0; j < this.FacilityList.length; j++) {
            for (var k = j + 1; k < this.FacilityList.length; k++) {
              if (this.FacilityList[j].ldCustid == this.FacilityList[k].ldCustid && this.FacilityList[j].ldDlodid == this.FacilityList[k].ldDlodid) {
                this.FacilityList[j].ldDlodamt = this.FacilityList[j].ldDlodamt + this.FacilityList[k].ldDlodamt;
                if (this.FacilityList[j].ldTenor < this.FacilityList[k].ldTenor) {
                  this.FacilityList[j].ldTenor = this.FacilityList[k].ldTenor;
                  this.FacilityList[j].ldDlodid = this.FacilityList[j].ldDlodid;
                }
                this.FacilityList.splice(k, 1);
                k--;
              }
            }
          }

          for (var m = 0; m < this.FacilityList.length; m++) {
            this.lpagriDropLineODDetails.forEach((element, index) => {
              if (element.ldTenor == this.FacilityList[m].ldTenor && element.ldCustid == this.FacilityList[m].ldCustid && element.ldDlodid == this.FacilityList[m].ldDlodid) {
                this.FacilityList[m].ldFrequency = element.ldFrequency;
                this.FacilityList[m].ldDropamt = element.ldDropamt;
                this.FacilityList[m].ldRowId = element.ldRowId;
                this.FacilityList[m].ldCreatedBy = element.ldCreatedBy;
                this.FacilityList[m].ldCreatedOn = element.ldCreatedOn;
                this.FacilityList[m].ldApprovedby = element.ldApprovedby;
                this.FacilityList[m].ldApprovedon = element.ldApprovedon;
                if (element.ldLimitDate != "" && element.ldLimitDate != undefined && element.ldDlodid == this.FacilityList[m].ldDlodid) {
                  var quotedate = element.ldLimitDate;
                  var matudate = quotedate.split("-");
                  this.FacilityList[m].ldLimitDate = matudate[2] + '/' + matudate[1] + '/' + matudate[0];
                }
                else
                  this.FacilityList[m].ldLimitDate = "";
                if (element.ldApprovedby != null && element.ldApprovedby != "") {
                  this.undoFlag = false;
                }
              }
            });
          }


          this.agridroplinedetailsService.getApproveFlag()
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.pageAccess = this.data.pageAccess;
                this.ApproveFlowFlag = this.data.responseData.ApproveFlowFlag;
                this.comments = this.data.comments;
                this.commentList = this.data.commentList;
                if (this.comments != null) {
                  this.model = this.comments;
                }
                if (this.ApproveFlowFlag) {
                  this.disableButton(true, true, false, true);
                  this.undoFlag = true;
                }
                else {
                  if (this.pageAccess == "R") {
                    this.ApproveFlowFlag = true;
                    this.disableButton(true, true, true, true);
                    this.undoFlag = true;
                    this.viewDisabled = true;
                  }
                  else {

                    this.disableButton(true, true, false, true);
                    if (this.undoFlag == false) {
                      this.undodropFlag = false;
                      this.ApproveFlowFlag = true;
                      this.undocomment = false;

                      this.dropCmt = false;
                      if (this.commentList.length > 0) {
                        this.viewDisabled = false;
                        this.refreshPage();
                      }

                    }
                    if (!this.ApproveFlowFlag) {

                      this.dropCmt = false;
                      if (this.commentList.length > 0) {
                        this.viewDisabled = false;
                        this.refreshPage();
                      }

                    }
                  }
                }
              }
              if (this.FacilityList.length == 0)
                this.disableButton(true, true, true, true);
              if (this.modelForChngNote.changeMode == "Y") {
                this.changenoteComponent.onload(this.pageAccess);
              }
            },
            error => {
            });

        }
      });
  }

  CalculateDropAmt(index) {
    if (this.FacilityList[index].ldDropamt != "") {
      if (parseFloat(this.FacilityList[index].ldDlodamt) < parseFloat(this.FacilityList[index].ldDropamt)) {
        alert("DropAmount should be Greater than Total Amount");
        this.FacilityList[index].ldDropamt = "";
      }
    }
  }


  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean) {
    if (this.pageAccess == 'R') {
      this.fieldDisable = true;
      this.saveDisabled = true;
      this.editDisabled = true;
      this.cancelDisabled = true;
    } else {
      this.fieldDisable = fieldDisable;
      this.saveDisabled = savebuttonDisable;
      this.editDisabled = editbuttonDisable;
      this.cancelDisabled = cancelbuttonDisable;
    }
  }

  editdroplinedetails() {
    this.disableButton(false, false, true, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  savedroplinedetails() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }

    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      this.flag = true;
      this.flag = this.fieldvalidation.multipleFieldValidation(this.FacilityList.length, this.idvalueList);
      if (this.flag) {

        this.FacilityList.forEach(element => {
          element.ldLimitDate = this.fieldvalidation.dPDateConversionFromIndianStd(element.ldLimitDate);
        });


        this.agridroplinedetailsService.saveDropLineODDetails(this.FacilityList, this.model)
          .subscribe(
          data => {
            this.data = data;
            progressStatus()
            if (this.data.success == true) {
              successStatus()
              this.ngOnInit();
            }
            else {
              failedStatus()
            }
          });
      }
    }
  }

  approvedropline() {
    var h = 0;
    this.FacilityList.forEach(element => {
      this.FacilityList[h].approve = "";
      h++;
    });
    // this.disableButton(true, true, false, true);
    this.undoFlag = true;
    $('#Comments').modal('show');
    this.commentsOnInit();

    // this.savedroplinedetails();
  }

  canceldroplinedetails() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

  undodropline() {
    $('#Comments').modal('show');
    this.commentsOnInit();
  }
  undosave() {
    if (this.undodropFlag) {

      this.agridroplinedetailsService.undodroplineODDetails(this.FacilityList, this.model)
        .subscribe(
        data => {
          this.data = data;
          progressStatus()
          if (this.data.success == true) {
            successStatus()
            this.ngOnInit();
            this.disableCommentBtn(false, true, true);
          }
          else {
            failedStatus()
          }
        });
    }
  }
  commentsOnInit() {
    this.fieldDisable = true;
    if (this.editorFlag) {
      this.editorFlag = false;
      callEditorbyId('existingCondn');
    }
    $("#existingCondn").Editor("setEnable", false);
    // this.disableComments(true);
    this.model = { 'ldcExistTerms': "" }

    $("#existingCondn").Editor("setText", this.model.ldcExistTerms);
    for (var i = 0; i < this.idvalueList.length; i++) {
      $('#' + this.idvalueList[i]).removeClass("has-error");
      $('#' + this.idvalueList[i]).attr('placeholder', ' ');
    }
    this.disableCommentBtn(false, true, true);
  }
  disableComments(fieldDisable: boolean) {
    this.fieldDisable = fieldDisable;
    $("#existingCondn").Editor("setEnable", !this.fieldDisable);
  }
  onEdit(fieldDisable) {
    this.disableComments(fieldDisable);
  }

  refreshPage() {
    this.fieldDisable = true;
    this.disableComments(true);
    $("#existingCondn").Editor("setEnable", false);
    if (this.model == null) {
      this.model = { 'ldcExistTerms': "" }
    }
    else
      $("#existingCondn").Editor("setText", this.model.ldcExistTerms);
    for (var i = 0; i < this.idvalueList.length; i++) {
      $('#' + this.idvalueList[i]).removeClass("has-error");
      $('#' + this.idvalueList[i]).attr('placeholder', ' ');
    }
  }
  viewComments() {

    $('#cmtHistory').modal('show');
  }

  closeComments() {
    $('#Comments').modal('hide');
    this.ngOnInit();
  }
  closeCmtHistory() {
    $('#cmtHistory').modal('hide');
    this.ngOnInit();
  }
  saveComments() {
    this.model.ldcExistTerms = $("#existingCondn").Editor("getText");
    if (this.model.ldcExistTerms != '' && this.model.ldcExistTerms != null && this.model.ldcExistTerms != undefined) {
      this.approve = true;
    }
    else {
      this.approve = false;
    }
    if (this.approve) {
      if (!this.undoFlag) {
        this.undodropFlag = true;
        this.undosave();
      }
      else {
        this.agridroplinedetailsService.saveDropLineODDetails(this.FacilityList, this.model)

          .subscribe(
          data => {
            this.data = data;
            progressStatus()
            if (this.data.success == true) {
              successStatus()
              this.ngOnInit();
              this.disableCommentBtn(false, true, true);

            }
            else {
              failedStatus()
            }
          });
      }
    }
  }
  disableCommentBtn(editbuttonDisable: boolean, savebuttonDisable: boolean, closebuttonDisable: boolean) {

    this.saveCmt = savebuttonDisable;
    this.editCmt = editbuttonDisable;
    this.closeCmt = closebuttonDisable;
  }
  editComment() {
    this.disableCommentBtn(true, false, false);
    if (this.ApproveFlowFlag || this.undoFlag) {
      this.onEdit(false);
    }
    else
      this.onEdit(false);
  }

  validatefuturedate(event) {
    if (event != null && event != "") {
      this.fieldvalidation.validatefuturedate(event.target.id);
    }
  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }


  allowFutureDate(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }

  calculateDropSchedule(val) {
    $('#drop').hide();

    this.dropScheduleList = [];
    var monthCheck;
    this.finalclsBalance = val.ldDlodamt;
    if (val.ldFrequency != "s" && val.ldFrequency != "N") {
      //Annual Installment Calculation 
      //Yearly

      if (val.ldFrequency == "Y") {
        var tenor = val.ldTenor / 12;
        monthCheck = 12;
        if (tenor % 12 > 0) {
          tenor += 1;
        }
      }
      //halfyearly
      else if (val.ldFrequency == "H") {
        var tenor = val.ldTenor / 6;
        monthCheck = 6;
        if (tenor % 6 > 0) {
          tenor += 1;
        }
      }
      //quarterly
      else if (val.ldFrequency == "Q") {
        var tenor = val.ldTenor / 3;
        monthCheck = 3;
        if (tenor % 3 > 0) {
          tenor += 1;
        }
      }
      //Monthly
      if (val.ldFrequency == "M") {
        var clsBal = parseFloat(this.finalclsBalance) - parseFloat(val.ldDropamt);
        this.dropScheduleList.push({
          limitDate: val.ldLimitDate, dropAmt: val.ldDropamt,
          clsBalance: clsBal

        });
        var quotedate = val.ldLimitDate;
        var matudate = quotedate.split("/");
        this.dropScheduleList[0].limitDate = matudate[2] + '-' + matudate[1] + '-' + matudate[0];

        let initialDue = new Date(this.dropScheduleList[0].limitDate);
        for (let i = 0; i < val.ldTenor - 1; i++) {
          let validDayFlag = false;
          var length = this.dropScheduleList.length;
          var prevClsBal = this.dropScheduleList[length - 1].clsBalance;
          var initDropAmt = this.dropScheduleList[0].dropAmt;
          let firstlimitDate = new Date(this.dropScheduleList[length - 1].limitDate);

          let year = firstlimitDate.getFullYear();
          let month = firstlimitDate.getMonth();
          let day = firstlimitDate.getDate();
          //leap year validation
          let validate = new Date(year, month + 2, 0).getDate();
          let finaldate;
          if (day <= validate && !(validDayFlag)) {
            if (initialDue.getDate() != day) {
              finaldate = initialDue.getDate();
            }
            else {
              finaldate = day;
            }

            validDayFlag = false;
          }
          else {
            finaldate = validate;
            validDayFlag = true;
          }
          ///
          var clsBal = parseFloat(prevClsBal) - parseFloat(initDropAmt);
          var minclsBal = false;
          if (clsBal <= initDropAmt) {

            if (clsBal < 0) {
              clsBal = 0.00;
              initDropAmt = prevClsBal;
              minclsBal = true;
            }
          }
          var lengthtenor = val.ldTenor - 2;
          if (i == Math.round(lengthtenor) && (clsBal >= initDropAmt || clsBal <= initDropAmt)) {
            clsBal = 0.00;
            initDropAmt = prevClsBal;
            minclsBal = true;
          }
          if (prevClsBal == 0)
            break;
          this.dropScheduleList.push({
            limitDate: new Date(year, ++month, finaldate), dropAmt: parseFloat(initDropAmt).toFixed(2),
            clsBalance: clsBal.toFixed(2)
          });
          if (minclsBal) {
            break;
          }
        }

      }
      else if (val.ldFrequency != "s" || val.ldFrequency != "N") {
        var clsBal = parseFloat(this.finalclsBalance) - parseFloat(val.ldDropamt);
        this.dropScheduleList.push({
          limitDate: val.ldLimitDate, dropAmt: parseFloat(val.ldDropamt).toFixed(2),
          clsBalance: clsBal.toFixed(2)

        });
        var quotedate = val.ldLimitDate;
        var matudate = quotedate.split("/");
        this.dropScheduleList[0].limitDate = matudate[2] + '-' + matudate[1] + '-' + matudate[0];

        let initialDue = new Date(this.dropScheduleList[0].limitDate);
        for (let i = 0; i < tenor - 1; i++) {
          let validDayFlag = false;
          var length = this.dropScheduleList.length;
          var prevClsBal = this.dropScheduleList[length - 1].clsBalance;
          var initDropAmt = this.dropScheduleList[0].dropAmt;
          // var prevDropAmt=parseFloat(val.ldDropamt) * tenor;
          let firstlimitDate = new Date(this.dropScheduleList[length - 1].limitDate);
          let year = firstlimitDate.getFullYear();
          let month = firstlimitDate.getMonth();
          let day = firstlimitDate.getDate();
          //leap year validation
          let validate = new Date(year, month + monthCheck + 1, 0).getDate();
          let finaldate;
          if (day <= validate && !(validDayFlag)) {
            if (initialDue.getDate() != day) {
              if (validate == 30)
                finaldate = validate;
              else
                finaldate = initialDue.getDate();
            }
            else {
              finaldate = day;
            }

            validDayFlag = false;
          }
          else {
            finaldate = validate;
            validDayFlag = true;
          }
          ///
          var clsBal = parseFloat(prevClsBal) - parseFloat(initDropAmt);
          var minclsBal = false;
          if (clsBal <= initDropAmt) {

            if (clsBal < 0) {
              clsBal = 0.00;
              initDropAmt = prevClsBal;
              minclsBal = true;
            }
          }
          var lengthTenor = tenor - 2;
          if (i == Math.round(lengthTenor) && (clsBal >= initDropAmt || clsBal <= initDropAmt)) {
            clsBal = 0.00;
            initDropAmt = prevClsBal;
            minclsBal = true;
          }

          if (prevClsBal == 0)
            break;
          this.dropScheduleList.push({
            limitDate: new Date(year, monthCheck + month, finaldate), dropAmt: parseFloat(initDropAmt).toFixed(2),
            clsBalance: clsBal.toFixed(2)
          });

          if (minclsBal) {
            break;
          }
        }
      }
      else {
        this.dropScheduleList = [];
      }

      $('#drop').show();
    }
  }
}
