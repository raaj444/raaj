import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepayscheduleComponent } from './repayschedule.component';

describe('RepayscheduleComponent', () => {
  let component: RepayscheduleComponent;
  let fixture: ComponentFixture<RepayscheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepayscheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepayscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
