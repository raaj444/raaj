import { Component, OnInit } from '@angular/core';
import { AgridroplineodService } from '../../util/service/agriservices/agridroplineod.service';
declare var $: any;
@Component({
  selector: 'lp-repayschedule',
  templateUrl: './repayschedule.component.html',
  styleUrls: ['./repayschedule.component.css']
})
export class RepayscheduleComponent  implements OnInit {   data:any; 
  constructor(private agridroplineodService: AgridroplineodService) { }

  model: any = {};
  FacilityTypeList: any = [];
  repayScheduleList: any = [];
  otherRepayScheduleList: any = [];
  ngOnInit() {
    
    $('#Monthly').hide();
    $('#Others').hide();
    this.model = this.agridroplineodService.getRepaySchedule();

  }
  getRepaymentSchedule() {
    $('#Monthly').hide();
    $('#Others').hide();
    this.model = this.agridroplineodService.getRepaySchedule();
    this.agridroplineodService.viewRepayChart(this.model)
      .subscribe(
      data => { this.data=data;
        let flag = false;
        if (this.data.success) {
          this.FacilityTypeList = this.data.responseData.FacilityTypeList;
          this.repayScheduleList = [];
          this.otherRepayScheduleList = [];
          if (this.data.recommendation) {
            alert("Please Save the Recommendation Page")
          }
          else if (this.data.busApproval) {
            alert("Please complete the Business Approval")
          }
          else
            this.calculateLoanLiabilityList();
        }
      });
  }
  calculateLoanLiabilityList() {
    $('#Monthly').hide();
    $('#Others').hide();
    this.FacilityTypeList.forEach(fcList => {
      
      this.repayScheduleList = [];
      this.otherRepayScheduleList = [];
      //Annual Installment Calculation 
      //Yearly
  
      if (fcList.repayFreq == "4") {
        var tenor = fcList.tenor / 12;
        if (tenor % 12 > 0) {
          tenor += 1;
        }
      }
      //halfyearly
      else if (fcList.repayFreq == "3") {
        var tenor = fcList.tenor / 6;
        if (tenor % 6 > 0) {
          tenor += 1;
        }
      }
      //quarterly
      else if (fcList.repayFreq == "2") {
        var tenor = fcList.tenor / 3;
        if (tenor % 3 > 0) {
          tenor += 1;
        }
      }
      //Monthly
      if (fcList.repayFreq == "1") {
        var monthlyInterestRatio = (fcList.intrate / 100) / 12;
        var top = Math.pow((1 + monthlyInterestRatio), fcList.tenor);
        var bottom = top - 1;
        var emi = ((fcList.proposalLimit * monthlyInterestRatio * top) / bottom);
        var Principal = emi - (fcList.proposalLimit * monthlyInterestRatio);
        var Interest = (fcList.proposalLimit * monthlyInterestRatio);
        var TotInterest = Interest;
        Principal = (emi - Interest);
        var TotPrincipal = Principal;
        var ActualAmtDue = fcList.proposalLimit - Principal;
        var TotaltempEMI = emi * monthlyInterestRatio;
        this.repayScheduleList.push({
          loanAmt: fcList.proposalLimit.toFixed(2), interest: Interest.toFixed(2), princAmt: Principal.toFixed(2), Emi: emi.toFixed(2),
          actualAmt: ActualAmtDue.toFixed(2), dueDate: fcList.firstDue
        });

        let initialDue = new Date(this.repayScheduleList[0].dueDate);
        for (let i = 0; i < fcList.tenor - 1; i++) {
          let validDayFlag = false;
          var length = this.repayScheduleList.length;
          var prevActAmt = this.repayScheduleList[length - 1].actualAmt;
          let firstDueDate = new Date(this.repayScheduleList[length - 1].dueDate);

          let year = firstDueDate.getFullYear();
          let month = firstDueDate.getMonth();
          let day = firstDueDate.getDate();
          //leap year validation
          let validate = new Date(year, month + 2, 0).getDate();
          let finaldate;
          if (day <= validate && !(validDayFlag)) {
            if (initialDue.getDate() != day) {
              finaldate = initialDue.getDate();
            }
            else {
              finaldate = day;
            }

            validDayFlag = false;
          }
          else {
            finaldate = validate;
            validDayFlag = true;
          }
          ///
          Interest = prevActAmt * monthlyInterestRatio;
          TotInterest = TotInterest + Interest;
          Principal = (emi - Interest);
          TotPrincipal = TotPrincipal + Principal;
          var tempActualAmtDue = prevActAmt - Principal;
          if (tempActualAmtDue < 0)
            tempActualAmtDue = 0.0;
          this.repayScheduleList.push({
            loanAmt: prevActAmt, interest: Interest.toFixed(2), princAmt: Principal.toFixed(2), Emi: emi.toFixed(2),
            actualAmt: tempActualAmtDue.toFixed(2), dueDate: new Date(year, ++month, finaldate)
          });

        }
        $('#Monthly').show();
      }
      else if (fcList.repayFreq != "0") {
        var emi = fcList.proposalLimit / tenor;
        var ActualAmtDue = fcList.proposalLimit - emi;
        this.otherRepayScheduleList.push({
          loanAmt: fcList.proposalLimit.toFixed(2), Emi: emi.toFixed(2), actualAmt: ActualAmtDue.toFixed(2)
        });
        for (let i = 0; i < tenor - 1; i++) {
          var length = this.otherRepayScheduleList.length;
          var prevActAmt = this.otherRepayScheduleList[length - 1].actualAmt;
          var ActualAmtDue = prevActAmt - emi;
          if (prevActAmt <= emi) {
            emi = parseFloat(prevActAmt);
            if (emi < 0)
              emi = 0.00;
          }
          this.otherRepayScheduleList.push({
            loanAmt: prevActAmt, Emi: emi.toFixed(2), actualAmt: ActualAmtDue.toFixed(2)
          });
        }
        $('#Others').show();
      }
    });
  }
}
