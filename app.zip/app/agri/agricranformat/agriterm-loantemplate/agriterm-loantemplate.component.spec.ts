import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgritermLoantemplateComponent } from './agriterm-loantemplate.component';

describe('AgritermLoantemplateComponent', () => {
  let component: AgritermLoantemplateComponent;
  let fixture: ComponentFixture<AgritermLoantemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgritermLoantemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgritermLoantemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
