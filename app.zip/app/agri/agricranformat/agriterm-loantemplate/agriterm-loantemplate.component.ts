import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';


@Component({
  selector: 'lp-agriterm-loantemplate',
  templateUrl: './agriterm-loantemplate.component.html',
  styleUrls: ['./agriterm-loantemplate.component.css']
})
export class AgritermLoantemplateComponent  implements OnInit {   data:any; 
  hidView1: boolean;
  hidView: boolean;
  model: any = {};
  kkrPremium: any = {};
  componentlist: any = [];
  reqDueDataList: any = [];
  borrowerType: any = [];
  private AgritermloanList: Array<any> = [];
  private facilityDetailsList: Array<any> = [];
  listOfValuesList = [];
  tempagritermloanList: Array<any> = [];
  kkrview: boolean = false;
  strProposedLimit: any = 0.00;
  totalAmount: any = 0.00;
  kkrPremiumAmount: any = 0.00;
  exposureAmount: any = 0.00;
  totalexposureAmount: any = 0.00;
  strTotalLimit: any = 0.00;
  strExistTotal: any = 0.00;
  totalExposureSanLimit: any = 0.00;
  totalExposureCrdRec: any = 0.00;
  totalExposureSalRec: any = 0.00;
  totalExposureProp: any;
  relationwithbor=[];
  RelationwithBorrowerkkr=[];
  finalAmt: any =0.00;
  strSalRecmdAmount: String; strCrdRecmdAmount: String; strSancLimit: String;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {

    this.kkrview = false;
    this.hidView=false;
    this.kkrPremium.lkpPremAmount = 0.00;
    this.finalAmt=0.00;
    this.componentlist = [
      {
        name: 'AgritermLoantemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.model.facilityDetailsList = this.data.responseData.FacilityList;
          this.model.exposures = this.data.exposures;
          this.exposureAmount = this.data.lpcomExposureAmount;
          this.listOfValuesList = this.data.lpmasListofvalueList;
          this.relationwithbor = this.data.relationwithbor;
          this.RelationwithBorrowerkkr = this.data.RelationwithBorrowerkkr;
          this.finalAmt=this.data.finalATLAmt;
          
          if (this.data.Agri) {
            this.model.AgritermloanList = this.data.responseData.AgritermloanList;
            if (this.model.AgritermloanList.length > 0) {
              this.hidView=true;
              this.model.AgritermloanList.forEach(element => {
                this.listOfValuesList.forEach(reqFrq => {
                  if (reqFrq.llvOptionVal == element.lcaRepayfreq) {
                    element.lcaRepayfreq = reqFrq.llvOptionDesc;
                  }
                });
                if (element.lcaQuotedate != "" && element.lcaQuotedate != undefined) {
                  var quotedate = element.lcaQuotedate;
                  var matudate = quotedate.split("-");
                  element.lcaQuotedate = matudate[2] + '/' + matudate[1] + '/' + matudate[0];
                }
                if (element.lcaFirstinstalldue != "" && element.lcaFirstinstalldue != undefined) {
                  var duedate = element.lcaFirstinstalldue;
                  var datearray = duedate.split("-");
                  element.lcaFirstinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                }
                if (element.lcaLastinstalldue != "" && element.lcaLastinstalldue != undefined) {
                  var lastduedate = element.lcaLastinstalldue;
                  var datearray = lastduedate.split("-");
                  element.lcaLastinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                }
                this.model.facilityDetailsList.forEach(facility => {
                  if (element.lcaFacno == facility.lfFacNo) {
                    element.facName = facility.facName;
                    element.lfProposedLimit = facility.lfProposedLimit;
                  }
                });
              });
            }
          }
          if(this.data.responseDataKKR !=null){
            this.hidView1=false;
          this.kkrPremium = this.data.responseDataKKR;}
          this.borrowerType = this.data.lpcomCustInfoApplist;
          if (this.kkrPremium == undefined || this.kkrPremium == "" || this.kkrPremium == null) {
            this.kkrview = false;
            this.kkrPremium = { 'lkpNomineeName': "", 'lkpKkrPremType': "", 'lkpRelOfNominee': "", 'lkpFacAvail': "", 'lkpRelWithBorrower': "" ,'lkpInsuredPerson':""};
          }
          else {
            this.kkrview = true;
            this.kkrPremium.lkpDob = this.data.lkpDob;

            this.borrowerType.forEach(element => {
              if (element.custId == this.kkrPremium.lkpInsuredPerson)
                this.kkrPremium.lkpInsuredPerson = element.custName;
              if (element.custId == this.kkrPremium.lkpNomineeName)
                this.kkrPremium.lkpNomineeName = element.custName;
                
            });
            var lkpRelOfNominee=this.kkrPremium.lkpRelOfNominee;
            var lkpRelWithBorrower=this.kkrPremium.lkpRelWithBorrower;
            this.relationwithbor.forEach(bor => {
              if(bor.llvOptionVal==lkpRelOfNominee)
              {
                this.kkrPremium.lkpRelOfNominee=bor.llvOptionDesc;
              }
             
            });
            this.RelationwithBorrowerkkr.forEach(kkrrel=>{
              if(kkrrel.llvOptionVal==lkpRelWithBorrower)
              {
                this.kkrPremium.lkpRelWithBorrower=kkrrel.llvOptionDesc;
              }
            });
          }


          let totalLimit = 0; let vartotallimit = 0;
          let varexistTotal = 0; let varProposedLimit = 0;
          // this.model.exposures.forEach(field1 => {
          //   field1.totalLimit = parseInt(field1.lfExistLimit) + parseInt(field1.lfProposedLimit);
          //   vartotallimit = vartotallimit + parseInt(field1.totalLimit);
          //   varexistTotal = varexistTotal + parseInt(field1.lfExistLimit);
          //   field1.totalLimit = field1.totalLimit.toFixed(2);
          //   if (field1.lfExistLimit != 0)
          //     field1.lfExistLimit = field1.lfExistLimit.toFixed(2);
          //   if (field1.lfProposedLimit != null && field1.lfProposedLimit !== "")
          //     varProposedLimit = varProposedLimit + parseInt(field1.lfProposedLimit);
          //   else
          //     varProposedLimit = varProposedLimit + 0;

          //   field1.lfProposedLimit = field1.lfProposedLimit.toFixed(2);

          // });

          //  varProposedLimit = varProposedLimit + parseFloat(this.kkrPremium.lkpPremAmount);
          //   if (varProposedLimit != 0)
          //     this.strProposedLimit = varProposedLimit.toFixed(2);
          //   else
          //     this.strProposedLimit = "";

          //   this.totalExposure = parseFloat(this.exposureAmount) + varProposedLimit;
          //   if (varProposedLimit != 0)
          //     this.strProposedLimit = varProposedLimit.toFixed(2);
          //   this.totalAmount = vartotallimit + parseFloat(this.kkrPremium.lkpPremAmount);
          //   this.totalexposureAmount = parseFloat(this.exposureAmount) + this.totalAmount;
          //   this.totalAmount = this.totalAmount.toFixed(2);
          //   this.strExistTotal = varexistTotal.toFixed(2);
          //   this.totalExposure = this.totalExposure.toFixed(2);
          //   this.totalexposureAmount = this.totalexposureAmount.toFixed(2);
          //   this.kkrPremium.lkpPremAmount = this.kkrPremium.lkpPremAmount.toFixed(2);
          //   this.exposureAmount = this.exposureAmount.toFixed(2);


          this.getTotal('S', 'C', 'SL');
          if (this.kkrPremiumAmount != undefined && this.kkrPremiumAmount != null)
            this.kkrPremiumAmount = this.kkrPremiumAmount.toFixed(2);
          if (this.exposureAmount != undefined && this.exposureAmount != null)
            this.exposureAmount = this.exposureAmount.toFixed(2);
        }
      });

  }
  getTotal(valSal: any, valCrd: any, valSanc: any) {
    let varSalTotal = 0; let varCrdTotal = 0; let varSancTotal = 0; let totalLimit = 0; let vartotallimit = 0;
    let varexistTotal = 0; let varProposedLimit = 0;
    this.model.exposures.forEach(field1 => {

      field1.totalLimit = this.parseEmptytoFloat(field1.lfExistLimit) + this.parseEmptytoFloat(field1.lfProposedLimit);
      vartotallimit = vartotallimit + this.parseEmptytoFloat(field1.totalLimit);
      varexistTotal = varexistTotal + this.parseEmptytoFloat(field1.lfExistLimit);
      field1.totalLimit = this.parseEmptytoFloat(field1.totalLimit).toFixed(2);
      if (field1.lfExistLimit != 0)
        field1.lfExistLimit = this.parseEmptytoFloat(field1.lfExistLimit).toFixed(2);

      if (field1.lfProposedLimit != null && field1.lfProposedLimit !== "")
        varProposedLimit = varProposedLimit + this.parseEmptytoFloat(field1.lfProposedLimit);
      else
        varProposedLimit = varProposedLimit + 0;
      if (field1.lfSalesRecmd != null && field1.lfSalesRecmd !== "")
        varSalTotal = varSalTotal + this.parseEmptytoFloat(field1.lfSalesRecmd);
      else
        varSalTotal = varSalTotal + 0;
      if (field1.lfCreditRecmd != null && field1.lfCreditRecmd !== "")
        varCrdTotal = varCrdTotal + this.parseEmptytoFloat(field1.lfCreditRecmd);
      else
        varCrdTotal = varCrdTotal + 0;
      if (field1.lfSancLimit != null && field1.lfSancLimit !== "") {
        if (field1.lfRecmd == 'Y')
          varSancTotal = varSancTotal + this.parseEmptytoFloat(field1.lfSancLimit);
      }
      else
        varSancTotal = varSancTotal + 0;
    });


    varSalTotal = varSalTotal + this.parseEmptytoFloat(this.kkrPremiumAmount);
    varCrdTotal = varCrdTotal + this.parseEmptytoFloat(this.kkrPremiumAmount);
    varSancTotal = varSancTotal + this.parseEmptytoFloat(this.kkrPremiumAmount);
    varProposedLimit = varProposedLimit + this.parseEmptytoFloat(this.kkrPremiumAmount);


    this.totalExposureProp = this.parseEmptytoFloat(this.exposureAmount) + varProposedLimit;
    this.totalExposureCrdRec = this.parseEmptytoFloat(this.exposureAmount) + varCrdTotal;
    this.totalExposureSalRec = this.parseEmptytoFloat(this.exposureAmount) + varSalTotal;
    this.totalExposureSanLimit = this.parseEmptytoFloat(this.exposureAmount) + varSancTotal;

    if (varProposedLimit != 0.00)
      this.strProposedLimit = varProposedLimit.toFixed(2);
    this.totalAmount = vartotallimit + this.parseEmptytoFloat(this.kkrPremiumAmount);
    this.totalexposureAmount = this.parseEmptytoFloat(this.exposureAmount) + this.totalAmount;
    this.totalAmount = this.totalAmount.toFixed(2);
    this.strExistTotal = varexistTotal.toFixed(2);
    this.totalExposureProp = this.parseEmptytoFloat(this.totalExposureProp).toFixed(2);
    this.totalExposureCrdRec = this.parseEmptytoFloat(this.totalExposureCrdRec).toFixed(2);
    this.totalExposureSalRec = this.parseEmptytoFloat(this.totalExposureSalRec).toFixed(2);
    this.totalExposureSanLimit = this.parseEmptytoFloat(this.totalExposureSanLimit).toFixed(2);
    this.totalexposureAmount = this.parseEmptytoFloat(this.totalexposureAmount).toFixed(2);


    if (valSal == 'S') {
      if (varSalTotal != 0.00)
        this.strSalRecmdAmount = varSalTotal.toFixed(2);
      else
        this.strSalRecmdAmount = "";
    }
    if (valCrd == 'C') {
      if (varCrdTotal != 0.00)
        this.strCrdRecmdAmount = varCrdTotal.toFixed(2);
      else
        this.strCrdRecmdAmount = "";
    }
    if (valSanc == 'SL') {
      if (varSancTotal != 0.00)
        this.strSancLimit = varSancTotal.toFixed(2);
      else
        this.strSancLimit = "";
    }

    if (varProposedLimit != 0.00)
      this.strProposedLimit = varProposedLimit.toFixed(2);
    else
      this.strProposedLimit = "";
    this.strExistTotal = varexistTotal.toFixed(2);


  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}
