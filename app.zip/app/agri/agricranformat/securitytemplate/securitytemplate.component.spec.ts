import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecuritytemplateComponent } from './securitytemplate.component';

describe('SecuritytemplateComponent', () => {
  let component: SecuritytemplateComponent;
  let fixture: ComponentFixture<SecuritytemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecuritytemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecuritytemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
