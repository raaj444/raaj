import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-securitytemplate',
  templateUrl: './securitytemplate.component.html',
  styleUrls: ['./securitytemplate.component.css']
})
export class SecuritytemplateComponent implements OnInit {
  data: any;
  componentlist: any = [];
  model: any = {};
  cropNameList = [];
  propertDetails = [];
  licSec = [];
  vehicleDet = [];
  fixedDep = [];
  nontradableList = [];
  borrowerList = [];
  mutualList=[];
  totLandAcres: any;
  totLeaseLand: any;
  landmortage: any;
  nsc: any;
  kvp: any;
  propview: any;
  licview:any;
  fixdepview:any;
  vehview:any;
  mutualview:any;
  nontradeview:any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.propview=false;
    this.licview=false;
    this.fixdepview=false;
    this.vehview=false;
    this.mutualview=false;
    this.nontradeview=false;
    this.componentlist = [
      {
        name: 'SecuritytemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          if (this.data.responseData != null) {
            this.propertDetails = this.data.responseData.propertyDet;
            this.vehicleDet = this.data.responseData.vehDet;
            this.licSec = this.data.responseData.lic;
            this.fixedDep = this.data.responseData.fixedDep;
            this.nontradableList = this.data.responseData.nontradable;
            this.mutualList=this.data.responseData.mutual;
            this.totLeaseLand = this.data.responseData.leaseland;
            this.landmortage = this.data.responseData.landmortgage;
            this.borrowerList = this.data.responseData.borrowerList;
            this.totLandAcres = parseFloat(this.landmortage + this.totLeaseLand);
            
            if (this.propertDetails.length > 0) {
              this.propview=true;
              this.propertDetails.forEach(prop => {
                this.borrowerList.forEach(cust => {
                  if (prop.custid == cust.custId) {
                    prop.custid = cust.custName;
                  }
                });

              });
            }
            if (this.vehicleDet.length > 0) {
              this.vehview=true;
              this.vehicleDet.forEach(veh => {
                this.borrowerList.forEach(cust => {
                  if (veh.custid == cust.custId) {
                    veh.custid = cust.custName;
                  }
                });

              });
            }
            if (this.licSec.length > 0) {
              this.licview=true;
              this.licSec.forEach(lic => {
                this.borrowerList.forEach(cust => {
                  if (lic.custid == cust.custId) {
                    lic.custid = cust.custName;
                  }
                });

              });
            }
            if (this.fixedDep.length > 0) {
              this.fixdepview=true;
              this.fixedDep.forEach(fixdep => {
                this.borrowerList.forEach(cust => {
                  if (fixdep.custid == cust.custId) {
                    fixdep.custid = cust.custName;
                  }
                });

              });
            }
            if (this.nontradableList.length > 0) {
              this.nontradeview=true;
              this.nontradableList.forEach(nontrade => {
                this.borrowerList.forEach(cust => {
                  if (nontrade.custid == cust.custId) {
                    nontrade.custid = cust.custName;
                  }
                });

              });
            }
            if (this.mutualList.length > 0) {
              this.mutualview=true;
              this.mutualList.forEach(mutual => {
                this.borrowerList.forEach(cust => {
                  if (mutual.custid == cust.custId) {
                    mutual.custid = cust.custName;
                  }
                });

              });
            }
            
            
          }
        }
      },
      error => {
      });
  }

}
