import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferencedettemplateComponent } from './referencedettemplate.component';

describe('ReferencedettemplateComponent', () => {
  let component: ReferencedettemplateComponent;
  let fixture: ComponentFixture<ReferencedettemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferencedettemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferencedettemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
