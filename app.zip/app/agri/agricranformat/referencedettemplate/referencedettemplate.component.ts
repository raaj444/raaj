import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-referencedettemplate',
  templateUrl: './referencedettemplate.component.html',
  styleUrls: ['./referencedettemplate.component.css']
})
export class ReferencedettemplateComponent  implements OnInit {   data:any; 

  hidView: boolean;
  componentlist :any=[];
  model: any = {};
  listOfValuesList:  any = [];
  stateList: Array<any> = [];
  private cropPatternArray: Array<any> = [];
  @Input()
  cranTypeFromResolver :string;
  relationList=[];
  feedbackStatusList=[];
  constructor(private cranService: CranService) { }
  
  ngOnInit() {
    this.hidView=false;
 this.componentlist = [
      {
        name: 'ReferencedettemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
  this.cranService.getAgriDataCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
          
          if (this.data.success) {
            if(this.data.responseData.referencedetails!=null){
              this.hidView=true;
            this.model.optionsFieldArray = this.data.responseData.referencedetails;
            this.relationList = this.data.responseData.relationmasterList;
            this.feedbackStatusList = this.data.responseData.FeedbackStatusList;

            this.model.optionsFieldArray.forEach(element => {
              this.relationList.forEach(bor => {
                if (bor.llvOptionVal == element.lrdRelation) {
                  element.lrdRelation = bor.llvOptionDesc;
                }
              });
              this.feedbackStatusList.forEach(bor => {
                if (bor.llvOptionVal == element.lrdStatus) {
                  element.lrdStatus = bor.llvOptionDesc;
                }
              });
            });
            }
            // if (this.model.optionsFieldArray.length < 1) {
            //   this.model.optionsFieldArray.push({ 'lrdRowId': '', 'lrdSeqNo': '', 'lrdRelation': 's', 'lrdStatus': 's' });
            // }
            
          } 
          },
        error => {
        }); 
  }

}

