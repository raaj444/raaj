import { Component, OnInit, Input } from '@angular/core';
import { CranService } from "../../../util/service/commonservices/cran.service";

@Component({
  selector: 'lp-agriprocessnotecredit',
  templateUrl: './agriprocessnotecredit.component.html',
  styleUrls: ['./agriprocessnotecredit.component.css']
})
export class AgriprocessnotecreditComponent implements OnInit {
  data: any;


  hidType1: boolean;
  hidType: boolean;
  currentDate: any;
  componentlist: any = [];
  constructor(private cranService: CranService) { }
  proposalno: any;
  state: any;
  category: any;
  logindate: any;
  BankingArrangement: any = [];
  TypeofCase: any = [];
  model: any = {};
  addr: any = {};
  modelRef: any = {};
  BorFather: any;
  BorCustName: any;
  BorDob: any;
  age: any;
  BorrowerList: any = [];
  CoBorrowerList: any = [];
  GuBorrowerList: any = [];
  Borrower: boolean = true;
  Guarantor: boolean = true;
  rmnameAndcode: any;
  fiDoneBy: any;
  fiStatus: any;
  fundingDist: any;
  branchcode: any;
  branchname: any;
  statecityList: any;
  ExistCrn: any;
  TotalAppliedAmt: any = {};
  relationwithbor = [];
  addrview: boolean;
  multiaddr: boolean;
  contactno: any;
  appNo: any;
  grpName: any;
  sourcingChannel: any;
  borrowerType: any;
  gender = [];
  UserName: any = "";
  fullAddress1: any;
  fullAddress2: any;
  @Input()
  cranTypeFromResolver: string;
  ngOnInit() {
    this.hidType = true;
    this.hidType1 = true;
    this.addrview = false;
    this.multiaddr = false;
    this.componentlist = [
      {
        name: 'AgriprocessnotecreditComponent', cranType: this.cranTypeFromResolver
      },
    ];


    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {


          this.model = this.data.responseData.CaseDetailrm;

          if (this.data.responseData.abmname != null)
            this.model.lpcdsABMName = this.data.responseData.abmname;
          if (this.data.responseData.rbmname != null)
            this.model.lpcdsRBMName = this.data.responseData.rbmname;

          this.proposalno = this.data.responseData.proposalnum;
          this.state = this.data.responseData.state;
          this.fundingDist = this.data.responseData.fundingDist;
          this.branchcode = this.data.responseData.branchcode;
          this.branchname = this.data.responseData.branchname;
          this.category = this.data.responseData.typeofcase;
          this.sourcingChannel = this.data.responseData.sourcingChannel;
          this.logindate = this.data.responseData.logindate;
          if (this.logindate != "" && this.logindate != null) {
            var logindatetemp = this.logindate;
            var logindatearray = logindatetemp.split("-");
            this.logindate = logindatearray[2] + '-' + logindatearray[1] + '-' + logindatearray[0];
          }

          this.UserName = this.data.responseData.UserName;
          this.BorCustName = this.data.responseData.BorCustName;
          this.BorFather = this.data.responseData.BorFather;
          this.BorDob = this.data.responseData.BorDob;
          this.currentDate = this.data.responseData.currentDate;
          this.ExistCrn = this.data.responseData.ExistCrn;
          this.appNo = this.data.responseData.appNo;
          this.grpName = this.data.responseData.grpName;
          this.borrowerType = this.data.responseData.BorType;
          if (this.BorDob != "" && this.BorDob != null) {

            var BorDobtemp = this.BorDob;
            var BorDobtemparray = BorDobtemp.split("-");
            this.BorDob = BorDobtemparray[2] + '/' + BorDobtemparray[1] + '/' + BorDobtemparray[0];
            var today_date = new Date();
            var today_year = today_date.getFullYear();
            var today_month = today_date.getMonth();
            var today_day = today_date.getDate();
            this.age = today_year - BorDobtemparray[0];

            if (today_month < (BorDobtemparray[1] - 1))
              this.age--;
            if (((BorDobtemparray[1] - 1) == today_month) && (today_day < BorDobtemparray[2]))
              this.age--;
          }

          this.addr = this.data.responseData.AddressDet;
          this.statecityList = this.data.responseData.statecity;
           if (this.addr.length > 0) {
            this.addrview = true;
            this.addr.forEach(addr => {
              this.statecityList.forEach(state => {
                if (addr.lcaState == state.sgmStateCode) {
                  addr.lcaState = state.sgmStateName;
                }
                if (addr.lcaCity == state.sgmCityCode) {
                  addr.lcaCity = state.sgmCityName;
                }
                if (addr.lcaDistrict == state.sgmDistrictCode)
                  addr.lcaDistrict = state.sgmDistrictName;
                else
                  addr.lcaDistrict = '';

                if (addr.lcaTaluka == state.lgmTalukCode)
                  addr.lcaTaluka = state.lgmTalukName;
                else
                  addr.lcaTaluka = '';
              });
            });
            if (this.addr.length > 1)
              this.multiaddr = true;
          }

          this.fullAddress1 = this.addr[0].lcaAddress1;
          if (this.addr[0].lcaAddress2)
            this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaAddress2;
          if (this.addr[0].lcaAddress3)
            this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaAddress3;
          this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaCity;
          if (this.addr[0].lcaDistrict)
            this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaDistrict;
          if (this.addr[0].lcaTaluka)
            this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaTaluka;
          this.fullAddress1 = this.fullAddress1 + ", " + this.addr[0].lcaState;

          if (this.multiaddr == true) {
            this.fullAddress2 = this.addr[0].lcaAddress1;
            if (this.addr[0].lcaAddress2)
              this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaAddress2;
            if (this.addr[0].lcaAddress3)
              this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaAddress3;
            this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaCity;
            if (this.addr[0].lcaDistrict)
              this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaDistrict;
            if (this.addr[0].lcaTaluka)
              this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaTaluka;
            this.fullAddress2 = this.fullAddress2 + ", " + this.addr[0].lcaState;
          }
          else
            this.fullAddress2 = '';

          if (this.data.responseData.BorrowerList != null) {
            this.hidType1 = false;
            this.BorrowerList = this.data.responseData.BorrowerList;
          }
          this.relationwithbor = this.data.responseData.RelationwithBorrower;
          this.gender = this.data.responseData.gender;
          this.fiDoneBy = this.data.responseData.fiDoneBy;

          this.fiStatus = this.data.responseData.fiStatus;
          if (this.fiStatus == "P")
            this.fiStatus = "Positive";
          if (this.fiStatus == "N")
            this.fiStatus = "Negative";
          if (this.fiStatus == "NA")
            this.fiStatus = "Not Applicable";
          if (this.data.responseData.TotalAppliedAmt != null) {
            this.hidType = false;
            this.TotalAppliedAmt = this.data.responseData.TotalAppliedAmt;
          }
          var i = 0;
          var k = 1;
          var S = 1;
          this.BorrowerList.forEach(element => {
            var BorDobtemp = element.DOB;
            var BorDobtemparray = BorDobtemp.split("-");
            element.DOB = BorDobtemparray[2] + '/' + BorDobtemparray[1] + '/' + BorDobtemparray[0];
            var today_date = new Date();
            var today_year = today_date.getFullYear();
            var today_month = today_date.getMonth();
            var today_day = today_date.getDate();
            this.BorrowerList[i].age = today_year - BorDobtemparray[0];
            if (element.BorType == "B") {
              this.BorrowerList[i].Type = "Borrower";
              this.BorrowerList[i].AppType = "Borrower";
              this.contactno = element.ContactNo;
            }
            if (element.BorType == "C") {
              this.BorrowerList[i].Type = "Co Borrower";
              this.BorrowerList[i].AppType = "Co Borrower" + " " + k;
              k++;
            }

            if (element.BorType == "G") {
              this.BorrowerList[i].Type = "Guarantors";
              this.BorrowerList[i].AppType = "Guarantors" + " " + S;
              S++;
            }


            var ageborrower = today_year - BorDobtemparray[0];
            if (today_month < (BorDobtemparray[1] - 1))
              this.BorrowerList[i].age--;
            if (((BorDobtemparray[1] - 1) == today_month) && (today_day < BorDobtemparray[2]))
              this.BorrowerList[i].age--;
            i++;
            this.relationwithbor.forEach(bor => {
              if (bor.llvOptionVal == element.Relation) {
                element.Relation = bor.llvOptionDesc;
              }

            });
            this.gender.forEach(bor => {
              if (bor.llvOptionVal == element.Gender) {
                element.Gender = bor.llvOptionDesc;
              }

            });

          });
          this.rmnameAndcode = this.data.responseData.rmnameAndcode;


        }
      },
      error => {        
      });
  }

}
