import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgriprocessnotecreditComponent } from './agriprocessnotecredit.component';

describe('AgriprocessnotecreditComponent', () => {
  let component: AgriprocessnotecreditComponent;
  let fixture: ComponentFixture<AgriprocessnotecreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgriprocessnotecreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgriprocessnotecreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
