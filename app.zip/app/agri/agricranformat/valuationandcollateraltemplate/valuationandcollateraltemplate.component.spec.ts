import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValuationandcollateraltemplateComponent } from './valuationandcollateraltemplate.component';

describe('ValuationandcollateraltemplateComponent', () => {
  let component: ValuationandcollateraltemplateComponent;
  let fixture: ComponentFixture<ValuationandcollateraltemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValuationandcollateraltemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValuationandcollateraltemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
