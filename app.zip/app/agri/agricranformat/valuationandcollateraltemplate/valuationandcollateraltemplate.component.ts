import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-valuationandcollateraltemplate',
  templateUrl: './valuationandcollateraltemplate.component.html',
  styleUrls: ['./valuationandcollateraltemplate.component.css']
})
export class ValuationandcollateraltemplateComponent implements OnInit {
  data: any;
  componentlist: any = [];
  model: any = {};
  cropNameList = [];

  landmortage: any;
  srovaluation: any;
  netsecvalue: any;
  dvofcollateral: any;
  collsrovaluation: any;
  peracresvalu: any;
  peracresfund: any;
  marketvalu: any;
  marketvaluation: any;
  calcovmarkvalu: any;
  pageAccess: any;
  disableCancelButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  fieldDisable: boolean;
  facilitysum: any;
  premumval: any;
  totfacproposal: any;
  mvsum: any;
  dvsum: any;
  VehicleSum: any;
  FDSUM: any;
  tradesec: any;
  nontradesec: any;
  Othersum: any
  colCoverageAgri: any;
  colCoverageMV: any;
  col_cov_A: any;
  col_cov_MV: any;
  perAcrFund: any;
  PostHairCut: any;
  totLeaseLand: any;
  totLandAcres: any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {

    this.landmortage = 0.00;
    this.netsecvalue = 0;
    this.dvofcollateral = 0;
    this.srovaluation = 0;
    this.marketvaluation = 0;
    this.facilitysum = 0;
    this.model.lpDvofNacollateral = 0;
    this.collsrovaluation = 0;
    this.peracresvalu = 0;
    this.peracresfund = 0;
    this.marketvalu = 0;
    this.calcovmarkvalu = 0;
    this.totfacproposal = 0.00;
    this.mvsum = 0;
    this.dvsum = 0;
    this.VehicleSum = 0;
    this.Othersum = 0;
    this.perAcrFund = 0;


    this.componentlist = [
      {
        name: 'ValuationandcollateraltemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {

            this.landmortage = this.data.responseData.landmortgage;
            if (this.landmortage == null)
              this.landmortage = 0.00;
            this.srovaluation = this.data.responseData.srovaluation;
            if (this.srovaluation == null)
              this.srovaluation = 0;
            this.totLeaseLand = this.data.responseData.totLeaseLand;
            if (this.totLeaseLand == null)
              this.totLeaseLand = 0.00;

            this.totLandAcres = parseFloat(this.landmortage + this.totLeaseLand);
            this.marketvaluation = this.data.responseData.marketvaluation;
            this.mvsum = this.data.responseData.MVsum;
            this.dvsum = this.data.responseData.DVsum;
            this.FDSUM = this.data.responseData.FDSUM;
            this.PostHairCut = this.data.responseData.PostHairCut;
            this.VehicleSum = this.data.responseData.VehicleSum;
            this.tradesec = this.data.responseData.tradesec;
            this.nontradesec = this.data.responseData.nontradesec;
            this.Othersum = this.data.responseData.Othersum;
            this.colCoverageAgri = this.data.responseData.Colcovagri;
            this.colCoverageMV = this.data.responseData.Colcovmv;
            if (this.marketvaluation == null)
              this.marketvaluation = 0;
            this.facilitysum = this.data.responseData.facilitysum;
            this.premumval = this.data.responseData.premumval;
            if (this.premumval == null) {
              this.premumval = 0;
            }

            if (this.facilitysum != "" || this.premumval != "") {
              var totloanamt = this.facilitysum + this.premumval;

              var col_Cov_A = (this.colCoverageAgri / totloanamt) * 100;
              this.col_cov_A = col_Cov_A.toFixed(2);
              var col_Cov_MV = (this.colCoverageMV / totloanamt) * 100;
              this.col_cov_MV = col_Cov_MV.toFixed(2);
            }
            this.perAcrFund = this.data.responseData.perAcr;
            this.perAcrFund = this.perAcrFund.toFixed(2);
            this.srovaluation = this.srovaluation.toFixed(2);
            this.netsecvalue = this.netsecvalue.toFixed(2);
            this.marketvaluation = this.marketvaluation.toFixed(2);
            this.facilitysum = this.facilitysum.toFixed(2);
            this.mvsum = this.mvsum.toFixed(2);
            this.dvsum = this.dvsum.toFixed(2);
            this.FDSUM = this.FDSUM.toFixed(2);
            this.PostHairCut = this.PostHairCut.toFixed(2);
            this.VehicleSum = this.VehicleSum.toFixed(2);
            this.tradesec = this.tradesec.toFixed(2);
            this.nontradesec = this.nontradesec.toFixed(2);
            this.Othersum = this.Othersum.toFixed(2);
          }
          else {

          }
        },
        error => {
        });

  }

}
