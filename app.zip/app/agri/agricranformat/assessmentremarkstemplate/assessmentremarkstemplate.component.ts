import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';


@Component({
  selector: 'lp-assessmentremarkstemplate',
  templateUrl: './assessmentremarkstemplate.component.html',
  styleUrls: ['./assessmentremarkstemplate.component.css']
})
export class AssessmentremarkstemplateComponent implements OnInit {
  atlremarksflag: boolean;
  stlremarksFlag: boolean;
  fdlremarksFlag: boolean;
  kccassessmentremarksFlag: boolean;
  data: any;
  model: any = {};
  componentlist: any = [];
  kccassessmentremarks: any = {};
  fdlremarks: any = [];
  atlremarks: any = [];
  stlremarks: any = [];
  lkeRemarks: any;
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'AssessmentremarkstemplateComponent'
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          if (this.data.kccassessmentremarks != null) {
            this.kccassessmentremarksFlag = false;
            this.kccassessmentremarks = this.data.kccassessmentremarks;
            this.lkeRemarks = this.kccassessmentremarks.lkrAssessRemark;
          }
          else {
            this.kccassessmentremarksFlag = true;
          }

          this.model.atlfacilityList = this.data.atlfacilityList;
          this.model.fdlfacilityList = this.data.fdlfacilityList;
          this.model.stlfacilityList = this.data.stlfacilityList;

          this.atlremarks = this.data.atlremarks;
          if (this.atlremarks.length > 0) {
            this.atlremarksflag = false;
            this.atlremarks.forEach(element => {
              this.model.atlfacilityList.forEach(facility => {
                if (element.lcaFacno == facility.lfFacNo) {
                  element.facName = facility.facName;
                  element.lfProposedLimit = facility.lfProposedLimit;
                }
              });
            });
          }
          else {
            this.atlremarksflag = true;
          }

          this.stlremarks = this.data.stlremarks;
          if (this.stlremarks.length > 0) {
            this.stlremarksFlag = false;
            this.stlremarks.forEach(element => {
              this.model.stlfacilityList.forEach(facility => {
                if (element.lstFacId == facility.lfFacNo) {
                  element.facName = facility.facName;
                  element.lfProposedLimit = facility.lfProposedLimit;
                }
              });
            });

          }
          else {
            this.stlremarksFlag = true;
          }
          this.fdlremarks = this.data.fdlremarks;
          if (this.fdlremarks.length > 0) {
            this.fdlremarksFlag = false;
            this.fdlremarks.forEach(element => {
              this.model.fdlfacilityList.forEach(facility => {
                if (element.lfFacno == facility.lfFacNo) {
                  element.facName = facility.facName;
                  element.lfProposedLimit = facility.lfProposedLimit;
                }
              });
            });

          } else {
            this.fdlremarksFlag = true;
          }
        }
      },
      error => {        
      });
  }

}
