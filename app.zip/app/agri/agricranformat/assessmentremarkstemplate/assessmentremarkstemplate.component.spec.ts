import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentremarkstemplateComponent } from './assessmentremarkstemplate.component';

describe('AssessmentremarkstemplateComponent', () => {
  let component: AssessmentremarkstemplateComponent;
  let fixture: ComponentFixture<AssessmentremarkstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessmentremarkstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessmentremarkstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
