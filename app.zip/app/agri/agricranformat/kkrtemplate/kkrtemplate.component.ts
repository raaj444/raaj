import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-kkrtemplate',
  templateUrl: './kkrtemplate.component.html',
  styleUrls: ['./kkrtemplate.component.css']
})
export class KkrtemplateComponent implements OnInit {
  hidView1: boolean;
  hidView: boolean;
  model: any = {};
  kkrPremium: any = {};
  componentlist: any = [];
  reqDueDataList: any = [];
  borrowerType: any = [];
  private AgritermloanList: Array<any> = [];
  private facilityDetailsList: Array<any> = [];
  listOfValuesList = [];
  tempagritermloanList: Array<any> = [];
  strProposedLimit: any = 0.00;
  totalAmount: any = 0.00;
  kkrPremiumAmount: any = 0.00;
  exposureAmount: any = 0.00;
  totalexposureAmount: any = 0.00;
  strTotalLimit: any = 0.00;
  strExistTotal: any = 0.00;
  totalExposureSanLimit: any = 0.00;
  totalExposureCrdRec: any = 0.00;
  totalExposureSalRec: any = 0.00;
  totalExposureProp: any;
  relationwithbor=[];
  RelationwithBorrowerkkr=[];
  finalAmt: any =0.00;
  strSalRecmdAmount: String; strCrdRecmdAmount: String; strSancLimit: String;
  data: any;
  lpmasListofvalueForKKRPremiumTypeListMap: any = {};
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }


  ngOnInit() {

    this.kkrPremium.lkpPremAmount = 0.00;
    this.finalAmt=0.00;
    this.componentlist = [
      {
        name: 'AgritermLoantemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.model.facilityDetailsList = this.data.responseData.FacilityList;
          this.model.exposures = this.data.exposures;
          this.exposureAmount = this.data.lpcomExposureAmount;
          this.listOfValuesList = this.data.lpmasListofvalueList;
          this.relationwithbor = this.data.relationwithbor;
          this.RelationwithBorrowerkkr = this.data.RelationwithBorrowerkkr;
          this.finalAmt=this.data.finalATLAmt;
          this.lpmasListofvalueForKKRPremiumTypeListMap = this.data.lpmasListofvalueForKKRPremiumTypeListMap;
          
        
          if(this.data.responseDataKKR !=null){
            this.hidView1=false;
          this.kkrPremium = this.data.responseDataKKR;}
          this.borrowerType = this.data.lpcomCustInfoApplist;
          if (this.kkrPremium == undefined || this.kkrPremium == "" || this.kkrPremium == null) {
            this.kkrPremium = { 'lkpNomineeName': "", 'lkpKkrPremType': "", 'lkpRelOfNominee': "", 'lkpFacAvail': "", 'lkpRelWithBorrower': "" ,'lkpInsuredPerson':""};
          }
          else {
            this.kkrPremium.lkpDob = this.data.lkpDob;

            this.borrowerType.forEach(element => {
              if (element.custId == this.kkrPremium.lkpInsuredPerson)
                this.kkrPremium.lkpInsuredPerson = element.custName;
              if (element.custId == this.kkrPremium.lkpNomineeName)
                this.kkrPremium.lkpNomineeName = element.custName;
                
            });
            var lkpRelOfNominee=this.kkrPremium.lkpRelOfNominee;
            var lkpRelWithBorrower=this.kkrPremium.lkpRelWithBorrower;
            this.relationwithbor.forEach(bor => {
              if(bor.llvOptionVal==lkpRelOfNominee)
              {
                this.kkrPremium.lkpRelOfNominee=bor.llvOptionDesc;
              }
             
            });
            this.RelationwithBorrowerkkr.forEach(kkrrel=>{
              if(kkrrel.llvOptionVal==lkpRelWithBorrower)
              {
                this.kkrPremium.lkpRelWithBorrower=kkrrel.llvOptionDesc;
              }
            });
          }


          let totalLimit = 0; let vartotallimit = 0;
          let varexistTotal = 0; let varProposedLimit = 0;
       

          
          if (this.kkrPremiumAmount != undefined && this.kkrPremiumAmount != null)
            this.kkrPremiumAmount = this.kkrPremiumAmount.toFixed(2);
          if (this.exposureAmount != undefined && this.exposureAmount != null)
            this.exposureAmount = this.exposureAmount.toFixed(2);
        }
      });

  }

}