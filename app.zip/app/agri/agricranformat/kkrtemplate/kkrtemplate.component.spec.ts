import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KkrtemplateComponent } from './kkrtemplate.component';

describe('KkrtemplateComponent', () => {
  let component: KkrtemplateComponent;
  let fixture: ComponentFixture<KkrtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KkrtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KkrtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
