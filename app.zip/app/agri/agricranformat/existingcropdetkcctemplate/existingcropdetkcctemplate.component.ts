import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lp-existingcropdetkcctemplate',
  templateUrl: './existingcropdetkcctemplate.component.html',
  styleUrls: ['./existingcropdetkcctemplate.component.css']
})
export class ExistingcropdetkcctemplateComponent  implements OnInit {   data:any; 

  constructor() { }

  ngOnInit() {
  }

}
