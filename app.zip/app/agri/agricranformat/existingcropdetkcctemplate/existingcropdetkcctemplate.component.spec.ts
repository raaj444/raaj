import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingcropdetkcctemplateComponent } from './existingcropdetkcctemplate.component';

describe('ExistingcropdetkcctemplateComponent', () => {
  let component: ExistingcropdetkcctemplateComponent;
  let fixture: ComponentFixture<ExistingcropdetkcctemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingcropdetkcctemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingcropdetkcctemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
