import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-agritakeovertemplate',
  templateUrl: './agritakeovertemplate.component.html',
  styleUrls: ['./agritakeovertemplate.component.css']
})
export class AgritakeovertemplateComponent implements OnInit {
  data: any;
  hidtype: boolean;
  componentlist: any = [];
  model: any = {};
  cropNameList = [];
  KMBLExpList = [];
  takeoverList = [];
  tempKMBLExpList = [];
  tempTakeoverList = [];
  borrowerList = [];
  productList = [];
  divsionList = [];
  takeview:boolean;
  kmblview:boolean;
  totpos:any;
  bankNames=[];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.takeview=false;
    this.kmblview=false;
    this.componentlist = [
      {
        name: 'AgritakeovertemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          this.takeoverList = this.data.takeoverList;
          this.KMBLExpList = this.data.KMBLExpList;
          this.borrowerList = this.data.borrowerList;
          this.productList = this.data.subCategoryList;
          this.divsionList = this.data.divsionList;
          this.bankNames=this.data.bankNames;
          if (this.KMBLExpList.length > 0) {
            this.kmblview=true;
            this.KMBLExpList.forEach(exp => {
              if (exp.ledKotakGrpName == '1') {
                this.tempKMBLExpList.push(exp);
              }
            });
            this.totpos=0.00;
            if (this.tempKMBLExpList.length > 0)
              this.tempKMBLExpList.forEach(exp => {
                this.borrowerList.forEach(cust => {
                  if (exp.ledCustId == cust.custId) {
                    exp.ledCustId = cust.custName;
                  }
                });
                this.productList.forEach(fac => {
                  if (fac.lsfFacId == exp.ledProduct) {
                    exp.ledProduct = fac.lsfFacDesc;
                  }
                });
                this.divsionList.forEach(div=>{
                  if(div.lbvRowId==exp.ledDivision)
                  {
                    exp.ledDivision=div.lbvBizVertical;
                  }

                });
                if(exp.ledFacType=='NF')
                {
                  exp.ledAmount=this.parseEmptytoFloat(exp.ledSancLimit).toFixed(2);
                }
                else
                {
                  exp.ledAmount=this.parseEmptytoFloat(exp.ledAmount).toFixed(2);
                }
                
                this.totpos = this.parseEmptytoFloat(this.totpos )+ this.parseEmptytoFloat(exp.ledAmount);
                this.totpos=this.totpos.toFixed(2);
              });
          }
          if (this.takeoverList.length > 0) {
            this.takeview=true;
            this.takeoverList.forEach(exp => {
              if (exp.leeOurBank == 'Y') {
                this.tempTakeoverList.push(exp);
              }
            });
            if (this.tempTakeoverList.length > 0)
              this.tempTakeoverList.forEach(exp => {
                
                
                this.bankNames.forEach(bank => {
                  if (exp.leeBankName == bank.llvOptionVal) {
                    exp.leeBankName = bank.llvOptionDesc;
                  }
                });
                this.productList.forEach(fac => {
                  if (fac.lsfFacId == exp.leeFacilityDesc) {
                    exp.leeFacilityDesc = fac.lsfFacDesc;
                  }
                });
                exp.leeOsAmt=this.parseEmptytoFloat(exp.leeOsAmt).toFixed(2);
              });
          }
        }
      },
      error => {        
      });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}
