import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgritakeovertemplateComponent } from './agritakeovertemplate.component';

describe('AgritakeovertemplateComponent', () => {
  let component: AgritakeovertemplateComponent;
  let fixture: ComponentFixture<AgritakeovertemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgritakeovertemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgritakeovertemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
