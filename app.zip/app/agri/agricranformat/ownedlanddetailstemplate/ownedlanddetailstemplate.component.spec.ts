import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnedlanddetailstemplateComponent } from './ownedlanddetailstemplate.component';

describe('OwnedlanddetailstemplateComponent', () => {
  let component: OwnedlanddetailstemplateComponent;
  let fixture: ComponentFixture<OwnedlanddetailstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnedlanddetailstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnedlanddetailstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
