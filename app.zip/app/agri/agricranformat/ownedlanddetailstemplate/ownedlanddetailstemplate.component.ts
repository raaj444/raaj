import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';


@Component({
  selector: 'lp-ownedlanddetailstemplate',
  templateUrl: './ownedlanddetailstemplate.component.html',
  styleUrls: ['./ownedlanddetailstemplate.component.css']
})
export class OwnedlanddetailstemplateComponent implements OnInit {
  data: any;
  mortagetotal: any;
  totalAcreConsAss: any;

  stateList: any;
  hidView1: boolean;
  model: any = {};
  componentlist: any = [];
  reqDueDataList: any = [];
  stGeographyMasterList: Array<any> = [];
  ownerName: Array<any> = [];
  total: any;
  totalCultivable: any;
  totalNoncul: any;
  ownland: any;
  governtotal: any;
  plm: any;
  borrowerType = [];
  relationList = [];
  irrigationList = [];
  statusList = [];
  tempVal: any = [];
  IrrigatempVal: any = [];

  talukList: any = [];
  otherborrowerName: any;
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.hidView1 = false;
    this.otherborrowerName = false;
    this.componentlist = [
      {
        name: 'OwnedlanddetailstemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          if (this.data.responseData.reqDueDataList != null) {
            this.reqDueDataList = this.data.responseData.reqDueDataList;
            this.borrowerType = this.data.responseData.ownerNameList;
            this.relationList = this.data.relationBorList;
            this.irrigationList = this.data.irrgationList;
            this.statusList = this.data.statusList;
          }
          if (this.data.responseData.lpcorpAdditionaldetail != null) {
            this.hidView1 = true;
            this.model = this.data.responseData.lpcorpAdditionaldetail;
            // if (data.json().responseData.lpcorpAdditionaldetail != null) {
            //   this.model.lcaFamilyland = data.json().responseData.lpcorpAdditionaldetail.lcaFamilyland;
            //   this.model.lcaBorrowerownland = data.json().responseData.lpcorpAdditionaldetail.lcaBorrowerownland;
            //   this.model.lcaLandmortgage = data.json().responseData.lpcorpAdditionaldetail.lcaLandmortgage;
            //   this.model.lcaSrovaluation = data.json().responseData.lpcorpAdditionaldetail.lcaSrovaluation;
            //   this.model.lcaMarketvaluation = this.toFixCall(data.json().responseData.lpcorpAdditionaldetail.lcaMarketvaluation);
            //   this.model.lcaLandverification = data.json().responseData.lpcorpAdditionaldetail.lcaLandverification;
            //   this.model.lcaLanddocsverfy = data.json().responseData.lpcorpAdditionaldetail.lcaLanddocsverfy;
            //   this.model.lcaTalathiname = data.json().responseData.lpcorpAdditionaldetail.lcaTalathiname;
            //   this.model.lcaTalathicontact = data.json().responseData.lpcorpAdditionaldetail.lcaTalathicontact;
            //   this.model.lcaLandverfonlinesite = data.json().responseData.lpcorpAdditionaldetail.lcaLandverfonlinesite;
            //   this.model.lcaPartiallandmort = data.json().responseData.lpcorpAdditionaldetail.lcaPartiallandmort;
            //   this.model.lcaPlm = data.json().responseData.lpcorpAdditionaldetail.lcaPlm;
            //   this.model.lcaRowId = data.json().responseData.lpcorpAdditionaldetail.lcaRowId;
            // }
          }
          this.ownerName = this.data.ownerName;
          // this.stateList = this.data.statecityList;
          this.talukList = this.data.talukList;
          this.reqDueDataList.forEach((element, index) => {
            this.talukList.forEach(talukdata => {
              talukdata.forEach(state => {
                if (state.sgmStateCode === element.aldstate) {
                  element.aldstate = state.sgmStateName;
                }
                if (state.sgmCityCode === element.aldDistrict) {
                  element.aldDistrict = state.sgmCityName;
                }
                if (state.lgmTalukCode === element.aldtaluk) {
                  element.aldtaluk = state.lgmTalukName;
                }
              });
            });

            if (element.aldOwnerId != "" && element.aldOwnerId != null) {
              this.tempVal = element.aldOwnerId.split(',');
              element.aldOwnerId = '';
              this.tempVal.forEach(custid => {
                if (custid == "0")
                  this.otherborrowerName = true;
                else {
                  this.borrowerType.forEach(value => {
                    if (value.custId == custid) {
                      {
                        if (element.aldOwnerId == '')
                          element.aldOwnerId = value.custName;
                        else
                          element.aldOwnerId = element.aldOwnerId + ", " + value.custName;
                      }
                    }
                  });
                }
              });
            }
            if (element.aldIrrigationSrc != null && element.aldIrrigationSrc != undefined) {
              this.IrrigatempVal = element.aldIrrigationSrc.split(',');
              var aldIrrigSrc = '';
              this.IrrigatempVal.forEach(element => {
                this.irrigationList.forEach(master => {
                  if (master.llvOptionVal == element.toString()) {
                    if (aldIrrigSrc == '')
                      aldIrrigSrc = master.llvOptionDesc;
                    else
                      aldIrrigSrc = aldIrrigSrc + ", " + master.llvOptionDesc;
                  }
                });
              });
             element.aldIrrigationSrc = aldIrrigSrc;
            }
            this.relationList.forEach(master => {
              if (master.llvOptionVal == element.aldBorrRelation) {
                element.aldBorrRelation = master.llvOptionDesc;
              }
            });

            this.statusList.forEach(master => {
              if (master.llvOptionVal == element.aldStatus) {
                element.aldStatus = master.llvOptionDesc;
              }
            });
          });


          this.acrecalculate(this.reqDueDataList.length - 1);

        }

      },
      error => {
      });
  }

  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }

  acrecalculate(i) {
    this.total = 0.00;
    this.totalCultivable = 0.00;
    this.ownland = 0.00;
    this.totalNoncul = 0.00;
    this.totalAcreConsAss = 0.00;
    this.governtotal = 0.00;
    this.mortagetotal = 0.00;
    this.plm = 0.00;
    this.reqDueDataList.forEach(value => {
      if (value.aldCultivable !== "" && value.aldCultivable != null && value.aldCultivable != undefined) {
        this.totalCultivable = parseFloat(value.aldCultivable) + parseFloat(this.totalCultivable);
      }
      if (value.aldNonCultivable !== "" && value.aldNonCultivable != null && value.aldNonCultivable != undefined) {
        this.totalNoncul = parseFloat(value.aldNonCultivable) + parseFloat(this.totalNoncul);
      }
      if (value.aldAssessment !== "" && value.aldAssessment != null && value.aldAssessment != undefined) {
        this.totalAcreConsAss = parseFloat(value.aldAssessment) + parseFloat(this.totalAcreConsAss);
      }
      if (value.aldAcreMortgaged !== "" && value.aldAcreMortgaged != null && value.aldAcreMortgaged != undefined) {
        let val = parseFloat(value.aldAcreMortgaged).toFixed(2);
        this.mortagetotal = parseFloat(this.mortagetotal) + parseFloat(val);
        this.plm = (this.mortagetotal / this.total) * 100;
        this.plm = parseFloat(this.plm).toFixed(2);
       // this.model.lcaPlm = this.parseEmptytoFloat(this.plm);
        // if (this.model.lcaPlm < 0 || this.model.lcaPlm == Infinity) {
        //   this.model.lcaPlm = 0.00;
        // }
        // this.model.lcaPlm = this.model.lcaPlm.toFixed(2);
      }
      if (value.aldGovtValuation !== "" && value.aldGovtValuation != null && value.aldGovtValuation != undefined) {
        let val1 = parseFloat(value.aldGovtValuation).toFixed(2);
        this.governtotal = parseFloat(this.governtotal) + parseFloat(val1);
        this.governtotal = parseFloat(this.governtotal).toFixed(2);
        this.model.lcaSrovaluation = this.governtotal;

      }
    });
    this.total = parseFloat(this.totalCultivable) + parseFloat(this.totalNoncul);
    this.model.lcaFamilyland = parseFloat(this.total).toFixed(2);
    this.totalCultivable = parseFloat(this.totalCultivable).toFixed(2);
    this.totalNoncul = parseFloat(this.totalNoncul).toFixed(2);
    this.totalAcreConsAss = parseFloat(this.totalAcreConsAss).toFixed(2);
    this.mortagetotal = parseFloat(this.mortagetotal).toFixed(2);

  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}

