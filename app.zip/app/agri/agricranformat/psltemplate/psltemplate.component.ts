import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-psltemplate',
  templateUrl: './psltemplate.component.html',
  styleUrls: ['./psltemplate.component.css']
})
export class PsltemplateComponent implements OnInit {
  data: any;
  componentlist: any = [];
  model: any = {};
  pslClassification: any = [];
  listFacilityByPropNum: any = [];
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'PsltemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];

    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          if (this.data.listOfFacility != null)
            this.listFacilityByPropNum = this.data.listOfFacility;
          if (this.data.lpagriPslClassificationList != null) {
            this.pslClassification = this.data.lpagriPslClassificationList;
            if (this.pslClassification.length > 0) {
              this.pslClassification.forEach(psl => {
                this.listFacilityByPropNum.forEach(fac => {
                  if (fac.facNo == psl.lpcFacNo) {
                    psl.lpcFacNo = fac.facName;
                    psl.lpcCustType = fac.customerType;
                  }
                });
              });
            }
          }
        }

      },
      error => {
      });
  }

}
