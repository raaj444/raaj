import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RcudetailstemplateComponent } from './rcudetailstemplate.component';

describe('RcudetailstemplateComponent', () => {
  let component: RcudetailstemplateComponent;
  let fixture: ComponentFixture<RcudetailstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RcudetailstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RcudetailstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
