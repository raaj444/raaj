import { Component, OnInit, Input } from '@angular/core';
import { DocumentdetailsService } from '../../../util/service/commonservices/documentdetails.service';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-rcudetailstemplate',
  templateUrl: './rcudetailstemplate.component.html',
  styleUrls: ['./rcudetailstemplate.component.css']
})
export class RcudetailstemplateComponent implements OnInit {
  data: any;
  hidtype: boolean;
  componentlist: any = [];
  model: any = {};
  propDocList = [];
  propSampleList = [];
  rcuAppList = [];
  tempList: any = [];
  takeview: boolean;

  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.takeview = false;
    this.model = {};
    this.componentlist = [
      {
        name: 'RcudetailstemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;

        if (this.data.success == true) {
          if (this.data.propDocList.length != 0)
            this.propDocList = this.data.propDocList;

          if (this.data.propSampleList.length != 0)
            this.propSampleList = this.data.propSampleList;

          if (this.data.rcuAppList.length != 0)
            this.rcuAppList = this.data.rcuAppList;
          this.tempList = [];
          if (this.propDocList.length > 0) {
            for (let i = 0; i <= this.propDocList.length; i++) {
              this.tempList = [];
              this.tempList = this.propDocList[i];
              if ((this.tempList.lpdRcuAction != "") && (this.tempList.lpdRemarks != "")) {
                this.model.lpdRcuAction = this.tempList.lpdRcuAction;
                this.model.lpdModifiedOn = this.tempList.lpdModifiedOn;
                break;
              }
            }
            if (this.propSampleList.length > 0) {
              for (let i = 0; i <= this.propSampleList.length; i++) {
                this.tempList = [];
                this.tempList = this.propSampleList[i];
                if ((this.tempList != "") && (this.tempList != undefined)) {
                  if ((this.tempList.lpsRcuAction != "") && (this.tempList.lpsRcuAction != undefined)) {
                    this.model.lpsRcuAction = this.tempList.lpsRcuAction;
                    this.model.lpsModifiedOn = this.tempList.lpsModifiedOn;
                    break;
                  }
                }
              }
            }
            if (this.rcuAppList.length > 0) {
              for (let i = 0; i <= this.rcuAppList.length; i++) {
                this.tempList = [];
                this.tempList = this.rcuAppList[i];
                if ((this.tempList.lraOverallStatus != "") && (this.tempList.lraOverallRejCode != "")) {
                  this.model.lraOverallStatus = this.tempList.lraOverallStatus;
                  this.model.lraApprovedOn = this.tempList.lraApprovedOn;
                  break;
                }
              }
            }
          }

        }
      },
      error => {
      });
  }

}