import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-applicantplacetemplate',
  templateUrl: './applicantplacetemplate.component.html',
  styleUrls: ['./applicantplacetemplate.component.css']
})
export class ApplicantplacetemplateComponent implements OnInit {
  data: any;
  hidtype: boolean;
  componentlist: any = [];
  model: any = {};
  cropNameList = [];
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.hidtype = false;
    this.componentlist = [
      {
        name: 'ApplicantplacetemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          if (this.data.responseData != null) {
            this.hidtype = true;
            this.model = this.data.responseData;
            if (this.model.lcaMode == "1")
              this.model.lcaMode = "Road";
            if (this.model.lcaMode == "2")
              this.model.lcaMode = "Rail";
          }
        }
      },
      error => {        
      });
  }

}
