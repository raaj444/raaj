import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditcondtemplateComponent } from './creditcondtemplate.component';

describe('CreditcondtemplateComponent', () => {
  let component: CreditcondtemplateComponent;
  let fixture: ComponentFixture<CreditcondtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditcondtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditcondtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
