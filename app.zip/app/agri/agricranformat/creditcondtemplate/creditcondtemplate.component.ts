import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
import { element } from 'protractor';

@Component({
  selector: 'lp-creditcondtemplate',
  templateUrl: './creditcondtemplate.component.html',
  styleUrls: ['./creditcondtemplate.component.css']
})
export class CreditcondtemplateComponent implements OnInit {

  data: any;
  hidtype: boolean;
  componentlist: any = [];
  model: any = {};
  protermcondList = [];
  generalList=[];
  facspecList=[];
  creditview:boolean;
monitoringScheme:any=[];
monitoringFac:any=[];
operationsScheme:any=[];
operationsFac:any=[];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
  //  this.creditview=false;

    this.componentlist = [
      {
        name: 'CreditcondtemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        this.generalList=[];
        this.facspecList=[];
        if (this.data.success == true) {
          this.protermcondList=this.data.propConditionList;

     


        if(this.protermcondList.length >0)
        {
          //this.creditview=true;
          this.protermcondList.forEach(element =>{
            if(element.lptcTermsFor=='S')
            {
              this.generalList.push(element);
            }
            if(element.lptcTermsFor=='F')
            {
              this.facspecList.push(element);
            }
          })
        }

        if(this.data.operations && this.data.operations.length>0)   {
          this.data.operations.forEach(element =>{
            if(element.lptcTermsFor=='S')
            {
              this.operationsScheme.push(element);
            }
            if(element.lptcTermsFor=='F')
            {
              this.operationsFac.push(element);
            }
          })
        }

        if(this.data.monitoring && this.data.monitoring.length>0)   {
          this.data.monitoring.forEach(element =>{
            if(element.lptcTermsFor=='S')
            {
              this.monitoringScheme.push(element);
            }
            if(element.lptcTermsFor=='F')
            {
              this.monitoringFac.push(element);
            }
          })
        }


        }
      },
      error => {        
      });
  }

}

