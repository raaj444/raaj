import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-fleetdetailstemplate',
  templateUrl: './fleetdetailstemplate.component.html',
  styleUrls: ['./fleetdetailstemplate.component.css']
})
export class FleetdetailstemplateComponent  implements OnInit {   data:any; 

  hidType: boolean;
  componentlist: any = [];
  model: any = {};
  borrowerType: any=[];
  relationwithBorrwerList=[];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
  this.hidType=false;
    this.componentlist = [
      {
        name: 'FleetdetailstemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        
        if (this.data.success == true) {
          if(this.data.lpagriFleetDetList!=null){
            this.hidType=true;
          this.model.fleetdetails = this.data.lpagriFleetDetList;
          this.relationwithBorrwerList=this.data.relationwithborrList;
          this.borrowerType = this.data.ownerNameList;
          this.model.fleetdetails.forEach(element => {
            element.afdInstallAmt = this.toFixCall(element.afdInstallAmt);
            element.afdInstallLiability = this.toFixCall(element.afdInstallLiability);
            element.afdMarketValue = this.toFixCall(element.afdMarketValue);
            this.borrowerType.forEach(value => {
              if(value.custId==element.afdOwnerId)
              {
                element.afdOwnerId=value.custName;
              }
              
            });
            this.relationwithBorrwerList.forEach(master => {
              if ( element.afdBorrRelation == master.llvOptionVal) {
                element.afdBorrRelation = master.llvOptionDesc;
              }
            });

          });
        }
         

        }
      },
      error => {
      });
  }
  toFixCall(value)
  {  let temp="";
    if(value!=="" && value!=null)
   {
     temp=parseFloat(value).toFixed(2);
   }
  return temp;
  }
}
