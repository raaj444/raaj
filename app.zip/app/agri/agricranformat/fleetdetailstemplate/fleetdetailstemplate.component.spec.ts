import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FleetdetailstemplateComponent } from './fleetdetailstemplate.component';

describe('FleetdetailstemplateComponent', () => {
  let component: FleetdetailstemplateComponent;
  let fixture: ComponentFixture<FleetdetailstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FleetdetailstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FleetdetailstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
