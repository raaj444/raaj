import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
@Component({
  selector: 'lp-additionalinctemplate',
  templateUrl: './additionalinctemplate.component.html',
  styleUrls: ['./additionalinctemplate.component.css']
})
export class AdditionalinctemplateComponent  implements OnInit {   data:any; 
  componentlist :any=[];
  model: any = {};
  hidType: boolean;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }
  ngOnInit() {
    this.hidType=true
   this.componentlist = [
        {
          name: 'AdditionalinctemplateComponent',cranType:this.cranTypeFromResolver
        },
      ];
    this.cranService.getAgriDataCranList(this.componentlist)
       .subscribe(
          data => { this.data=data; 
            
            
             if (this.data.success == true) {
              if( this.data.responseData != null)
              {
                this.hidType=false;
              this.model = this.data.responseData;
              if (this.model.laDiary != " " && this.model.laDiary  !=null) { this.model.laDiary = this.model.laDiary.toFixed(2); } 
              if (this.model.laPoultry != " " && this.model.laPoultry  !=null) { this.model.laPoultry = this.model.laPoultry.toFixed(2); }
              if (this.model.laFishery != " " && this.model.laFishery  !=null){ this.model.laFishery = this.model.laFishery.toFixed(2); }
              if (this.model.laCombHarv != " " && this.model.laCombHarv  !=null){ this.model.laCombHarv = this.model.laCombHarv.toFixed(2); }
              if (this.model.laJcb != " " && this.model.laJcb  !=null){ this.model.laJcb = this.model.laJcb.toFixed(2); }
              if (this.model.laTractor != " " && this.model.laTractor  !=null){ this.model.laTractor = this.model.laTractor.toFixed(2); }
              if (this.model.laOthrAgri != " " && this.model.laOthrAgri  !=null){ this.model.laOthrAgri = this.model.laOthrAgri.toFixed(2); }
              if (this.model.laSalary != " " && this.model.laSalary  !=null){ this.model.laSalary = this.model.laSalary.toFixed(2); }
              if (this.model.laRental != " " && this.model.laRental  !=null){ this.model.laRental = this.model.laRental.toFixed(2); }
              if (this.model.laBusInc != " " && this.model.laBusInc  !=null){ this.model.laBusInc = this.model.laBusInc.toFixed(2); }
              if (this.model.laVehHir != " " && this.model.laVehHir  !=null){ this.model.laVehHir = this.model.laVehHir.toFixed(2); }
              if (this.model.laOthersNonagri  != " " && this.model.laOthersNonagri  !=null){ this.model.laOthersNonagri = this.model.laOthersNonagri.toFixed(2); }
              if (this.model.laTotAgri != " " && this.model.laTotAgri  !=null){ this.model.laTotAgri = this.model.laTotAgri.toFixed(2); }
              if (this.model.laTotNonagri != " " && this.model.laTotNonagri  !=null){ this.model.laTotNonagri = this.model.laTotNonagri.toFixed(2); }
               }
            
             }   
            },
          error => {                          
          }); 
    }

}
