import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalinctemplateComponent } from './additionalinctemplate.component';

describe('AdditionalinctemplateComponent', () => {
  let component: AdditionalinctemplateComponent;
  let fixture: ComponentFixture<AdditionalinctemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalinctemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalinctemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
