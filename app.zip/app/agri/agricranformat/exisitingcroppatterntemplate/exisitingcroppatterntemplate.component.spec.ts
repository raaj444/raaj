import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExisitingcroppatterntemplateComponent } from './exisitingcroppatterntemplate.component';

describe('ExisitingcroppatterntemplateComponent', () => {
  let component: ExisitingcroppatterntemplateComponent;
  let fixture: ComponentFixture<ExisitingcroppatterntemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExisitingcroppatterntemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExisitingcroppatterntemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
