import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
@Component({
  selector: 'lp-exisitingcroppatterntemplate',
  templateUrl: './exisitingcroppatterntemplate.component.html',
  styleUrls: ['./exisitingcroppatterntemplate.component.css']
})
export class ExisitingcroppatterntemplateComponent  implements OnInit {   data:any; 

  componentlist :any=[];
  model: any = {};
  cropNameList = [];
  cropSeasonList=[];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.componentlist = [
      {
        name: 'ExisitingcroppatterntemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
  this.cranService.getAgriDataCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
          
          if (this.data.success) {
            this.cropNameList = this.data.responseData.cropNameList;
            this.cropSeasonList = this.data.responseData.cropSeasonList;
            this.model.prevcroppatternArray = [];
            if(this.data.responseData.reqDueDataList!=null){
            this.data.responseData.reqDueDataList.forEach(element => {
              this.model.prevcroppatternArray.push(element)

              this.model.prevcroppatternArray.forEach((element, index) => {
           
                 this.cropNameList.forEach(value => {
                   if(value.llvOptionVal==element.lpcpCropId)
                   {
                    element.lpcpCropId=value.llvOptionDesc;
                   }
                 });
                 this.cropSeasonList.forEach(value => {
                  if(value.llvOptionVal==element.lpcpSeason)
                  {
                   element.lpcpSeason=value.llvOptionDesc;
                  }
                });
              });
            });}
            // if (this.model.prevcroppatternArray.length < 1)
  
            //   this.model.prevcroppatternArray = [{ lpcpYear: '', lpcpSeason: 's', lpcpCropId: 's', lpcpAreaCultivated: '', lpcpYieldPerAcre: '', lpcpRatePerQuintal: '', lpcpGrossRevenue: '', lpcpCropSoldDet: '' }];
          } 
          },
        error => {                 
        }); 
  }

}
