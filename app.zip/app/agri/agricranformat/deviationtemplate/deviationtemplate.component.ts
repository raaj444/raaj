import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-deviationtemplate',
  templateUrl: './deviationtemplate.component.html',
  styleUrls: ['./deviationtemplate.component.css']
})
export class DeviationtemplateComponent implements OnInit {

  data: any;
  hidtype: boolean;
  componentlist: any = [];
  model: any = {};
  protermcondList = [];
  userDefList =[];
  SysDefList =[];
  deviationList =[];
  userview:boolean;
  sysDefview:boolean;
  devview: boolean;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.devview=false;

    this.componentlist = [
      {
        name: 'DeviationtemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        this.userDefList=[];
        this.SysDefList=[];
        if (this.data.success == true) {
          this.deviationList=this.data.deviationList;
        if(this.deviationList.length >0)
        {
          this.devview=true;
          this.deviationList.forEach(element =>{
            if(element.ldDevType=='U')
            {
              this.userDefList.push(element);
            }
           else
           {
            this.SysDefList.push(element);
           }
          })

          if(this.userDefList.length >0)
          {
            this.userview=true;
          }
          if(this.SysDefList.length >0)
          {
            this.sysDefview=true;
          }
        }
        }
      },
      error => {        
      });
  }

}

