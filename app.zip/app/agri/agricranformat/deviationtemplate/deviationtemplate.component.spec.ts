import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviationtemplateComponent } from './deviationtemplate.component';

describe('DeviationtemplateComponent', () => {
  let component: DeviationtemplateComponent;
  let fixture: ComponentFixture<DeviationtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviationtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviationtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
