import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-droplineodtemplate',
  templateUrl: './droplineodtemplate.component.html',
  styleUrls: ['./droplineodtemplate.component.css']
})
export class DroplineodtemplateComponent implements OnInit {
  componentlist: any = [];
  model: any = {};
  lpagriDropLineODDetails = [];
  dropview: any;
  data: any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.dropview = false;
    this.componentlist = [
      {
        name: 'DroplineodtemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.lpagriDropLineODDetails = this.data.lpagriDropLineODDetails;
            if (this.lpagriDropLineODDetails.length > 0) {
              this.dropview = true;
            }

          }
        },
        error => {          
        });
  }

}
