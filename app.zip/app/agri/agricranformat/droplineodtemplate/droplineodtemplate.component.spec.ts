import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DroplineodtemplateComponent } from './droplineodtemplate.component';

describe('DroplineodtemplateComponent', () => {
  let component: DroplineodtemplateComponent;
  let fixture: ComponentFixture<DroplineodtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DroplineodtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DroplineodtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
