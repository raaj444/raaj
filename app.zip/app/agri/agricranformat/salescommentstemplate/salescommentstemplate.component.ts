import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-salescommentstemplate',
  templateUrl: './salescommentstemplate.component.html',
  styleUrls: ['./salescommentstemplate.component.css']
})
export class SalescommentstemplateComponent implements OnInit {
    data: any;

  hidView2: boolean;
  hidView3: boolean;
  hidView1: boolean;
  hidView: boolean;
  model: any = {};
  componentlist: any = [];
  lpaiCommentsSale: any = {};
  lpaiCommentsTVR: any = {};
  lpaiCommentsBorrower: any = {};
  lpaiCommentsVisit: any = {};
  lpaiRMCommentsSale:any={};
  salescomments: any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.hidView = false;
    this.hidView1 = false;
    this.hidView2 = false;
    this.hidView3 = false;
    this.componentlist = [
      {
        name: 'SalescommentstemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
        data => {
        this.data = data;
          if (this.data.success == true) {

            if (this.data.lpaiCommentsSale != null) {
              this.hidView = true;
              this.lpaiCommentsSale = this.data.lpaiCommentsSale;
            }
            else {
              this.lpaiCommentsSale = "No Data Found";
            }

            if (this.data.lpaiRMCommentsSale != null) {
              this.hidView = true;
              this.lpaiRMCommentsSale = this.data.lpaiRMCommentsSale;
            }
            else {
              this.lpaiRMCommentsSale = "No Data Found";
            }

            if (this.data.lpaiCommentsTVR != null) {
              this.hidView1 = true;
              this.lpaiCommentsTVR = this.data.lpaiCommentsTVR;
            } else {
              this.lpaiCommentsTVR = "No Data Found";
            }

            if (this.data.lpaiCommentsBorrower != null) {
              this.hidView2 = true;
              this.lpaiCommentsBorrower = this.data.lpaiCommentsBorrower;
            }
            else {
              this.lpaiCommentsBorrower = "No Data Found";
            }
            if (this.data.lpaiCommentsVisit != null) {
              this.hidView3 = true;
              this.lpaiCommentsVisit = this.data.lpaiCommentsVisit;
            } else {
              this.lpaiCommentsVisit = "No Data Found";
            }




          }
        },
        error => {
        });
  }

}
