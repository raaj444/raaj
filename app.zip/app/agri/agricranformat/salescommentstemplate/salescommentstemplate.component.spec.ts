import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalescommentstemplateComponent } from './salescommentstemplate.component';

describe('SalescommentstemplateComponent', () => {
  let component: SalescommentstemplateComponent;
  let fixture: ComponentFixture<SalescommentstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalescommentstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalescommentstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
