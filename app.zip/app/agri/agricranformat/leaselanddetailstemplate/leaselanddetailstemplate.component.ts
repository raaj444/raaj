import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-leaselanddetailstemplate',
  templateUrl: './leaselanddetailstemplate.component.html',
  styleUrls: ['./leaselanddetailstemplate.component.css']
})
export class LeaselanddetailstemplateComponent  implements OnInit {   data:any; 
  componentlist :any=[];
  model: any = {};
  leaseNameList = [];
  listOfleasesList = [];
  stateList: any = [];
  borRelationList: any = [];
  kycTypeList: any = [];
  partiesCRNList: any = [];
  cityDetails: any = [];
  districtList: any = [];
  totalcul:any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'LeaselanddetailstemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
 
  this.cranService.getAgriDataCranList(this.componentlist)
    .subscribe(
        data => { this.data=data; 
          if (this.data.success == true) {
            
              
                
          this.model.leaseLandDetArray = this.data.LeaseLandDetails;
          this.borRelationList = this.data.borrowerRelationList;
          this.kycTypeList = this.data.kycproofTypeList;
          this.stateList = this.data.talukList;
          this.totalcul=0.00;
          if(this.model.leaseLandDetArray.length >0)
          {
          this.model.leaseLandDetArray.forEach(lease => {
            this.borRelationList.forEach(master => {
              
              if (master.llvOptionVal == lease.lldBorRelationship) {
                lease.lldBorRelationship = master.llvOptionDesc;
              }
            });
            this.kycTypeList.forEach(master => {
              if (master.llvOptionVal == lease.lldKycType) {
                lease.lldKycType = master.llvOptionDesc;
              }
            });
            
            this.stateList.forEach(statecity => {
              statecity.forEach(state => {
              if (state.sgmStateCode == lease.lldStateid) {
                lease.lldStateid = state.sgmStateName;
              }
              if (state.sgmCityCode == lease.lldDistrictid) {
                lease.lldDistrictid = state.sgmCityName;
              }
               
              if (state.lgmTalukCode == lease.lldTalukid) {
                lease.lldTalukid = state.lgmTalukName;
              }  
            });
          });
          if (lease.lldCulArea !== "" && lease.lldCulArea != null && lease.lldCulArea != undefined) {
            this.totalcul = parseFloat(lease.lldCulArea) + parseFloat(this.totalcul);
          }
            });
          }
          }
          },
        error => {
        }); 
  }

}
