import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaselanddetailstemplateComponent } from './leaselanddetailstemplate.component';

describe('LeaselanddetailsComponent', () => {
  let component: LeaselanddetailstemplateComponent;
  let fixture: ComponentFixture<LeaselanddetailstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaselanddetailstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaselanddetailstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
