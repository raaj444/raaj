import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityapprovalComponent } from './facilityapproval.component';

describe('FacilityapprovalComponent', () => {
  let component: FacilityapprovalComponent;
  let fixture: ComponentFixture<FacilityapprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacilityapprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityapprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
