import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-facilityapproval',
  templateUrl: './facilityapproval.component.html',
  styleUrls: ['./facilityapproval.component.css']
})
export class FacilityapprovalComponent implements OnInit {
  data:any; 
  hidView1: boolean;
  hidView: boolean;
  model: any = {};
  kkrPremium: any = {};
  componentlist: any = [];
  reqDueDataList: any = [];
  borrowerType: any = [];
  private AgritermloanList: Array<any> = [];
  private facilityDetailsList: Array<any> = [];
  listOfValuesList = [];
  tempagritermloanList: Array<any> = [];
  kkrview: boolean = false;
  strProposedLimit: any = 0.00;
  totalAmount: any = 0.00;
  exposureAmount: any = 0.00;
  totalexposureAmount: any = 0.00;
  strTotalLimit: any = 0.00;
  strExistTotal: any = 0.00;
  totalExposureSanLimit: any = 0.00;
  totalExposureCrdRec: any = 0.00;
  totalExposureSalRec: any = 0.00;
  totalExposureProp: any;
  relationwithbor=[];
  RelationwithBorrowerkkr=[];
  lpagriDropLineODDetails = [];
  finalAmt: any =0.00;
  strSalRecmdAmount: String; strCrdRecmdAmount: String; strSancLimit: String;
  strGrandExistTotal:any=0.00;strGrandProposedLimit:any=0.00;strGrandSancLimit:any=0.00;

  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.kkrPremium.lkpPremAmount = 0.00;
    this.kkrview = false;
    this.hidView=false;
    this.finalAmt=0.00;
    this.componentlist = [
      {
        name: 'AgritermLoantemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.model.facilityDetailsList = this.data.responseData.FacilityList;
          this.model.exposures = this.data.exposures;

if(this.model.exposures)
{
  this.model.exposures.forEach(element => {
    if(element.lfExistLimit)
    element.lfExistLimit=element.lfExistLimit.toFixed(2);
    if(element.lfProposedLimit)
    element.lfProposedLimit=element.lfProposedLimit.toFixed(2);
    if(element.lfSancLimit)
    element.lfSancLimit=element.lfSancLimit.toFixed(2);
    
  });
}


          if(this.data.responseDataKKR==null)
           this.kkrPremium.lkpPremAmount = 0.00;
          else{
          this.kkrPremium=this.data.responseDataKKR;
          if(this.kkrPremium)
          this.kkrPremium.lkpPremAmount=this.kkrPremium.lkpPremAmount.toFixed(2)
          else
          this.kkrPremium.lkpPremAmount = 0.00;
          }
          this.exposureAmount = this.data.lpcomExposureAmount;
          let totalLimit = 0; let vartotallimit = 0;
          let varexistTotal = 0; let varProposedLimit = 0;
          if(this.exposureAmount)
          this.exposureAmount = this.exposureAmount.toFixed(2);
          
          this.lpagriDropLineODDetails = this.data.lpagriDropLineODDetails;         
          this.getTotal('S', 'C', 'SL');
         
        }
      });

  }
  getTotal(valSal: any, valCrd: any, valSanc: any) {
    let varSalTotal = 0; let varCrdTotal = 0; let varSancTotal = 0; let totalLimit = 0; let vartotallimit = 0;
    let varexistTotal = 0; let varProposedLimit = 0;
     
    this.model.exposures.forEach(field1 => {
      field1.totalLimit = this.parseEmptytoFloat(field1.lfExistLimit) + this.parseEmptytoFloat(field1.lfProposedLimit);
      vartotallimit = vartotallimit + this.parseEmptytoFloat(field1.totalLimit);
      varexistTotal = varexistTotal + field1.lfExistLmtTakeOver=="N" ? this.parseEmptytoFloat(field1.lfExistLimit) : 0;
      field1.totalLimit = this.parseEmptytoFloat(field1.totalLimit).toFixed(2);
      if (field1.lfExistLimit != 0)
        field1.lfExistLimit = this.parseEmptytoFloat(field1.lfExistLimit).toFixed(2);

      if (field1.lfProposedLimit != null && field1.lfProposedLimit !== "")
        varProposedLimit = varProposedLimit + this.parseEmptytoFloat(field1.lfProposedLimit);
      else
        varProposedLimit = varProposedLimit + 0;
      if (field1.lfSalesRecmd != null && field1.lfSalesRecmd !== "")
        varSalTotal = varSalTotal + this.parseEmptytoFloat(field1.lfSalesRecmd);
      else
        varSalTotal = varSalTotal + 0;
      if (field1.lfCreditRecmd != null && field1.lfCreditRecmd !== "")
        varCrdTotal = varCrdTotal + this.parseEmptytoFloat(field1.lfCreditRecmd);
      else
        varCrdTotal = varCrdTotal + 0;
      if (field1.lfSancLimit != null && field1.lfSancLimit !== "") {
        if (field1.lfRecmd == 'Y')
          varSancTotal = varSancTotal + this.parseEmptytoFloat(field1.lfSancLimit);
      }
      else
        varSancTotal = varSancTotal + 0;
        if (this.lpagriDropLineODDetails.length > 0) {
          this.lpagriDropLineODDetails.forEach(drop => {
            if(drop.ldFacno== field1.lfFacNo)
            {
              field1.ldFrequency=drop.ldFrequency;
              field1.ldDropamt=drop.ldDropamt;
                if(field1.ldFrequency=='M')
                {
                  field1.ldFrequency='Monthly';
                }
                else if(field1.ldFrequency=='Q')
                {
                  field1.ldFrequency='Quaterly';
                }
                else  if(field1.ldFrequency=='H')
                {
                  field1.ldFrequency='Half-Yearly';
                }
               else  if(field1.ldFrequency=='Y')
                {
                  field1.ldFrequency='Yearly';
                }
                else
                {
                  field1.ldFrequency='';
                }
            }
          });
        }
        else
        {
          field1.ldFrequency="";
          field1.ldDropamt="";

        }
    });

    this.strGrandExistTotal=varexistTotal.toFixed(2);
    this.strGrandProposedLimit=varProposedLimit.toFixed(2);
    this.strGrandSancLimit=varSancTotal.toFixed(2);

    varSalTotal = varSalTotal + this.parseEmptytoFloat(this.kkrPremium.lkpPremAmount);
    varCrdTotal = varCrdTotal + this.parseEmptytoFloat(this.kkrPremium.lkpPremAmount);
    varSancTotal = varSancTotal + this.parseEmptytoFloat(this.kkrPremium.lkpPremAmount);
    varProposedLimit = varProposedLimit + this.parseEmptytoFloat(this.kkrPremium.lkpPremAmount);


    this.totalExposureProp =  varProposedLimit;
    this.totalExposureCrdRec = this.parseEmptytoFloat(this.exposureAmount) + varCrdTotal;
    this.totalExposureSalRec = this.parseEmptytoFloat(this.exposureAmount) + varSalTotal;
    this.totalExposureSanLimit = this.parseEmptytoFloat(this.exposureAmount) + varSancTotal;

    if (varProposedLimit != 0.00)
      this.strProposedLimit = varProposedLimit.toFixed(2);
    this.totalAmount = vartotallimit + this.parseEmptytoFloat(this.kkrPremium.lkpPremAmount);
    this.totalexposureAmount = this.parseEmptytoFloat(this.exposureAmount) + this.totalAmount;
    this.totalAmount = this.totalAmount.toFixed(2);
    this.strExistTotal = varexistTotal.toFixed(2);
    this.totalExposureProp = this.parseEmptytoFloat(this.totalExposureProp).toFixed(2);
    this.totalExposureCrdRec = this.parseEmptytoFloat(this.totalExposureCrdRec).toFixed(2);
    this.totalExposureSalRec = this.parseEmptytoFloat(this.totalExposureSalRec).toFixed(2);
    this.totalExposureSanLimit = this.parseEmptytoFloat(this.totalExposureSanLimit).toFixed(2);
    this.totalexposureAmount = this.parseEmptytoFloat(this.totalexposureAmount).toFixed(2);


    if (valSal == 'S') {
      if (varSalTotal != 0.00)
        this.strSalRecmdAmount = varSalTotal.toFixed(2);
      else
        this.strSalRecmdAmount = "";
    }
    if (valCrd == 'C') {
      if (varCrdTotal != 0.00)
        this.strCrdRecmdAmount = varCrdTotal.toFixed(2);
      else
        this.strCrdRecmdAmount = "";
    }
    if (valSanc == 'SL') {
      if (varSancTotal != 0.00)
        this.strSancLimit = varSancTotal.toFixed(2);
      else
        this.strSancLimit = "";
    }

    if (varProposedLimit != 0.00)
      this.strProposedLimit = varProposedLimit.toFixed(2);
    else
      this.strProposedLimit = "";
    this.strExistTotal = varexistTotal.toFixed(2);

  
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}
