import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
import { DscrService } from '../../../util/service/agriservices/dscr.service';

@Component({
  selector: 'lp-dscrtemplate',
  templateUrl: './dscrtemplate.component.html',
  styleUrls: ['./dscrtemplate.component.css']
})
export class DscrtemplateComponent implements OnInit {
  data: any;
  componentlist :any=[];
  model: any = {};
  incomeAgriList: any = [];
  yeildMasterList: any = [];
  incomeOtherList: any = [];
  expenseAgriList: any = [];
  familyExpenseList: any = [];
  loanLiabilityList: any = [];
  currentcorpPatternList: any = [];
  listOfValuesList: any = [];
  cropYieldMasterList: any = [];
  cropIncomeList: any = [];
  facilityList: any = [];
  repayfreqList: any = [];
  totIncomeConsi: any = 0.00;
  disableEditButton: boolean = false;
  disableSaveButton: boolean = true;
  disableCancelButton: boolean = true;
  disableFields: boolean = true;
  disableLLFields: boolean = true;
  totIncome: any = 0.00;
  totOtherIncome: any = 0.00;
  totExpense: any = 0.00;
  totFamilyExpense: any = 0.00;
  totLoanLiability: any = 0.00;
  finTotExpense: any = 0.00;
  netTotSurpulus: any = 0.00;
  dscrRatio: any = 0.00;
  totincomeAgri: any = 0.00;
  netIncome: any = 0.00;
  totofferedKccAmt: any;
  loanLListLength: any;
  getDataLoanLength: any;
  pageAccess: any;
  loanComments: string="Principle Repayment + Interest";
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService,private dscrService: DscrService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'DscrtemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
  this.cranService.getAgriDataCranList(this.componentlist)
     .subscribe(
        data => { 
          this.data = data;
          if (this.data.success == true) {
            
            this.incomeAgriList = this.data.responseData.incomeAgriExpenseList;
            this.incomeOtherList = this.data.responseData.incomeOtherExpenseList;
            this.expenseAgriList = this.data.responseData.expenseAgriList;
            this.familyExpenseList = this.data.responseData.familyExpenseList;
            this.loanLiabilityList = this.data.responseData.loanLiabilityList;
            this.getDataLoanLength=this.loanLiabilityList.length;
            this.currentcorpPatternList = this.data.responseData.lpagriCurrCropPatternList;
            this.yeildMasterList = this.data.responseData.lpagriYieldMasterList;
            this.listOfValuesList = this.data.responseData.lpmasListofvalueList;
            this.facilityList = this.data.responseData.facilityList;
            this.repayfreqList = this.data.responseData.repayfreqList;
            this.totofferedKccAmt = this.data.responseData.totOfferedKccAmt;
            this.totIncomeConsi = 0.00;
            this.dscrService.getExistingExposure(this.model)
              .subscribe(
              data => {
                this.data = data;
                if (this.data.success) {
                  
                  this.model.exposures = [];
                  this.model.exposures = this.data.responseData.exposures;
                }
              });
            for (let i = 0; i < this.currentcorpPatternList.length; i++) {
              var flag = false;
              for (let j = 0; j < this.yeildMasterList.length; j++) {
                if (this.currentcorpPatternList[i].lpcpStateId == this.yeildMasterList[j].lymStatecode && this.currentcorpPatternList[i].lpcpCropId == this.yeildMasterList[j].lymCropcode) {
                  this.cropYieldMasterList.push({ 'acres': this.yeildMasterList[j].lymPeracres, 'price': this.yeildMasterList[j].lymRateQt });
                  flag = true;
                }
              }
              if (!flag) {
                this.cropYieldMasterList.push({ 'acres': '0', 'price': '0' });
              }
            }
  
            for (let i = 0; i < this.currentcorpPatternList.length; i++) {
              for (let j = 0; j < this.listOfValuesList.length; j++)
                if (this.currentcorpPatternList[i].lpcpCropId == this.listOfValuesList[j].llvOptionVal)
                  this.cropIncomeList.push({ 'cropName': this.listOfValuesList[j].llvOptionDesc, 'totalAcres': this.currentcorpPatternList[i].lpcpAreaCultivated, 'yieldPerAcre': this.cropYieldMasterList[i].acres, 'pricePerAcre': this.cropYieldMasterList[i].price, 'expectedIncome': (this.parseEmptytoFloat(this.currentcorpPatternList[i].lpcpAreaCultivated) * this.parseEmptytoFloat(this.cropYieldMasterList[i].acres) * this.parseEmptytoFloat(this.cropYieldMasterList[i].price)).toFixed(2) })
            }
          
            var time = setInterval(() => {
              
              this.totIncomeConsi = 0.00;
              this.totIncome = 0.00;
              this.totOtherIncome = 0.00;
              this.totExpense = 0.00;
              this.totFamilyExpense = 0.00;
              this.totLoanLiability = 0.00;
              this.finTotExpense = 0.00;
              this.netTotSurpulus = 0.00;
              this.dscrRatio = 0.00;
              var total = 0.00;
              this.netIncome=0.00;
              this.cropIncomeList.forEach(currentCrop => {
                total += this.parseEmptytoFloat(currentCrop.expectedIncome);
                this.totIncomeConsi = total.toFixed(2);
  
              });
              if (this.incomeAgriList.length == 0) {
                let modelincomeAgri = {
                  ldComments: "As per above calculations", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IAE",
                  ldHeader: "Income from Agri land", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: this.totIncomeConsi, lpcomProposal: ""
                }
                this.totincomeAgri = this.totIncomeConsi;
                this.incomeAgriList.push(modelincomeAgri);
              }
              else {
                this.totincomeAgri = 0.00;
                var total = 0.00;
                this.incomeAgriList.forEach((inc, index) => {
                  if (index == 0) {
                    inc.ldValue = this.totIncomeConsi;
                  }
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totincomeAgri = total.toFixed(2);
                });
              }
  
              if (this.incomeOtherList.length == 0) {
                let modelincomeOther = {
                  ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IOE",
                  ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", lpcomProposal: ""
                }
                this.incomeOtherList.push(modelincomeOther);
              } else {
                this.totOtherIncome = 0.00;
                var total = 0.00;
                this.incomeOtherList.forEach((inc, index) => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totOtherIncome = total.toFixed(2);
                });
              }
              if (this.expenseAgriList.length == 0) {
                let modelexpenseAgri = {
                  ldComments: "Cost of cultivation of Crops to be funded", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "AE",
                  ldHeader: "Agri Expenses", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: this.totofferedKccAmt, lpcomProposal: ""
                }
                this.expenseAgriList.push(modelexpenseAgri);
                this.totExpense = 0.00;
                var total = 0.00;
                this.expenseAgriList.forEach(inc => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totExpense = total.toFixed(2);
                });
                // if(this.totofferedKccAmt =='0')
                // alert("Kindly please Freeze the KCC Assessment to auto populate Expense value.");
              } else {
                this.totExpense = 0.00;
                var total = 0.00;
                this.expenseAgriList.forEach((inc, index) => {
                  if (index == 0) {
                    inc.ldValue = this.totofferedKccAmt;
                  }
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totExpense = total.toFixed(2);
                });
              }
              if (this.familyExpenseList.length == 0) {
                let modelfamilyExpense = {
                  ldComments: "No of Dependents -", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "FE", ldFeInpval1: "", ldFeComments: "Per Person Per Month Expenses Rs.",
                  ldHeader: "Other Expenses", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", lpcomProposal: ""
                }
                this.familyExpenseList.push(modelfamilyExpense);
                this.totFamilyExpense = 0.00;
                var total = 0.00;
                this.familyExpenseList.forEach(inc => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totFamilyExpense = total.toFixed(2);
                });
              } else {
                this.totFamilyExpense = 0.00;
                var total = 0.00;
                this.familyExpenseList.forEach(inc => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totFamilyExpense = total.toFixed(2);
                });
              }
              if (this.loanLiabilityList.length == 0) {
                let modelloanLiability = {
                  ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "LL",
                  ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", ldLlInpval: "", lpcomProposal: "",
                }
                //this.loanLiabilityList.push(modelloanLiability);
                var busApp=false;
                this.calculateLoanLiabilityList();
                this.totLoanLiability = 0.00;
                var total = 0.00;
                this.loanLiabilityList.forEach(inc => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totLoanLiability = total.toFixed(2);
                  if(inc.ldLlInpval=='0')
                  {
                    busApp=true;
                  }
                });
              
              } else {
                this.totLoanLiability = 0.00;
                var total = 0.00;
                this.loanLListLength = this.facilityList.length - 1;
                this.calculateLoanLiabilityList();
                this.loanLiabilityList.forEach(inc => {
                  total += this.parseEmptytoFloat(inc.ldValue);
                  this.totLoanLiability = total.toFixed(2);
  
                });
              }
              this.totIncome = this.parseEmptytoFloat(this.totincomeAgri) + this.parseEmptytoFloat(this.totOtherIncome);
              this.totIncome = this.parseEmptytoFloat(this.totIncome).toFixed(2);              
              var tot = this.parseEmptytoFloat(this.totExpense) + this.parseEmptytoFloat(this.totFamilyExpense) + this.parseEmptytoFloat(this.totLoanLiability);
              this.finTotExpense = tot.toFixed(2);              
              this.netTotSurpulus = (this.totIncome - this.finTotExpense).toFixed(2);              
              // calculation for dscr               
              var totincome = ((this.parseEmptytoFloat(this.totincomeAgri) / 100000) + (this.parseEmptytoFloat(this.totOtherIncome) / 100000));              
              var totexpensess = ((this.parseEmptytoFloat(this.totExpense) / 100000) + (this.parseEmptytoFloat(this.totFamilyExpense) / 100000) + (this.parseEmptytoFloat(this.totLoanLiability) / 100000));              
              var netsurpulus = (totincome - totexpensess);              
              var netIncome = (totincome - (this.parseEmptytoFloat(this.totExpense) / 100000) - (this.parseEmptytoFloat(this.totFamilyExpense) / 100000));              
              this.netIncome = netIncome.toFixed(2);
              var dscrratio = (netIncome / (this.parseEmptytoFloat(this.totLoanLiability) / 100000));              
              dscrratio = this.parseEmptytoFloat(dscrratio);
              if (dscrratio < 0 || dscrratio == Infinity) {
                dscrratio = 0.00;
              }
              this.dscrRatio = dscrratio.toFixed(2);
  
              clearInterval(time);
            }, 600);
          }
        },
       
        error => {                 
        }); 
  }
  calculateLoanLiabilityList() {
    this.facilityList.forEach(fcList => {
      
      //Annual Installment Calculation 
      
    
      if (fcList.prdDesc == "KCC" && fcList.repayFreq == "0") {

        var monthlyInterestRatio = (fcList.intrate / 100) / 12;
        var top = Math.pow((1 + monthlyInterestRatio), fcList.tenor);
        var bottom = top - 1;
        var emi = ((fcList.proposalLimit * monthlyInterestRatio * top) / bottom);
        var repay = emi;
        var a = (repay * fcList.tenor);
        var b = (a - fcList.proposalLimit);
        var tempInstAmt = (b / (fcList.tenor / 12));
        if (tempInstAmt < 0 || tempInstAmt == Infinity) {
          tempInstAmt = 0.00;
        }
        var InstallmentAmt = tempInstAmt.toFixed(2);
      }
      // Default
      else if (fcList.prdDesc != "KCC" && fcList.repayFreq == "0") {
        var tempInstAmt = 0.00;
        var InstallmentAmt = tempInstAmt.toFixed(2);
      }

      else {
        var monthlyInterestRatio = (fcList.intrate / 100) / 12;
        var top = Math.pow((1 + monthlyInterestRatio), fcList.tenor);
        var bottom = top - 1;
        var emi = ((fcList.proposalLimit * monthlyInterestRatio * top) / bottom);
        var tempInstAmt = emi * 12;
        if (tempInstAmt < 0 || tempInstAmt == Infinity) {
          tempInstAmt = 0.00;
        }
        var InstallmentAmt = tempInstAmt.toFixed(2);
      }


      if (this.getDataLoanLength > 1) {
        for (let i = 0; i < this.loanLiabilityList.length; i++) {
          var proddesc = fcList.prdDesc + " Annual Installment";
          if (proddesc == this.loanLiabilityList[i].ldHeader) {
            this.loanLiabilityList[i].ldValue = InstallmentAmt;
            this.loanLiabilityList[i].ldLlInpval = fcList.intrate;
            break;
          }

        }
      }
      else {
        this.loanLiabilityList.push({
          ldHeader: fcList.prdDesc + " Annual Installment", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "LL",
          ldComments: this.loanComments, ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: InstallmentAmt, ldLlInpval: fcList.intrate, lpcomProposal: ""
        });        
      }

    });

    this.loanLListLength = this.facilityList.length - 1;
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

}

