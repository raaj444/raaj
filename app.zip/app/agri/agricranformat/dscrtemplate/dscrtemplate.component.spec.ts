import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DscrtemplateComponent } from './dscrtemplate.component';

describe('DscrtemplateComponent', () => {
  let component: DscrtemplateComponent;
  let fixture: ComponentFixture<DscrtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DscrtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DscrtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
