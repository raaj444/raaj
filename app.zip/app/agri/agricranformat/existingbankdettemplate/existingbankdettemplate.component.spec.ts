import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingbankdettemplateComponent } from './existingbankdettemplate.component';

describe('ExistingbankdettemplateComponent', () => {
  let component: ExistingbankdettemplateComponent;
  let fixture: ComponentFixture<ExistingbankdettemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingbankdettemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingbankdettemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
