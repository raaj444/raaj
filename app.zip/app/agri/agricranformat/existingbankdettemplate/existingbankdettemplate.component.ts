import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
@Component({
  selector: 'lp-existingbankdettemplate',
  templateUrl: './existingbankdettemplate.component.html',
  styleUrls: ['./existingbankdettemplate.component.css']
})
export class ExistingbankdettemplateComponent  implements OnInit {   data:any; 

  hidType: boolean;
  componentlist :any=[];
  model: any = {};
  partiesCRNList : any= [];
  bankNames: any= [];
  bankAccountType: any= [];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }
  
  ngOnInit() {
 this.componentlist = [
      {
        name: 'ExistingbankdettemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.model.existingbankdetails=[];
    this.partiesCRNList = [];
  this.cranService.getAgriDataCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
          
          if(this.data.success){
            if(this.data.ExistingBankDetails!=null){
            this.model.existingbankdetails=this.data.ExistingBankDetails;
            }
            this.partiesCRNList = this.data.responseData.LpcomCustInfoApplist;
            this.bankNames = this.data.responseData.bankNames;
            this.bankAccountType = this.data.responseData.bankaccounttype;

            this.model.existingbankdetails.forEach(element => {
              this.partiesCRNList.forEach(party => {
                if(party.newId==element.lebdCustId)
                element.lebdCustId=party.name;
              });
              this.bankAccountType.forEach(type => {
                if(type.llvOptionVal==element.lebdBankAccountType)
                element.lebdBankAccountType=type.llvOptionDesc;
              });
            
              this.bankNames.forEach(name => {
                if(name.llvOptionVal==element.lebdBankName)
                element.lebdBankName=name.llvOptionDesc;
              });
            
              
            });
            // if(this.model.existingbankdetails.length<1)
            // {
            //   this.model.existingbankdetails.push({lebdRowId:0,lebdOrderNo:0,lebdPartyType:'s',
            //   lebdBankAccountType:'s',lebdBankName:'s',lebdCustId:'s'});
            // }
          
          }  
          },
        error => {                            
        }); 
  }

}
