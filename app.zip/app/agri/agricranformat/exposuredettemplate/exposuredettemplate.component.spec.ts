import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExposuredettemplateComponent } from './exposuredettemplate.component';

describe('ExposuredettemplateComponent', () => {
  let component: ExposuredettemplateComponent;
  let fixture: ComponentFixture<ExposuredettemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExposuredettemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExposuredettemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
