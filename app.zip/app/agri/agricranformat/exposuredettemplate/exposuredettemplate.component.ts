import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-exposuredettemplate',
  templateUrl: './exposuredettemplate.component.html',
  styleUrls: ['./exposuredettemplate.component.css']
})
export class ExposuredettemplateComponent implements OnInit {
    data: any;
  hidType: boolean;
  componentlist: any = [];
  model: any = {};
  cropNameList = [];
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }
  ngOnInit() {
    this.model.exposureDetails = [];
    this.hidType = false;
    this.componentlist = [
      {
        name: 'ExposuredettemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
        data => {
        this.data = data;
          if (this.data.success == true) {

            if (this.data.responseData != null) {
              this.hidType = true;
              this.model.exposureDetails = this.data.lpcomExposureDetList;

            }
          }
        },
        error => {
        });
  }

}


