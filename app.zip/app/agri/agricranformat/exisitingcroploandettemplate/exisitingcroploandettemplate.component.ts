import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
import { CropexistingloandetailsService } from '../../../util/service/agriservices/cropexistingloandetails.service';

@Component({
  selector: 'lp-exisitingcroploandettemplate',
  templateUrl: './exisitingcroploandettemplate.component.html',
  styleUrls: ['./exisitingcroploandettemplate.component.css']
})
export class ExisitingcroploandettemplateComponent  implements OnInit {   data:any; 
  borrowerType: any;
  hidView2: boolean;
  hidView1: boolean;
  hidView: boolean;
  componentlist :any=[];
  model: any = {};
  cropNameList = [];
  @Input()
  cranTypeFromResolver :string;
  lpmasListofvalueMap: any = {};
  constructor(private cranService: CranService) { }
        

  ngOnInit() {
    
    this.hidView=false;
    this.hidView1=false;
    this.hidView2=false;
    this.componentlist = [
      {
        name: 'ExisitingcroploandettemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    
    this.cranService.getAgriDataCranList(this.componentlist)
    .subscribe(
       data => { 
         this.data=data;
        this.borrowerType = this.data.ownerNameList;
          if (this.data.success == true) {
            this.lpmasListofvalueMap = this.data.lpmasListofvalueMap;
            if(this.data.corpExistingExposureList!=null){
              this.hidView=true;
            this.model.cropExistingExposure = this.data.corpExistingExposureList;
            }
            if(this.data.termExistingExposureList!=null){
              this.hidView1=true;
            this.model.termExistingExposure = this.data.termExistingExposureList;
            }
            if(this.data.otherExistingExposureList!=null){
              this.hidView2=true;
            this.model.otherExistingExposure = this.data.otherExistingExposureList;
            }
            this.model.cropExistingExposure.forEach(element => {
              this.borrowerType.forEach(value => {
                if(value.custId==element.lpexCustId)
                {
                  element.lpexCustId=value.custName;
                }
                
              });
            });
            this.model.termExistingExposure.forEach(element1 => {
              this.borrowerType.forEach(value => {
                if(value.custId==element1.lpexCustId)
                {
                  element1.lpexCustId=value.custName;
                }
                
              });
            });
            this.model.otherExistingExposure.forEach(element2 => {
              this.borrowerType.forEach(value => {
                if(value.custId==element2.lpexCustId)
                {
                  element2.lpexCustId=value.custName;
                }
                
              });
            });
          }

        },
      
       error => {                         
       });
  }

}
