import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExisitingcroploandettemplateComponent } from './exisitingcroploandettemplate.component';

describe('ExisitingcroploandettemplateComponent', () => {
  let component: ExisitingcroploandettemplateComponent;
  let fixture: ComponentFixture<ExisitingcroploandettemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExisitingcroploandettemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExisitingcroploandettemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
