import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-cropsurrogatetermtemplate',
  templateUrl: './cropsurrogatetermtemplate.component.html',
  styleUrls: ['./cropsurrogatetermtemplate.component.css']
})
export class CropsurrogatetermtemplateComponent implements OnInit {
  data: any;

  componentlist: any = [];

  repaymentFreq: any = [];
  SurrogateFacility: any = [];
  lpagrifleetdetList: any = [];
  SurrogateFacilityKccList: any;
  SurrogateList: any = [];
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  deletebuttonDisable: boolean
  pageAccess: any;
  fieldFacDisable: boolean;
  totincome: any;
  modelArray: any = {};
  flag: boolean;
  sum: any;
  itrdeviation: any;
  salarydeviation: any;
  vehicledeviation: any;
  kccdeviation: any;
  facid: any;
  propStatus: any;
  vehIncomeList: Array<any> = [];
  modelForChngNote: any;
  maxDate: Date; minDate: Date;
  tempagrifleetdetList: any = [];
  FacList: any = [];
  surView: boolean;
  stlTotalSancLimit:any=0.0;
  @Input()
  cranTypeFromResolver: string;

  constructor(private cranService: CranService) { }
  ngOnInit() {

    this.componentlist = [
      {
        name: 'CropsurrogatetermtemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];

    this.SurrogateFacilityKccList = 0.0;
    this.totincome = 0.0;
    this.fieldFacDisable = false;
    this.stlTotalSancLimit=0.0;
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        this.surView = false;
        if (this.data.success == true) {
          this.SurrogateList = this.data.responseData;
          this.FacList = this.data.SurrogateFacility;
          this.repaymentFreq = this.data.RepaymentFrequencyList;
          this.stlTotalSancLimit=this.data.Surrogatetlamt;
          var stlTot = 0.00;
          if (this.SurrogateList.length > 0) {
            this.surView = true;
          }
          this.SurrogateList.forEach(element => {
            if (element.lstFirstinstalDate != "" && element.lstFirstinstalDate != null) {
              var lstFirstinstalDate = element.lstFirstinstalDate;
              var lstarray = lstFirstinstalDate.split("-");
              element.lstFirstinstalDate = lstarray[2] + '/' + lstarray[1] + '/' + lstarray[0];
            }
            if (element.lstLastinstalDate != "" && element.lstLastinstalDate != null) {
              var lstLastinstalDate = element.lstLastinstalDate;
              var lstLast = lstLastinstalDate.split("-");
              element.lstLastinstalDate = lstLast[2] + '/' + lstLast[1] + '/' + lstLast[0];
            }
            /// ---------------ITR Deviation------------////////
            var lstItrAvrgedev = parseFloat(element.lstItrAvrge) / 2;
            if (lstItrAvrgedev < parseFloat(element.lstItrTlamnt)) {
              var devTemp = (parseFloat(element.lstItrTlamnt) / parseFloat(element.lstItrAvrge)) * 100;
              var deviation = this.toFixCall(devTemp);
              if (deviation < 0 || deviation == Infinity) {
                deviation = 0.00;
              }
              element.itrdeviation = "Deviation - " + deviation + "%";
            } else {
              var devTemp = (parseFloat(element.lstItrTlamnt) / parseFloat(element.lstItrAvrge)) * 100;
              var deviation = this.toFixCall(devTemp);
              if (deviation < 0 || deviation == Infinity) {
                deviation = 0.00;
              }
              element.itrdeviation = "Not a Deviation - " + deviation + "%";
            }

            /////////----End---///////
            /// ---------------ITR LTV (%)-----------////////

            var devTemp = (parseFloat(element.lstItrTlamnt) / parseFloat(element.lstItrAvrge)) * 100;
            var itrLtv = this.toFixCall(devTemp);
            if (itrLtv < 0 || itrLtv == Infinity) {
              itrLtv = 0.00;
            }
            element.itrLtv = itrLtv;


            /////////----End---///////
            //////////////--------Salary Deviation------------//////////
            var stlamntcal = parseFloat(element.lstSalbasAnnualnet) / 2;
            var devTemp = (parseFloat(element.lstSalbasTlamt) / parseFloat(element.lstSalbasAnnualnet)) * 100;
            var deviation = this.toFixCall(devTemp);
            if (deviation < 0 || deviation == Infinity) {
              deviation = 0.00;
            }
            if (stlamntcal < parseFloat(element.lstSalbasTlamt))
              element.salarydeviation = "Deviation - " + deviation + "%";
            else
              element.salarydeviation = "Not a Deviation - " + deviation + "%";
            /////////----End---///////
            /// ---------------ITR LTV (%)-----------////////

            var devTemp = (parseFloat(element.lstSalbasTlamt) / parseFloat(element.lstSalbasAnnualnet)) * 100;
            var salLtv = this.toFixCall(devTemp);
            if (salLtv < 0 || salLtv == Infinity) {
              salLtv = 0.00;
            }
            element.salLtv = salLtv;


            /////////----End---///////
            /////////////------------vehicle Deviation------//////////
            var totincomecal = parseFloat(element.lstVehTotharvestinc) / 2;
            var devTemp = (parseFloat(element.lstVehTlamt) / parseFloat(element.lstVehTotharvestinc)) * 100;
            var deviation = this.toFixCall(devTemp);
            if (deviation < 0 || deviation == Infinity) {
              deviation = 0.00;
            }
            if (totincomecal < parseFloat(element.lstVehTlamt))               
              element.vehicledeviation = "Deviation - " + deviation + "%";
            else 
              element.vehicledeviation = "Not a Deviation - " + deviation + "%";
            
            /////////----End---///////
            /// ---------------ITR LTV (%)-----------////////

            var devTemp = (parseFloat(element.lstVehTlamt) / parseFloat(element.lstVehTotharvestinc)) * 100;
            var vehLtv = this.toFixCall(devTemp);
            if (vehLtv < 0 || vehLtv == Infinity) {
              vehLtv = 0.00;
            }
            element.vehLtv = vehLtv;


            /////////----End---///////


            stlTot += this.parseEmptytoFloat(element.lstItrTlamnt) + this.parseEmptytoFloat(element.lstVehTlamt) + this.parseEmptytoFloat(element.lstSalbasTlamt);
            element.totalStl = stlTot.toFixed(2);
            this.FacList.forEach(fac => {
              if (fac.FacilityId == element.lstFacId) {
                element.facname = fac.FacilityName;
                element.proposedLimit = fac.ProposalLimit;
              }
            }

            );
            this.repaymentFreq.forEach(reqFrq => {
              if (reqFrq.llvOptionVal == element.lstRepayfreq) {
                element.lstRepayfreq = reqFrq.llvOptionDesc;
              }
            });
          });
       }
      },
      error => {
      });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

  toFixCall(value) {

    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1.toFixed(2);
    }
  }

}
