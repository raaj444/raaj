import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropsurrogatetermtemplateComponent } from './cropsurrogatetermtemplate.component';

describe('CropsurrogatetermtemplateComponent', () => {
  let component: CropsurrogatetermtemplateComponent;
  let fixture: ComponentFixture<CropsurrogatetermtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropsurrogatetermtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropsurrogatetermtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
