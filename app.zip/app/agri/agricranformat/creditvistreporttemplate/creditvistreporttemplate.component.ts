import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
@Component({
  selector: 'lp-creditvistreporttemplate',
  templateUrl: './creditvistreporttemplate.component.html',
  styleUrls: ['./creditvistreporttemplate.component.css']
})
export class CreditvistreporttemplateComponent  implements OnInit {   data:any; 
  
  hidView: boolean;
  constructor(private cranService: CranService) { }
  
  componentlist: any = [];
  cvrAnnxMasterList: any = [];
  private cvrAnnxList: Array<any> = [];
  cvrAnnxContentList: any = [];
  model: any = {};
  @Input()
  cranTypeFromResolver :string;
  ngOnInit() {
this.hidView=false;
    this.componentlist = [
      {
        name: 'CreditvistreporttemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.model.cvrAnnxHeadingList = [];
    this.model.cvrAnnxContentListObject = {};
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        
        if (this.data.success == true) {
          this.model.lcrCreditempName= this.data.userName;          
          
        if(this.data.responseData.CvrAnnx!=null){
          this.hidView=true;
          this.data.responseData.CvrAnnx.forEach(annx => {

            if (annx.lcrParentId == 0)
              this.model.cvrAnnxHeadingList.push({ lcrDescription: annx.lcrDescription, lcrRemarks: " ", lcrParentId: annx.lcrParentId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
            else {
              if (this.model.cvrAnnxContentListObject[annx.lcrParentId] == undefined) {
                this.model.cvrAnnxContentListObject[annx.lcrParentId] = [];
                this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrPropId: annx.lcrPropId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });
              }
              else {
                this.model.cvrAnnxContentListObject[annx.lcrParentId].push({ lcrDescription: annx.lcrDescription, lcrRemarks: annx.lcrRemarks, lcrParentId: annx.lcrParentId, lcrPropId: annx.lcrPropId, lcrOrderNo: annx.lcrOrderNo, lcrRowId: annx.lcrRowId });

              }
            }
            if (annx.lcrVisitdate != "" && annx.lcrVisitdate != undefined) {
              var visitdate = annx.lcrVisitdate;
              var date = visitdate.split("-");
              this.model.lcrVisitdate = date[2] + '/' + date[1] + '/' + date[0];
            }
            this.model.lcrMetwith = annx.lcrMetwith;
          });
        }
        }
      },
      error => {        
      });
  }

}