import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditvistreporttemplateComponent } from './creditvistreporttemplate.component';

describe('CreditvistreporttemplateComponent', () => {
  let component: CreditvistreporttemplateComponent;
  let fixture: ComponentFixture<CreditvistreporttemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditvistreporttemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditvistreporttemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
