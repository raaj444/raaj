import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItrdetailstemplateComponent } from './itrdetailstemplate.component';

describe('ItrdetailstemplateComponent', () => {
  let component: ItrdetailstemplateComponent;
  let fixture: ComponentFixture<ItrdetailstemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItrdetailstemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItrdetailstemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
