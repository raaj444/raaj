import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';



@Component({
  selector: 'lp-itrdetailstemplate',
  templateUrl: './itrdetailstemplate.component.html',
  styleUrls: ['./itrdetailstemplate.component.css']
})
export class ItrdetailstemplateComponent implements OnInit {

  kccassessmentremarksFlag: boolean;
  data: any;
  model: any = {};
  componentlist: any = [];

  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'ItrdetailstemplateComponent'
      },
    ];
    this.model.MainborrowerName = '';
    this.model.surrogateList = [{ 'lstSalbasAnnualnet': '', 'lstSalbasAnnualGross': '', 'lstSalbasNameofEmpl': '', 'lstItrAvrge': '', 'lstItrThirdyr': '', 'lstItrThirdamt': '', 'lstItrFirstyr': '', 'lstItrFirstamt': '', 'lstItrSecndyr': '', 'lstItrSecndamt': ' ' }];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          if (this.data.lpagriSurrogateTermLoan.length > 0)
            this.model.surrogateList = this.data.lpagriSurrogateTermLoan[0];

          if (this.data.SurrogateFacility.length > 0)
            this.model.facilityList = this.data.SurrogateFacility;

          this.model.MainborrowerName = this.data.BorCustName;
        }
      },
      error => {
      });
  }

}
