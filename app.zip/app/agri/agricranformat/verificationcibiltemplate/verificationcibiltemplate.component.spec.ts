import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerificationcibiltemplateComponent } from './verificationcibiltemplate.component';

describe('VerificationcibiltemplateComponent', () => {
  let component: VerificationcibiltemplateComponent;
  let fixture: ComponentFixture<VerificationcibiltemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerificationcibiltemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerificationcibiltemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
