import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-verificationcibiltemplate',
  templateUrl: './verificationcibiltemplate.component.html',
  styleUrls: ['./verificationcibiltemplate.component.css']
})
export class VerificationcibiltemplateComponent implements OnInit {

  data: any;
  model: any = {};
  hygienelist: any = [];
  ExistingCustRef: any = {};
  existingkccrepay: any = {};
  componentlist: any = [];
  BorrowerList: any = [];
  scoreList: any = [];
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {

    this.componentlist = [
      {
        name: 'VerificationcibiltemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];
    
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        this.BorrowerList = this.data.responseData.profilebasicdet;
        this.hygienelist = this.data.responseData.hygienelist;
        this.hygienelist.forEach(hclist => {
          if(hclist.lhcOdAmount!=null)
          hclist.lhcOdAmount = parseFloat(hclist.lhcOdAmount).toFixed(2);
          hclist.flag = hclist.lhcSource;
        });
        if (this.hygienelist.length < 1) {
          let i = 1;
          this.scoreList = this.data.responseData.lpcomCustInfoApplist;
          this.BorrowerList.forEach(element1 => {
            this.scoreList.forEach(element => {
              if (element1.lhcCustId == element.custId) {
                element1.cibilscore = element.cibilscore;
                element1.ncifstatus = element.ncifstatus;
              }
            });
          });
          this.BorrowerList.forEach(element => {
            this.hygienelist.push({ lhcCustId: element.lhcCustId, lhcRelationshipBnk: element.lhcRelationshipBnk, lhcCibilScore: element.cibilscore, lhcOdAmount: '0.00', lhcNcifCustomer: element.ncifstatus });
          });
        }
        this.hygienelist.forEach((element, index) => {
          this.BorrowerList.forEach(distEle => {
            if (distEle.lhcCustId == element.lhcCustId) {
              element.custname = distEle.custname;
            }
          });
        });
      },
      error => {
      });
  }
}