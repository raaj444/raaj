import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-currentcroppatterntemplate',
  templateUrl: './currentcroppatterntemplate.component.html',
  styleUrls: ['./currentcroppatterntemplate.component.css']
})
export class CurrentcroppatterntemplateComponent  implements OnInit {   data:any; 

  hidView: boolean;
  componentlist: any = [];
  model: any = {};
  itr: any;
  private cropPatternArray: Array<any> = [];
  stateArray = [];
  districtArray = [];
  cropSeasonList = [];
  cropDurationList = [];
  stateName: string = "";
  districtName: string = "";
  listOfValuesList = [];
  stateList: Array<any> = [];
  majorlistOfValuesList = [];
  cityDetails: any = [];
  districtList: any = [];
  majorcrop:any;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
  this.hidView=false;
 

    this.componentlist = [
      {
        name: 'CurrentcroppatterntemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getAgriDataCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.model.cropPatternArray = this.data.lpagriCurrCropPatternList;
          this.listOfValuesList = this.data.lpmasListofvalueList;

          this.stateList = this.data.stateList;
          this.cityDetails = this.data.cityList;
          this.cropSeasonList = this.data.lpmasListofSeasonList;
          this.cropDurationList = this.data.lpmasListofDurationList;
          if(this.model.cropPatternArray !=undefined && this.model.cropPatternArray.length >0)
          {
            this.hidView=true;
            this.majorcrop=this.model.cropPatternArray[0].lpcpMajorCrop;
            this.listOfValuesList.forEach(master => {
              if ( this.majorcrop == master.llvOptionVal) {
                this.majorcrop = master.llvOptionDesc;
              }
            });
          }
          this.model.cropPatternArray.forEach((crop) => {
            this.listOfValuesList.forEach(master => {
              if (crop.lpcpCropId == master.llvOptionVal) {
                crop.lpcpCropId = master.llvOptionDesc;
              }
            });
            this.cropDurationList.forEach(master => {
              if (master.llvOptionVal == crop.lpcpCropDuration) {
                crop.lpcpCropDuration = master.llvOptionDesc;
              }
            });
            this.cropSeasonList.forEach(master => {
              if (crop.lpcpCropSeason == master.llvOptionVal) {
                crop.lpcpCropSeason = master.llvOptionDesc;
              }
            });
            this.stateList.forEach(state => {
              if (state.sgmStateCode == crop.lpcpStateId) {
                crop.lpcpStateId = state.sgmStateName;
              }
            });
            this.cityDetails.forEach(statecity => {
              // let tempCity=[];
              statecity.forEach(city=> {
                if (city.sgmCityCode == crop.lpcpDistrictId) {
                  crop.lpcpDistrictId = city.sgmCityName;
                }  
              });
              
            });

          });
          if (this.data.lpcpMajorCrop != null)
            this.model.lpcpMajorCrop = this.data.lpcpMajorCrop;
          if (this.data.lpcpInsAmt != null) {
            this.model.lpcpInsAmt = this.data.lpcpInsAmt;
            this.model.lpcpInsAmt = this.model.lpcpInsAmt.toFixed(2);
          }

        }
      },
      error => {        
      });
  }

}
