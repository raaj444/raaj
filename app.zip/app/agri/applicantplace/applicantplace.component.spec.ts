import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicantplaceComponent } from './applicantplace.component';

describe('ApplicantplaceComponent', () => {
  let component: ApplicantplaceComponent;
  let fixture: ComponentFixture<ApplicantplaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicantplaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicantplaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
