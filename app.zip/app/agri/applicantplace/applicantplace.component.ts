import { Component, OnInit, ViewChild } from '@angular/core';
import { ApplicantplaceService } from "../../util/service/agriservices/applicantplace.service";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Validator } from '../../util/helper/validator';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var progressStatus: any
declare var successStatus: any
declare var failedStatus: any
declare var $: any;
@Component({
  selector: 'lp-applicantplace',
  templateUrl: './applicantplace.component.html',
  styleUrls: ['./applicantplace.component.css']
})
export class ApplicantplaceComponent extends Validator  implements OnInit {   data:any; 


  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  deletebuttonDisable: boolean
  model: any = {};
  flag: boolean;
  idvalueList: any = ['lcaFromPlace', 'lcaToPlace', 'lcaRoute', 'lcaMode', 'lcaKm', 'lcaDisFrmBranch', 'lcaDisFrmRmlocation', 'lcaDisFrmRestoagri'];
  modelForChngNote: any;
  pageAccess: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private applicantplaceService: ApplicantplaceService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.disableButton(true, true, false, true, true)
    this.model.lcaMode = 's';
    this.get();

  }
  get() {
    this.model.lcaMode = 's';
    this.applicantplaceService.getApplicantplace()
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
        
          if (this.data.responseData != null) {
            this.model = this.data.responseData
          }
          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess != 'R' && this.data.responseData == null) {
            this.disableButton(false, false, true, false, false);
          }
          else
          this.disableButton(true, true, false, true, true);
          if (this.pageAccess == 'R') {
            this.disableButton(true, true, true, true, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.data.pageAccess);
            this.disableButton(true, true, false, true, true);
          }
        }
      });
  }

  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean, deletebuttonDisable: boolean) {
    this.fieldDisable = fieldDisable;
    this.savebuttonDisable = savebuttonDisable;
    this.editbuttonDisable = editbuttonDisable;
    this.cancelbuttonDisable = cancelbuttonDisable;
    this.deletebuttonDisable = deletebuttonDisable;
  }

  editApproachApplicant() {
    this.disableButton(false, false, true, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

  saveApproachApplicant() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.validateField(this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.validateField(this.idvalueList)
      if (this.flag == true) {
        progressStatus()
        this.applicantplaceService.saveApplicantPlace(this.model)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.disableButton(true, true, false, true, true)
              successStatus()
            }
            else
              failedStatus()
          },
          error => {
          });
      }
    }
  }

  deleteApproachApplicant() {
    this.model = {};
    this.applicantplaceService.deleteapplicantPlace()
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.get();
          this.disableButton(true, true, false, true, true)
        }
        else {
        }

      },
      error => {
        // this.alertService.error(error);
      });
  }

}
