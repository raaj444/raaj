import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ExistingcustrefService } from '../../util/service/agriservices/existingcustref.service';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
declare var customStatus: any
declare var $: any;
@Component({
  selector: 'lp-existingcustref',
  templateUrl: './existingcustref.component.html',
  styleUrls: ['./existingcustref.component.css']
})
export class ExistingcustrefComponent extends Validator implements OnInit {
  data: any;
  disableFields: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  disableFlag: boolean;
  validation: boolean;
  model: any = {};
  fieldArray: Array<any> = [];
  newAttribute: any = {};
  maxid: number = 0;
  ControllList: any = ['txt_fieldrefname', 'txt_fieldTFERelation', 'txt_fieldcontactNo'];
  pageAccess: any;
  modelForChngNote: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private existingcustrefService: ExistingcustrefService, private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) { super(); }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.validators();
    this.getData();
  }

  disableButtons(add: boolean, edit: boolean, save: boolean, cancel: boolean, deleteAll: boolean) {
    if (this.pageAccess == 'R') {
      this.disableNewButton = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.disableDeleteAllButton = true;
      this.disableFields = true;
    }
    else {
      this.disableNewButton = add;
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.disableDeleteAllButton = deleteAll;
    }
  }
  addFieldValue() {

    if (this.model.fieldArray.length < 10) {
      var fieldArraymax = JSON.parse(JSON.stringify(this.model.fieldArray));
      this.model.fieldArraymax = [];
      fieldArraymax.forEach(field => {
        this.maxid = field.aecrOrderNo;
      });
      this.model.fieldArray.push({ aecrRowId: 0, 'aecrOrderNo': this.maxid + 1 });
    }

  }

  deleteFieldValue(aecrOrderNo: number) {
    if (confirm("Do you want to Delete?")) {

      if (this.model.fieldArray.length <= 1) {
        customStatus("Please Maintain Atleast One Row");
      }
      else {
        var FieldArrayTemp = JSON.parse(JSON.stringify(this.model.fieldArray));
        this.model.fieldArray = [];
        FieldArrayTemp.forEach(field => {
          if (field.aecrRowId != 0 && field.aecrOrderNo == aecrOrderNo) {
            var rowid = "";
            this.model.SeqId = field.aecrOrderNo;
            this.existingcustrefService.deleteAllExistingCustRef(this.model, field.aecrOrderNo)
              .subscribe(
              data => {
                this.data = data;
                this.getData();
              },
              error => {
              });
          }
          else {
            if (field.aecrOrderNo != aecrOrderNo) {
              this.model.fieldArray.push(field);
            }
          }

        });
      }
    }

  }

  dosave() {
    var phCount = 0;
    var phId = 'txt_fieldcontactNo';
    var i = this.model.fieldArray.length;
    for (let j = 0; j < i; j++) {
      var phfieldId = phId + j;
      if (this.model.fieldArray[j].aecrContactno !== "" && this.model.fieldArray[j].aecrContactno != null) {
        if ((this.model.fieldArray[j].aecrContactno.toString()).length < 10) {
          phCount++;
          $('#' + phfieldId).addClass("has-error");
        }
      }
    }

    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.fieldArray.length, this.ControllList)) {
        this.changenoteComponent.onSave();
      }
      this.validation = this.fieldvalidation.multipleFieldValidation(this.model.fieldArray.length, this.ControllList);
      if (phCount > 0)
        alert("Enter valid Contact No.");
      if (this.validation == true && phCount == 0) {
        progressStatus()
        this.existingcustrefService.saveExistingCustRefdet(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.getData();
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
            else
              failedStatus()
          },
          error => {
            failedStatus()
          },
        );
        this.disableButtons(true, false, true, true, true);
      }
    }
  }
  getData() {
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.model.fieldArray = [];
    this.existingcustrefService.getExistingCustRef(this.model)
      .subscribe(data => {
        this.data = data;
        if (this.data.success) {
          this.model.fieldArray = this.data.responseData.ExistingCustRef;
          this.pageAccess = this.data.pageAccess;
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
            this.disableButtons(true, false, true, true, true);
          }
          if (this.model.fieldArray.length < 1) {
            this.model.fieldArray.push({ 'aecrRowId': 0, aecrOrderNo: 1 });
            this.disableFields = false;
            this.disableButtons(true, true, false, false, false);
          }
          else {
            this.disableFields = true;
            this.disableButtons(true, false, true, true, true);
          }
         }
      },
      error => {
      });
  }

  docancel() {
    loadingStatus();
    this.ngOnInit();
    sessionStorage.setItem("editMode", "N");
    $('input,select,textarea').removeClass('ng-dirty');
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.ngOnInit();
    }
    hide();
  }
  doedit() {
    this.disableButtons(false, true, false, false, false);
    this.disableFields = false;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  dodelete() {
    if (confirm("Do you want to Delete?")) {
      this.existingcustrefService.deleteAllData(this.model)
        .subscribe(
        data => {
          this.data = data;
          this.getData();
        },
        error => {
        });
    }
  }
}
