import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingcustrefComponent } from './existingcustref.component';

describe('ExistingcustrefComponent', () => {
  let component: ExistingcustrefComponent;
  let fixture: ComponentFixture<ExistingcustrefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingcustrefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingcustrefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
