import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingcroppatternComponent } from './existingcroppattern.component';

describe('ExistingcroppatternComponent', () => {
  let component: ExistingcroppatternComponent;
  let fixture: ComponentFixture<ExistingcroppatternComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingcroppatternComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingcroppatternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
