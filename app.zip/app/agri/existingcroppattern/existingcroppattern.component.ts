import { Component, OnInit, ViewChild } from '@angular/core';
import { ExistingcroppatternService } from "../../util/service/agriservices/existingcroppattern.service";
import { Router } from '@angular/router';
import { Validator } from "../../util/helper/validator";
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-existingcroppattern',
  templateUrl: './existingcroppattern.component.html',
  styleUrls: ['./existingcroppattern.component.css']
})
export class ExistingcroppatternComponent extends Validator implements OnInit {
    data: any;
  model: any = {};
  private prevcroppatternArray: Array<any> = [];
  fieldDisable: boolean;
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  validation: boolean;
  id: number; flag: boolean;
  pageAccess: any;
  cropNameList = [];
  cropSeasonList: any = [];
  idvalueList = ['lpcpYear', 'lpcpSeason', 'lpcpCropId', 'lpcpAreaCultivated', 'lpcpYieldPerAcre', 'lpcpRatePerQuintal', 'lpcpCropSoldDet'];
  modelForChngNote: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private existingcroppatternService: ExistingcroppatternService, private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();

    this.disableButtons(true, true, false, true, false, true);
    this.model.prevcroppatternArray = [{ lpcpYear: '', lpcpSeason: 's', lpcpCropId: 's', lpcpAreaCultivated: '', lpcpYieldPerAcre: '', lpcpRatePerQuintal: '', lpcpGrossRevenue: '', lpcpCropSoldDet: '' }];
    this.existingcroppatternService.getPrevCropPattern()
      .subscribe(
      data => {
      this.data = data;
        if (this.data.success) {
          this.cropNameList = this.data.responseData.cropNameList;
          this.cropSeasonList = this.data.lpmasListofSeasonList;
          this.pageAccess = this.data.pageAccess;
          /**** Sorting Alphabetic order ****/
          this.cropNameList = this.cropNameList.sort((a, b) => {
            var a = a.llvOptionDesc; a = a.toUpperCase();
            var b = b.llvOptionDesc; b = b.toUpperCase();
            if (a < b)
              return -1;
            if (a > b)
              return 1;
            return 0;
          });
          // **** End Sorting Alphabetic order ****/

          this.model.prevcroppatternArray = [];
          this.data.responseData.reqDueDataList.forEach(element => {
            this.model.prevcroppatternArray.push(element)
          });
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
          if (this.model.prevcroppatternArray.length < 1) {
            this.model.prevcroppatternArray = [{ lpcpYear: '', lpcpSeason: 's', lpcpCropId: 's', lpcpAreaCultivated: '', lpcpYieldPerAcre: '', lpcpRatePerQuintal: '', lpcpGrossRevenue: '', lpcpCropSoldDet: ''}];
            this.disableButtons(false, false, true, false, false, false);
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }
          if (this.pageAccess == "R") {
            this.disableButtons(true, true, true, true, true, true);
          }

        }

      },
      error => {

      });

  }



  addFieldValue() {

    this.disableButtons(false, false, true, false, false, false);
    this.model.prevcroppatternArray.push({ lpcpYear: '', lpcpSeason: 's', lpcpCropId: 's', lpcpAreaCultivated: '', lpcpYieldPerAcre: '', lpcpRatePerQuintal: '', lpcpGrossRevenue: '', lpcpCropSoldDet: '' });
  }


  cancelButton() {

    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }

  editFields() {

    this.disableButtons(false, false, true, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  saveExistingcroppattern() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.prevcroppatternArray.length, this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.prevcroppatternArray.length, this.idvalueList);

      if (this.flag) {

        this.existingcroppatternService.savePrevCropPattern(this.model.prevcroppatternArray)
          .subscribe(
          data => {
          this.data = data;
            if (this.data.success) {
              this.model.prevcroppatternArray = this.data.responseData;
              this.disableButtons(true, true, false, true, false, true);
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              successStatus();
            }

          },
          error => {
            failedStatus();
          });

      }

    }
  }


  calGrossRevenue(e, i) {
    if (this.model.prevcroppatternArray[i].lpcpAreaCultivated !== "" && this.model.prevcroppatternArray[i].lpcpAreaCultivated !== null)
      this.model.prevcroppatternArray[i].lpcpAreaCultivated = parseFloat(this.model.prevcroppatternArray[i].lpcpAreaCultivated).toFixed(2);
    if (this.model.prevcroppatternArray[i].lpcpYieldPerAcre !== "" && this.model.prevcroppatternArray[i].lpcpYieldPerAcre != null)
      this.model.prevcroppatternArray[i].lpcpYieldPerAcre = parseFloat(this.model.prevcroppatternArray[i].lpcpYieldPerAcre).toFixed(2);
    if (this.model.prevcroppatternArray[i].lpcpRatePerQuintal !== "" && this.model.prevcroppatternArray[i].lpcpRatePerQuintal != null)
      this.model.prevcroppatternArray[i].lpcpRatePerQuintal = parseFloat(this.model.prevcroppatternArray[i].lpcpRatePerQuintal).toFixed(2);
    if (this.model.prevcroppatternArray[i].lpcpAreaCultivated !== "" || this.model.prevcroppatternArray[i].lpcpYieldPerAcre !== "" || this.model.prevcroppatternArray[i].lpcpRatePerQuintal !== "") {
      this.model.prevcroppatternArray[i].lpcpGrossRevenue = this.model.prevcroppatternArray[i].lpcpAreaCultivated * this.model.prevcroppatternArray[i].lpcpYieldPerAcre * this.model.prevcroppatternArray[i].lpcpRatePerQuintal;
      this.model.prevcroppatternArray[i].lpcpGrossRevenue = parseFloat(this.model.prevcroppatternArray[i].lpcpGrossRevenue).toFixed(2);
    }


  }

  delete(row: any, id: any, i: any) {
    if (id == '' || id == undefined) {
      this.model.prevcroppatternArray.splice(i, 1);

    } else {

      this.existingcroppatternService.deletePrevCropPattern(row)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success) {
            this.ngOnInit();
          }
        },
        error => {

        });
    }
  }

  deleteAllExistingcroppattern() {
    if (confirm("Do you want to Delete All?")) {

      this.existingcroppatternService.deleteAllExistingcroppattern(this.model.prevcroppatternArray)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success) {
            this.ngOnInit();
          }
        },
        error => {

        });
    }
    else {
      this.ngOnInit();
    }
  }

  validate(val: any, i: number, label: string) {
    var valFlag;
    if (val != "") {

      valFlag = this.checkAcreLimit(val, i, label);
      if (valFlag) {
        alert("Enter Acre Limit Below 1000");
      }
      else {
        this.calGrossRevenue(val, i);
      }
    }

  }


  checkAcreLimit(value: any, i: number, label: string) {
    var AcreVal = parseFloat(parseFloat(value).toFixed(2));

    if (AcreVal > 999.99) {
      if (label == "C") {
        this.model.prevcroppatternArray[i].lpcpAreaCultivated = "";
        $('#lpcpAreaCultivated' + i).addClass("has-error");
        return true;

      }
      else if (label == "Y") {
        this.model.prevcroppatternArray[i].lpcpYieldPerAcre = "";
        $('#lpcpYieldPerAcre' + i).addClass("has-error");
        return true;
      }
    } else { return false; }


  }
  disableButtons(field: boolean, add: boolean, edit: boolean, save: boolean, deleteAll: boolean, cancel: boolean) {
    this.fieldDisable = field;
    this.newbuttonDisable = add;
    this.editbuttonDisable = edit;
    this.cancelbuttonDisable = cancel;
    this.deleteAllbuttonDisable = deleteAll;
    this.savebuttonDisable = save;
  }

}

