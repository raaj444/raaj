import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentcroppatternComponent } from './currentcroppattern.component';

describe('CurrentcroppatternComponent', () => {
  let component: CurrentcroppatternComponent;
  let fixture: ComponentFixture<CurrentcroppatternComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentcroppatternComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentcroppatternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
