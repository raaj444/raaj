import { Component, OnInit, ViewChild } from '@angular/core';
import { CurrentcroppatternService } from "../../util/service/agriservices/currentcroppattern.service";
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { IndividualappdetService } from '../../util/service/corporateservices/individualappdet.service';
import { SearchComponent } from '../../common/search/search.component';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { StgeographymasterService } from '../../util/service/setupservices/stgeographymaster.service';
declare var successStatus: any;
declare var failedStatus: any;
declare var $: any;

@Component({
  selector: 'lp-currentcroppattern',
  templateUrl: './currentcroppattern.component.html',
  styleUrls: ['./currentcroppattern.component.css']
})
export class CurrentcroppatternComponent extends Validator implements OnInit {
    data: any;
  @ViewChild(SearchComponent)
  Searchpop: SearchComponent

  itr: any;
  districtDisable: boolean;
  stateDisable: boolean;
  stateFlag: boolean;
  districtFlag: boolean;
  model: any = {};
  private cropPatternArray: Array<any> = [];
  stateArray = [];
  districtArray = [];
  cropSeasonList = [];
  cropDurationList = [];
  disableFields: boolean;
  disableFieldsduration: boolean;
  disableFieldseason: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  hidStateCode: any = ""; hidDistrictCode: string = "";
  idvalueList = ['hid_lpcpStateCode_', 'hid_lpcpDistrictCode_', 'lpcpCropSeason', 'lpcpCropId', 'lpcpLandOwnership', 'lpcpAreaCultivated'];
  crpidvalueList = ['lpcpMajorCrop'];
  stateName: string = "";
  districtName: string = "";
  listOfValuesList = [];
  stateList: Array<any> = [];
  // districtList: any;
  modelForChngNote: any;
  deleteMajorcrop: boolean;
  majorlistOfValuesList = [];
  cityDetails: any = [];
  districtList: any = [];
  lpcpMajorCrop = ['lpcpMajorCrop'];

  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private currentcroppatternService: CurrentcroppatternService, private router: Router, private fieldvalidation: Fieldvalidation,
    private individualappdetService: IndividualappdetService, private changenoteService: ChangenoteService,
    private stgeographymasterService: StgeographymasterService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.validators();
    this.deleteMajorcrop = false;
    this.model={
      lpcpMajorCrop:"s",lpcpInsAmt:"",lpcpCropInsured:"N"
    }
    // this.model.lpcpMajorCrop = 's';
    // this.model.lpcpInsAmt = '';
    // this.model.lpcpCropInsured="N";
    this.model.cropPatternArray = [{ lpcpRowId: '', lpcpStateId: 's', lpcpDistrictId: 's', lpcpCropDuration: 's', lpcpCropSeason: 's', lpcpCropId: 's', lpcpAgeOfHorti: '', lpcpAreaCultivated: '', lpcpStandingCrop: 's', lpcpRemarks: '', lpcpLandOwnership: 's', lpcpCropType: '' }];
    this.disableButtons(true, false, false, true, true, true);
    this.disableFieldsduration = true;
    this.disableFieldseason = true;
    this.stateDisable = true;
    this.districtDisable = true;
    this.stateFlag = false;
    this.districtFlag = false;
    this.majorlistOfValuesList = [];
    this.currentcroppatternService.getAgriCurYearCropPattern(this.model)
      .subscribe(
      data => {
      this.data = data;
        if (this.data.success == true) {
         this.disableButtons(true, true, false, true, true, true);


          if (this.data.lpagriKccEligibility != null) {
            this.disableButtons(true, true, true, true, true, true);
          }
          this.model.cropPatternArray = this.data.lpagriCurrCropPatternList;
          this.listOfValuesList = this.data.lpmasListofvalueList;
          /**** Sorting Alphabetic order ****/
          this.listOfValuesList = this.listOfValuesList.sort((a, b) => {
            var a = a.llvOptionDesc; a = a.toUpperCase();
            var b = b.llvOptionDesc; b = b.toUpperCase();
            if (a < b)
              return -1;
            if (a > b)
              return 1;
            return 0;
          });
          // **** End Sorting Alphabetic order ****/
          this.stateList = this.data.stateList;
          this.cityDetails = this.data.cityList;
          this.cropSeasonList = this.data.lpmasListofSeasonList;
          this.cropDurationList = this.data.lpmasListofDurationList;

          this.model.cropPatternArray.forEach((element) => {
            this.listOfValuesList.forEach(element1 => {
              if (element.lpcpCropId == element1.llvOptionVal) {
                let addMajor = this.majorlistOfValuesList.find(x => x.llvOptionVal === element.lpcpCropId);
                if (addMajor == undefined) {
                  this.majorlistOfValuesList.push(element1);
                }
              }
            });
          });
          if (this.data.lpcpMajorCrop != null)
            this.model.lpcpMajorCrop = this.data.lpcpMajorCrop;
          if (this.data.lpcpInsAmt != null) {
            this.model.lpcpInsAmt = this.data.lpcpInsAmt;
            this.model.lpcpInsAmt = this.model.lpcpInsAmt.toFixed(2);
          }
          if(this.data.lpcpCropInsured!=null && this.data.lpcpCropInsured!=undefined)
                this.model.lpcpCropInsured=this.data.lpcpCropInsured;
        
          if (this.model.cropPatternArray.length == 0) {
            this.model.cropPatternArray.push({ lpcpRowId: '', lpcpStateId: 's', lpcpDistrictId: 's', lpcpCropDuration: 's', lpcpCropSeason: 's', lpcpCropId: 's', lpcpAgeOfHorti: '', lpcpAreaCultivated: '', lpcpStandingCrop: 's', lpcpRemarks: '', lpcpLandOwnership: 's', lpcpCropType: '' });
            this.disableButtons(false, false, true, false, false, false);
          }
          if (this.data.pageAccess=='R') {
            this.disableButtons(true, true, true, true, true, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.data.pageAccess);
          }
          setTimeout(() => {
            let i = this.model.cropPatternArray.length - 1;
            for (let i = 0; i < this.model.cropPatternArray.length; i++) {
              $("#hid_lpcpStateCode_" + i).select2();
              $("#hid_lpcpDistrictCode_" + i).select2();
              $("#hid_lpcpStateCode_" + i).on('change', (e) => {
                this.model.cropPatternArray[i].lpcpStateId = e.target.value;
                this.getCityList(this.model.cropPatternArray[i].lpcpStateId, i);
              });
              $("#hid_lpcpDistrictCode_" + i).on('change', (e) => {
                this.model.cropPatternArray[i].lpcpDistrictId = e.target.value;
              });
            }
          }, 50);
        }
      },
      error => {
        // this.alertService.error(error);
      });

    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });
  }


  saveCurrCropPattern() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.cropPatternArray.length, this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      if (this.fieldvalidation.multipleFieldValidation(this.model.cropPatternArray.length, this.idvalueList) && this.fieldvalidation.validateField(this.crpidvalueList)) {
        this.currentcroppatternService.saveAgriCurYearCropPattern(this.model)
          .subscribe(
          data => {
          this.data = data;
            if (this.data.success == true) {
              this.currentcroppatternService.getAgriCurYearCropPattern(this.model)
                .subscribe(
                data => {
                this.data = data;
                  if (this.data.success == true) {
                    this.model.cropPatternArray = this.data.lpagriCurrCropPatternList;
                    this.ngOnInit();
                    sessionStorage.setItem("editMode", "N");
                    $('input,select,textarea').removeClass('ng-dirty');
                    successStatus();

                  }
                  else {
                    failedStatus();
                  }
                },
                error => {
                  // this.alertService.error(error);
                });
            }
                     },
          error => {
            // this.alertService.error(error);
          });
      }
    }
  }

  addRow() {
    this.model.cropPatternArray.push({ lpcpRowId: '', lpcpStateId: 's', lpcpDistrictId: 's', lpcpCropDuration: 's', lpcpCropSeason: 's', lpcpCropId: 's', lpcpAgeOfHorti: '', lpcpAreaCultivated: '', lpcpStandingCrop: 's', lpcpRemarks: '', lpcpLandOwnership: 's', lpcpCropType: '' });
    this.disableButtons(false, false, true, false, false, false);
    this.hidStateCode = "";
    setTimeout(() => {
      let i = this.model.cropPatternArray.length - 1;
      $("#hid_lpcpStateCode_" + i).select2();
      $("#hid_lpcpDistrictCode_" + i).select2();
      $("#hid_lpcpStateCode_" + i).on('change', (e) => {
        this.model.cropPatternArray[i].lpcpStateId = e.target.value;
        this.getCityList(this.model.cropPatternArray[i].lpcpStateId, i);
      });
      $("#hid_lpcpDistrictCode_" + i).on('change', (e) => {
        this.model.cropPatternArray[i].lpcpDistrictId = e.target.value;
      });

    }, 50);

  }

  onClickDeleteButton(row: any, id: any, i: any) {

    if (id == '' || id == undefined) {
      this.model.cropPatternArray.splice(i, 1);

    } else {


      if (this.model.lpcpMajorCrop == row.lpcpCropId) {
        this.deleteMajorcrop = true;
        alert("Please change Major Crop and Save before delete it");
      }
      else if (this.deleteMajorcrop != false) {
        this.saveCurrCropPattern();
      }
      else {
        this.currentcroppatternService.deleteAgriCurYearCropPattern(row)
          .subscribe(
          data => {
          this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
            }
           
          },
          error => {
            // this.alertService.error(error);
          });
      }



    }
  }

  onClickEditButton() {
    this.disableButtons(false, false, true, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }

  onClickDeleteAllButton() {
    if (confirm("Do you want to Delete?")) {
      this.currentcroppatternService.deleteAllAgriCurYearCropPattern(this.model)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success == true) {
            this.ngOnInit();
          }
          else
            alert("Error..");
        },
        error => {
          // this.alertService.error(error);
        });
    }
    else {
      this.ngOnInit();
    }
  }


  searchState(event, i) {

    this.itr = i;
    this.stateFlag = true;
    var pageid = "State";
    $('#name').text("State Name");
    $('#code').text("State Code");
    $('#header').text("State Search");
    $('#txt_pageid').val(pageid);
    $('#txt_hidCode').val("S");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');
  }

  searchDistrict(event, i) {

    this.districtFlag = true;
    this.itr = i;
    var pageid = "City";
    $('#name').text("District Name");
    $('#code').text("District Code");
    $('#header').text("District Search");
    $('#txt_pageid').val(pageid);

    let rowCount = event.target.id.split("_");

    if ($('#hid_lpcpStateCode_' + rowCount[1]).val() !== "" && $('#lpcpStateId_' + this.itr).val() !== "") {
      this.hidStateCode = this.model.cropPatternArray[this.itr].lpcpStateId;
      $('#txt_hidCode').val("S:" + this.hidStateCode);
      if (this.hidStateCode == null || this.hidStateCode == "" || this.hidStateCode == undefined)
        this.hidStateCode = $('#lpcpStateId_' + this.itr).val();
      $('#txt_hidCode').val("S:" + this.hidStateCode);
    }
    else
      $('#txt_hidCode').val("C");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');
  }

  modalClosed() {
    if (this.stateFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt-txt_Searchcode').val() != "") {
        var stateName = $('#txt-Searchname').val();
        var stateCode = $('#txt_Searchcode').val();
        if (stateName != "" && stateCode != "") {

          this.model.cropPatternArray[this.itr].lpcpStateId = stateCode;
          $('#hid_lpcpStateCode_' + this.itr).val(stateName);
          this.hidStateCode = stateCode;
          $('#lpcpStateId_' + this.itr).val(stateCode);
        }

        this.model.cropPatternArray[this.itr].lpcpDistrictId = "";
        $('#hid_lpcpDistrictCode' + this.itr).val("");

      }
      this.stateFlag = false;
    }

    else if (this.districtFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt-txt_Searchcode').val() != "") {
        var districtName = $('#txt-Searchname').val();
        var districtCode = $('#txt_Searchcode').val();

        if (districtName != "" && districtCode != "") {
          this.model.cropPatternArray[this.itr].lpcpDistrictId = districtCode;
          $('#hid_lpcpDistrictCode_' + this.itr).val(districtName);
          $('#lpcpDistrictId_' + this.itr).val(districtCode);
        }
        if ($('#txt_hidCode').val() == "D") {
          var strState = $('#txt_hidValue').val().split("@");
          var splitCity = strState[1].split("/");
          this.model.cropPatternArray[this.itr].lpcpStateId = strState[0];
          $('#hid_lpcpStateCode_' + this.itr).val(splitCity[0]);
          this.hidStateCode = strState[0];
        }
      }
      this.districtFlag = false;
    }
  }

  validate(value: any, i: number) {
    var AcreVal = parseFloat(parseFloat(value).toFixed(2));

    if (AcreVal > 999.99) {
      this.model.cropPatternArray[i].lpcpAreaCultivated = "";
      $('#lpcpAreaCultivated' + i).addClass("has-error");
      alert("Enter Acre Limit Below 1000");
      return true;
    }
    else {
      this.model.cropPatternArray[i].lpcpAreaCultivated = this.toFixCall(value);
      return false;
    }
  }
  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }
  // onChangeCropSeason(value: any, i: any) {
  //   this.croptypeList.forEach(element => {
  //     if (element.lcmDurationId == value) {
  //       this.model.cropPatternArray[i].lpcpCropType = element.lcmCropTypeId;
  //    }
  //   });
  // }

  onChangeCropSeasonDuration(value: any, i: any) {
    var durationval;
    var seasonval;
    this.listOfValuesList.forEach(element => {
      if (element.llvOptionVal == value) {
        durationval = element.llvDuration;
        seasonval = element.llvSeason;
      }
    });
    this.cropDurationList.forEach(element1 => {
      if (element1.llvOptionVal == durationval) {
        this.model.cropPatternArray[i].lpcpCropDuration = element1.llvOptionVal;
        $('#lpcpCropDuration' + i).val(element1.llvOptionVal);
        this.model.cropPatternArray[i].lpcpCropType = element1.llvCropType;
        // this.onChangeCropSeason(element1.llvOptionVal, i);
      }
    });
    this.cropSeasonList.forEach(element => {
      if (element.llvOptionVal == seasonval) {
        this.model.cropPatternArray[i].lpcpCropSeason = element.llvOptionVal;
        $('#lpcpCropSeason' + i).val(element.llvOptionVal);
      }
    });
  }
  majorcroplist() {
    this.majorlistOfValuesList = [];
    this.model.cropPatternArray.forEach((element) => {
      this.listOfValuesList.forEach(element1 => {
        if (element.lpcpCropId == element1.llvOptionVal) {
          let addMajor = this.majorlistOfValuesList.find(x => x.llvOptionVal === element.lpcpCropId);
          if (addMajor == undefined) {
            this.majorlistOfValuesList.push(element1);
          }
        }
      });
    });
  }

  disableButtons(field: boolean, add: boolean, edit: boolean, save: boolean, deleteAll: boolean, cancel: boolean) {
    this.disableFields = field;
    this.disableNewButton = add;
    this.disableEditButton = edit;
    this.disableSaveButton = save;
    this.disableCancelButton = cancel;
    this.disableDeleteAllButton = deleteAll;
  }
  getCityList(stateCode, index) {
    this.cityDetails[index] = [];
    this.stgeographymasterService.getCityListBasedOnStateCode(stateCode)
      .subscribe(
      data => {
      this.data = data;
        this.cityDetails[index] = this.data.cityList;
        this.districtList[index] = [];
      },
      error => {

      }
      );
  }
  toFixedOnBlur(e: any) {
    if (e.target.value != "") {
      var value = parseFloat(e.target.value).toFixed(2);
      $('#' + e.target.id).val(value);
    }
  }
}