import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingexposureComponent } from './existingexposure.component';

describe('ExistingexposureComponent', () => {
  let component: ExistingexposureComponent;
  let fixture: ComponentFixture<ExistingexposureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingexposureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingexposureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
