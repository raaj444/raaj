import { Component, OnInit } from '@angular/core';
import { ExistingexposureService } from '../../util/service/agriservices/existingexposure.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
declare var $ : any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-existingexposure',
  templateUrl: './existingexposure.component.html',
  styleUrls: ['./existingexposure.component.css']
})
export class ExistingexposureComponent extends Validator  implements OnInit {   data:any; 
  lpexLoanFor: any = '';
  model: any = {};
  temp: any = {};
  branch = [];
  borrowerType=[];
  private existingExposure: Array<any> = [];
  os: boolean;
  comment: boolean;
  other: boolean = true;
  term: boolean = true;
  crop: boolean = true;
  all: boolean = true;
  freq: any = 'Interest servicing - Half yearly/Annually';
  osCont: any = 'Outstanding Rs.';
  remarks: any = 'Remarks';
  disableFields: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  flag : boolean;loanForFlag:string='';
  idvalueList1 = ['lpexCustId', 'lpexFacNature', 'lpexFacType', 'lpexFacility', 'lpexBankName', 'lpexBranch', 'lpexLoanAmt', 'lpexAgrmtYear', 'lpexInstlFreq', 'lpexTenor', 'lpexAnnualInstl', 'lpexCurrOs', 'lpexLoanStatus', 'lpexLandMortDetails', 'lpexRemarks'];
  idvalueList2 = ['lpexCustId', 'lpexFacNature', 'lpexFacType', 'lpexFacility', 'lpexBankName', 'lpexBranch', 'lpexLoanAmt', 'lpexAgrmtYear', 'lpexInstlFreq', 'lpexAnnualInstl', 'lpexInstlDue', 'lpexInstlPaid', 'lpexAvgDelayDays', 'lpexLandMortDetails', 'lpexRemarks'];
  idvalueList3 = ['lpexCustId', 'lpexFacNature', 'lpexFacType', 'lpexFacility', 'lpexBankName', 'lpexBranch', 'lpexLoanAmt', 'lpexAgrmtYear', 'lpexInstlFreq', 'lpexAnnualInstl', 'lpexLandMortDetails', 'lpexRemarks'];
  constructor(private existingexposureService: ExistingexposureService, private router: Router, private fieldvalidation: Fieldvalidation)
  {
    super();
  }

  ngOnInit() {
    this.validators();
    this.model.existingExposure = [];
    this.lpexLoanFor = "1";

    this.disableFields = true;
    this.disableNewButton = true;
    this.disableEditButton = false;
    this.disableSaveButton = true;
    this.disableDeleteAllButton = true;
    this.disableCancelButton = true;

    this.existingexposureService.getBranch()
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.branch = this.data.responseData.distinctCity;
        }

    this.existingexposureService.getExistingExposure()
      .subscribe(
      data => { this.data=data;
        this.crop = false;
        this.term = true;
        this.other = true;
        if (this.data.success == true) {
     
          this.borrowerType= this.data.loanAvailableBy;
        this.temp = this.data.existingExposureList;
        this.model.existingExposure=this.data.existingExposureList;
      
      
          // this.temp.forEach(element => {
           
          //   if (element.lpexLoanFor == this.lpexLoanFor)
          //     this.model.existingExposure.push(element);
          // });
          if (this.model.existingExposure.length == 0)
          { 
            this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexRemarks: '' });
            this.loanForFlag='C'; 
         }


  if(this.loanForFlag=='C')  
    {this.lpexLoanFor="1";}
  else
  if(this.loanForFlag=='T')  
   { this.lpexLoanFor="2";}
  else
    if(this.loanForFlag=='O')  
  {  this.lpexLoanFor="3";  } 
   
    this.onChangeLoanFor(this.lpexLoanFor);
          
      
        
//            else
// {
//   this.model.existingExposure.forEach(element => {
//   element.lpexLoanAmt=element.lpexLoanAmt!=""  ? parseFloat(element.lpexLoanAmt).toFixed(2):'';
//   element.lpexAnnualInstl=element.lpexAnnualInstl!="" ? parseFloat(element.lpexAnnualInstl).toFixed(2):'';
//   element.lpexCurrOs=element.lpexCurrOs!="" && element.lpexCurrOs!='NaN' ? parseFloat(element.lpexCurrOs).toFixed(2) : '';
// });
// }
            this.disableFields = true;
            this.disableNewButton = false;
            this.disableEditButton = false;
            this.disableSaveButton = true;
            this.disableDeleteAllButton = true;
            this.disableCancelButton = true;

        }
       
         
      },
      error => {
        // this.alertService.error(error);
      });
     
    },
    error => {
      // this.alertService.error(error);
    });
    this.all = false;
    this.crop = false;
  }

  onChangeLoanFor(val: any) {
    this.model.existingExposure = [];
    this.all = false;
    if (val == 1) {
      this.crop = false;
      this.term = true;
      this.other = true;
      this.comment = false;
      this.freq = 'Interest servicing';
      this.os = false;
      this.osCont = 'Outstanding Rs.';
      this.remarks = 'Remarks';
      this.lpexLoanFor = "1";
this.loanForFlag='C';
      this.temp.forEach(element => {
         if (element.lpexLoanFor == 1)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0)
        this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexRemarks: '' });


    } else if (val == 2) {
      this.crop = true;
      this.term = false;
      this.other = true;
      this.comment = true;
      this.freq = 'Frequency of Installment servicing ';
      this.os = false;
      this.osCont = 'Balance POS as on date (Rs.)';
      this.remarks = 'Track Status & Remark';
      this.lpexLoanFor = "2";
      this.loanForFlag='T';
      this.temp.forEach(element => {
        
        if (element.lpexLoanFor == 2)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0)
      {  this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '2', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: ' ', lpexAnnualInstl: '', lpexCurrOs: '',  lpexInstlDue: '', lpexInstlPaid: '', lpexAvgDelayDays: '', lpexLandMortDetails: '', lpexRemarks: '' });}
      else
{
  this.model.existingExposure.forEach(element => {
  element.lpexLoanAmt=element.lpexLoanAmt!="" ? parseFloat(element.lpexLoanAmt).toFixed(2):'';
  element.lpexAnnualInstl=element.lpexAnnualInstl!="" ? parseFloat(element.lpexAnnualInstl).toFixed(2):'';
  element.lpexCurrOs=element.lpexCurrOs!="" && element.lpexCurrOs!='NaN' ? parseFloat(element.lpexCurrOs).toFixed(2):'';
});
}

    } else if (val == 3) {
      this.crop = true;
      this.term = true;
      this.other = false;
      this.comment = false;
      this.freq = 'Repayment Frequency';
      this.os = true;
      this.remarks = 'Remarks';
      this.lpexLoanFor = "3";
      this.loanForFlag='O';
      this.temp.forEach(element => {
      
        if (element.lpexLoanFor == 3)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0)
     {   this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '3', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexAnnualInstl: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexLandMortDetails: '', lpexRemarks: '' });}
     else
{
  this.model.existingExposure.forEach(element => {
    element.lpexLoanAmt=element.lpexLoanAmt!="" ? parseFloat(element.lpexLoanAmt).toFixed(2):'';
    element.lpexAnnualInstl=element.lpexAnnualInstl!="" ? parseFloat(element.lpexAnnualInstl).toFixed(2):'';
   
  
});
}
      
    
      }

    this.disableFields = true;
    this.disableNewButton = false;
    this.disableEditButton = false;
    this.disableSaveButton = true;
    this.disableDeleteAllButton = true;
    this.disableCancelButton = true;
  }

  addRow() {
    if (this.lpexLoanFor == "1")
      this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexRemarks: '' });
    else if (this.lpexLoanFor == "2")
      this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '2', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: ' ', lpexAnnualInstl: '', lpexCurrOs: '', lpexInstlDue: '', lpexInstlPaid: '', lpexAvgDelayDays: '', lpexLandMortDetails: '', lpexRemarks: '' });
    else if (this.lpexLoanFor == "3")
    this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '3', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexAnnualInstl: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexLandMortDetails: '', lpexRemarks: '' });

    this.disableFields = false;
    this.disableNewButton = false;
    this.disableEditButton = true;
    this.disableSaveButton = false;
    this.disableDeleteAllButton = false;
    this.disableCancelButton = false;
  }

  saveExistingExposure() {
    if(this.lpexLoanFor == "1")
    {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList1);
    }
    else if(this.lpexLoanFor == "2")
    {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList2);
    }
    else if(this.lpexLoanFor == "3")
    {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList3);
    }

  

    if(this.flag )
    {
    this.existingexposureService.saveExistingExposure(this.model.existingExposure)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
        successStatus();
       this.ngOnInit();
        }
      error => {
        failedStatus();
        // this.alertService.error(error);
      }
      });
    }
   
  }


  onClickDeleteButton(row: any, id: any, i: any) {
    if(this.disableEditButton)
    {
    if (id == '' || id == undefined) {
      this.model.existingExposure.splice(i, 1);
    }
    else {
      this.existingexposureService.deleteExistingExposure(row)
        .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            this.ngOnInit();
                     }
      
           
        },
        error => {
          // this.alertService.error(error);
        });
     } 
    }
  }

  onClickDeleteAllButton() {
    this.existingexposureService.deleteAllExistingExposure(this.model.existingExposure,this.lpexLoanFor)
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.ngOnInit();
          this.disableFields = false;
          this.disableNewButton = false;
          this.disableEditButton = true;
          this.disableSaveButton = false;
          this.disableDeleteAllButton = false;
          this.disableCancelButton = false;
        }
      
      },
      error => {
        // this.alertService.error(error);
      });
  }

  onClickEditButton() {
    this.disableFields = false;
    this.disableNewButton = false;
    this.disableEditButton = true;
    this.disableSaveButton = false;
    this.disableDeleteAllButton = false;
    this.disableCancelButton = false;
   
  }

  onClickCancelButton() {
    if(confirm("Do you want to Cancel?"))
    {
      this.ngOnInit();
    }
    else{
      return false;
    }
  }

  toFixCall(value)
  {
    let temp="";
    if(value!=="" && value!=null)
   {
     temp=parseFloat(value).toFixed(2);
   }
  return temp;


  }



// onSettingData()
// {
//   this.existingexposureService.getExistingExposure()
//   .subscribe(
//   data => { this.data=data;
//     this.crop = false;
//     this.term = true;
//     this.other = true;
//     if (this.data.success == true) {
 
//       this.borrowerType= this.data.loanAvailableBy;
//     this.temp = this.data.existingExposureList;
     
   
//       this.temp.forEach(element => {
       
//         if (element.lpexLoanFor == this.lpexLoanFor)
//           this.model.existingExposure.push(element);
//       });
//       if (this.model.existingExposure.length == 0)
//         this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: 's', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexRemarks: '' });
// else
// {
// this.model.existingExposure.forEach(element => {
// element.lpexLoanAmt=element.lpexLoanAmt!="" ? parseFloat(element.lpexLoanAmt).toFixed(2):'';
// element.lpexAnnualInstl=element.lpexAnnualInstl!="" ? parseFloat(element.lpexAnnualInstl).toFixed(2):'';
// element.lpexCurrOs=element.lpexCurrOs!="" ? parseFloat(element.lpexCurrOs).toFixed(2):'';
// });
// }
//         this.disableFields = true;
//         this.disableNewButton = false;
//         this.disableEditButton = false;
//         this.disableSaveButton = true;
//         this.disableDeleteAllButton = true;
//         this.disableCancelButton = true;

//     }
   
     
//   });
// }
}
