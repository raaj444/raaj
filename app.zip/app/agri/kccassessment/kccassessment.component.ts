import { Component, OnInit, ViewChild } from '@angular/core';
import { KccService } from "../../util/service/agriservices/kcc.service";
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ChangenoteComponent } from "../../common/changenote/changenote.component";
import { ChangenoteService } from "../../util/service/commonservices/changenote.service";
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;

@Component({
  selector: 'lp-kccassessment',
  templateUrl: './kccassessment.component.html',
  styleUrls: ['./kccassessment.component.css']
})
export class KccassessmentComponent extends Validator implements OnInit {
  data: any;
  approvedFlag: any;
  deviationPercent: any = 0.00;
  deviationRatio: any = 0.00;
  acreSOfdeviation: any = 0.00;
  sumvalueSOfdeviation: any = 0.00;
  toatalLeaseLand: any = 0.00;
  freezeButtondisable: boolean;
  fieldDisable: boolean;
  model: any = {};
  sofListAll = [];
  sofListAllWithoutDeviation = [];
  sofList = [];
  sofTempList = [];
  deviationFinalList = [];
  deviationList = [];
  deviationOwnedList = [];
  deviationLeadedList = [];
  fdlList = [];
  stateList = [];
  cropList = [];
  ownLandDetails: any = [];
  LeaseLandDetails: any = [];
  SofDeviation: any = [];
  acerageLeaseDeviation: any = [];
  DeviationAcerageList: any = [];
  DeviationAcerageStateList: any = [];
  repayFreqList: any = [];
  fdltermList: any = [];
  DeviationListMap: any;
  stateCode: string = "";
  totOwnedLand: any = 0.00;
  freezeDisabled: boolean = false;
  unfreezeDisabled: boolean = false;
  sofSum: any = 0.00;
  fdlSum: any = 0.00;
  asstotal: any = 0.00;
  valueSofSum: any = 0.00;
  valueSOfwithOutdeviation: any = 0.00;
  valueSOfdeviation: any = 0.00;
  valueSOfLeaseddeviation: any = 0.00;
  valueSOfOwndeviation: any = 0.00;
  totalSOfOwndeviation: any = 0.00;
  valueFdlSum: any = 0.00;
  valueTot: any = 0.00;
  eligibleSofAmt: any = 0.00;
  eligibleFdlAmt: any = 0.00;
  eligibleTotAmt: any = 0.00;
  finalSofKcc: any = 0.00;
  finalFdlKcc: any = 0.00;
  finalTotKcc: any = 0.00;
  OfferingTot: any = 0.00;
  totEligibleSof: any = 0.00;
  totEligibleFdl: any = 0.00;
  checkstateflag: boolean;
  conditionFlag: boolean;
  totalSofValue: any = 0.00;
  modelForChngNote: any;
  finalSOfOwndeviation: any = 0.00;
  finalSOfLeaseddeviation: any = 0.00;
  finalFdlSum: any = 0.00;
  fdlfieldDisable: boolean;
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  pageAccess: any;
  tenorDisable: any;
  freezeFlag: any;
  fdlFac: any;
  tempFdl: any = [];
  modelRemarks: any = {};
  CropListflag: any;
  FdlvalueList = ['alRepayfreq', 'alRepaymonths', 'alMoratorium', 'alFirstinstalldue', 'alLastinstalldue'];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private kccService: KccService,
    private fieldvalidation: Fieldvalidation, private changenoteService: ChangenoteService) { super(); }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.conditionFlag = true;
    this.freezeButtondisable = true;
    this.sofListAll = [];
    this.sofList = [];
    this.deviationList = [];
    this.fdlList = [];
    this.stateList = [];
    this.cropList = [];
    this.ownLandDetails = [];
    this.LeaseLandDetails = [];
    this.SofDeviation = [];
    this.acerageLeaseDeviation = [];
    this.DeviationAcerageList = [];
    this.DeviationAcerageStateList = [];
    this.deviationFinalList = [];
    this.sofTempList = [];
    this.deviationOwnedList = [];
    this.deviationLeadedList = [];
    this.sofListAllWithoutDeviation = [];
    this.fieldDisable = false;
    this.modelRemarks = { lkrAssessRemark: "", lkrIntFreq: "" };
    this.kccService.getAllKccData().subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.pageAccess = this.data.pageAccess;
          this.sofSum = 0.00;
          this.fdlSum = 0.00;
          this.asstotal = 0.00;
          this.valueSofSum = 0.00;
          this.valueSOfwithOutdeviation = 0.00;
          this.valueSOfdeviation = 0.00;
          this.valueSOfLeaseddeviation = 0.00;
          this.valueSOfOwndeviation = 0.00;
          this.totalSOfOwndeviation = 0.00;
          this.valueFdlSum = 0.00;
          this.valueTot = 0.00;
          this.eligibleSofAmt = 0.00;
          this.eligibleFdlAmt = 0.00;
          this.eligibleTotAmt = 0.00;
          this.finalSofKcc = 0.00;
          this.finalFdlKcc = 0.00;
          this.finalTotKcc = 0.00;
          this.OfferingTot = 0.00;
          this.totEligibleSof = 0.00;
          this.totEligibleFdl = 0.00;
          this.totalSofValue = 0.00;
          this.finalSOfOwndeviation = 0.00;
          this.finalSOfLeaseddeviation = 0.00;
          this.finalFdlSum = 0.00;
          this.deviationPercent = 0.00;
          this.deviationRatio = 0.00;
          this.acreSOfdeviation = 0.00;
          this.sumvalueSOfdeviation = 0.00;
          this.toatalLeaseLand = 0.00;
          this.totOwnedLand = 0.00;
          this.CropListflag = this.data.cropListflag;
          if (this.data.LpagriKccassessmentRemark != "" && this.data.LpagriKccassessmentRemark != null && this.data.LpagriKccassessmentRemark != undefined) {
            this.modelRemarks = this.data.LpagriKccassessmentRemark;
          }
          this.model = this.data.LpagriKccEligibility;
          if (this.model.lkeSofOfferAmt == null)
            this.model.lkeSofOfferAmt = 0.00;
          else
            this.model.lkeSofOfferAmt = this.model.lkeSofOfferAmt.toFixed(2);

          if (this.model.lkeFdlOfferAmt == null)
            this.model.lkeFdlOfferAmt = 0.00;
          else
            this.model.lkeFdlOfferAmt = this.model.lkeFdlOfferAmt.toFixed(2);

          if (this.model.lkeFreeze == "Y") {
            this.fieldDisable = true;
            this.freezeButtondisable = false;
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(true);
            }
          }
          else {
            if (this.model.lkeSofOwnFundPercent == null)
              this.model.lkeSofOwnFundPercent = 100;
            if (this.model.lkeSofLeasedFundPercent == null)
              this.model.lkeSofLeasedFundPercent = 100;
            if (this.model.lkeFdlFundPercent == null)
              this.model.lkeFdlFundPercent = 100;
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }
          if (this.data.OwnLandDetails != null) {
            this.ownLandDetails = this.data.OwnLandDetails;
          }
          if (this.data.LpagriLeaseDetList != null) {
            this.LeaseLandDetails = this.data.LpagriLeaseDetList;
          }
          if (this.data.listForSofDeviationAcer != null) {
            this.DeviationAcerageList = this.data.listForSofDeviationAcer;
            if (this.data.lpmasCropSofDevAcerageMap != "") {
              this.DeviationListMap = this.data.lpmasCropSofDevAcerageMap;
            }
          }
          if (this.data.lpagriLeasedlandDeviationList != null)
            this.acerageLeaseDeviation = this.data.lpagriLeasedlandDeviationList;
          if (this.data.lpagriSofDeviationList != null)
            this.SofDeviation = this.data.lpagriSofDeviationList;
          
          this.freezeDisabled = this.data.savedflag;
          this.approvedFlag = this.data.approvedflag;
          this.stateList = this.data.stateList;
          this.fdlList = this.data.fdlList;
          this.sofSum = parseFloat(this.data.sofAmtRequested).toFixed(2);
          this.fdlSum = parseFloat(this.data.fdlAmtRequested).toFixed(2);
        
          this.asstotal = (parseFloat(this.sofSum) + parseFloat(this.fdlSum)).toFixed(2);
          this.cropList = this.data.cropList;
          if (this.data.sofAllList != undefined && this.data.sofAllList != null)
            this.sofListAll = this.data.sofAllList;
          if (this.sofListAll.length == 0) {
            this.freezeButtondisable = true;
            this.conditionFlag = false;
          }
          this.totalSofValue = 0.00;
          if (this.sofListAll != null) {
            this.sofListAll.forEach(sofvalue => {
              let stateCode = "";
              let stateDeviation = "";
              var keepGoing = true;
              if (sofvalue.lkaAcre == 0) {
                this.conditionFlag = false;
              }
              if (sofvalue.lkaCalcType != "D" && sofvalue.lkaCalcType != "4") {
                this.totalSofValue += parseFloat(sofvalue.lkaSofValue);
              }
              if (sofvalue.lkaCalcType != "D") {
                this.sofTempList.push(sofvalue);
              }
              this.stateList.forEach(state => {
                if (state.sgmStateCode == sofvalue.lkaStateId) {
                  stateDeviation = state.lgmDeviation;
                  if ((stateDeviation == "N" || stateDeviation == null) && sofvalue.lkaCalcType != "D") {
                    this.sofList.push(sofvalue);
                  }
                  else {
                    if (this.freezeDisabled == false && stateDeviation == "Y")
                      this.deviationList.push(sofvalue);
                    if (sofvalue.lkaCalcType == "D" && this.freezeDisabled == true)
                      this.deviationFinalList.push(sofvalue);
                  }
                }
              });
              sofvalue.lkaSofAcre = parseFloat(sofvalue.lkaSofAcre).toFixed(2);
              sofvalue.lkaSofValue = parseFloat(sofvalue.lkaSofValue).toFixed(2);
            });
          }
          if (this.freezeDisabled == true) {
            this.sofListAll = [];
            this.sofTempList.forEach(sofvalue => {
              this.sofListAll.push(sofvalue);
            });
          }
          this.totalSofValue = this.totalSofValue.toFixed(2);
          this.sofList = JSON.parse(JSON.stringify(this.sofList));
          this.deviationList = JSON.parse(JSON.stringify(this.deviationList));
          if (this.freezeDisabled == false) {
            if (this.deviationList != null) {
              this.deviationList.forEach(sof => {
                this.totOwnedLand = 0.00;
                this.toatalLeaseLand = 0.00;
                this.ownLandDetails.forEach(landDetails => {
                  if (landDetails.aldstate == sof.lkaStateId) {
                    this.totOwnedLand = parseFloat(landDetails.aldCultivable) + parseFloat(landDetails.aldNonCultivable);
                  }
                });
                if (this.LeaseLandDetails != null) {
                  this.LeaseLandDetails.forEach(leaselandDetails => {
                    if (leaselandDetails.lldStateid == sof.lkaStateId) {
                      this.toatalLeaseLand = parseFloat(leaselandDetails.lldCulArea) + parseFloat(leaselandDetails.lldUnculArea);
                    }
                  });
                }
                let acres = this.totOwnedLand;
                if (sof.lkaOwnerType == "1") {
                  if (this.freezeDisabled == false) {
                    sof.lkaTotLeasedland = 0.00;
                    sof.lkaEligibleAcre = 0.00;
                    sof.lkaTotOwnland = 0.00;
                    sof.lkaTotOwnland = this.totOwnedLand;
                    if (this.SofDeviation != null) {
                      this.SofDeviation.forEach(dev => {
                        if (dev.lsdStateCode == sof.lkaStateId) {
                          if (parseFloat(acres) >= parseFloat(dev.lsdAcrefrom) && parseFloat(acres) <= parseFloat(dev.lsdAcreto)) {
                            sof.lkaDeviation = dev.lsdDeviationPercent;
                            if (sof.lkaDeviation == 0)
                              sof.lkaSofValue = parseFloat(sof.lkaSofValue);
                            else
                              sof.lkaSofValue = parseFloat(sof.lkaSofValue) + (parseFloat(sof.lkaSofValue) * (parseFloat(sof.lkaDeviation) / 100));
                          }
                        }
                      });
                    }
                  }
                }
                if (sof.lkaOwnerType == "2") {
                  if (this.freezeDisabled == false) {
                    sof.lkaTotOwnland = 0.00;
                    sof.lkaTotLeasedland = 0.00;
                    sof.lkaTotOwnland = this.totOwnedLand;
                    sof.lkaTotLeasedland = this.toatalLeaseLand;
                    let Eligibleleaseland = 0.00;
                    let totCalculated = 0.00;
                    if (this.acerageLeaseDeviation != null) {
                      this.acerageLeaseDeviation.forEach(elgLand => {
                        if (elgLand.lldStateCode == sof.lkaStateId) {
                          if (parseFloat(acres) >= parseFloat(elgLand.lldAcrefrom) && parseFloat(acres) <= parseFloat(elgLand.lldAcreto)) {
                            Eligibleleaseland = parseFloat(acres) * parseFloat(elgLand.lldDeviationPercent);
                            sof.lkaDeviation = parseFloat(elgLand.lldDeviationPercent);
                            sof.lkaEligibleAcre = Eligibleleaseland;
                          }
                        }
                      });
                    }
                    if (this.DeviationListMap != null) {
                      this.DeviationAcerageList.forEach(deviation => {
                        if (deviation.lsStateCode == sof.lkaStateId) {
                          this.DeviationAcerageStateList = this.DeviationListMap[deviation.lsRowId];
                        }
                      });
                      if (this.DeviationAcerageStateList != null) {
                        this.DeviationAcerageStateList.forEach(element => {
                          if (parseFloat(sof.lkaTotOwnland) >= parseFloat(element.lcsAcreFrom) && parseFloat(sof.lkaTotLeasedland) <= parseFloat(element.lcsAcreTo)) {
                            sof.lkaSofAcre = element.lcsValue;
                            sof.lkaSofValue = parseFloat(sof.lkaTotLeasedland) * parseFloat(element.lcsValue);
                          }
                        });
                      }
                    }
                  }
                }
              });
              let i = 1;
              let sumAcre;
              this.stateList.forEach(state => {
                this.checkstateflag = false;
                this.sumvalueSOfdeviation = 0.00;
                sumAcre = 0.00;
                this.totOwnedLand = 0.00;
                this.deviationPercent = 0.00;
                this.acreSOfdeviation = 0.00;
                this.deviationList.forEach(sof => {
                  if (state.sgmStateCode == sof.lkaStateId) {
                    if (sof.lkaOwnerType == "1") {
                      this.checkstateflag = true;
                      this.toatalLeaseLand = 0.00;
                      this.totOwnedLand = parseFloat(sof.lkaTotOwnland);
                      this.deviationPercent = parseFloat(sof.lkaDeviation);
                      this.sumvalueSOfdeviation += parseFloat(sof.lkaSofValue);
                      this.acreSOfdeviation += parseFloat(sof.lkaSofAcre);
                      sumAcre += parseFloat(sof.lkaAcre);
                    }
                  }
                });
                if (this.checkstateflag) {
                  this.deviationFinalList.push({ lkaLoanType: "1", lkaAcre: sumAcre, lkaFdlAcre: "0", lkaFdlValue: "0", lkaCropType: "0", lkaCalcType: "D", lkaOrderNo: i, lkaSofAcre: this.acreSOfdeviation, lkaSofValue: this.sumvalueSOfdeviation, lkaFundPercent: '100', lkaDeviation: this.deviationPercent, lkaTotLeasedland: this.toatalLeaseLand, lkaTotOwnland: this.totOwnedLand, lkaOwnerType: '1', lkaStateId: state.sgmStateCode, lkaEligibleAcre: "0" });
                  i++;
                }
              });
              let j = 1;
              this.stateList.forEach(state => {
                this.checkstateflag = false;
                sumAcre = 0.00;
                let eligibleAcre = 0.00;
                this.sumvalueSOfdeviation = 0.00;
                this.totOwnedLand = 0.00;
                this.deviationRatio = 0.00;
                this.acreSOfdeviation = 0.00;
                this.toatalLeaseLand = 0.00;
                this.deviationList.forEach(sof => {
                  if (state.sgmStateCode == sof.lkaStateId) {
                    if (sof.lkaOwnerType == "2") {
                      this.checkstateflag = true;
                      this.toatalLeaseLand = parseFloat(sof.lkaTotLeasedland);
                      this.totOwnedLand = parseFloat(sof.lkaTotOwnland);
                      this.deviationRatio = parseFloat(sof.lkaDeviation);
                      this.sumvalueSOfdeviation += parseFloat(sof.lkaSofValue);
                      this.acreSOfdeviation += parseFloat(sof.lkaSofAcre);
                      eligibleAcre += parseFloat(sof.lkaEligibleAcre);
                      sumAcre += parseFloat(sof.lkaAcre);
                    }
                  }
                });
                if (this.checkstateflag) {
                  this.deviationFinalList.push({ lkaEligibleAcre: eligibleAcre, lkaLoanType: "1", lkaAcre: sumAcre, lkaFdlAcre: "0", lkaFdlValue: "0", lkaCropType: "0", lkaCalcType: "D", lkaOrderNo: j, lkaSofAcre: this.acreSOfdeviation, lkaSofValue: this.sumvalueSOfdeviation, lkaFundPercent: '100', lkaDeviation: this.deviationRatio, lkaTotLeasedland: this.toatalLeaseLand, lkaTotOwnland: this.totOwnedLand, lkaOwnerType: '2', lkaStateId: state.sgmStateCode });
                  j++;
                }
              });
            }
          }
          if (this.sofList != null) {
            this.sofList.forEach(element => {
              this.valueSOfwithOutdeviation += parseFloat(element.lkaSofValue);
            });
          }
          if (this.fdlList != null) {
            this.fdlList.forEach(fdl => {
              this.valueFdlSum += fdl.lkaFdlValue;
              fdl.lkaFdlAcre = parseFloat(fdl.lkaFdlAcre).toFixed(2);
              fdl.lkaFdlValue = parseFloat(fdl.lkaFdlValue).toFixed(2);
            });
          }
          if (this.deviationFinalList != null) {
            this.deviationFinalList.forEach(sof => {
              if (sof.lkaOwnerType == "1") {
                this.deviationOwnedList.push(sof);
                this.valueSOfOwndeviation += parseFloat(sof.lkaSofValue);
              }
              else {
                this.deviationLeadedList.push(sof);
                this.valueSOfLeaseddeviation += parseFloat(sof.lkaSofValue);
              }
              sof.lkaSofAcre = parseFloat(sof.lkaSofAcre).toFixed(2);
              sof.lkaSofValue = parseFloat(sof.lkaSofValue).toFixed(2);
            });
          }
          this.sofListAll.forEach(sofData => {
            if (sofData.lkaCalcType != 4) {
              this.sofListAllWithoutDeviation.push(sofData);
            }
          });


          // if (this.freezeDisabled == false) {
          //   this.eligibleSofAmt = (Math.min(this.valueSofSum, this.sofSum)).toFixed(2);
          //   this.eligibleFdlAmt = (Math.min(this.valueFdlSum, this.fdlSum)).toFixed(2);
          // }
          // else {
          // this.eligibleSofAmt = (Math.min(this.finalSofKcc, this.sofSum)).toFixed(2);
          // this.eligibleFdlAmt = (Math.min(this.finalFdlSum, this.fdlSum)).toFixed(2);
          // }
          this.calculateEligibleAmt();
          if (this.conditionFlag == false) {
            this.finalSofKcc = 0.00;
            this.finalFdlKcc = 0.00;
            this.freezeButtondisable = true;

          }
          else {
            this.freezeButtondisable = false;
          }
          if (this.CropListflag == false)
          this.conditionFlag = true;
          this.finalTotKcc = (parseFloat(this.finalSofKcc) + parseFloat(this.finalFdlKcc)).toFixed(2);
          this.calculateOfferingAmt();
          // ******************FDL TERM LOAN *****************//
          this.model.facilityDetailsList = this.data.FacilityList;
          this.repayFreqList = this.data.repayFreqList;
          this.fdlFac = this.data.Agri;
          if (this.fdlFac) {
            this.model.FdltermloanList = this.data.FdltermloanList;
            if (this.model.FdltermloanList.length < 1) {
              this.tenorDisable = true;
              this.disableButton(true, false, true, false);
            }
            else {
              this.tenorDisable = true;
              this.disableButton(false, true, false, true);
            }
            this.model.facilityDetailsList.forEach(facility => {
              let count = 0;
              this.model.FdltermloanList.forEach(fdltermloan => {
                if (fdltermloan.lfFacno == facility.lfFacNo) {
                  ++count;
                  fdltermloan.facName = facility.facName;
                  fdltermloan.lfProposedLimit = facility.lfProposedLimit;
                  if (fdltermloan.lfFirstinstalldue != "" && fdltermloan.lfFirstinstalldue != undefined) {
                    var duedate = fdltermloan.lfFirstinstalldue;
                    var datearray = duedate.split("-");
                    fdltermloan.lfFirstinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                  }
                  if (fdltermloan.lfLastinstalldue != "" && fdltermloan.lfLastinstalldue != undefined) {
                    var lastduedate = fdltermloan.lfLastinstalldue;
                    var datearray = lastduedate.split("-");
                    fdltermloan.lfLastinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                  }
                }
              });
              if (count == 0) {
                this.model.FdltermloanList.push({
                  lfRepayfreq: '', lfRepaymonths: '', lfTenor: facility.lfTenor, lfMoratorium: '', lfFirstinstalldue: '', lfLastinstalldue: '',
                  lfFacno: facility.lfFacNo, facName: facility.facName, lfProposedLimit: facility.lfProposedLimit,
                });
              }
            });
            this.freezeFlag = this.freezeDisabled;
            if (this.model.FdltermloanList.length > 1) {
              this.model.FdltermloanList = this.model.FdltermloanList.sort((a, b) => {
                var a = a.lfFacno;
                var b = b.lfFacno;
                if (a < b)
                  return -1;
                if (a > b)
                  return 1;
                return 0;
              });
            }
            if (this.freezeDisabled)
              this.disableButton(true, true, true, true);
            else {
              this.disableButton(false, true, true, true);
            }
          }
          else {
            this.disableButton(true, true, true, true);
            this.model.FdltermloanList = [];
          }
        }
      },
      error => {
      });
  }
  calculateFundPercent(e: any, label: string) {
    if (e != "") {
      if (label == 'lkeFdlFundPercent') {
        var AcreVal = parseFloat(parseFloat(this.model.lkeFdlFundPercent).toFixed(2));
        if (AcreVal > 999.99) {
          this.model.lkeFdlFundPercent = "";
          $('#lkeFdlFundPercent').addClass("has-error");
        }
        else {
          $('#lkeFdlFundPercent').removeClass("has-error");
          this.caluculatefundpercent();
        }
      }
      else if (label == 'lkeSofLeasedFundPercent') {
        var AcreVal = parseFloat(parseFloat(this.model.lkeSofLeasedFundPercent).toFixed(2));
        if (AcreVal > 999.99) {
          this.model.lkeSofLeasedFundPercent = "";
          $('#lkeSofLeasedFundPercent').addClass("has-error");
        }
        else {
          $('#lkeSofLeasedFundPercent').removeClass("has-error");
          this.caluculatefundpercent();
        }
      }
      else if (label == 'lkeSofOwnFundPercent') {
        var AcreVal = parseFloat(parseFloat(this.model.lkeSofOwnFundPercent).toFixed(2));
        if (AcreVal > 999.99) {
          this.model.lkeSofOwnFundPercent = "";
          $('#lkeSofOwnFundPercent').addClass("has-error");
        }
        else {
          $('#lkeSofOwnFundPercent').removeClass("has-error");
          this.caluculatefundpercent();
        }
      }
    }
  }

  calculateEligibleAmt() {
    this.totalSOfOwndeviation = parseFloat(this.valueSOfOwndeviation) + parseFloat(this.valueSOfwithOutdeviation);
    this.valueSOfdeviation = parseFloat(this.valueSOfOwndeviation) + parseFloat(this.valueSOfLeaseddeviation);
    this.valueSofSum = parseFloat(this.totalSOfOwndeviation) + parseFloat(this.valueSOfLeaseddeviation);
    this.finalSOfOwndeviation = (parseFloat(this.totalSOfOwndeviation) * (this.model.lkeSofOwnFundPercent / 100)).toFixed(2);
    this.finalSOfLeaseddeviation = (parseFloat(this.valueSOfLeaseddeviation) * (this.model.lkeSofLeasedFundPercent / 100)).toFixed(2);
    this.finalFdlSum = (this.valueFdlSum * (this.model.lkeFdlFundPercent / 100)).toFixed(2);
    this.valueTot = (parseFloat(this.valueSofSum) + parseFloat(this.valueFdlSum)).toFixed(2);
    this.valueSOfOwndeviation = parseFloat(this.valueSOfOwndeviation).toFixed(2);
    this.valueSOfLeaseddeviation = parseFloat(this.valueSOfLeaseddeviation).toFixed(2);
    this.valueSOfdeviation = parseFloat(this.valueSOfdeviation).toFixed(2);
    this.finalSofKcc = parseFloat(this.finalSOfOwndeviation) + parseFloat(this.finalSOfLeaseddeviation);
    this.eligibleSofAmt = (Math.min(this.finalSofKcc, this.sofSum)).toFixed(2);
    this.eligibleFdlAmt = (Math.min(this.finalFdlSum, this.fdlSum)).toFixed(2);
    this.eligibleTotAmt = (parseFloat(this.eligibleSofAmt) + parseFloat(this.eligibleFdlAmt)).toFixed(2);
    this.finalFdlKcc = parseFloat(this.finalFdlSum).toFixed(2);
    this.valueFdlSum = parseFloat(this.valueFdlSum).toFixed(2);
    this.valueSofSum = parseFloat(this.valueSofSum).toFixed(2);
    this.finalSofKcc = this.finalSofKcc.toFixed(2);
    this.finalTotKcc = (parseFloat(this.finalSofKcc) + parseFloat(this.finalFdlKcc)).toFixed(2);
    this.model.lkeSofOfferAmt = this.eligibleSofAmt;
    this.model.lkeFdlOfferAmt = this.eligibleFdlAmt;
  }



  caluculatefundpercent() {
    this.calculateEligibleAmt();
    this.calculateOfferingAmt();
  }
  doFreeze() {
    let flagCM = true;
    let fdlFlag = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (this.model.FdltermloanList.length > 0)
      fdlFlag = this.fieldvalidation.multipleFieldValidation(this.model.FdltermloanList.length, this.FdlvalueList)
    if (flagCM && fdlFlag) {
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      if (confirm("Please Note. You are freezing the assessment part.")) {
        if (this.deviationFinalList != null) {
          this.deviationFinalList.forEach(sof => {
            this.sofListAll.push(sof);
          });
        }
        this.kccService.saveAllData(this.sofListAll, this.fdlList, this.model, this.modelRemarks).subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.valueSofSum = 0.00;
              this.valueFdlSum = 0.00;
              this.valueSOfwithOutdeviation = 0.00;
              this.valueSOfLeaseddeviation = 0.00;
              this.valueSOfOwndeviation = 0.00;
              this.valueSOfdeviation = 0.00;
              this.ngOnInit();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
          },
          error => {
          });
      }
      else {
        return false;
      }
    }
  }
  doUnFreeze() {
    if (confirm("Please Note. You are Unfreezing the assessment part.")) {
      if (this.deviationFinalList != null) {
        this.deviationFinalList.forEach(sof => {
          this.sofListAll.push(sof);
        });
      }
      this.kccService.deleteAllData(this.sofListAll, this.fdlList, this.model).subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.valueSofSum = 0.00;
            this.valueFdlSum = 0.00;
            this.valueSOfwithOutdeviation = 0.00;
            this.valueSOfLeaseddeviation = 0.00;
            this.valueSOfOwndeviation = 0.00;
            this.valueSOfdeviation = 0.00;
            this.ngOnInit();
          }
        },
        error => {
        });
    }
    else {
      return false;
    }
  }
  calculateOfferingAmt() {
    if (this.model.lkeSofOfferAmt != "" && this.model.lkeSofOfferAmt != "0.00" && this.model.lkeSofOfferAmt != null) {
      if (parseFloat(this.model.lkeSofOfferAmt) > parseFloat(this.eligibleTotAmt)) {
        alert("SOF Offering Amount Should not be greater than Final Total Amount");
        this.model.lkeSofOfferAmt = " ";
        return;
      }
      else if (this.eligibleTotAmt != 0) {
        this.model.lkeFdlOfferAmt = (parseFloat(this.eligibleTotAmt) - parseFloat(this.model.lkeSofOfferAmt)).toFixed(2);
        this.totEligibleSof = ((parseFloat(this.model.lkeSofOfferAmt) / parseFloat(this.eligibleTotAmt)) * 100).toFixed(2);
        this.totEligibleFdl = ((parseFloat(this.model.lkeFdlOfferAmt) / parseFloat(this.eligibleTotAmt)) * 100).toFixed(2);
      }
      else {
        this.totEligibleSof = 0.00;
        this.totEligibleFdl = 0.00;
        this.model.lkeSofOfferAmt = 0.00;
        this.model.lkeFdlOfferAmt = 0.00;
        this.freezeButtondisable = true;
      }
      this.OfferingTot = (parseFloat(this.model.lkeSofOfferAmt) + parseFloat(this.model.lkeFdlOfferAmt)).toFixed(2);
      this.model.lkeSofOfferAmt = parseFloat(this.model.lkeSofOfferAmt).toFixed(2);
    }
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean) {
    if (this.pageAccess == "R") {
      this.fdlfieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deleteAllbuttonDisable = true;
      this.approvedFlag = true;
      this.freezeButtondisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fdlfieldDisable = field;
    }
  }
  onClickEditButton() {
    if (!this.freezeFlag) {
      this.freezeButtondisable = true;
    }
    this.disableButton(true, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  saveFdlTermLoan() {
    let flagCM = true; let flag = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      flag = this.fieldvalidation.multipleFieldValidation(this.model.FdltermloanList.length, this.FdlvalueList)
      var dateComp = this.compareDates();
      if (flag && dateComp) {
        this.model.FdltermloanList.forEach(element => {
          element.lfFirstinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lfFirstinstalldue);
          element.lfLastinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lfLastinstalldue);
        });
        this.kccService.saveFdlData(this.model.FdltermloanList, this.modelRemarks).subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
          },
          error => {
          });
      }
      else {
        return false;
      }
    }
  }
  deleteFdlTerm(field) {
    this.model = field;
    this.model.lstFirstinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lstFirstinstalDate);
    this.model.lstLastinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lstLastinstalDate);
    this.kccService.deleteFdlTerm(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.ngOnInit();
        }
        else {
        }
      },
      error => {
      });
  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }
  effDateRes(id: any) {
    var futdate = (<HTMLInputElement>document.getElementById(id)).value;
    var dateParts = futdate.split("/");
    new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]);
    return new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]).getTime() < new Date().getTime();
  }
  compareDates() {
    var dateCheck = true;
    this.model.FdltermloanList.forEach((element, i) => {
      if (element.lfFirstinstalldue != "" && element.lfLastinstalldue != "") {
        let lfrm = this.fieldvalidation.validatedate('alFirstinstalldue' + i);
        let lto = this.fieldvalidation.validatedate('alLastinstalldue' + i);
        if (lfrm && lto) {
          let vallfrm = this.effDateRes('alFirstinstalldue' + i);
          let vallto = this.effDateRes('alLastinstalldue' + i);
          if (!vallfrm && !vallto) {
            var alFirstinstalldue = (<HTMLInputElement>document.getElementById('alFirstinstalldue' + i)).value;
            var alLastinstalldue = (<HTMLInputElement>document.getElementById('alLastinstalldue' + i)).value;
            //LeadFrom Date
            var firstDue = alFirstinstalldue.split("/");
            alFirstinstalldue = firstDue[1] + '/' + firstDue[0] + '/' + firstDue[2];
            var firstDueDate = new Date(alFirstinstalldue);
            //LeadTo Date
            var lastDue = alLastinstalldue.split("/");
            alLastinstalldue = lastDue[1] + '/' + lastDue[0] + '/' + lastDue[2];
            var lastDueDate = new Date(alLastinstalldue);
            if (firstDueDate.getTime() > lastDueDate.getTime()) {
              $('#alFirstinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "From date must be less than To date");
              dateCheck = false;
            }
            else if (firstDueDate.getTime() == lastDueDate.getTime()) {
              $('#alFirstinstalldue' + i).val("");
              $('#alLastinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alLastinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "Enter valid date");
              $('#alLastinstalldue' + i).attr("placeholder", "Enter valid date");
              dateCheck = false;
            }
          }
          else {
            if (vallfrm) {
              $('#alFirstinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "Past date not allowed here");
              dateCheck = false;
            }
            else {
              $('#alLastinstalldue' + i).val("");
              $('#alLastinstalldue' + i).addClass("has-error");
              $('#alLastinstalldue' + i).attr("placeholder", "Past date not allowed here");
              dateCheck = false;
            }
          }
        }
        else {
          $('#alFirstinstalldue' + i).val("");
          $('#alLastinstalldue' + i).val("");
          $('#alFirstinstalldue' + i).attr("placeholder", "Enter valid date");
          $('#alLastinstalldue' + i).attr("placeholder", "Enter valid date");
          dateCheck = false;
        }
      }
    });
    return dateCheck;
  }
}