import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KccassessmentComponent } from './kccassessment.component';

describe('KccassessmentComponent', () => {
  let component: KccassessmentComponent;
  let fixture: ComponentFixture<KccassessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KccassessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KccassessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
