import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { KccacuntmaturityService } from "../../util/service/agriservices/kccacuntmaturity.service";
import { ChangenoteComponent } from "../../common/changenote/changenote.component";
import { ChangenoteService } from "../../util/service/commonservices/changenote.service";
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-kccacuntmaturity',
  templateUrl: './kccacuntmaturity.component.html',
  styleUrls: ['./kccacuntmaturity.component.css']
})
export class KccacuntmaturityComponent extends Validator implements OnInit {
    data: any;
  model: any = {};
  pageAccess: any;
  fieldDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;
  modelForChngNote: any;

  KccvalueList = ['kccappDates', 'lamNextreview', 'lamAcmaturitydate'];
  minDate: Date;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private KccacuntmaturityService: KccacuntmaturityService, private changenoteService: ChangenoteService) {
    super();
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate());
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.validators();
    this.disableButton(false, true, true, true, true);

    this.KccacuntmaturityService.getKccMaturityDetails()
      .subscribe(
      data => {
      this.data = data;

        if (this.data.success) {
          this.model.lamKccinterest = this.data.lamKccinterest;
          this.model.lamNextreview = this.data.lamNextreview;
          this.model.lamAcmaturitydate = this.data.lamAcmaturitydate;
          this.model.lamRowid = this.data.lamRowid;
          if (this.model.lamRowid == null || this.model.lamRowid == "") {
            this.disableButton(true, false, false, false, true);
          }

          if (this.data.pageAccess)
            this.disableButton(true, true, true, true, true)
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onEdit(true);
          }

        }

      },
      error => {

      });
  }

  validatefuturedate(eventId) {
    this.fieldvalidation.isValidDOB(eventId);
  }
  saveKccMaturity() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      this.flag = this.fieldvalidation.validateField(this.KccvalueList)
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.flag == true) {
        this.changenoteComponent.onSave();
      }
      if (this.flag) {

        this.model.lamNextreview = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lamNextreview);
        this.model.lamAcmaturitydate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lamAcmaturitydate);

        this.KccacuntmaturityService.saveKccmaturity(this.model)
          .subscribe(
          data => {
          this.data = data;
            if (this.data.success) {
              this.ngOnInit();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              successStatus();

            }
          },
          error => {

            failedStatus();
          });

      }
    }
  }

  onClickEditButton() {
    this.disableButton(true, false, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }

  }

  onClickCancelButton() {
    var answer = confirm("Some Data has been Changed, Do you want to save it?");
    if (answer)
      this.saveKccMaturity();
    else {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
    }

    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.ngOnInit();
    }
  }


  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }


  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deletekcc: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deletekcc;
    }
  }

  deleteKccMaturity() {
    if (confirm("Do you want to Delete?")) {
      
      this.KccacuntmaturityService.deleteKccMaturitydetails(this.model)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success) {
            if (this.data.responseData == null) {
              this.model = {};
              this.disableButton(true, false, false, false, true);

            }
          }
        },
        error => {

        });
    }
  }


  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }


}
