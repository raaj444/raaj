import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KccacuntmaturityComponent } from './kccacuntmaturity.component';

describe('KccacuntmaturityComponent', () => {
  let component: KccacuntmaturityComponent;
  let fixture: ComponentFixture<KccacuntmaturityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KccacuntmaturityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KccacuntmaturityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
