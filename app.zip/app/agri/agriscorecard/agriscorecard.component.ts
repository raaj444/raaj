import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Validator } from "../../util/helper/validator";
import { HomeService } from '../../util/service/commonservices/home.service';
declare var $: any;
import { ScorecardmasterService } from '../../util/service/setupservices/scorecardmaster.service';
import { error } from 'selenium-webdriver';
import { ChangenoteComponent } from "../../common/changenote/changenote.component";
import { ChangenoteService } from "../../util/service/commonservices/changenote.service";
declare var successStatus: any;
declare var failedStatus: any;

@Component({
  selector: 'lp-agriscorecard',
  templateUrl: './agriscorecard.component.html',
  styleUrls: ['./agriscorecard.component.css']
})
export class AgriscorecardComponent implements OnInit {
  data: any;
  scoreHeaderList: Array<any> = [];
  valueList: Array<any> = [];
  riskProfileAnalysis: any = [];
  maxtotal: number = 0;
  scoreObtained: number = 0;
  BorrowerList: Array<any> = [];
  editDisabled: boolean;
  saveDisabled: boolean;
  cancelDisabled: boolean;
  fieldDisabled: boolean;
  model: any = {};
  pageAccess: any;
  calc = {};
  modelForChngNote: any;

  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private scorecardService: ScorecardmasterService, private homeService: HomeService, private changenoteService: ChangenoteService) { }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.scoreHeaderList = [];
    this.riskProfileAnalysis = [];

    this.pageAccess = this.homeService.getPageAccess();

    this.buttonAccess(true, false, true, true);
    if (this.pageAccess == 'R')
      this.buttonAccess(true, true, true, true);
    this.scorecardService.getBusinessRuleById({ id: "7" })
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.riskProfileAnalysis = this.data.lpstpRiskruleCutoffrangelist;
        }
      });


    this.getScoreCardCalcForTech();
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onload(this.pageAccess);
    }
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  calcScoreforRange(e: any, header, i: any) {
    var flag = false;
    var invalid = false;
    var value = e.target.value;
    this.valueList = header.LpstpScorecardOptionMasterlist;

    this.valueList.forEach(option => {
      if (!flag) {
        if ((parseInt(option.scpmOptionFrom) <= parseInt(value)) && (parseInt(value) <= parseInt(option.scpmOptionTo))) {

          header.scoreobtained = parseInt(header.LpstpScorecardMasterObj.scmQuestionWgt) * parseInt(option.scpmOptionWgt);
          flag = true;
          invalid = false;
          if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
            header.calc.lsAns = value;
            header.calc.lsAnsWeight = option.scpmOptionWgt;
            header.calc.lsHeaderId = header.LpstpScorecardMasterObj.scmQuesHeaderId;
            header.calc.lsMaxScore = header.maxScore;
            header.calc.lsObtainedScore = header.scoreobtained;
            header.calc.lsScorecardFor = header.LpstpScorecardMasterObj.scmScFor;
            header.calc.lsQuesDesc = header.LpstpScorecardMasterObj.scmQuestion;
            header.calc.lsQuesId = header.LpstpScorecardMasterObj.scmRowId;
            header.calc.lsQuesWeight = header.LpstpScorecardMasterObj.scmQuestionWgt;
            header.calc.lsScorecardType = "R";
          }
        }
        else {
          invalid = true;
          if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
            header.calc.lsObtainedScore = "";
            header.calc.lsAns = "";
            header.calc.lsAnsWeight = option.scpmOptionWgt;
            header.calc.lsHeaderId = header.LpstpScorecardMasterObj.scmQuesHeaderId;
            header.calc.lsMaxScore = header.maxScore;
            header.calc.lsScorecardFor = header.LpstpScorecardMasterObj.scmScFor;
            header.calc.lsQuesDesc = header.LpstpScorecardMasterObj.scmQuestion;
            header.calc.lsQuesId = header.LpstpScorecardMasterObj.scmRowId;
            header.calc.lsQuesWeight = header.LpstpScorecardMasterObj.scmQuestionWgt;
            header.calc.lsScorecardType = "R";
            header.scoreobtained = "";
          }
        }
      }

    });

    if (invalid) {
      var id = e.target.id;
      $('#' + id).val("");
      header.calc.lsAns = "";
      alert("Range should be from " + header.from + " " + " To " + header.to);
      $('#scoreOption_' + i).blur();
    }
    this.scoreObtained = 0;
    this.model.riskProfile = 0;
    this.scoreHeaderList.forEach(header => {
      if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
        if (header.calc.lsObtainedScore != "" && header.calc.lsObtainedScore != null && header.calc.lsObtainedScore != undefined) {
          this.scoreObtained += parseInt(header.calc.lsObtainedScore);
          if (this.model.riskProfile < header.calc.lsObtainedScore) {
            this.model.riskProfile = header.calc.lsObtainedScore;
          }
        }
      }
    });
    this.riskProfileAnalysis.forEach(value => {
      if (parseFloat(this.model.riskProfile) >= parseFloat(value.lrcRangeFrom) && parseFloat(this.model.riskProfile) <= parseFloat(value.lrcRangeTo)) {
        this.model.riskCategory = value.lrcRangeDesc;
      }
    });
  }
  calcScoreforValue(e: any, header) {
    var value = e.target.value;
    this.valueList = header.LpstpScorecardOptionMasterlist;
    if (value == "") {
      header.scoreobtained = "";
      header.calc.lsObtainedScore = "";
      header.calc.lsAns = "";
      header.calc.lsAnsWeight = "";
    }

    else {
      this.valueList.forEach(option => {
        if (option.scpmOptionValue == value) {
          header.scoreobtained = parseInt(header.LpstpScorecardMasterObj.scmQuestionWgt) * parseInt(option.scpmOptionWgt);
          header.calc.lsAns = option.scpmOptionValue;
          header.calc.lsAnsWeight = option.scpmOptionWgt;
          header.calc.lsHeaderId = header.LpstpScorecardMasterObj.scmQuesHeaderId;
          header.calc.lsMaxScore = header.maxScore;
          header.calc.lsScorecardFor = header.LpstpScorecardMasterObj.scmScFor;
          header.calc.lsObtainedScore = header.scoreobtained;
          header.calc.lsQuesDesc = header.LpstpScorecardMasterObj.scmQuestion;
          header.calc.lsQuesId = header.LpstpScorecardMasterObj.scmRowId;
          header.calc.lsQuesWeight = header.LpstpScorecardMasterObj.scmQuestionWgt;
          header.calc.lsScorecardType = "V";
        }

      });
    }
    this.scoreObtained = 0;
    this.model.riskProfile = 0;
    this.model.riskProfile = this.scoreHeaderList[0].calc.lsObtainedScore;
    this.scoreHeaderList.forEach(header => {
      if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
        if (header.calc.lsObtainedScore != "" && header.calc.lsObtainedScore != null && header.calc.lsObtainedScore != undefined) {
          this.scoreObtained += parseInt(header.calc.lsObtainedScore);
          if (this.model.riskProfile < header.calc.lsObtainedScore) {
            this.model.riskProfile = header.calc.lsObtainedScore;
          }
        }
      }
    });
    this.riskProfileAnalysis.forEach(value => {
      if (parseFloat(this.model.riskProfile) >= parseFloat(value.lrcRangeFrom) && parseFloat(this.model.riskProfile) <= parseFloat(value.lrcRangeTo)) {
        this.model.riskCategory = value.lrcRangeDesc;
      }
    });
  }
  saveScoreCardCalc() {

    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }

      var count = 0;
      this.scoreHeaderList.forEach((header, index) => {
        var id = '#range_' + index;
        $(id).removeClass("has-error");
      });
      this.scoreHeaderList.forEach((header, index) => {
        if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
          if (header.LpstpScorecardMasterObj.scmOptionType == 'R') {
            var id = '#scoreOption_' + index;
            if (header.calc.lsAns == "" || header.calc.lsAns == undefined || header.calc.lsAns == null) {
              $(id).addClass("has-error");
              count++;
            }
          }
          if (header.LpstpScorecardMasterObj.scmOptionType == 'V') {
            var id = '#range_' + index;
            if (header.calc.lsAns == "" || header.calc.lsAns == undefined || header.calc.lsAns == null) {
              $(id).addClass("has-error");
              count++;
            }
          }
        }
      });
      if (count == 0) {
        this.scoreHeaderList.forEach(value => {
          value.calc.lsRiskProfile = this.model.riskProfile;
          value.calc.lsRiskCategory = this.model.riskCategory;
        });

        this.scorecardService.saveScoreCardCalcForAgri(this.scoreHeaderList)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.scoreHeaderList = [];
              this.maxtotal = 0;
              this.model.riskProfile = 0;
              this.scoreObtained = 0;
              this.scoreHeaderList = this.data.tempLpcomScorecardList;
              this.scoreHeaderList.forEach(header => {
                if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0)
                  if (header.maxScore != "" && header.maxScore != null)
                    this.maxtotal += parseInt(header.maxScore);
              });
              this.model.riskProfile = this.scoreHeaderList[0].calc.lsObtainedScore;
              this.scoreHeaderList.forEach((header, index) => {
                if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
                  if (header.calc.lsObtainedScore != "" && header.calc.lsObtainedScore != null && header.calc.lsObtainedScore != undefined) {
                    this.scoreObtained += parseInt(header.calc.lsObtainedScore);
                    if (this.model.riskProfile < header.calc.lsObtainedScore) {
                      this.model.riskProfile = header.calc.lsObtainedScore;
                    }
                  }
                  var id = '#range_' + index;
                  if (header.LpstpScorecardMasterObj.scmOptionType == 'V') {
                    var ans = header.calc.lsAns;
                    setTimeout(() => {
                      $(id).val(ans);
                    }, 500);
                  }

                }
              });

              this.editDisabled = false;
              this.saveDisabled = true;
              this.cancelDisabled = true;
              this.fieldDisabled = true;
              if (this.modelForChngNote.changeMode == "Y") {
                this.changenoteComponent.onEdit(true);
              }
              this.riskProfileAnalysis.forEach(value => {
                if (parseFloat(this.model.riskProfile) >= parseFloat(value.lrcRangeFrom) && parseFloat(this.model.riskProfile) <= parseFloat(value.lrcRangeTo)) {
                  this.model.riskCategory = value.lrcRangeDesc;
                }
              });
            }
          },
          error => {
            failedStatus();
          });
      }
    }
  }
  remove(e: any) {
    $(e.target.id).removeClass("has-error");
  }
  editScoreCardCalc() {
    this.buttonAccess(false, true, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  cancelButton() {

    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }

    }
    else
      return false;
  }
  buttonAccess(field: boolean, edit: boolean, save: boolean, cancel: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisabled = true;
      this.editDisabled = true;
      this.saveDisabled = true;
      this.cancelDisabled = true;
    }
    else {
      this.fieldDisabled = field;
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.cancelDisabled = cancel;
    }
  }
  getScoreCardCalcForTech() {
    this.scoreHeaderList = [];
    this.scorecardService.getScoreCardCalcForAgri()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.scoreObtained = 0;
          this.model.riskProfile = 0;
          this.scoreHeaderList = this.data.scoreMap;
          this.scoreHeaderList.forEach((header, index) => {
            if (header.LpstpScorecardMasterObj.scmQuesHeaderId != 0) {
              var id = '#range_' + index;
              if (header.maxScore != "" && header.maxScore != null)
                this.maxtotal += parseInt(header.maxScore);
              if (header.calc.lsObtainedScore != "" && header.calc.lsObtainedScore != null && header.calc.lsObtainedScore != undefined) {
                this.scoreObtained += parseInt(header.calc.lsObtainedScore);
                if (parseInt(this.model.riskProfile) < parseInt(header.calc.lsObtainedScore)) {
                  this.model.riskProfile = header.calc.lsObtainedScore;
                }
              }
              if (header.LpstpScorecardMasterObj.scmOptionType == 'V') {
                var ans = header.calc.lsAns;

                setTimeout(() => {
                  $(id).val(ans);
                }, 500);
              }
            }
          });
          if (this.data.pageAccess == 'R')
            this.buttonAccess(true, true, true, true);
          if (this.riskProfileAnalysis != null) {
            this.riskProfileAnalysis.forEach(value => {
              if (parseFloat(this.model.riskProfile) >= parseFloat(value.lrcRangeFrom) && parseFloat(this.model.riskProfile) <= parseFloat(value.lrcRangeTo)) {
                this.model.riskCategory = value.lrcRangeDesc;
              }
            });
          }
        }
      },
      error => {
      });
  }

}

