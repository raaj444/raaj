import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgriscorecardComponent } from './agriscorecard.component';

describe('AgriscorecardComponent', () => {
  let component: AgriscorecardComponent;
  let fixture: ComponentFixture<AgriscorecardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgriscorecardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgriscorecardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
