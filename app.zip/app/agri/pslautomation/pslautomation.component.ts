import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { PslautomationService } from '../../util/service/agriservices/pslautomation.service';
import { SearchComponent } from '../../common/search/search.component';
import { esLocale } from 'ngx-bootstrap/chronos/i18n/es';
import { ValueTransformer } from '@angular/compiler/src/util';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any;
@Component({
  selector: 'lp-pslautomation',
  templateUrl: './pslautomation.component.html',
  styleUrls: ['./pslautomation.component.css']
})
export class PslautomationComponent extends Validator implements OnInit {
  data: any;

  hidStateName: any;
  hidStateCode: any;
  model: any = {};
  index: any;
  pslautoList: any = [];
  communityList: any = [];
  subCatList: any = [];
  cropList: any = [];
  MainActList: any = [];
  catFarmerList: any = [];
  atlPurposeList: any = [];
  productTypeList: any = [];
  pslsubpurList: any = [];
  bsrcodeList: any = [];
  weakerSecList: any = [];
  religionList: any = [];
  categoryList: any = [];
  tempCommunityMaster: any = [];
  pslCommunity: any = [];
  atlFacPurposeList: any = [];
  loanPurposeList: any = [];
  tempCommunity: any = [];
  tempCropMaster: any = [];
  tempCrop: any = [];
  dupCheck: any = [];
  tempPsl: any = [];
  filterPrdList: any = [];
  pageAccess: any;
  dupCheckFlag: any;
  fieldDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  textareaDisable: boolean;
  flag: boolean;
  comCropFlag: any;
  temp: any;
  filterKCCList: any = [];
  filterFDList: any = [];
  filterSTLList: any = [];
  filterATLList: any = [];
  landRange: any = [];
  landRangeChk: any = [];
  dupCheckPrd: any = [];
  stateList: any;
  disableState: any;
  idvalueList = ['lpaPrdType_', 'lpaLandholdFrom_', 'lpaLandholdTo_', 'lpaAtlPurpose_',
    'lpaPslsubCat_', 'lpaMainAct_', 'lpaCatFormer_', 'lpaPurposeCode_', 'lpaSubpurCode_', 'lpaBsrCode_', 'lpaWeakerCode_'];


  @ViewChild(SearchComponent)
  Searchpop: SearchComponent;
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private pslautomationService: PslautomationService) {
    super();
  }

  ngOnInit() {
    this.textareaDisable = true;
    this.disableState = false;
    this.disableButton(false, true, true, true, true);
    $('#community').modal('hide');
    $('#pslData').hide();
    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });
    this.pslautomationService.getStateList(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.stateList = this.data.stateList;
        }

      });
    $("#lpaStatecode").select2();
    $("#lpaStatecode").on('change', (e) => {
      this.model.lpaStatecode = e.target.value;
      this.getPslData();
    });
  }

  getPslData() {
    this.pslautomationService.getPslAutomation(this.pslautoList, this.model)
      .subscribe(
      data => {
        this.data = data;

        if (this.data.success) {
          this.pslautoList = this.data.pslautoList;
          this.productTypeList = this.data.productType;
          this.communityList = this.data.communityList;
          this.tempCommunityMaster = this.communityList;
          this.tempCommunityMaster.push({
            lcRowId: "", lcReligionType: "Any", lcCategory: "Any", lcCommunityCode: "A", lcCreatedBy: "", lcCreatedOn: "", lcModifiedBy: "",
            lcModifiedOn: ""
          })
          this.cropList = this.data.cropList;
          this.tempCropMaster = this.data.cropList;
          this.tempCropMaster.push({
            llvRowId: "", llvHeader: "", llvInterfaceCode: "", llvOptionDesc: "Any", llvOptionVal: "A", llvSeason: "", llvDuration: "", llvCropType: "",
            llvCautionPro: "", lpCreatedBy: "", lpCreatedOn: "", lpModifiedBy: "",
            lpModifiedOn: ""
          })
          this.subCatList = this.data.subCatList;
          this.MainActList = this.data.MainActList;
          this.catFarmerList = this.data.catFarmerList;
          this.atlFacPurposeList = this.data.atlFacPurposeList;
          this.pslsubpurList = this.data.pslsubpurList;
          this.bsrcodeList = this.data.bsrcodeList;
          this.weakerSecList = this.data.weakerSecList;
          this.religionList = this.data.religionList;
          this.categoryList = this.data.categoryList;
          this.atlPurposeList = this.data.atlPurpose;
          this.loanPurposeList = this.data.loanPurposeList;

          if (this.pslautoList.length == 0) {
            this.addNewRow();
          }
          else {
            this.pslautoList.forEach((psl, index) => {
              this.tempCommunity = psl.lpagriPslCommunities;
              this.tempCrop = psl.lpagriPslCroplists;
              this.pslautoList[index].lpaCommunity = [];
              this.pslautoList[index].lcCommunity = [];
              this.pslautoList[index].lcCropCode = [];
              this.pslautoList[index].lpaCroplist = [];
              this.pslautoList[index].lpCroplist = [];
              this.tempCommunity.forEach(tempCom => {
                this.pslautoList[index].lpaCommunity.push(tempCom.lpcCommunityCode);
                this.pslautoList[index].lcCommunity.push(tempCom.lpcCommunityCode);
              });
              this.tempCrop.forEach(crop => {
                this.pslautoList[index].lcCropCode.push(crop.lpcCropValue);
                this.pslautoList[index].lpaCroplist.push(crop.lpcCropValue);
              });

            });
            this.pslautoList.forEach((psl, index) => {
              let cropNameList = [] = psl.lpaCroplist;
              cropNameList.forEach(element => {
                this.tempCropMaster.forEach(crop => {
                  if (crop.llvOptionVal == element)
                    this.pslautoList[index].lpCroplist.push(crop.llvOptionDesc);
                });
              });
            });
          }
          this.disableState = false;
          this.disableButton(false, true, true, true, true);
          $('#pslData').show();
        }

      },
      error => {

      });
  }
  savePslAutomation() {

    this.flag = this.fieldvalidation.multipleFieldValidation(this.pslautoList.length, this.idvalueList);
    var listFlag = 0;
    this.comCropFlag = true;

    for (var i = 0; i < this.pslautoList.length; i++) {
      if (this.pslautoList[i].lpaCommunity.length == 0 || this.pslautoList[i].lpaCroplist.length == 0) {
        listFlag++;
      }
    }
    if (listFlag > 0) {
      this.comCropFlag = false;
    }
    this.dupCheckFlag = this.duplicateCheck();
    if (!(this.dupCheckFlag)) {
      alert("Same product with above data can't be allowed ")
    }
    if (this.flag && this.comCropFlag && this.dupCheckFlag) {
      progressStatus()
      this.pslautomationService.savePslAutomation(this.pslautoList, this.model)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            successStatus();
            this.getPslData();
          }
        },
        error => {
          failedStatus();
        });
    }
  }
  addNewRow() {
    this.pslautoList.push({
      lpaRowId: "", lpaAtlPurpose: "s", lpaBsrCode: "s", lpaCatFormer: "s", lpaCommunity: "", lpaLandholdFrom: "", lpaLandholdTo: "",
      lpaMainAct: "s", lpaPrdType: "s", lpaPurposeCode: "s", lpaStatecode: "", lpaPslsubCat: "s", lpaSubpurCode: "s", lpaWeakerCode: "s",
      lpaCreatedBy: "", lpaCreatedOn: "", lpaModifiedBy: "", lpaModifiedOn: ""
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteA: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deleteA;
    }
  }

  onClickEditButton() {
    this.disableButton(true, false, false, false, false);
    this.disableState = true;
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.getPslData()
    }
    else {
      return false;
    }
  }
  deletePslAutomation(row: any, id: any, i: any) {

    if (id == '' || id == undefined) {
      this.pslautoList.splice(i, 1);
    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.pslautomationService.deletePslAutomation(this.pslautoList)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              this.getPslData();
            }
          },
          error => {
          });
      }
    }
  }

  deleteAll() {

    this.pslautomationService.deleteAll(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.getPslData();
        }
      },
      error => {
      });
  }

  rmvErr(event: any) {
    var value = (<HTMLInputElement>document.getElementById(event.target.id)).value;
    if (value != "" && value != null && value != undefined) {
      if ($('#' + event.target.id).hasClass("has-error")) {
        $('#' + event.target.id).removeClass("has-error");
        $('#' + event.target.id).attr("placeholder", "");
      }
    }
  }
  callSearch(val: string) {
    if (val == 'State') {
      var pageid = "State";
      $('#name').text("State Name");
      $('#code').text("State Code");
      $('#header').text("State Search");
      $('#txt_pageid').val(pageid);
      $('#txt_hidCode').val("S");
      this.Searchpop.ngOnInit();
      $('#Search').modal('show');
    }
  }
  modalClosed() {

    this.model.lpaStatecode = '';
    let stateName = $('#txt-Searchname').val();
    let stateCode = $('#txt_Searchcode').val();
    if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
      if (stateName != "" && stateCode != "") {
        this.model.lpaStatecode = stateCode;
        $('#txt-Searchname').val(stateName);
        this.hidStateCode = stateCode;
        this.hidStateName = stateName;
        this.getPslData();
      }
    }
    else {
      this.model.lpaStatecode = this.hidStateCode;
      $('#txt-Searchname').val(this.hidStateName);
    }
  }

  selectCommunity(index: any) {
    this.index = index;
    this.tempCommunity = [];
    this.communityList.forEach(cm => {
      this.religionList.forEach(rel => {
        if (cm.lcReligionType == rel.llvOptionVal) {
          cm.lcReligionType = rel.llvOptionDesc;
        }
      });
      this.categoryList.forEach(cat => {
        if (cm.lcCategory == cat.llvOptionVal) {
          cm.lcCategory = cat.llvOptionDesc;
        }
      });

    });
    this.tempCommunityMaster.forEach((master, mindex) => {

      this.tempCommunityMaster[mindex].check = "N";

    });
    this.pslautoList.forEach((psl, pindex) => {
      if (index == pindex) {
        this.tempCommunity = psl.lpaCommunity;
        if (this.tempCommunity) {
          this.tempCommunity.forEach(tempCom => {
            this.tempCommunityMaster.forEach((master, mindex) => {
              if (tempCom == master.lcCommunityCode.trim()) {
                this.tempCommunityMaster[mindex].check = "Y";
              }
            });
          });
        }
      }
    });

    $('#community').modal('show');
  }
  selectCrop(index: any) {
    this.index = index;
    this.tempCrop = [];
    this.tempCropMaster.forEach((master, mindex) => {

      this.tempCropMaster[mindex].check = "N";

    });
    this.pslautoList.forEach((psl, pindex) => {
      if (index == pindex) {
        this.tempCrop = psl.lcCropCode;
        if (this.tempCrop) {
          this.tempCrop.forEach(tempCrop => {
            this.tempCropMaster.forEach((master, mindex) => {
              if (tempCrop == master.llvOptionVal) {
                this.tempCropMaster[mindex].check = "Y";
              }
            });
          });
        }
      }
    });

    $('#crop').modal('show');
  }
  checkCommunity(idvalue) {
    var id = 'checkboxlst_' + idvalue;
    this.temp = this.tempCommunityMaster.findIndex(x => x.lcCommunityCode == idvalue);
    if ((<HTMLInputElement>(document.getElementById(id))).checked) {
      this.tempCommunityMaster[this.temp].check = "Y";
    }
    else
      this.tempCommunityMaster[this.temp].check = "N";
  }
  checkCrop(idvalue) {
    var id = 'checkcroplst_' + idvalue;
    this.temp = this.tempCropMaster.findIndex(x => x.llvOptionVal == idvalue);
    if ((<HTMLInputElement>(document.getElementById(id))).checked) {
      this.tempCropMaster[this.temp].check = "Y";
    }
    else
      this.tempCropMaster[this.temp].check = "N";
  }


  PushData() {
    this.pslautoList[this.index].lcCommunity = [];
    this.tempCommunityMaster.forEach(field1 => {
      if (field1.check == "Y") {
        this.pslautoList[this.index].lcCommunity.push(field1.lcCommunityCode.trim());
      }
    });
    this.pslautoList[this.index].lpaCommunity = this.pslautoList[this.index].lcCommunity;
    this.tempCommunity = [];
    $('#community').modal('hide');
  }


  PushCropData() {
    this.pslautoList[this.index].lcCropCode = [];
    this.pslautoList[this.index].lpCroplist = [];
    this.tempCropMaster.forEach(field1 => {
      if (field1.check == "Y") {
        this.pslautoList[this.index].lcCropCode.push(field1.llvOptionVal.trim());
      }
    });
    this.pslautoList[this.index].lcCropCode.forEach(element => {
      this.tempCropMaster.forEach(crop => {
        if (element == crop.llvOptionVal) {
          this.pslautoList[this.index].lpCroplist.push(crop.llvOptionDesc);
        }
      });
    });
    this.pslautoList[this.index].lpaCroplist = this.pslautoList[this.index].lcCropCode;

    this.tempCrop = [];
    $('#crop').modal('hide');
  }

  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }
  duplicateCheck() {

    this.filterATLList = [];
    this.filterSTLList = [];
    this.filterFDList = [];
    this.filterKCCList = [];
    this.filterPrdList = [];
    var ATLFlag = true, STLFlag = true, FDLFlag = true, KCCFlag = true;
    this.pslautoList.forEach(element => {
      if (element.lpaPrdType === '1') {
        this.filterKCCList.push(element);
      }
      if (element.lpaPrdType === '2') {
        this.filterATLList.push(element);
      }
      if (element.lpaPrdType === '3') {
        this.filterSTLList.push(element);
      }
      if (element.lpaPrdType === '4') {
        this.filterFDList.push(element);
      }
    });
    if (this.filterATLList.length > 1) {
      this.filterATLList = this.filterATLList.sort((a, b) => {
        if (a.lpaLandholdTo < b.lpaLandholdTo)
          return -1;
        if (a.lpaLandholdTo > b.lpaLandholdTo)
          return 1;
        return 0;
      });
      ATLFlag = this.validatePrdList(this.filterATLList);
    }
    if (this.filterKCCList.length > 1) {
      this.filterKCCList = this.filterKCCList.sort((a, b) => {
        if (a.lpaLandholdTo < b.lpaLandholdTo)
          return -1;
        if (a.lpaLandholdTo > b.lpaLandholdTo)
          return 1;
        return 0;
      });
      KCCFlag = this.validatePrdList(this.filterKCCList);
    }

    if (this.filterSTLList.length > 1) {
      this.filterSTLList = this.filterSTLList.sort((a, b) => {
        if (a.lpaLandholdTo < b.lpaLandholdTo)
          return -1;
        if (a.lpaLandholdTo > b.lpaLandholdTo)
          return 1;
        return 0;
      });
      STLFlag = this.validatePrdList(this.filterSTLList);
    }

    if (this.filterFDList.length > 1) {
      this.filterFDList = this.filterFDList.sort((a, b) => {
        if (a.lpaLandholdTo < b.lpaLandholdTo)
          return -1;
        if (a.lpaLandholdTo > b.lpaLandholdTo)
          return 1;
        return 0;
      });
      FDLFlag = this.validatePrdList(this.filterFDList);
    }
    if (STLFlag && FDLFlag && KCCFlag && ATLFlag) {
      this.dupCheckFlag = true;
    }
    else {
      this.dupCheckFlag = false;
    }

    return this.dupCheckFlag;
  }

  validatePrdList(pslautoList: any) {
    this.filterPrdList = pslautoList;
    this.landRange = this.filterPrdList[this.filterPrdList.length - 1];
    this.landRangeChk = this.filterPrdList[this.filterPrdList.length - 2];

    var dupCommunity = false, dupCrop = false, crossFrom = false;
    var CommunityCount = 0;
    //Community check
    for (let t = 0; t < this.filterPrdList.length - 1; t++) {
      this.tempPsl = this.filterPrdList[t];
      this.temp = this.filterPrdList[t].lpaCommunity;
      for (let d = t + 1; d < this.filterPrdList.length; d++) {
        var checkLength = d;
        var maxLandholdlength = this.filterPrdList.length - 1;
        if (this.filterPrdList.length != "1" && this.filterPrdList.length > checkLength) {
          this.dupCheck = this.filterPrdList[d];
          this.dupCheckPrd = this.filterPrdList[d].lpaCommunity;
          var from = parseFloat(this.dupCheck.lpaLandholdFrom) <= parseFloat(this.landRange.lpaLandholdTo);
          var to = parseFloat(this.dupCheck.lpaLandholdTo) <= parseFloat(this.landRange.lpaLandholdTo);
          var tempFrom = parseFloat(this.tempPsl.lpaLandholdFrom) <= parseFloat(this.landRange.lpaLandholdTo);
          var tempTo = parseFloat(this.tempPsl.lpaLandholdTo) <= parseFloat(this.landRange.lpaLandholdTo);
          var crossCheck = parseFloat(this.dupCheck.lpaLandholdFrom) < parseFloat(this.landRangeChk.lpaLandholdTo);
          if (maxLandholdlength == checkLength) {
            crossCheck = true;
          }
          var crossFrom = parseFloat(this.landRange.lpaLandholdFrom) > parseFloat(this.landRangeChk.lpaLandholdTo);
          if (from && to && tempFrom && tempTo && crossCheck && (d != t)) {
            if (crossFrom && maxLandholdlength != checkLength) {
              this.temp.forEach(a => {
                this.dupCheckPrd.forEach(b => {
                  if (a == b || b == "A" || a == "A") {
                    let tempArrAny = this.filterPrdList.filter((item) => item.lpaAtlPurpose == this.dupCheck.lpaAtlPurpose).filter((item) => item.lpaLandholdFrom >= this.dupCheck.lpaLandholdFrom).filter((item) => item.lpaLandholdTo <= this.dupCheck.lpaLandholdTo);
                    let CommunityAll = false;
                    tempArrAny.forEach(element => {
                      let community = element.lpaCommunity;
                      if (community[0] == "A") {
                        CommunityAll = true
                        return 0;
                      }
                    });
                    if (tempArrAny.length > 1 && CommunityAll) {
                      for (var i = 0; i < tempArrAny.length-1; i++) {
                        let cropListfirst = tempArrAny[i].lpaCroplist;
                        let cropListsecond = tempArrAny[i + 1].lpaCroplist;
                        cropListfirst.forEach(a => {
                          cropListsecond.forEach(b => {
                            if (a == b ||  b == "A" || a == "A") {
                              CommunityCount++;
                            }
                          });
                        });
                      }
                    }
                  }
                });
              });

              crossFrom = false;
            }
            else {
              crossFrom = parseFloat(this.landRange.lpaLandholdFrom) > parseFloat(this.landRangeChk.lpaLandholdTo);
              if (crossFrom)
                crossFrom = false;
              else {
                crossFrom = true;
                if (tempFrom && tempTo) {
                  crossFrom = false;
                  this.temp.forEach(a => {
                    this.dupCheckPrd.forEach(b => {
                      if (a == b || b == "A" || a == "A") {
                        let tempArrAny = this.filterPrdList.filter((item) => item.lpaAtlPurpose == this.dupCheck.lpaAtlPurpose).filter((item) => item.lpaLandholdFrom >= this.dupCheck.lpaLandholdFrom).filter((item) => item.lpaLandholdTo <= this.dupCheck.lpaLandholdTo);
                        let CommunityAll = false;
                        tempArrAny.forEach(element => {
                          let community = element.lpaCommunity;
                          if (community[0] == "A") {
                            CommunityAll = true
                            return 0;
                          }
                        });

                        if (tempArrAny.length > 1 && CommunityAll) {
                          for (var i = 0; i < tempArrAny.length-1; i++) {
                            let cropListfirst = tempArrAny[i].lpaCroplist;
                            let cropListsecond = tempArrAny[i + 1].lpaCroplist;
                            cropListfirst.forEach(a => {
                              cropListsecond.forEach(b => {
                                if (a == b ||  b == "A" || a == "A") {
                                  CommunityCount++;
                                }
                              });
                            });
                          }
                        }
                      }
                    });
                  });
                }
              }
            }
          }
          else {
            this.dupCheckFlag = true;
            break;
          }

        }
      }
    }
    //End check
    var CropCount = 0;
    for (let t = 0; t < this.filterPrdList.length - 1; t++) {
      this.tempPsl = this.filterPrdList[t];
      this.temp = this.filterPrdList[t].lpaCroplist;
      for (let d = t + 1; d < this.filterPrdList.length; d++) {
        var checkLength = d;
        var maxLandholdlength = this.filterPrdList.length - 1;
        if (this.filterPrdList.length != "1" && this.filterPrdList.length > checkLength) {
          this.dupCheck = this.filterPrdList[d];
          this.dupCheckPrd = this.filterPrdList[d].lpaCroplist;
          var from = parseFloat(this.dupCheck.lpaLandholdFrom) <= parseFloat(this.landRange.lpaLandholdTo);
          var to = parseFloat(this.dupCheck.lpaLandholdTo) <= parseFloat(this.landRange.lpaLandholdTo);
          var tempFrom = parseFloat(this.tempPsl.lpaLandholdFrom) <= parseFloat(this.landRange.lpaLandholdTo);
          var tempTo = parseFloat(this.tempPsl.lpaLandholdTo) <= parseFloat(this.landRange.lpaLandholdTo);
          var crossCheck = parseFloat(this.dupCheck.lpaLandholdFrom) < parseFloat(this.landRangeChk.lpaLandholdTo);
          if (maxLandholdlength == checkLength) {
            crossCheck = true;
          }
          var crossFrom = this.landRange.lpaLandholdFrom > this.landRangeChk.lpaLandholdTo;
          if (from && to && tempFrom && tempTo && crossCheck && (d != t)) {
            if (crossFrom && maxLandholdlength != checkLength) {
              this.temp.forEach(a => {
                this.dupCheckPrd.forEach(b => {
                  if (a == b || b == "A" || a == "A") {

                    let tempArrAny = this.filterPrdList.filter((item) => item.lpaAtlPurpose == this.dupCheck.lpaAtlPurpose).filter((item) => item.lpaLandholdFrom >= this.dupCheck.lpaLandholdFrom).filter((item) => item.lpaLandholdTo <= this.dupCheck.lpaLandholdTo);
                    let CropAll = false;
                    tempArrAny.forEach(element => {
                      let cropList = element.lpaCroplist;
                      if (cropList[0] == "A") {
                        CropAll = true
                        return 0;
                      }
                    });

                    if (tempArrAny.length > 1 && CropAll) {
                      for (var i = 0; i < tempArrAny.length-1; i++) {
                        let communityfirst = tempArrAny[i].lpaCommunity;
                        let communitytsecond = tempArrAny[i + 1].lpaCommunity;
                        communityfirst.forEach(a => {
                          communitytsecond.forEach(b => {
                            if (a == b ||  b == "A" || a == "A" ) {
                              CropCount++;
                            }
                          });
                        });
                      }
                    }
                  }
                });
              });
              crossFrom = false;
            }
            else {

              crossFrom = parseFloat(this.landRange.lpaLandholdFrom) > parseFloat(this.landRangeChk.lpaLandholdTo);
              var btwrange = false;

              if (crossFrom)
                crossFrom = false;
              else {
                crossFrom = true;
                if (tempFrom && tempTo) {
                  crossFrom = false;
                  this.temp.forEach(a => {
                    this.dupCheckPrd.forEach(b => {
                      if (a == b || b == "A" || a == "A") {
                        let tempArrAny = this.filterPrdList.filter((item) => item.lpaAtlPurpose == this.dupCheck.lpaAtlPurpose).filter((item) => item.lpaLandholdFrom >= this.dupCheck.lpaLandholdFrom).filter((item) => item.lpaLandholdTo <= this.dupCheck.lpaLandholdTo);
                        let CropAll = false;
                        tempArrAny.forEach(element => {
                          let cropList = element.lpaCroplist;
                          if (cropList[0] == "A") {
                            CropAll = true
                            return 0;
                          }
                        });

                        if (tempArrAny.length > 1 && CropAll) {
                          for (var i = 0; i < tempArrAny.length-1; i++) {
                            let communityfirst = tempArrAny[i].lpaCommunity;
                            let communitytsecond = tempArrAny[i + 1].lpaCommunity;
                            communityfirst.forEach(a => {
                              communitytsecond.forEach(b => {
                                if (a == b ||  b == "A" || a == "A") {
                                  CropCount++;
                                }
                              });
                            });
                          }
                        }

                      }
                    });
                  });
                }
              }
            }
          }
          else {
            this.dupCheckFlag = true;
            break;
          }
        }
      }
    }
    if (CropCount != 0)
      dupCrop = true;
    else
      dupCrop = false;

    if (CommunityCount != 0)
      dupCommunity = true;
    else
      dupCommunity = false;

    if (dupCommunity || dupCrop || crossFrom) {
      this.dupCheckFlag = false;
    }
    else {
      this.dupCheckFlag = true;
    }
    return this.dupCheckFlag;
  }

  rangefrom(id: number) {

    if ($('#lpaLandholdTo_' + (id)).val() != "" && $('#lpaLandholdFrom_' + id).val() != "" && $('#lpaLandholdTo_' + (id)).val() != undefined && $('#lpaLandholdFrom_' + id).val() != undefined) {
      var fromVal = parseFloat($('#lpaLandholdFrom_' + id).val());
      var maxLand = 1000;
      if (fromVal <= maxLand) {
        if (parseFloat($('#lpaLandholdFrom_' + (id)).val()) >= parseFloat($('#lpaLandholdTo_' + id).val())) {
          alert("LandHolding From Range should not exceed To Range");
          $('#lpaLandholdFrom_' + id).val('');
          this.pslautoList[id].lpaLandholdFrom = '';
        }
      }
      else {
        alert("LandHolding From Range should not exceed 1000");
        this.pslautoList[id].lpaLandholdFrom = '';
      }
    }
  }

  rangeto(id: number) {

    if ($('#lpaLandholdTo_' + id).val() != undefined && $('#lpaLandholdTo_' + id).val() != "" && $('#lpaLandholdFrom_' + id).val() != undefined && $('#lpaLandholdFrom_' + id).val() != "") {
      var fromVal = parseFloat($('#lpaLandholdTo_' + id).val());
      var maxLand = 1000;
      if (fromVal <= maxLand) {
        if (parseFloat($('#lpaLandholdFrom_' + id).val()) >= parseFloat($('#lpaLandholdTo_' + id).val())) {
          alert(" LandHolding To Range should not less than From Range");
          $('#lpaLandholdTo_' + id).val('');
          this.pslautoList[id].lpaLandholdTo = '';
        }
      }
      else {
        alert("LandHolding To Range should not exceed 1000");
        this.pslautoList[id].lpaLandholdTo = '';
      }
    }
  }
  atlPrdCheck(i) {
    this.tempPsl = this.pslautoList[i];
    // If Product ATL
    if ((this.tempPsl.lpaPrdType != "s" && this.tempPsl.lpaPrdType == "2")) {
      if (this.tempPsl.lpaAtlPurpose != "s") {

        for (let j = 0; j < this.atlFacPurposeList.length; j++) {
          this.temp = this.atlFacPurposeList[j];
          if (this.temp.lamAtlpurpose == this.tempPsl.lpaAtlPurpose) {
            this.pslautoList[i].lpaSubpurCode = this.temp.lamSubpurpose;
            this.pslautoList[i].lpaBsrCode = this.temp.lamBsrCode;
            break;
          }
        }
      }
    }
  }
}





