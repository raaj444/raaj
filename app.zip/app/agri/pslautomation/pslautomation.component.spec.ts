import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PslautomationComponent } from './pslautomation.component';

describe('PslautomationComponent', () => {
  let component: PslautomationComponent;
  let fixture: ComponentFixture<PslautomationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PslautomationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PslautomationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
