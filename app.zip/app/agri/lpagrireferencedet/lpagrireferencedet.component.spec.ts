import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LpagrireferencedetComponent } from './lpagrireferencedet.component';

describe('LpagrireferencedetComponent', () => {
  let component: LpagrireferencedetComponent;
  let fixture: ComponentFixture<LpagrireferencedetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LpagrireferencedetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LpagrireferencedetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
