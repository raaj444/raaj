import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { LpagrireferenceService } from '../../util/service/agriservices/lpagrireference.service';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-lpagrireferencedet',
  templateUrl: './lpagrireferencedet.component.html',
  styleUrls: ['./lpagrireferencedet.component.css']
})
export class LpagrireferencedetComponent extends Validator implements OnInit {
  data: any;
  pageAccess: any;
  model: any = {};
  optionsModel: any = {};
  editDisabled: boolean = true;
  saveDisabled: boolean = true;
  cancelDisabled: boolean = true;
  addreferenceDisabled: boolean = true;
  deleteDisabled: boolean = true;
  lpreferencedetlist: any = [];
  getvalues: any = [];
  disableFields: boolean = true;
  validation: boolean;
  ControllList: any = ['txt_lprefName', 'sel_lprefRelation', 'sel_lprefStatus', 'txt_lprefContNo', 'txt_lprefKnownSince', 'txt_lprefAddress'];
  modelForChngNote: any;
  relationList: any = [];
  feedbackStatusList: any = [];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private lpagrireference: LpagrireferenceService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) { super(); }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();
    this.model.optionsFieldArray = [{ 'lrdRowId': '', 'lrdSeqNo': '', 'lrdRelation': 's', 'lrdStatus': 's' }];
    this.lpagrireference.getreferencedetails(this.model)
      .subscribe(data => {
        this.data = data;
        if (this.data.success) {
          this.model.optionsFieldArray = this.data.responseData.referencedetails;
          this.relationList = this.data.responseData.RelationmasterList;
          this.feedbackStatusList = this.data.responseData.FeedbackStatusList;
          this.pageAccess = this.data.pageAccess;
          this.disableButton(true, false, true, true, false);

          if (this.model.optionsFieldArray.length < 1) {
            this.model.optionsFieldArray.push({ 'lrdRowId': '', 'lrdSeqNo': '', 'lrdRelation': 's', 'lrdStatus': 's', 'lrdName': '', 'lrdAddress': '', 'lrdRemarks': '', 'lrdContNo': '', 'lrdKnownSince': '' });
            this.disableButton(false, true, false, false, false);
            this.disableFields = false;
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }

          }
          else
            this.disableFields = true;
          if (this.pageAccess == "R") {
            this.disableButton(true, true, true, true, true);
            this.disableFields = true;
          }

          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
        } else {
        }
      },
      error => {
      });



  }
  disableButton(addnew: boolean, edit: boolean, save: boolean, btndelete: boolean, cancel: boolean) {
    this.addreferenceDisabled = addnew;
    this.editDisabled = edit;
    this.saveDisabled = save;
    this.deleteDisabled = btndelete;
    this.cancelDisabled = cancel;
  }

  addnewreference() {
    this.disableButton(false, true, false, true, false);
    this.disableFields = false;
    if (this.model.optionsFieldArray.length < 10) {
      this.model.optionsFieldArray.push({ 'lrdRowId': '', 'lrdSeqNo': '', 'lrdRelation': 's', 'lrdStatus': 's', 'lrdName': '', 'lrdAddress': '', 'lrdRemarks': '', 'lrdContNo': '', 'lrdKnownSince': '' });
    }
  }
  deletereference(row: any, id: any, i: any, lrdSeqNo: number) {
    if (id == '' || id == undefined) {
      this.model.optionsFieldArray.splice(i, 1);


    }
    else {
      var optionsFieldArrayTemp = JSON.parse(JSON.stringify(this.model.optionsFieldArray));
      this.model.optionsFieldArray = [];
      optionsFieldArrayTemp.forEach(field => {
        if (field.lrdRowId != 0 && field.lrdSeqNo == lrdSeqNo) {
          var rowid = "";
          this.model.SeqId = field.lrdSeqNo;
          this.lpagrireference.deletesinglereferencedet(this.model, field.lrdSeqNo)
            .subscribe(
            data => {
              this.data = data;
              this.ngOnInit();
            },
            error => {
            });
        }
        else {
          if (field.lrdSeqNo != lrdSeqNo) {
            this.model.optionsFieldArray.push(field);
          }
        }
      });

    }
  }



  dosave() {
    var phCount = 0;
    var phId = 'txt_lprefContNo';
    var i = this.model.optionsFieldArray.length;
    for (let j = 0; j < i; j++) {
      var phfieldId = phId + j;
      if (this.model.optionsFieldArray[j].lrdContNo !== "" && this.model.optionsFieldArray[j].lrdContNo != null) {
        if ((this.model.optionsFieldArray[j].lrdContNo.toString()).length < 10) {
          phCount++;
          $('#' + phfieldId).addClass("has-error");
        }
      }
    }

    this.validation = this.fieldvalidation.multipleFieldValidation(this.model.optionsFieldArray.length, this.ControllList);
    if (this.validation && phCount == 0) {
      var optionsFieldArrayvali = JSON.parse(JSON.stringify(this.model.optionsFieldArray));
      this.model.optionsFieldArrayvali = [];
      optionsFieldArrayvali.forEach(field => {
        if (field.lrdRelation == "") {
          alert("Select Relation with Applicant");
          return false;
        }
        if (field.lrdStatus == "") {
          alert("Select Feedback");
          return false;
        }

      });
      let flagCM = true;
      //check on changeMode
      if (this.modelForChngNote.changeMode == "Y") {
        flagCM = this.changenoteComponent.onValidate();
      }
      if (flagCM) {
        if (this.modelForChngNote.changeMode == "Y" && flagCM) {
          this.changenoteComponent.onSave();
        }
        this.lpagrireference.savelpreferencedetails(this.model).subscribe(
          data => {
            this.data = data;

            if (this.data.success == true) {
              this.ngOnInit();
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
          }
          ,
          error => {
            failedStatus();
          });
      }
    }

    if (phCount > 0)
      alert("Enter valid Contact No.");
  }
  doedit() {
    this.disableButton(false, true, false, false, false);
    this.disableFields = false;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  dodelete() {
    this.lpagrireference.deletereference(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success)
          this.ngOnInit();
      },
      error => {
      });
    this.deleteDisabled = true;
    this.disableFields = true;
  }

  docancel() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
    this.disableFields = true;
  }

  reffutureYearRes(e: any) {

    if (e.target.value.length < 4) {
      e.target.value = "";
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Invalid year");
    }
    else if (this.futureYrRes(e.target.value)) {
      e.target.value = "";
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Future year not allowed here");
    }
  }


}

