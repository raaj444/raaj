import { Component, OnInit, ViewChild } from '@angular/core';
import { CropsurrogatetermService } from "../../util/service/agriservices/cropsurrogateterm.service";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Validator } from '../../util/helper/validator';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any

@Component({
  selector: 'lp-cropsurrogateterm',
  templateUrl: './cropsurrogateterm.component.html',
  styleUrls: ['./cropsurrogateterm.component.css']
})
export class CropsurrogatetermComponent extends Validator implements OnInit {
  data: any;

  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private cropsurrogatetermService: CropsurrogatetermService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();

    this.maxDate = new Date();
    this.minDate = new Date(1899, 12, 1);
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());
  }
  repaymentFreq: any = [];
  SurrogateFacility: any = [];
  lpagrifleetdetList: any = [];
  SurrogateFacilityKccList: any;
  SurrogateList: any = [];
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  deletebuttonDisable: boolean
  pageAccess: any;
  fieldFacDisable: boolean;
  totincome: any;
  modelArray: any = {};
  flag: boolean;
  idvalueList: any = ['lstItrFirstyr', 'lstItrFirstamt', 'lstItrSecndyr', 'lstItrSecndamt', 'lstItrThirdyr', 'lstItrThirdamt', 'lstItrAvrge', 'lstItrTlamnt', 'lstItrProofdet', 'lstSalbasAnnualnet', 'lstSalbasTlamt', 'lstSalbasProofdet', 'lstVehTlamt', 'lstVehProofdet', 'lstTotalTlamt', 'lstRepayfreq', 'lstRepaymonth', 'lstTenormonth', 'lstTermlnInmonth', 'lstFirstinstalDate', 'lstLastinstalDate'];
  itridvalueList: any = ['lstItrFirstyr', 'lstItrFirstyrEnd', 'lstItrFirstamt', 'lstItrSecndyr', 'lstItrSecndyrEnd', 'lstItrSecndamt', 'lstItrThirdyr', 'lstItrThirdyrEnd', 'lstItrThirdamt', 'lstItrAvrge', 'lstItrTlamnt', 'lstItrProofdet', 'lstRepayfreq', 'lstRepaymonth', 'lstTenormonth', 'lstTermlnInmonth', 'lstFirstinstalDate', 'lstLastinstalDate'];
  salidvalueList: any = ['lstSalbasAnnualnet', 'lstSalbasTlamt', 'lstSalbasProofdet', 'lstRepayfreq', 'lstRepaymonth', 'lstTenormonth', 'lstTermlnInmonth', 'lstFirstinstalDate', 'lstLastinstalDate'];
  vehidvalueList: any = ['lstVehTlamt', 'lstVehProofdet', 'lstTotalTlamt', 'lstRepayfreq', 'lstRepaymonth', 'lstTenormonth', 'lstTermlnInmonth', 'lstFirstinstalDate', 'lstLastinstalDate'];
  sum: any;
  itrdeviation: any;
  salarydeviation: any;
  vehicledeviation: any;
  kccdeviation: any;
  facid: any;
  propStatus: any;
  vehIncomeList: Array<any> = [];
  modelForChngNote: any;
  maxDate: Date; minDate: Date;
  tempagrifleetdetList: any = [];
  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.modelArray.model = { 'lstItrFirstyr': '', 'lstItrFirstamt': '', 'lstItrSecndyr': '', 'lstItrSecndamt': '', 'lstItrThirdyr': '', 'lstItrThirdamt': '', 'lstItrAvrge': '', 'lstItrTlamnt': '', 'lstItrProofdet': '', 'lstSalbasAnnualnet': '', 'lstSalbasTlamt': '', 'lstSalbasProofdet': '', 'lstVehTlamt': '', 'lstVehProofdet': '', 'lstTotalTlamt': '', 'lstRepayfreq': '', 'lstRepaymonth': '', 'lstTenormonth': '', 'lstTermlnInmonth': '', 'lstFirstinstalDate': '', 'lstLastinstalDate': '', 'lstSalbasNameofEmpl': '' };
    this.modelArray.model.lstRepayfreq = 's';
    this.modelArray.model.lstItrAvrge = 0.0;
    this.modelArray.model.lstTotalTlamt = 0.0;
    this.SurrogateFacilityKccList = 0.0;
    this.totincome = 0.0;
    this.disableButton(true, true, true, true, true);
    this.fieldFacDisable = false;
    this.cropsurrogatetermService.getSurrogateFacilityDetails()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.SurrogateFacility = this.data.responseData.SurrogateFacility;
          this.SurrogateFacilityKccList = this.data.responseData.SurrogateFacilityKccList;
          this.vehIncomeList = this.data.responseData.VehIncomeDevList;
          this.repaymentFreq = this.data.responseData.RepaymentFrequencyList;
          this.tempagrifleetdetList = this.data.responseData.lpagrifleetdetList;
          this.propStatus = this.data.FacStatus;

          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess == 'R') {
            // this.fieldFacDisable = true;
            this.disableButton(true, true, true, true, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);

          }
        }
        this.get();
      },
      error => {
      });
  }

  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean, deletebuttonDisable: boolean) {
    this.fieldDisable = fieldDisable;
    this.savebuttonDisable = savebuttonDisable;
    this.editbuttonDisable = editbuttonDisable;
    this.cancelbuttonDisable = cancelbuttonDisable;
    this.deletebuttonDisable = deletebuttonDisable;
  }

  onChangeSurrogate(val: any) {


    var empty = true;

    this.disableButton(true, true, false, true, true);
    if (this.pageAccess == 'R') {
      this.disableButton(true, true, true, true, true);
    }
    this.modelArray.model = { 'lstItrFirstyr': '', 'lstItrFirstamt': '', 'lstItrSecndyr': '', 'lstItrSecndamt': '', 'lstItrThirdyr': '', 'lstItrThirdamt': '', 'lstItrAvrge': '', 'lstItrTlamnt': '', 'lstItrProofdet': '', 'lstSalbasAnnualnet': '', 'lstSalbasTlamt': '', 'lstSalbasProofdet': '', 'lstVehTlamt': '', 'lstVehProofdet': '', 'lstTotalTlamt': '', 'lstRepayfreq': '', 'lstRepaymonth': '', 'lstTenormonth': '', 'lstTermlnInmonth': '', 'lstFirstinstalDate': '', 'lstLastinstalDate': '' };
    this.modelArray.model.lstFacId = val;
    this.modelArray.model.lstRepayfreq = 's';
    this.modelArray.model.lstItrAvrge = 0.0;
    this.facid = val;
    this.itrdeviation = '';
    this.salarydeviation = '';
    this.vehicledeviation = '';
    this.kccdeviation = '';
    this.modelArray.lpagrifleetdetList = [];
    /**** Vehcile Income Base Autopopulate Fleet Details****/
    this.modelArray.lpagrifleetdetList = this.tempagrifleetdetList;
    this.totincome = 0.0;
    if (this.modelArray.lpagrifleetdetList != null && this.modelArray.lpagrifleetdetList != '') {
      if (this.propStatus == 'AP') {
        var i = 0;
        this.modelArray.lpagrifleetdetList.forEach(element => {
          if(element.afdHarvestIncome)
          this.totincome = parseFloat(this.totincome) + parseFloat(element.afdHarvestIncome);

          i++;
        });
      }
      else {
        var i = 0;
        this.modelArray.lpagrifleetdetList.forEach(element => {

          var currentyear = (new Date()).getFullYear();
          var yearval = currentyear - (element.afdYearMfgr);
          for (var j = 0; j < this.vehIncomeList.length; j++) {

            if (yearval >= this.vehIncomeList[j].lvdVehagefrom && yearval <= this.vehIncomeList[j].lvdVehageto) {
              if(this.vehIncomeList[j].lvdVehInc)
            { 
              this.modelArray.lpagrifleetdetList[i].afdHarvestIncome = this.vehIncomeList[j].lvdVehInc;
              break;
            }
            }
          }
          if(element.afdHarvestIncome)
          this.totincome = parseFloat(this.totincome) + parseFloat(element.afdHarvestIncome);

          i++;
        });
      }
    }
    /**End Vehcile Income Base Autopopulate Fleet Details ****/

    this.SurrogateFacility.forEach(element => {
      if (element.FacilityId == val) {
        this.modelArray.model.lstTenormonth = element.Tenor;
        this.modelArray.model.lstItrProofdet = element.itrDoc;
      }
    });
    for (var j = 0; j < this.SurrogateList.length; j++) {
      if (this.SurrogateList[j].lstFacId == val) {
        this.modelArray.model = this.SurrogateList[j];
        var lstItrAvrgedev = parseFloat(this.modelArray.model.lstItrAvrge) / 2;
        if (lstItrAvrgedev < parseFloat(this.modelArray.model.lstItrTlamnt)) {
          var devTemp = (parseFloat(this.modelArray.model.lstItrTlamnt) / parseFloat(this.modelArray.model.lstItrAvrge)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.itrdeviation = "Deviation - " + deviation + "%";
        }
        else {
          var devTemp = (parseFloat(this.modelArray.model.lstItrTlamnt) / parseFloat(this.modelArray.model.lstItrAvrge)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.itrdeviation = "Not a Deviation - " + deviation + "%";
        }
        var stlamntcal = parseFloat(this.modelArray.model.lstSalbasAnnualnet) / 2;
        if (stlamntcal < parseFloat(this.modelArray.model.lstSalbasTlamt)) {
          var devTemp = (parseFloat(this.modelArray.model.lstSalbasTlamt) / parseFloat(this.modelArray.model.lstSalbasAnnualnet)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.salarydeviation = "Deviation - " + deviation + "%";
        }
        else {
          var devTemp = (parseFloat(this.modelArray.model.lstSalbasTlamt) / parseFloat(this.modelArray.model.lstSalbasAnnualnet)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.salarydeviation = "Not a Deviation - " + deviation + "%";
        }

        var totincomecal = parseFloat(this.totincome) / 2;
        if (totincomecal < parseFloat(this.modelArray.model.lstVehTlamt)) {
          var devTemp = (parseFloat(this.modelArray.model.lstVehTlamt) / parseFloat(this.totincome)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.vehicledeviation = "Deviation - " + deviation + "%";
        }
        else {
          var devTemp = (parseFloat(this.modelArray.model.lstVehTlamt) / parseFloat(this.totincome)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.vehicledeviation = "Not a Deviation - " + deviation + "%";
        }
        if (parseFloat(this.SurrogateFacilityKccList) < parseFloat(this.modelArray.model.lstVehTlamt)) {
          var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(this.modelArray.model.lstVehTlamt)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.kccdeviation = "Deviation - " + deviation + "%";
        }
        else {
          var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(this.modelArray.model.lstVehTlamt)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.kccdeviation = "Not Deviation -" + deviation + "%";
        }

        var empty = false;
      }
      if (this.modelArray.model.lstStlpercentage != null) {
        var stlPerc = this.toFixCall(this.modelArray.model.lstStlpercentage);
        if (stlPerc < 0 || stlPerc == Infinity) {
          stlPerc = 0.00;
        }
        this.modelArray.model.lstStlpercentage = stlPerc;
      }
    }

    if (this.SurrogateList.length == 0) {
      if (this.pageAccess == 'R')
        this.disableButton(true, true, true, true, true);
      else
        this.disableButton(false, false, true, false, false);
      this.fieldFacDisable = true;
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onEdit(false);
      }
    }
    else {
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onload(this.pageAccess);
      }
    }

  }

  get() {
    this.cropsurrogatetermService.getSurrogateTermLoan()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.SurrogateList = this.data.responseData;
          this.SurrogateList.forEach(element => {
            if (element.lstFirstinstalDate != "" && element.lstFirstinstalDate != null) {
              var lstFirstinstalDate = element.lstFirstinstalDate;
              var lstarray = lstFirstinstalDate.split("-");
              element.lstFirstinstalDate = lstarray[2] + '/' + lstarray[1] + '/' + lstarray[0];
            }
            if (element.lstLastinstalDate != "" && element.lstLastinstalDate != null) {
              var lstLastinstalDate = element.lstLastinstalDate;
              var lstLast = lstLastinstalDate.split("-");
              element.lstLastinstalDate = lstLast[2] + '/' + lstLast[1] + '/' + lstLast[0];
            }

          });

        }
      });
  }


  editSurrogateTermLoan() {
    this.disableButton(false, false, true, false, false);
    this.fieldFacDisable = true;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  saveSurrogateTermLoan() {
    // this.flag=this.fieldvalidation.validateField(this.idvalueList) ;
    // if(this.flag)
    //   {
    this.flag = false;

    if (parseFloat(this.modelArray.model.lstTotalTlamt) > 0 || this.modelArray.model.lstTotalTlamt == '') {

      if (parseFloat(this.modelArray.model.lstItrTlamnt) > 0 && this.modelArray.model.lstItrTlamnt != '') {
        this.flag = this.fieldvalidation.validateField(this.itridvalueList);
        
      }
      if (this.flag && (parseFloat(this.modelArray.model.lstSalbasTlamt) > 0 && this.modelArray.model.lstSalbasTlamt != '')) {
        this.flag = this.fieldvalidation.validateField(this.salidvalueList);
      }
      if (this.flag && (parseFloat(this.modelArray.model.lstVehTlamt) > 0 && this.modelArray.model.lstVehTlamt != '')) {
        this.flag = this.fieldvalidation.validateField(this.vehidvalueList);
      }
    }
    if (parseFloat(this.modelArray.model.lstTotalTlamt) <= 0 || this.modelArray.model.lstTotalTlamt == '') {
      alert("Total Surrogate TL Amount cannot be less than zero");
    }
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    var dateComp = this.compareDates();
    if (parseFloat(this.modelArray.model.lstTotalTlamt) > 0 && this.flag == true && flagCM && dateComp) {

      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }

      this.modelArray.model.lstFirstinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.modelArray.model.lstFirstinstalDate);
      this.modelArray.model.lstLastinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.modelArray.model.lstLastinstalDate);
      this.modelArray.model.lstVehTotharvestinc = this.totincome;
      this.cropsurrogatetermService.saveSurrogateTermLoan(this.modelArray)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            successStatus()
            sessionStorage.setItem("editMode", "N");
            $('input,select,textarea').removeClass('ng-dirty');
            this.cropsurrogatetermService.getSurrogateTermLoan()
              .subscribe(
              data => {
                this.data = data;
                if (this.data.success) {
                  successStatus()
                  this.SurrogateList = this.data.responseData;
                  this.SurrogateList.forEach(element => {
                    if (element.lstFirstinstalDate != "" && element.lstFirstinstalDate != null) {
                      var lstFirstinstalDate = element.lstFirstinstalDate;
                      var lstarray = lstFirstinstalDate.split("-");
                      element.lstFirstinstalDate = lstarray[2] + '/' + lstarray[1] + '/' + lstarray[0];
                    }
                    if (element.lstLastinstalDate != "" && element.lstLastinstalDate != null) {
                      var lstLastinstalDate = element.lstLastinstalDate;
                      var lstLast = lstLastinstalDate.split("-");
                      element.lstLastinstalDate = lstLast[2] + '/' + lstLast[1] + '/' + lstLast[0];
                    }
                  });
                  this.onChangeSurrogate(this.modelArray.model.lstFacId);
                  this.disableButton(true, true, false, true, true);
                  this.fieldFacDisable = false;
                  sessionStorage.setItem("editMode", "N");
                  $('input,select,textarea').removeClass('ng-dirty');
                }
              });

          }
          else {
            failedStatus()
          }
        });
    }

  }



  cancelSurrogateTermLoan() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

  deleteSurrogateTermLoan() {
    this.modelArray.model.lstFirstinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.modelArray.model.lstFirstinstalDate);
    this.modelArray.model.lstLastinstalDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.modelArray.model.lstLastinstalDate);
    this.facid = this.modelArray.model.lstFacId;
    this.cropsurrogatetermService.deleteSurrogateTermLoan(this.modelArray.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.modelArray.model = { 'lstSalbasNameofEmpl': '', 'lstItrFirstyr': '', 'lstItrFirstamt': '', 'lstItrSecndyr': '', 'lstItrSecndamt': '', 'lstItrThirdyr': '', 'lstItrThirdamt': '', 'lstItrAvrge': '', 'lstItrTlamnt': '', 'lstItrProofdet': '', 'lstSalbasAnnualGross': '', 'lstSalbasAnnualnet': '', 'lstSalbasTlamt': '', 'lstSalbasProofdet': '', 'lstVehTlamt': '', 'lstVehProofdet': '', 'lstTotalTlamt': '', 'lstRepayfreq': '', 'lstRepaymonth': '', 'lstTenormonth': '', 'lstTermlnInmonth': '', 'lstFirstinstalDate': '', 'lstLastinstalDate': '' };
          this.modelArray.model.lstRepayfreq = 's';
          this.modelArray.model.lstItrAvrge = 0.0;
          this.disableButton(false, false, true, false, false);
          this.modelArray.model.lstFacId = this.facid;
          this.fieldFacDisable = true;
          this.SurrogateFacility.forEach(element => {
            if (element.FacilityId == this.facid) {
              this.modelArray.model.lstTenormonth = element.Tenor;
            }
          });
        }
        else {
        }

      },
      error => {
        // this.alertService.error(error);
      });
  }

  calculateavg(eventId) {
    this.modelArray.model.lstItrAvrge = 0.0;
    this.sum = 0.0;
    var amount1 = "0.0";
    var amount1 = (<HTMLInputElement>document.getElementById("lstItrFirstamt")).value;
    var amount2 = (<HTMLInputElement>document.getElementById("lstItrSecndamt")).value;
    var amount3 = (<HTMLInputElement>document.getElementById("lstItrThirdamt")).value;
    if (amount1 == null || amount1 == '') {
      amount1 = "0.0";
    }
    if (amount2 == null || amount2 == '') {
      amount2 = "0.0";
    }
    if (amount3 == null || amount3 == '') {
      amount3 = "0.0";
    }
    this.sum = parseFloat(amount1) + parseFloat(amount2) + parseFloat(amount3);
    this.modelArray.model.lstItrAvrge = (parseFloat(this.sum) / 3).toFixed(2);
    this.calitrdeviation();
  }

  calitrdeviation() {


    var stlamnt = (<HTMLInputElement>document.getElementById("lstItrTlamnt")).value;

    if (stlamnt != null && stlamnt != '') {
      if (this.modelArray.model.lstItrAvrge != null && this.modelArray.model.lstItrAvrge != '') {
        var lstItrAvrgedev = this.modelArray.model.lstItrAvrge / 2;

        if (lstItrAvrgedev < parseFloat(stlamnt)) {
          var devTemp = (parseFloat(stlamnt) / this.modelArray.model.lstItrAvrge) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.itrdeviation = "Deviation - " + deviation + "%";
        }
        else {
          var devTemp = (parseFloat(stlamnt) / this.modelArray.model.lstItrAvrge) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.itrdeviation = "Not Deviation - " + deviation + "%";
        }
      }
    }

  }


  calsalarydeviation(eventId) {
    var stlamnt = (<HTMLInputElement>document.getElementById("lstSalbasAnnualnet")).value;
    if (stlamnt != null && stlamnt != '') {
      if (this.modelArray.model.lstSalbasTlamt != null && this.modelArray.model.lstSalbasTlamt != '') {
        var stlamntcal = parseFloat(stlamnt) / 2;
        if (stlamntcal < parseFloat(this.modelArray.model.lstSalbasTlamt)) {
          var devTemp = (parseFloat(this.modelArray.model.lstSalbasTlamt) / parseFloat(stlamnt)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.salarydeviation = "Deviation - " + deviation + "%";
          //this.salarydeviation ="Deviation";
        }
        else {
          var devTemp = (parseFloat(this.modelArray.model.lstSalbasTlamt) / parseFloat(stlamnt)) * 100;
          var deviation = this.toFixCall(devTemp);
          if (deviation < 0 || deviation == Infinity) {
            deviation = 0.00;
          }
          this.salarydeviation = "Not a Deviation - " + deviation + "%";
        }
      }
    }

  }

  calltotsurr() {
    this.modelArray.model.lstTotalTlamt = 0.0;
    var amount1 = (<HTMLInputElement>document.getElementById("lstItrTlamnt")).value;
    var amount2 = (<HTMLInputElement>document.getElementById("lstSalbasTlamt")).value;
    var amount3 = (<HTMLInputElement>document.getElementById("lstVehTlamt")).value;
    if (amount1 == null || amount1 == '') {
      amount1 = "0.0";
    }
    if (amount2 == null || amount2 == '') {
      amount2 = "0.0";
    }
    if (amount3 == null || amount3 == '') {
      amount3 = "0.0";
    }
    this.modelArray.model.lstTotalTlamt = parseFloat(amount1) + parseFloat(amount2) + parseFloat(amount3);
    //STL Percentage
    // var lstTotalTlamt = (<HTMLInputElement>document.getElementById("lstTotalTlamt")).value;
    if (this.modelArray.model.lstTotalTlamt != null && this.modelArray.model.lstTotalTlamt != '') {


      if (parseFloat(this.SurrogateFacilityKccList) < parseFloat(this.modelArray.model.lstTotalTlamt)) {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(this.modelArray.model.lstTotalTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Deviation - " + deviation + "%";
      }
      else {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(this.modelArray.model.lstTotalTlamtalTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Not Deviation -" + deviation + "%";
      }
    }
  }
  calstlpercen() {
    var amount1 = (<HTMLInputElement>document.getElementById("lstSalbasAnnualnet")).value;
    this.calltotsurr();
    if (amount1 != null && amount1 != '') {
      if (this.modelArray.model.lstTotalTlamt != null && this.modelArray.model.lstTotalTlamt != '') {
        var sum = parseFloat(this.modelArray.model.lstItrAvrge) + parseFloat(amount1) + parseFloat(this.totincome);
        this.modelArray.model.lstStlpercentage = (parseFloat(this.modelArray.model.lstTotalTlamt) / sum).toFixed(2);
      }
    }
    else {
      amount1 = "0.0";
      var sum = parseFloat(this.modelArray.model.lstItrAvrge) + parseFloat(amount1) + parseFloat(this.totincome);
      this.modelArray.model.lstStlpercentage = (parseFloat(this.modelArray.model.lstTotalTlamt) / sum).toFixed(2);
    }
  }

  callvehicledeviation() {

    var lstVehTlamt = (<HTMLInputElement>document.getElementById("lstVehTlamt")).value;
    if (lstVehTlamt != null && lstVehTlamt != '') {
      var totincomecal = parseFloat(this.totincome) / 2;
      if (totincomecal < parseFloat(lstVehTlamt)) {
        var devTemp = (parseFloat(lstVehTlamt) / parseFloat(this.totincome)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.vehicledeviation = "Deviation - " + deviation + "%";
        //this.vehicledeviation = "Deviation";
      }
      else {
        var devTemp = (parseFloat(lstVehTlamt) / parseFloat(this.totincome)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.vehicledeviation = "Not Deviation - " + deviation + "%";
      }
      if (parseFloat(this.SurrogateFacilityKccList) < parseFloat(lstVehTlamt)) {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(lstVehTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Deviation - " + deviation + "%";
      }
      else {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(lstVehTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Not Deviation -" + deviation + "%";
      }
    }
    this.callkccdeviation();
  }

  allowFutureDate(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }
  callkccdeviation() {
    var lstTotalTlamt = (<HTMLInputElement>document.getElementById("lstTotalTlamt")).value;
    if (lstTotalTlamt != null && lstTotalTlamt != '') {


      if (parseFloat(this.SurrogateFacilityKccList) < parseFloat(lstTotalTlamt)) {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(lstTotalTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Deviation - " + deviation + "%";
      }
      else {
        var devTemp = (parseFloat(this.SurrogateFacilityKccList) / parseFloat(lstTotalTlamt)) * 100;
        var deviation = this.toFixCall(devTemp);
        if (deviation < 0 || deviation == Infinity) {
          deviation = 0.00;
        }
        this.kccdeviation = "Not Deviation -" + deviation + "%";
      }
    }
  }

  sameYearValidate(event) {
    let year1 = (<HTMLInputElement>document.getElementById("lstItrFirstyr"));
    let year2 = (<HTMLInputElement>document.getElementById("lstItrSecndyr"));
    let year3 = (<HTMLInputElement>document.getElementById("lstItrThirdyr"));
    let year1End = (<HTMLInputElement>document.getElementById("lstItrFirstyrEnd"));
    let year2End = (<HTMLInputElement>document.getElementById("lstItrSecndyrEnd"));
    let year3End = (<HTMLInputElement>document.getElementById("lstItrThirdyrEnd"));
    if (year1.value && year1End.value && year1.value >= year1End.value) {
      this.modelArray.model.lstItrFirstyrEnd = null;
      $("#lstItrFirstyrEnd").attr('placeholder', "YYYY");
    }
    if (year2.value && year2End.value) {
      if (year2.value >= year2End.value) {
        this.modelArray.model.lstItrSecndyrEnd = null;
        $("#lstItrSecndyrEnd").attr('placeholder', "YYYY");
      } else if (year2.value < year2End.value) {
        if ((year2.value >= year1.value && year2.value < year1End.value) || (year2End.value >= year1.value && year2End.value <= year1End.value) || (year2.value >= year3.value && year2.value <= year3End.value) || (year2End.value > year3.value && year2End.value <= year3End.value)) {
          this.modelArray.model.lstItrSecndyr = null;
          $("#lstItrSecndyr").attr('placeholder', "YYYY");
          this.modelArray.model.lstItrSecndyrEnd = null;
          $("#lstItrSecndyrEnd").attr('placeholder', "YYYY");
        }
      }
    }
    if (year3.value && year3End.value) {
      if (year3.value >= year3End.value) {
        this.modelArray.model.lstItrThirdyrEnd = null;
        $("#lstItrThirdyrEnd").attr('placeholder', "YYYY");
      } else if (year3.value < year3End.value) {
        if ((year3.value >= year1.value && year3.value < year1End.value) || (year3End.value >= year1.value && year3End.value <= year1End.value) || (year3.value >= year2.value && year3.value < year2End.value) || (year3End.value >= year2.value && year3End.value <= year2End.value)) {
          this.modelArray.model.lstItrThirdyr = null;
          $("#lstItrThirdyr").attr('placeholder', "YYYY");
          this.modelArray.model.lstItrThirdyrEnd = null;
          $("#lstItrThirdyrEnd").attr('placeholder', "YYYY");
        }
      }
    }
  }
  toFixCall(value) {

    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1.toFixed(2);
    }
  }

  // checkManualEntry(event) {
  //   if (event != "" && event != null) {
  //     let blFlag = this.fieldvalidation.validatedate(event.target.id);
  //     if (blFlag) {
  //       this.fieldvalidation.validatefuturedate(event.target.id);
  //     }
  //   }
  // }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }
  effDateRes(id: any) {
    var futdate = (<HTMLInputElement>document.getElementById(id)).value;
    var dateParts = futdate.split("/");
    new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]);
    return new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]).getTime() < new Date().getTime();
  }
  compareDates() {

    var dateCheck = true;
    if ($('#lstFirstinstalDate').val() != "" && $('#lstLastinstalDate').val() != "") {
      let lfrm = this.fieldvalidation.validatedate('lstFirstinstalDate');
      let lto = this.fieldvalidation.validatedate('lstLastinstalDate');
      if (lfrm && lto) {
        let vallfrm = this.effDateRes('lstFirstinstalDate');
        let vallto = this.effDateRes('lstLastinstalDate');
        if (!vallfrm && !vallto) {
          var lstFirstinstalDate = (<HTMLInputElement>document.getElementById('lstFirstinstalDate')).value;
          var lstLastinstalDate = (<HTMLInputElement>document.getElementById('lstLastinstalDate')).value;
          //LeadFrom Date
          var firstDue = lstFirstinstalDate.split("/");
          lstFirstinstalDate = firstDue[1] + '/' + firstDue[0] + '/' + firstDue[2];
          var firstDueDate = new Date(lstFirstinstalDate);
          //LeadTo Date
          var lastDue = lstLastinstalDate.split("/");
          lstLastinstalDate = lastDue[1] + '/' + lastDue[0] + '/' + lastDue[2];
          var lastDueDate = new Date(lstLastinstalDate);
          if (firstDueDate.getTime() > lastDueDate.getTime()) {
            $('#lstFirstinstalDate').val("");
            $('#lstFirstinstalDate').addClass("has-error");
            $('#lstFirstinstalDate').attr("placeholder", "From date must be less than To date");
            dateCheck = false;
          }
          else if (firstDueDate.getTime() == lastDueDate.getTime()) {
            $('#lstFirstinstalDate').val("");
            $('#lstLastinstalDate').val("");
            $('#lstFirstinstalDate').addClass("has-error");
            $('#lstLastinstalDate').addClass("has-error");
            $('#lstFirstinstalDate').attr("placeholder", "Enter valid date");
            $('#lstLastinstalDate').attr("placeholder", "Enter valid date");
            dateCheck = false;
          }
        }
        else {
          if (vallfrm) {
            $('#lstFirstinstalDate').val("");
            $('#lstFirstinstalDate').addClass("has-error");
            $('#lstFirstinstalDate').attr("placeholder", "Past date not allowed here");
            dateCheck = false;
          }
          else {
            $('#lstLastinstalDate').val("");
            $('#lstLastinstalDate').addClass("has-error");
            $('#lstLastinstalDate').attr("placeholder", "Past date not allowed here");
            dateCheck = false;
          }

        }

      }
      else {
        $('#lstFirstinstalDate').val("");
        $('#lstLastinstalDate').val("");
        $('#lstFirstinstalDate').attr("placeholder", "Enter valid date");
        $('#lstLastinstalDate').attr("placeholder", "Enter valid date");
        dateCheck = false;
      }
    }
    return dateCheck;
  }

}
