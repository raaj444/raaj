import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropsurrogatetermComponent } from './cropsurrogateterm.component';

describe('CropsurrogatetermComponent', () => {
  let component: CropsurrogatetermComponent;
  let fixture: ComponentFixture<CropsurrogatetermComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropsurrogatetermComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropsurrogatetermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
