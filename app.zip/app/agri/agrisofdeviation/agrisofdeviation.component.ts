import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { AgrisofdeviationService } from '../../util/service/agriservices/agrisofdeviation.service';
import { SearchComponent } from '../../common/search/search.component';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-agrisofdeviation',
  templateUrl: './agrisofdeviation.component.html',
  styleUrls: ['./agrisofdeviation.component.css']
})
export class AgrisofdeviationComponent extends Validator  implements OnInit {   data:any; 

  model: any = {};
  private sofdeviation: Array<any> = [];
  pageAccess: any;
  fieldDisable: boolean;
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;
  hidStateCode: any = ""; hidDistrictCode: string = "";
  hidStateName: any;
  stateList: any = [];
  sofvalueList = ['lsdAcrefrom', 'lsdAcreto', 'lsdDeviationPercent'];

  @ViewChild(SearchComponent)
  Searchpop: SearchComponent
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private AgrisofdeviationService: AgrisofdeviationService) {
    super();
  }

  ngOnInit() {

    this.validators();
    this.newbuttonDisable = true;
    $('#Sofacre').hide();
    this.model.sofdeviation = [{ lsdAcrefrom: '', lsdAcreto: '', lsdDeviationPercent: '' }];

    this.disableButton(false, true, true, true, true);
    this.AgrisofdeviationService.getSofDeviationbyState(this.model.lymStatecode)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.stateList = this.data.stateList;
        }

        },
      error => {

      });

    $("#lsStateCode").select2();
    $("#lsStateCode").on('change', (e) => {
      this.model.lsStateCode = e.target.value;
      this.getData();
    });
  }
  getData() {
    if (this.model.lymStatecode != "" && this.model.lymStatecode != 'undefined') {
      $('#Sofacre').show();
      this.AgrisofdeviationService.getSofDeviationbyState(this.model.lsStateCode)
        .subscribe(
        data => { this.data=data;


          if (this.data.success) {
            this.model.sofdeviation = this.data.responseData.requestList;

            this.model.sofdeviation.forEach(element => {
              element.lsdAcrefrom = this.toFixCall(element.lsdAcrefrom);
              element.lsdAcreto = this.toFixCall(element.lsdAcreto);
              element.lsdDeviationPercent = this.toFixCall(element.lsdDeviationPercent);

            });

            if (this.model.sofdeviation.length < 1)
            {
              this.model.sofdeviation = [{ lsdAcrefrom: '', lsdAcreto: '', lsdDeviationPercent: '' }];
            }
            this.newbuttonDisable = true;
            this.disableButton(false, true, true, true, true);

          }

        },
        error => {

        });



    }

  }
  saveSofDeviation() {

    this.flag = this.fieldvalidation.multipleFieldValidation(this.model.sofdeviation.length, this.sofvalueList);
    if (this.flag) {

      this.AgrisofdeviationService.saveSofDeviation(this.model)
        .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            this.newbuttonDisable = true;
            this.disableButton(false, true, true, true, true);
            this.getData();
            successStatus();
          }
        },
        error => {
          failedStatus();
        });

    }
  }



  onClickEditButton() {
    this.disableButton(true, false, false, false, false);
    this.newbuttonDisable = false;
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();

    }
    else {
      return false;
    }
  }


  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deletekcc: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deletekcc;
    }
  }


  addFieldValue() {

    this.model.sofdeviation.push({ lsdAcrefrom: '', lsdAcreto: '', lsdDeviationPercent: '' });
  }


  callSearch(val: string) {


    var pageid = "StateandDeviation";

    $('#name').text("State Name");
    $('#code').text("State Code");
    $('#header').text("State Search");
    $('#txt_pageid').val(pageid);
    $('#txt_hidCode').val("S");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');

  }
  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }
  modalClosed() {
    this.disableButton(false, true, true, true, true);

    let stateName = $('#txt-Searchname').val();
    let stateCode = $('#txt_Searchcode').val();
    if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
      if (stateName != "" && stateCode != "") {
        this.model.lsStateCode = stateCode;
        $('#txt-Searchname').val(stateName);
        this.hidStateCode = stateCode;
        this.hidStateName = stateName;
        $('#Sofacre').show();


        this.AgrisofdeviationService.getSofDeviationbyState(this.hidStateCode)
          .subscribe(
          data => { this.data=data;

            if (this.data.success) {

              this.model.sofdeviation = this.data.responseData.requestList;

              if (this.model.sofdeviation.length < 1)
                this.model.sofdeviation = [{ lsdAcrefrom: '', lsdAcreto: '', lsdDeviationPercent: '' }];


            }

          },
          error => {

          });



      }

    }
    else {
      this.model.sofdeviation = this.hidStateCode;
      $('#txt-Searchname').val(this.hidStateName);
    }
    // if ($('#txt-Searchname').val() == "" && $('#txt_Searchcode').val() == "") {
    //   $('#Sofacre').hide();
    // }
  }

  deleteSofDeviation(row: any, id: any, i: any) {


    if (id == '' || id == undefined) {
      this.model.sofdeviation.splice(i, 1);

    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.AgrisofdeviationService.deleteSofDeviationdetails(row)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {

          });
      }
    }
  }

  deleteAllSofDeviation() {

    this.AgrisofdeviationService.deleteAllSofDeviationdetails(this.model)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {

      });

  }

  rangefrom(id: number) {
    
    var tempid = id - 1;
    if (id != 0) {

      if ($('#lsdAcreto' + (id - 1)).val() != "" && $('#lsdAcrefrom' + id).val() != "" && $('#lsdAcreto' + (id - 1)).val() != undefined && $('#lsdAcrefrom' + id).val() != undefined) {
        if (parseFloat($('#lsdAcreto' + (id - 1)).val()) >= parseFloat($('#lsdAcrefrom' + id).val())) {

          alert("Current Acre From Range  should  be Greater than Previous AcreTo Range");
          $('#lsdAcrefrom' + id).val('');
        }
        else if (parseFloat($('#lsdAcreto' + (id)).val()) >= parseFloat($('#lsdAcrefrom' + (id + 1)).val())) {

          alert("Current Acre To Range should  be Lesser than Next Acre From Range");
          $('#lsdAcreto' + id).val('');
        }
      }

    }
  }

  rangeto(i: number, e: any) {
    var id = i;
    
    if ($('#' + e.target.id).val() != "" && $('#' + e.target.id).val() != undefined) {
      if ($('#lsdAcreto' + id).val() != undefined && $('#lsdAcreto' + id).val() != "" && $('#lsdAcrefrom' + id).val() != undefined && $('#lsdAcrefrom' + id).val() != "") {

        if (parseFloat($('#lsdAcrefrom' + id).val()) >= parseFloat($('#lsdAcreto' + id).val())) {
          alert(" Acre To Range should  be greater than Acre From Range");
          $('#lsdAcreto' + id).val('');
        }
        else {
          this.rangefrom(id);
        }

      }

      else if (($('#lsdAcrefrom' + id).val() != undefined && $('#lsdAcrefrom' + id).val() != "") || ($('#lsdAcreto' + id).val() != undefined && $('#lsdAcreto' + id).val() != "")) {
        this.rangefrom(id);
      }



    }
  }
  percentageCheck(i: number, e: any) {
    var id = i;
    
    if ($('#' + e.target.id).val() != "" && $('#' + e.target.id).val() != undefined) {
      if (!(parseFloat($('#' + e.target.id).val()) <= 100)) {
        alert("Percentage should not exceed 100")
        $('#' + e.target.id).val('');
        this.model.leaselanddeviation[id].lldDeviationPercent = '';
        $('#' + e.target.id).blur();
        return false;
      }

    }
  }
}
