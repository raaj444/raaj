import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgrisofdeviationComponent } from './agrisofdeviation.component';

describe('AgrisofdeviationComponent', () => {
  let component: AgrisofdeviationComponent;
  let fixture: ComponentFixture<AgrisofdeviationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgrisofdeviationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgrisofdeviationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
