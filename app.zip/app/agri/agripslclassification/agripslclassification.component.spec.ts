import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgripslclassificationComponent } from './agripslclassification.component';

describe('AgripslclassificationComponent', () => {
  let component: AgripslclassificationComponent;
  let fixture: ComponentFixture<AgripslclassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgripslclassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgripslclassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
