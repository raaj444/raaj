import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { SearchComponent } from '../../common/search/search.component';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { AgripslclassificationService } from '../../util/service/agriservices/agripslclassification.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any;
@Component({
  selector: 'lp-agripslclassification',
  templateUrl: './agripslclassification.component.html',
  styleUrls: ['./agripslclassification.component.css']
})
export class AgripslclassificationComponent extends Validator  implements OnInit {   data:any; 
  model: any = {};
  modelForChngNote: any;
  pslautoList: any = [];
  communityList: any = [];
  subCatList: any = [];
  cropList: any = [];
  MainActList: any = [];
  catFarmerList: any = [];
  atlPurposeList: any = [];
  productTypeList: any = [];
  pslsubpurList: any = [];
  bsrcodeList: any = [];
  weakerSecList: any = [];
  religionList: any = [];
  categoryList: any = [];
  pslClassList: any = {};
  arryOfFacility: any = [];
  atlFacPurposeList: any = [];
  loanPurposeList: any = [];
  tempPsl: any = [];
  tempPSLAuto: any = [];
  pageAccess: any;
  fieldDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  nodata: any;
  datacls: any;
  tempFac: any;
  loanType: any;
  religionType: any;
  categoryType: any;
  tempComCode: any;
  prefStateCode: any;
  majorCrop: any;
  customerType: any;
  idvalueList = ['lpcLandAcre_', 'lpcCommunity_', 'lpcCroplist_', 'lpcAtlPurpose_', 'lpcMainAct_', 'lpcPslsubCat_','lpcCatFormer_',
 'lpcPurposeCode_','lpcSubpurCode_','lpcBsrCode_','lpcWeakerCode_'];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService, private agripslclassificationService: AgripslclassificationService) {
    super();
  }


  ngOnInit() {
    // $(document).ready(function () {
    //   $("form").change(function () {
    //     sessionStorage.setItem("editMode", "Y");
    //   });
    // });
    this.disableButton(false, true, true, true, true);
    this.datacls = true;
    this.nodata = true;
    this.addNewRow();
    this.getPropNumber();
  }
  addNewRow() {
    this.pslClassList = {
      lpcRowId: "", lpcAtlPurpose: "s", lpcBsrCode: "s", lpcCatFormer: "s", lpcCommunity: "s", lpcCroplist: "s", lpcLandAcre: "",
      lpcFacNo: "s", lpcMainAct: "s", lpcPurposeCode: "s", lpcPslsubCat: "s", lpcSubpurCode: "s", lpcWeakerCode: "s",
      lpcCreatedBy: "", lpcCreatedOn: "", lpcModifiedBy: "", lpcModifiedOn: ""
    };
  }
  getPropNumber() {

    this.agripslclassificationService.getListFacilityByPropNum().subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.arryOfFacility = this.data.listFacilityByPropNum;
          this.getPslData();
        }

      },
      error => {

      }
    );
  }


  getPslData() {
    this.agripslclassificationService.getPslClassMaster(this.model)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.pslautoList = this.data.pslautoList;
          this.productTypeList = this.data.productType;
          this.communityList = this.data.communityList;
          this.cropList = this.data.cropList;
          this.subCatList = this.data.subCatList;
          this.MainActList = this.data.MainActList;
          this.catFarmerList = this.data.catFarmerList;
          this.atlFacPurposeList = this.data.atlFacPurposeList;
          this.pslsubpurList = this.data.pslsubpurList;
          this.bsrcodeList = this.data.bsrcodeList;
          this.weakerSecList = this.data.weakerSecList;
          this.religionList = this.data.religionList;
          this.categoryList = this.data.categoryList;
          this.atlPurposeList = this.data.atlPurpose;
          this.loanPurposeList = this.data.loanPurposeList;
          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess == 'R') {
            this.disableButton(true, true, true, true, true);
          }
        }

      },
      error => {

      });
  }
  onChangeFac(e: any) {
    if (e != "s") {
      this.model.lpcFacNo = e;
      this.idvalueList.forEach(id=>{
        if ($('#'+ id).hasClass("has-error")) {
          $('#' +id).removeClass("has-error");
          $('#' + id).attr("placeholder", "");
        }
      })
      this.agripslclassificationService.getPslClassification(this.model)
        .subscribe(
        data => { this.data=data;

          if (this.data.success) {
            this.pslClassList = this.data.pslClassList;
            if (this.pslClassList == null) {
              this.addNewRow();
              this.pslClassList.lpcLandAcre = this.data.totOwnedLand;
              this.pslClassList.lpcFacNo = this.model.lpcFacNo;
              this.pslClassList.lpcAtlPurpose = this.data.atlPurpose;
              this.religionType = this.data.religionType;
              this.categoryType = this.data.categoryType;
              this.majorCrop = this.data.majorcrop;
              this.prefStateCode = this.data.prefStateCode;
              this.customerType=this.data.custemrType;
              this.communityList.forEach(element => {
                if (element.lcReligionType == this.religionType && element.lcCategory == this.categoryType) {
                  this.tempComCode = element.lcCommunityCode;
                }
              });
              if(this.tempComCode =="" || this.tempComCode ==null || this.tempComCode==undefined)
              {
                this.tempComCode="nomatch";
              }
              if (this.majorCrop != "") {
                this.pslClassList.lpcCroplist = this.majorCrop;
              }
              if (this.prefStateCode != "")
                this.dupCheck();

            }
            else {
              this.nodata = true;
              this.datacls = false;
            }

          }

        },
        error => {

        });
    }
  }
  onClickedEdit() {

    this.disableButton(true, false, false, false, false);

    // if(this.modelForChngNote.changeMode=="Y")
    //     {
    //       this.changenoteComponent.onEdit(false);
    //     }
  }
  onClickedSave() {
    if ( this.fieldvalidation.validateField(this.idvalueList)){
    this.agripslclassificationService.savePslClassification(this.pslClassList, this.model)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.pslClassList = this.data.pslClassList;
          this.disableButton(false, true, true, true, true);
          // sessionStorage.setItem("editMode", "N");
          // $('input,select,textarea').removeClass('ng-dirty');
        }

      },
      error => {

      });
    }
  }
  deleteAll() {
    this.agripslclassificationService.deleteAll(this.model)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.pslClassList = this.data.pslClassList;
          if (this.pslClassList == null) {
            this.addNewRow();
            this.pslClassList.lpcFacNo = "s";
            this.nodata = true;
            this.datacls = true;
          }
          this.disableButton(false, true, true, true, true);
        }

      },
      error => {

      });

  }
  dupCheck() {
    //Product Type Desc
    if (this.arryOfFacility.length == 1) {
      this.loanType = this.arryOfFacility[0].loanType;
    }
    else {
      for (let i = 0; i <= this.arryOfFacility.length; i++) {
        this.tempFac = this.arryOfFacility[i];
        if (this.tempFac.facNo == this.model.lpcFacNo) {
          this.loanType = this.tempFac.loanType;
          break;
        }
      }
    }
    //Product Type Value
    this.productTypeList.forEach(prd => {
      if (prd.llvOptionDesc == this.loanType) {
        this.loanType = prd.llvOptionVal;
      }

    });
    //Product Type based PSL Automation List
    this.tempPSLAuto = [];
    for (let i = 0; i < this.pslautoList.length; i++) {
      this.tempPsl = this.pslautoList[i];
      if (this.tempPsl.lpaPrdType == this.loanType && this.tempPsl.lpaStatecode == this.prefStateCode) {
        this.tempPSLAuto.push(this.tempPsl);
      }

    }
    //Auto populate PSL Automation Values
    var autocheck = false;
    for (let i = 0; i < this.tempPSLAuto.length; i++) {
      this.tempPsl = this.tempPSLAuto[i];
      var from = this.tempPsl.lpaLandholdFrom;
      var to = this.tempPsl.lpaLandholdTo;
      var tempatlpur = this.tempPsl.lpaAtlPurpose;

      if (from <= this.pslClassList.lpcLandAcre && to >= this.pslClassList.lpcLandAcre) {
        var atlpur = this.pslClassList.lpcAtlPurpose == tempatlpur;
        var community = false;
        var majorCrop = false;

        //Community check
        for (let t = 0; t < this.tempPsl.lpagriPslCommunities.length; t++) {
          var tempC = this.tempPsl.lpagriPslCommunities[t].lpcCommunityCode;
          if (tempC == this.tempComCode.trim() || tempC == "A") {
            community = true;
            break;
          }
        }
        // End Community check
        //Crop check
        for (let t = 0; t < this.tempPsl.lpagriPslCroplists.length; t++) {
          var tempC = this.tempPsl.lpagriPslCroplists[t].lpcCropValue;
          if (tempC == this.majorCrop || tempC == "A") {
            majorCrop = true;
            break;
          }
        }
        // End Crop check
        if (tempatlpur == "A") {
          atlpur = true;
        }
      }

      if (atlpur && community && majorCrop) {
        autocheck = true;
        break;
      }
    }
    if (autocheck) {
      this.pslClassList.lpcCommunity = this.religionType;
      this.pslClassList.lpcPslsubCat = this.tempPsl.lpaPslsubCat;
      this.pslClassList.lpcMainAct = this.tempPsl.lpaMainAct;
      this.pslClassList.lpcCatFormer = this.tempPsl.lpaCatFormer;
      this.pslClassList.lpcPurposeCode = this.tempPsl.lpaPurposeCode;
      this.pslClassList.lpcSubpurCode = this.tempPsl.lpaSubpurCode;
      this.pslClassList.lpcBsrCode = this.tempPsl.lpaBsrCode;
      this.pslClassList.lpcWeakerCode = this.tempPsl.lpaWeakerCode;
      this.nodata = true;
      this.datacls = false;
    }
    else {
      this.datacls = true;
      this.nodata = false;
    }

  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteA: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = true;
      this.deletebuttonDisable = deleteA;
    }
  }
  onClickedCancel()
  {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      // sessionStorage.setItem("editMode", "N");
      // $('input,select,textarea').removeClass('ng-dirty');
    }
    else {
      return false;
    }
  }
  rmvErr(event: any) {
    var value = (<HTMLInputElement>document.getElementById(event.target.id)).value;
    if (value != "" && value != null && value != undefined) {
      if ($('#' + event.target.id).hasClass("has-error")) {
        $('#' + event.target.id).removeClass("has-error");
        $('#' + event.target.id).attr("placeholder", "");
      }
    }
  }
}
