import { Component, OnInit } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { StlvehincdeviationService } from '../../util/service/agriservices/stlvehincdeviation.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
declare var loadingStatus:any
declare var progressStatus:any
declare var hide:any
@Component({
  selector: 'lp-stlvehincdeviation',
  templateUrl: './stlvehincdeviation.component.html',
  styleUrls: ['./stlvehincdeviation.component.css']
})
export class StlvehincdeviationComponent extends Validator  implements OnInit {   data:any; 
  model: any = {};
  vehincdevList: any = [];
  pageAccess: any;
  fieldDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;

  idvalueList = ['lvdVehagefrom', 'lvdVehageto', 'lvdVehInc'];
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private StlvehincdeviationService: StlvehincdeviationService) {
    super();
  }

  ngOnInit() {
    this.disableButton(false, true, true, true, true);
    this.StlvehincdeviationService.getVehIncDeviation(this.vehincdevList)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.vehincdevList = this.data.VehIncList;
          if (this.vehincdevList.length == 0) {
            this.addNewRow();
          }
        }

      },
      error => {

      });

  }
  saveVehIncDeviation() {

    this.flag = this.fieldvalidation.multipleFieldValidation(this.vehincdevList.length, this.idvalueList);
    if (this.flag) {
      progressStatus()
      this.StlvehincdeviationService.saveVehIncDeviation(this.vehincdevList)
        .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            successStatus();
            this.ngOnInit();
          
          }
        },
        error => {
          failedStatus();
        });

    }
  }
  addNewRow() {
    this.vehincdevList.push({
      lvdRowId: "", lvdVehagefrom: "", lvdVehageto: "", lvdCreatedBy: "", lvdCreatedOn: "", lvdVehInc: "", lvdModifiedBy: "", lvdModifiedOn: ""
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteA: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deleteA;
    }
  }

  onClickEditButton() {
    this.disableButton(true, false, false, false, false);


  }

  // onClickCancelButton() {
  //   var answer = confirm("Some Data has been Changed, Do you want to save it?");
  //   if (answer)
  //     this.saveVehIncDeviation();
  //   else
  //     this.ngOnInit()
  // }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit()

    }
    else {
      this.saveVehIncDeviation();
    }
  }
  deleteVehIncDeviation(row: any, id: any, i: any) {

    if (id == '' || id == undefined) {
      this.vehincdevList.splice(i, 1);
    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.StlvehincdeviationService.deleteVehIncDeviation(row)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {
          });
      }
    }
  }

  deleteAllVehIncDeviation() {

    this.StlvehincdeviationService.deleteAll(this.vehincdevList)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {

      });

  }
  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }

  rangefrom(id: number) {
    
    var tempid = id - 1;
    if (id != 0) {
      if ($('#lvdVehageto' + (id - 1)).val() != "" && $('#lvdVehagefrom' + id).val() != "" && $('#lvdVehageto' + (id - 1)).val() != undefined && $('#lvdVehagefrom' + id).val() != undefined) {
        var fromVal = parseFloat($('#lvdVehagefrom' + id).val());
        var maxAge = 20;
        if (fromVal <= maxAge) {
          if (parseFloat($('#lvdVehageto' + (id - 1)).val()) >= parseFloat($('#lvdVehagefrom' + id).val())) {

            alert("Vehicle Age FromRange  should  be Greater than Previous ToRange");
            $('#lvdVehagefrom' + id).val('');
            this.vehincdevList[id].lvdVehagefrom = '';
          }
          else if (parseFloat($('#lvdVehageto' + (id)).val()) >= parseFloat($('#lvdVehagefrom' + (id + 1)).val())) {

            alert("Vehicle Age ToRange should  be Lesser than Next FromRange");
            $('#lvdVehageto' + id).val('');
            this.vehincdevList[id].lvdVehageto = '';
          }
        }
        else {
          alert("Value should not be greater than 20");
          $('#lvdVehagefrom' + id).val('');
          this.vehincdevList[id].lvdVehagefrom = '';
          $('#lvdVehagefrom' + id).blur();
          return false;
        }

      }
    }
    else if (id == 0) {
      if ($('#lvdVehageto' + (id)).val() != "" && $('#lvdVehagefrom' + id).val() != "" && $('#lvdVehageto' + (id)).val() != undefined && $('#lvdVehagefrom' + id).val() != undefined) {
        var fromVal = parseFloat($('#lvdVehagefrom' + id).val());
        var maxAge = 20;
        if (fromVal <= maxAge) {
          if (parseFloat($('#lvdVehagefrom' + (id)).val()) >= parseFloat($('#lvdVehageto' + id).val())) {

            alert("Vehicle Age FromRange  should  be lesser than  ToRange");
            $('#lvdVehagefrom' + id).val('');
            this.vehincdevList[id].lvdVehagefrom = '';
          }

        }
        else {
          alert("Value should not be greater than 20");
          $('#lvdVehagefrom' + id).val('');
          this.vehincdevList[id].lvdVehagefrom = '';
          $('#lvdVehagefrom' + id).blur();
          return false;
        }

      }
    }
  }

  rangeto(i: number, e: any) {
    var id = i;
    
    if ($('#' + e.target.id).val() != "" && $('#' + e.target.id).val() != undefined) {
      if (parseFloat($('#' + e.target.id).val()) <= 20) {
        if ($('#lvdVehageto' + id).val() != undefined && $('#lvdVehageto' + id).val() != "" && $('#lvdVehagefrom' + id).val() != undefined && $('#lvdVehagefrom' + id).val() != "") {

          if (parseFloat($('#lvdVehagefrom' + id).val()) >= parseFloat($('#lvdVehageto' + id).val())) {
            alert(" Vehicle Age ToRange should  be greater than FromRange");
            $('#lvdVehageto' + id).val('');
            this.vehincdevList[id].lvdVehageto = '';
          }
          else {
            this.rangefrom(id);
          }

        }
        else if (($('#lvdVehagefrom' + id).val() != undefined && $('#lvdVehagefrom' + id).val() != "") || ($('#lvdVehageto' + id).val() != undefined && $('#lvdVehageto' + id).val() != "")) {
          this.rangefrom(id);
        }

      }
      else {
        alert("Value should not be greater than 20");
        $('#' + e.target.id).val('');
        this.vehincdevList[id].lvdVehageto = '';
        $('#' + e.target.id).blur();
        return false;
      }

    }
  }


}
