import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StlvehincdeviationComponent } from './stlvehincdeviation.component';

describe('StlvehincdeviationComponent', () => {
  let component: StlvehincdeviationComponent;
  let fixture: ComponentFixture<StlvehincdeviationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StlvehincdeviationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StlvehincdeviationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
