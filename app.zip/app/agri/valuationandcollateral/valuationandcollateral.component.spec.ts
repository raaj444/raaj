import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValuationandcollateralComponent } from './valuationandcollateral.component';

describe('ValuationandcollateralComponent', () => {
  let component: ValuationandcollateralComponent;
  let fixture: ComponentFixture<ValuationandcollateralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValuationandcollateralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValuationandcollateralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
