import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingkccrepaymentComponent } from './existingkccrepayment.component';

describe('ExistingkccrepaymentComponent', () => {
  let component: ExistingkccrepaymentComponent;
  let fixture: ComponentFixture<ExistingkccrepaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingkccrepaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingkccrepaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
