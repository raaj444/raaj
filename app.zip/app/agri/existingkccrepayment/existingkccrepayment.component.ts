import { Component, OnInit, ViewChild } from '@angular/core';
import { ExistingkccrepaymentService } from "../../util/service/agriservices/existingkccrepayment.service";
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';

declare var progressStatus: any
declare var successStatus: any
declare var failedStatus: any
declare var $: any;

@Component({
  selector: 'lp-existingkccrepayment',
  templateUrl: './existingkccrepayment.component.html',
  styleUrls: ['./existingkccrepayment.component.css']
})
export class ExistingkccrepaymentComponent extends Validator implements OnInit {
  data: any;

  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  disableNewButton: boolean;
  disableFields: boolean;
  private existingkccrepay: Array<any> = [];
  model: any = {};
  bankname: any = [];
  disableFlag: any;
  modelForChngNote: any;

  idvalueList = ['lerBankName', 'lerErstLimits', 'lerExistkccChurning', 'lerExistkccInterest', 'lerRemark'];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private existingkccrepaymentService: ExistingkccrepaymentService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }


  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.model.existingkccrepay = [];

    this.disableButtons(true, false, true, true, true);
    this.disableFields = true;
    this.existingkccrepaymentService.getMasterData()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.bankname = this.data.responseData.bankname;
          this.get();
        }
      },
      error => {
      });


  }

  get() {
    this.disableFlag = true;
    this.existingkccrepaymentService.getExistingkccRepay()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.model.existingkccrepay = this.data.existingkccrepay;
          if (this.model.existingkccrepay.length == 0) {
            this.model.existingkccrepay.push({ lerRowId: '', lerBankName: 's', lerErstLimits: '', lerExistkccChurning: '', lerExistkccInterest: '', lerRemark: '', lerOtherBankName: '' });
          }
          if (this.data.pageAccess == 'R') {
            this.disableButtons(true, true, true, true, true);
          }
        }
        else {
          if (this.data.pageAccess != 'R') {
            this.model.existingkccrepay.push({ lerRowId: '', lerBankName: 's', lerErstLimits: '', lerExistkccChurning: '', lerExistkccInterest: '', lerRemark: '', lerOtherBankName: '' });
            this.disableButtons(false, true, false, false, false);
            this.disableFields = false;

          }
          else {
            this.disableButtons(true, true, true, true, true);

            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }

          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.data.pageAccess);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onEdit(true);
          }
        }
      },
      error => {
      });
  }

  addRow() {
    this.model.existingkccrepay.push({ lerRowId: '', lerBankName: 's', lerErstLimits: '', lerExistkccChurning: '', lerExistkccInterest: '', lerRemark: '', lerOtherBankName: '' });
    this.disableButtons(false, true, false, false, false);
  }


  disableButtons(add: boolean, edit: boolean, save: boolean, cancel: boolean, deleteAll: boolean) {
    this.disableNewButton = add;
    this.disableEditButton = edit;
    this.disableSaveButton = save;
    this.disableCancelButton = cancel;
    this.disableDeleteAllButton = deleteAll;
  }

  onClickEditButton() {
    this.disableFields = false;
    this.disableFlag = false;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
    this.disableButtons(false, true, false, false, false);
  }

  saveExistingkccRepay() {
    let flagCM = true;
    let otherBank = true;

    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    //Save on changeMode
    if (this.modelForChngNote.changeMode == "Y" && flagCM) {
      this.changenoteComponent.onSave();
    }
    if (this.fieldvalidation.multipleFieldValidation(this.model.existingkccrepay.length, this.idvalueList)) {
      this.model.existingkccrepay.forEach((value, i) => {
        $('#lerOtherBankName' + i).removeClass("has-error");
        if (value.lerBankName == "0" && (value.lerOtherBankName == "" || value.lerOtherBankName == null)) {
          otherBank = false;
          $('#lerOtherBankName' + i).addClass("has-error");
          $('#lerOtherBankName' + i).attr("placeholder", "Enter Bank Name");
        }
      });
      if (otherBank) {
        this.existingkccrepaymentService.saveExistingKccRepay(this.model.existingkccrepay)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.get();
              this.disableFields = true;
              this.disableButtons(true, false, true, true, true);
              successStatus();
            }
            else {
              failedStatus();
            }
          },
          error => {
          });
      }
    }
  }


  onClickDeleteButton(row: any, id: any, i: any) {
    if (this.disableFlag == false) {
      if (confirm("Do you want to Delete?")) {
        if (id == '' || id == undefined) {
          this.model.existingkccrepay.splice(i, 1);
          if (this.model.existingkccrepay.length == 0)
            this.model.existingkccrepay.push({ lerRowId: '', lerBankName: 's', lerErstLimits: '', lerExistkccChurning: '', lerExistkccInterest: '', lerRemark: '' });
        }
        else {

          this.existingkccrepaymentService.deleteexistingkccrepay(row)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success == true) {
                this.model.existingkccrepay.splice(i, 1);
              }

            },
            error => {
              // this.alertService.error(error);
            });
        }
      }
    }

  }

  onClickDeleteAllButton() {
    if (confirm("Do you want to Delete?")) {
      this.existingkccrepaymentService.deleteAllexistingkccrepay()
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.model.existingkccrepay = [];
            this.get();
            this.disableFields = true;
            this.disableButtons(true, false, true, true, true);
          }

        },
        error => {
          // this.alertService.error(error);
        });
    }
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

}
