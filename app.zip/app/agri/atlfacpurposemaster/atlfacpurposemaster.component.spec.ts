import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtlfacpurposemasterComponent } from './atlfacpurposemaster.component';

describe('AtlfacpurposemasterComponent', () => {
  let component: AtlfacpurposemasterComponent;
  let fixture: ComponentFixture<AtlfacpurposemasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtlfacpurposemasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtlfacpurposemasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
