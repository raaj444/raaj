import { Component, OnInit } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { AtlfacpurposemasterService } from '../../util/service/agriservices/atlfacpurposemaster.service';


declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
@Component({
  selector: 'lp-atlfacpurposemaster',
  templateUrl: './atlfacpurposemaster.component.html',
  styleUrls: ['./atlfacpurposemaster.component.css']
})
export class AtlfacpurposemasterComponent extends Validator  implements OnInit {   data:any; 
  model: any = {};
  atlfacpurList: any = [];
  facPurposeList: any = [];
  tempList: any = [];
  checkList: any = [];
  pslsubpurList: any = [];
  bsrcodeList: any = [];
  pageAccess: any;
  fieldDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;
  purposeFlag: boolean;
  idvalueList = ['lamAtlpurpose_', 'lamSubpurpose_', 'lamBsrCode_'];
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private atlfacpurposemasterService: AtlfacpurposemasterService) {
    super();
  }

  ngOnInit() {
    this.disableButton(false, true, true, true, true);
    this.atlfacpurposemasterService.getAtlfacpurMaster(this.atlfacpurList)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.atlfacpurList = this.data.atlfacPurposeList;
          this.facPurposeList = this.data.facPurposeList;
          this.pslsubpurList = this.data.pslsubpurList;
          this.bsrcodeList = this.data.bsrcodeList;
          if (this.atlfacpurList.length == 0) {
            this.addNewRow();
          }
        }

      },
      error => {

      });

  }
  saveAtlfacPurMaster() {
    var dupCheck=this.validateCheck();
    if(!dupCheck)
    {
    this.flag = this.fieldvalidation.multipleFieldValidation(this.atlfacpurList.length, this.idvalueList);
    if (this.flag) {
      progressStatus()
      this.atlfacpurposemasterService.saveAtlfacpurMaster(this.atlfacpurList)
        .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            successStatus();
            this.ngOnInit();

          }
        },
        error => {
          failedStatus();
        });
      }
    }
  }
  addNewRow() {
    this.atlfacpurList.push({
      lamRowId: "", lamAtlpurpose: "", lamSubpurpose: "", lamCreatedBy: "", lamCreatedOn: "", lamBsrCode: "", lamModifiedBy: "", lamModifiedOn: ""
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteA: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deleteA;
    }
  }

  onClickEditButton() {
    this.disableButton(true, false, false, false, false);


  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit()

    }
    else {
      this.saveAtlfacPurMaster();
    }
  }
  deleteAtlfacPurMaster(row: any, id: any, i: any) {

    if (id == '' || id == undefined) {
      this.atlfacpurList.splice(i, 1);
    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.atlfacpurposemasterService.deleteAtlfacpurMaster(row)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {
          });
      }
    }
  }

  deleteAll() {

    this.atlfacpurposemasterService.deleteAll(this.atlfacpurList)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {

      });

  }

  purposeChange(relid: any, index: any) {

    if (this.atlfacpurList.length > 1) {
      for (let j = 0; j < this.atlfacpurList.length - 1; j++) {
        this.checkList = this.atlfacpurList[index];
        this.tempList = this.atlfacpurList[j];

        if ((this.checkList.lamAtlpurpose != "")) {
          if (j == index) {
            this.tempList = this.atlfacpurList[j+1];
          }
          if ((this.tempList.lamAtlpurpose == this.checkList.lamAtlpurpose)) {
            alert("Already purpose choosed");
            this.atlfacpurList[index].lamAtlpurpose = "s";
            $('#lamAtlpurpose_'+index).val("s");
            break;
          }
        }
      }
    }
  }
  validateCheck() {
    for (let j = 0; j < this.atlfacpurList.length; j++) {
      this.checkList = this.atlfacpurList[j];
      for (let d = j + 1; d < this.atlfacpurList.length; d++) {
        this.tempList = this.atlfacpurList[d];
        if (this.checkList.lamAtlpurpose != "" && this.tempList.lamAtlpurpose != "" ) {

          if ((this.tempList.lamAtlpurpose == this.checkList.lamAtlpurpose) ) {
           this.atlfacpurList[d].lamAtlpurpose = "s";
            $('#lamAtlpurpose_'+d).val("s");
            this.purposeFlag = true;
            break;
          }
          else
            this.purposeFlag = false;
        }
      }
    }
    return this.purposeFlag;
  }
  rmvErr(event: any) {
    var value = (<HTMLInputElement>document.getElementById(event.target.id)).value;
    if (value != "" && value != null && value != undefined) {
      if ($('#' + event.target.id).hasClass("has-error")) {
        $('#' + event.target.id).removeClass("has-error");
        $('#' + event.target.id).attr("placeholder", "");
      }
    }
  }
}
