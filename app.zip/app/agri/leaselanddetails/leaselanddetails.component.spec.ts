import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaselanddetailsComponent } from './leaselanddetails.component';

describe('LeaselanddetailsComponent', () => {
  let component: LeaselanddetailsComponent;
  let fixture: ComponentFixture<LeaselanddetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaselanddetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaselanddetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
