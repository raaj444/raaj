import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { SearchComponent } from '../../common/search/search.component';
import { LeaselanddetService } from '../../util/service/agriservices/leaselanddet.service';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { StgeographymasterService } from '../../util/service/setupservices/stgeographymaster.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-leaselanddetails',
  templateUrl: './leaselanddetails.component.html',
  styleUrls: ['./leaselanddetails.component.css']
})
export class LeaselanddetailsComponent extends Validator implements OnInit {
  data: any;
  @ViewChild(SearchComponent)
  Searchpop: SearchComponent
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  maxDate: Date; minDate: Date;
  constructor(private router: Router, private fieldvalidation: Fieldvalidation,
    private leaselanddetService: LeaselanddetService,
    private changenoteService: ChangenoteService, private stgeographymasterService: StgeographymasterService) {
    super();
    this.maxDate = new Date();
    this.minDate = new Date(1899, 12, 1);
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());
  }

  itr: any;
  model: any = {};
  private leaseLandDetArray: Array<any> = [];

  disableFields: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  hidStateCode: any = ""; hidDistrictCode: string = "";
  idvalueList = ['lldBorRelationship', 'lldLessorContact', 'hid_lldStateid_', 'hid_lldDistrictid_',
    'hid_lldTalukid_', 'lldVillage', 'lldCulArea', 'lldValidFrom',
    'lldValidTo', 'lldKycType', 'lldKycProof'];
  stateName: string = "";
  districtName: string = "";
  listOfValuesList = [];
  stateList: any = [];
  borRelationList: any = [];
  kycTypeList: any = [];
  partiesCRNList: any = [];
  pageAccess: any;
  stateFlag: boolean;
  cityFlag: boolean;
  districtFlag: boolean;
  flag: any;
  hidCityCode: any;
  modelForChngNote: any;
  cityDetails: any = [];
  //districtList: any = [];
  talukList: any = [];
  borrowerFlag: any;
  tempVal: any = [];
  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();
    this.model.leaseLandDetArray = [{
      lldRowId: '', lldBorName: 's', lldLandCul: 'Y', lldLessorName: '', lldBorRelationship: 's',
      lldLessorAddr: '', lldLessorContact: '', lldLandAddr: '', lldStateid: 's', lldDistrictid: 's', lldTalukid: 's', lldVillage: '',
      lldSurvey: '', lldKhataNo: '', lldKhasaraNo: '', lldCulArea: '', lldUnculArea: '',
      lldLeaseRate: '', lldValidFrom: '', lldValidTo: '', lldKycType: 's', lldKycProof: '',lldRemarks:""
    }];
    this.disableButtons(true, false, false, true, true, true);
    this.borrowerFlag = true;

    // this.getPartyList();
    this.leaselanddetService.getLeaseLandDetails(this.model)
      .subscribe(
      data => {
        this.data = data;

        if (this.data.success == true) {
          this.pageAccess = this.data.pageAccess;

          this.disableButtons(true, true, false, true, true, true);

          if (this.data.lpagriKccEligibility != null) {
            this.disableButtons(true, true, true, true, true, true);
          }

          this.model.leaseLandDetArray = this.data.LeaseLandDetails;
          this.borRelationList = this.data.borrowerRelationList;
          this.kycTypeList = this.data.kycproofTypeList;
          this.stateList = this.data.stateList;
          this.cityDetails = this.data.cityList;
          this.talukList = this.data.talukList;
          this.partiesCRNList = this.data.borrowerList;
          this.model.leaseLandDetArray.forEach(element => {
            if (element.lldValidFrom != "" && element.lldValidFrom != undefined) {
              var quotedate = element.lldValidFrom;
              var matudate = quotedate.split("-");
              element.lldValidFrom = matudate[2] + '/' + matudate[1] + '/' + matudate[0];
            }
            if (element.lldValidTo != "" && element.lldValidTo != undefined) {
              var quotedate = element.lldValidTo;
              var matudate = quotedate.split("-");
              element.lldValidTo = matudate[2] + '/' + matudate[1] + '/' + matudate[0];
            }
            if (element.lldBorName != "" && element.lldBorName != null) {
              this.tempVal = element.lldBorName.split(',');
              element.lldBorName = this.tempVal;
            }
            if (element.lldBorName.includes("0"))
              element.otherBorrowerName = false;
            else
              element.otherBorrowerName = true;
          });

          if (this.model.leaseLandDetArray.length == 0) {
            this.model.leaseLandDetArray = [{
              lldRowId: '', lldBorName: 's', lldLandCul: 'Y', lldLessorName: '', lldBorRelationship: 's',
              lldLessorAddr: '', lldLessorContact: '', lldLandAddr: '', lldStateid: 's', lldDistrictid: 's', lldTalukid: 's', lldVillage: '',
              lldSurvey: '', lldKhataNo: '', lldKhasaraNo: '', lldCulArea: '', lldUnculArea: '',
              lldLeaseRate: '', lldValidFrom: '', lldValidTo: '', lldKycType: 's', lldKycProof: '', otherBorrowerName: true,lldRemarks:""
            }];
            this.disableButtons(false, false, true, false, false, false);
          }
        }
        if (this.pageAccess == "R") {
          this.disableButtons(true, true, true, true, true, true);
        }

        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onload(this.pageAccess);
          this.disableButtons(true, true, false, true, true, true);
        }
        setTimeout(() => {
          let i = this.model.leaseLandDetArray.length - 1;
          for (let i = 0; i < this.model.leaseLandDetArray.length; i++) {
            $("#hid_lldStateid_" + i).select2();
            $("#hid_lldDistrictid_" + i).select2();
            $("#hid_lldTalukid_" + i).select2();
            $("#hid_lldStateid_" + i).on('change', (e) => {
              this.model.leaseLandDetArray[i].lldStateid = e.target.value;
              this.getCityList(this.model.leaseLandDetArray[i].lldStateid, i);
            });
            $("#hid_lldDistrictid_" + i).on('change', (e) => {
              this.model.leaseLandDetArray[i].lldDistrictid = e.target.value;
              this.getTalukList(this.model.leaseLandDetArray[i].lldStateid, this.model.leaseLandDetArray[i].lldDistrictid, i);
            });
            $("#hid_lldTalukid_" + i).on('change', (e) => {
              this.model.leaseLandDetArray[i].lldTalukid = e.target.value;
            });
          }
        }, 50);
      },
      error => {
        // this.alertService.error(error);
      });
    this.disableButtons(true, false, false, true, true, true);
    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });
  }

  // getPartyList() {
  //   this.leaselanddetService.getPartiesCRN()
  //     .subscribe(
  //     data => { this.data=data;
  //       if (this.data.success == true) {
  //         this.partiesCRNList = this.data.responseData.LpcomCustInfoApplist;
  //       }
  //     },
  //     error => {
  //     });
  // }
  saveLeaseLandDetails() {
    let flagCM = true;
    this.borrowerFlag = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.leaseLandDetArray.length, this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.leaseLandDetArray.length, this.idvalueList)
      let otherOwnerEmpCount = 0;
      this.model.leaseLandDetArray.forEach((element, index) => {
        $('#lldOtherBorname' + index).removeClass("has-error");
        $('#lldBorName' + index).removeClass("has-error");
        if (element.lldBorName.includes("0") && (element.lldOtherBorname == "" || element.lldOtherBorname == null)) {
          otherOwnerEmpCount++;
          $('#lldOtherBorname' + index).addClass("has-error");
          $('#lldOtherBorname' + index).attr("placeholder", "Enter Owner Name");
        }

        if (element.lldBorName == "0") {
          $('#lldBorName' + index).addClass("has-error");
          alert("Select atleast One Borrower");
          this.borrowerFlag = false;
        }
        if (element.lldBorName == "s" || element.lldBorName == '') {
          $('#lldBorName' + index).focus();
          $('#lldBorName' + index).addClass("has-error");
          alert("Select atleast One Borrower");
          this.borrowerFlag = false;
        }
      });
      if (this.flag && otherOwnerEmpCount == 0 && this.borrowerFlag) {
        this.model.leaseLandDetArray.forEach(element => {
          element.lldValidFrom = this.fieldvalidation.dPDateConversionFromIndianStd(element.lldValidFrom);
          element.lldValidTo = this.fieldvalidation.dPDateConversionFromIndianStd(element.lldValidTo);
          if (element.lldBorName != "s") {
            var tempvalue = element.lldBorName.join();
            element.lldBorName = tempvalue;
          }
        });
        this.leaselanddetService.saveLeaseLandDetails(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.model.leaseLandDetArray = this.data.responseData;
              this.disableButtons(true, false, false, true, true, true);
              this.ngOnInit();

            }
          },
          error => {
            failedStatus();
          });
      }
    }
  }
  addRow() {
    this.model.leaseLandDetArray.push({
      lldRowId: '', lldBorName: 's', lldLandCul: 'Y', lldLessorName: '', lldBorRelationship: 's',
      lldLessorAddr: '', lldLessorContact: '', lldLandAddr: '', lldStateid: 's', lldDistrictid: 's', lldTalukid: 's', lldVillage: '',
      lldSurvey: '', lldKhataNo: '', lldKhasaraNo: '', lldCulArea: '', lldUnculArea: '',
      lldLeaseRate: '', lldValidFrom: '', lldValidTo: '', lldKycType: 's', lldKycProof: '', otherBorrowerName: true,lldRemarks:""
    });
    this.disableButtons(false, false, true, false, false, false);
    this.hidStateCode = "";
    setTimeout(() => {
      let i = this.model.leaseLandDetArray.length - 1;
      $("#hid_lldStateid_" + i).select2();
      $("#hid_lldDistrictid_" + i).select2();
      $("#hid_lldTalukid_" + i).select2();
      $("#hid_lldStateid_" + i).on('change', (e) => {
        this.model.leaseLandDetArray[i].lldStateid = e.target.value;
        this.getCityList(this.model.leaseLandDetArray[i].lldStateid, i);
      });
      $("#hid_lldDistrictid_" + i).on('change', (e) => {
        this.model.leaseLandDetArray[i].lldDistrictid = e.target.value;
        this.getTalukList(this.model.leaseLandDetArray[i].lldStateid, this.model.leaseLandDetArray[i].lldDistrictid, i);
      });
      $("#hid_lldTalukid_" + i).on('change', (e) => {
        this.model.leaseLandDetArray[i].lldTalukid = e.target.value;
      });
    }, 50);

  }

  onClickEditButton() {
    this.disableButtons(false, false, true, false, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  onClickDeleteButton(row: any, id: any, i: any) {
    if (id == '' || id == undefined) {
      this.model.leaseLandDetArray.splice(i, 1);

    } else {
      if (row.lldBorName != "s") {
        var tempvalue = row.lldBorName.join();
        row.lldBorName = tempvalue;
      }
      this.leaselanddetService.deleteLeaseLandDetails(row)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.ngOnInit();
          }
        },
        error => {
        });
    }
  }

  onClickDeleteAllButton() {
    if (confirm("Do you want to Delete?")) {
      this.leaselanddetService.deleteAllData(this.model)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.ngOnInit();
          }
     
        },
        error => {
          // this.alertService.error(error);
        });
    }
    else {
      this.ngOnInit();
    }
  }

  disableButtons(field: boolean, add: boolean, edit: boolean, save: boolean, deleteAll: boolean, cancel: boolean) {
    this.disableFields = field;
    this.disableNewButton = add;
    this.disableEditButton = edit;
    this.disableSaveButton = save;
    this.disableCancelButton = cancel;
    this.disableDeleteAllButton = deleteAll;
  }

  validatefuturedate(eventId) {

    this.fieldvalidation.validatefuturedate(eventId);
  }

  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }

  validateKYCProof(kycType: any, proofId: any, index: any) {
    var kycProof = (<HTMLInputElement>document.getElementById(kycType)).value;
    var proofVal = (<HTMLInputElement>document.getElementById(proofId)).value;
    var proof;

    // if (kycProof == '1' && proofVal != "") {
    //   proof = this.fieldvalidation.passportNoValidate(proofVal);
    // }
    // else 
    if (kycProof == '2' && proofVal != "") {
      proof = this.fieldvalidation.AadharnoValidate(proofVal);
    }
    else if (kycProof == '3' && proofVal != "") {
      this.model.leaseLandDetArray[index].lldKycProof = $('#' + proofId).val().toUpperCase();
      proofVal = proofVal.toUpperCase();
      proof = this.fieldvalidation.PanValidate(proofVal);
    }
    // else if (kycProof == '4' && proofVal != "") {
    //   proof = this.fieldvalidation.VoterIDValidate(proofVal);
    // }
    // else if (kycProof == '5' && proofVal != "") {
    //   proof = this.fieldvalidation.driveLicValidate(proofVal);
    // }
    if (proof == false) {
      (<HTMLInputElement>document.getElementById(proofId)).value = "";
      $('#' + proofId).val("");
      this.model.leaseLandDetArray[index].lldKycProof = "";
      $('#' + proofId).addClass("has-error");
      $('#' + proofId).attr('placeholder', 'Please enter the valid  KYC Proof');
    }
    else if (proof == true) {
      $('#' + proofId).removeClass("has-error");
      $('#' + proofId).attr('placeholder', '');
    }
    else {
      $('#' + proofId).removeClass("has-error");
      $('#' + proofId).attr('placeholder', '');
    }
  }
  searchState(event, i) {

    this.itr = i;
    this.stateFlag = true;
    var pageid = "State";
    $('#name').text("State Name");
    $('#code').text("State Code");
    $('#header').text("State Search");
    $('#txt_pageid').val(pageid);
    $('#txt_hidCode').val("S");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');
  }

  searchDistrict(event, i) {

    this.itr = i;
    this.cityFlag = true;
    var pageid = "City";
    $('#name').text("City Name");
    $('#code').text("City Code");
    $('#header').text("City Search");
    $('#txt_pageid').val(pageid);

    let rowCount = event.target.id.split("_");

    if ($('#hid_lldStateid_' + rowCount[1]).val() !== "" && $('#lldStateid_' + this.itr).val() !== "") {
      $('#txt_hidCode').val("S:" + this.hidStateCode);
      if (this.hidStateCode == null || this.hidStateCode == "" || this.hidStateCode == undefined) {
        this.hidStateCode = $('#lldStateid_' + this.itr).val();
        $('#txt_hidCode').val("S:" + this.hidStateCode);
      }
    }
    else
      $('#txt_hidCode').val("D");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');
  }
  searchTaluk(event, i) {
    this.itr = i;
    this.districtFlag = true;
    var pageid = "District";
    $('#name').text("Taluk Name");
    $('#code').text("Taluk Code");
    $('#header').text("Taluk Search");
    $('#txt_pageid').val(pageid);
    if ($('#lldStateid_' + this.itr).val() == "" && $('#hid_lldDistrictid_' + this.itr).val() == "") {
      $('#txt_hidCode').val("D");

    }
    else if ($('#lldStateid_' + this.itr).val() != "" && $('#hid_lldDistrictid_' + this.itr).val() == "") {
      this.hidStateCode = this.model.leaseLandDetArray[this.itr].lldStateid;
      $('#txt_hidCode').val("S:" + this.hidStateCode);
    }
    else if ($('#lldStateid_' + this.itr).val() != "" && $('#hid_lldDistrictid_' + this.itr).val() != "") {
      this.hidDistrictCode = this.model.leaseLandDetArray[this.itr].lldDistrictid;
      $('#txt_hidCode').val("C:" + this.hidDistrictCode);

    }
    else if ($('#lldStateid_' + this.itr).val() != "" && $('#hid_lldDistrictid_' + this.itr).val() != "" && $('#hid_lldTalukid_' + this.itr).val() != "") {
      $('#txt_hidCode').val("S:" + this.hidStateCode);


    }
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');
  }

  modalClosed() {
    if (this.stateFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt-txt_Searchcode').val() != "") {
        var stateName = $('#txt-Searchname').val();
        var stateCode = $('#txt_Searchcode').val();
        if (stateName != "" && stateCode != "") {

          this.model.leaseLandDetArray[this.itr].lldStateid = stateCode;
          $('#hid_lldStateid_' + this.itr).val(stateName);
          this.hidStateCode = stateCode;
          $('#lldStateid_' + this.itr).val(stateCode);
          this.hidStateCode = stateCode;


        }
        this.model.leaseLandDetArray[this.itr].lldDistrictid = "";
        this.model.leaseLandDetArray[this.itr].lldTalukid = "";
        this.model.leaseLandDetArray[this.itr].hid_lldTalukid = "";
        this.model.leaseLandDetArray[this.itr].lldDistrictid = "";
        this.model.leaseLandDetArray[this.itr].hid_lldDistrictid_ = "";

      }
      this.stateFlag = false;
    }
    else if (this.districtFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt-txt_Searchcode').val() != "") {
        var districtName = $('#txt-Searchname').val();
        var districtCode = $('#txt_Searchcode').val();

        if (districtName != "" && districtCode != "") {

          this.model.leaseLandDetArray[this.itr].lldTalukid = districtCode;
          this.model.leaseLandDetArray[this.itr].hid_lldTalukid = districtName;
          $('#hid_lldTalukid_' + this.itr).val(districtName);
          $('#lldTalukid_' + this.itr).val(districtCode);
        }
        if ($('#txt_hidCode').val() == "D") {
          var strState = $('#txt_hidValue').val().split("@");
          var splitCity = strState[1].split("/");
          this.model.leaseLandDetArray[this.itr].lldStateid = strState[0];
          $('#hid_lldStateid_' + this.itr).val(splitCity[0]);
          this.hidStateCode = strState[0];
        }
        else if ($('#txt_hidCode').val().match("^S:")) {
          let temp = $('#txt_hidValue').val().split("@");
          this.model.leaseLandDetArray[this.itr].lldDistrictid = temp[0];
          $('#hid_lldDistrictid_' + this.itr).val(temp[1]);
          this.hidDistrictCode = temp[0];;
        }


      }

      this.districtFlag = false;
    }

    else if (this.cityFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt-txt_Searchcode').val() != "") {
        var cityName = $('#txt-Searchname').val();
        var cityCode = $('#txt_Searchcode').val();

        if (cityName != "" && cityCode != "") {

          this.model.leaseLandDetArray[this.itr].lldDistrictid = cityCode;
          this.model.leaseLandDetArray[this.itr].hid_lldDistrictid_ = cityName;
          $('#hid_lldDistrictid_' + this.itr).val(cityName);
          $('#lldDistrictid_' + this.itr).val(cityCode);
          this.hidDistrictCode = cityCode;

          if ($('#txt_hidCode').val() == "D") {
            var strState = $('#txt_hidValue').val().split("@");
            var splitCity = strState[1].split("/");
            this.model.leaseLandDetArray[this.itr].lldDistrictid = strState[0];
            $('#hid_lldStateid_' + this.itr).val(splitCity[0]);
            this.hidStateCode = strState[0];
          }
        }

        this.model.leaseLandDetArray[this.itr].lldTalukid = "";
        this.model.leaseLandDetArray[this.itr].hid_lldTalukid = "";
        $('#hid_lldTalukid_' + this.itr).val("");

      }

      this.cityFlag = false;
    }


  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }
  getCityList(stateCode, index) {
    this.cityDetails[index] = [];
    this.stgeographymasterService.getCityListBasedOnStateCode(stateCode)
      .subscribe(
      data => {
        this.data = data;
        this.cityDetails[index] = this.data.cityList;
        this.talukList[index] = [];
      },
      error => {

      }
      );
  }

  getTalukList(stateCode, cityCode, index) {

    let parentIdForTaluk = this.cityDetails[index].find(city => city.sgmStateCode == stateCode && city.sgmCityCode == cityCode).sgmRowId;
    let codeDetail = cityCode + ":" + stateCode + ":" + parentIdForTaluk;

    this.talukList[index] = [];

    this.stgeographymasterService.getDistinctTalukList(codeDetail)
      .subscribe(
      data => {
        this.data = data;
        this.talukList[index] = this.data.distinctTalukList;

      },
      error => {

      }
      );
  }

  selectOtherBorrowerName(val, i) {
    if (val.includes("0")) {
      this.model.leaseLandDetArray[i].otherBorrowerName = false;
      // this.model.leaseLandDetArray[i].lldOtherBorname = "";
    }
    else
      this.model.leaseLandDetArray[i].otherBorrowerName = true;
  }
  checkAcreLimit(event: any,i:number) {
    var AcreVal = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (AcreVal > 999.99) {
      this.model.leaseLandDetArray[i].lldCulArea="";
      alert("Enter Acre Limit Below 1000");
      return true;
     
    }
  }
}
