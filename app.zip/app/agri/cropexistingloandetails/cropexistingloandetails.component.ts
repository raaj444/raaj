import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { CropexistingloandetailsService } from "../../util/service/agriservices/cropexistingloandetails.service";
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;

@Component({
  selector: 'lp-cropexistingloandetails',
  templateUrl: './cropexistingloandetails.component.html',
  styleUrls: ['./cropexistingloandetails.component.css']
})
export class CropexistingloandetailsComponent extends Validator  implements OnInit {   data:any; 

  lpexLoanFor: any = '';
  model: any = {};
  temp: any = {};
  branch = [];
  borrowerType = [];
  private existingExposure: Array<any> = [];
  private existingExposurelen: Array<any> = [];
  os: boolean;
  comment: boolean;
  other: boolean = true;
  term: boolean = true;
  crop: boolean = true;
  all: boolean = true;
  freq: any = 'Interest servicing - Half yearly/Annually';
  freq1: any = 'Interest servicing';
  freq2: any = '';
  osCont1: any = 'Outstanding Rs.';
  osCont2: any = '';
  remarks: any = 'Remarks';
  disableFields: boolean;
  disableNewButton: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableDeleteAllButton: boolean;
  disableCancelButton: boolean;
  flag: boolean; loanForFlag: string = '';
  disableLoanFor: boolean;
  pageAccess: any;
  idvalueList1 = ['lpexCustId', 'lpexBankName', 'lpexBranch', 'lpexLoanAmt', 'lpexAnnualInstl', 'lpexCurrOs','lpexTenor'];
  idvalueList2 = ['lpexCustId', 'lpexBankName', 'lpexBranch', 'lpexLoanAmt', 'lpexAnnualInstl', 'lpexCurrOs', 'lpexRemarks','lpexTenor'];
  idvalueList3 = ['lpexCustId', 'lpexFacNature', 'lpexFacType', 'lpexFacility', 'lpexBankName', 'lpexLoanAmt', 'lpexAnnualInstl','lpexTenor'];
  modelForChngNote: any; repaymentFreqList:any=[];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private cropexistingloandetailsService: CropexistingloandetailsService, private router: Router, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.validators();
    this.model.existingExposure = [];
    this.existingExposurelen = [];
    this.lpexLoanFor = "s";
    this.disableButtons(true, true, true, true, true);
    this.disableFields = true;
    this.disableLoanFor = true;
    this.repaymentFreqList=[];
    this.cropexistingloandetailsService.getBranch()
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.branch = this.data.responseData.distinctCity;
        }

        this.cropexistingloandetailsService.getExistingExposure()
          .subscribe(
          data => { this.data=data;
            this.crop = false;
            this.term = true;
            this.other = true;
            if (this.data.success == true) {

this.repaymentFreqList=this.data.repaymentFreqList;
              this.borrowerType = this.data.loanAvailableBy;
              this.temp = this.data.existingExposureList;
              this.model.existingExposure = this.data.existingExposureList;
              this.existingExposurelen = this.model.existingExposure;
              if (this.loanForFlag == 'C') { this.lpexLoanFor = "1"; }
              else
                if (this.loanForFlag == 'T') { this.lpexLoanFor = "2"; }
                else
                  if (this.loanForFlag == 'O') { this.lpexLoanFor = "3"; }

              this.lpexLoanFor = 's';
              this.pageAccess = this.data.pageAccess;



              this.onChangeLoanFor(this.lpexLoanFor);
              if (this.modelForChngNote.changeMode == "Y") {
                this.changenoteComponent.onload(this.pageAccess);

              }
            }

          },
          error => {
            // this.alertService.error(error);
          });

      },
      error => {
        // this.alertService.error(error);
      });
    this.all = false;
    this.crop = false;

  }

  get() {
    this.validators();
    this.model.existingExposure = [];
    this.existingExposurelen = [];
    this.disableButtons(true, true, true, true, true);
    this.disableFields = true;
    this.disableLoanFor = false;
    this.cropexistingloandetailsService.getBranch()
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.branch = this.data.responseData.distinctCity;
        }

        this.cropexistingloandetailsService.getExistingExposure()
          .subscribe(
          data => { this.data=data;
            this.crop = false;
            this.term = true;
            this.other = true;
            if (this.data.success == true) {


              this.borrowerType = this.data.loanAvailableBy;
              this.temp = this.data.existingExposureList;
              this.model.existingExposure = this.data.existingExposureList;
              this.existingExposurelen = this.model.existingExposure;

              if (this.loanForFlag == 'C') { this.lpexLoanFor = "1"; }
              else
                if (this.loanForFlag == 'T') { this.lpexLoanFor = "2"; }
                else
                  if (this.loanForFlag == 'O') { this.lpexLoanFor = "3"; }


              this.onChangeLoanFor(this.lpexLoanFor);
            }

          },
          error => {
            // this.alertService.error(error);
          });

      },
      error => {
        // this.alertService.error(error);
      });
    this.all = false;
    this.crop = false;

  }

  disableButtons(add: boolean, edit: boolean, save: boolean, cancel: boolean, deleteAll: boolean) {
    this.disableNewButton = add;
    this.disableEditButton = edit;
    this.disableSaveButton = save;
    this.disableCancelButton = cancel;
    this.disableDeleteAllButton = deleteAll;
  }


  onChangeLoanFor(val: any) {

    this.model.existingExposure = [];
    this.all = false;
    if (val == 1) {
      this.crop = false;
      this.term = true;
      this.other = true;
      this.comment = false;
      this.freq1 = 'Interest servicing';
      this.freq2 = ' ';
      this.os = false;
      this.osCont1 = 'Outstanding Rs.';
      this.osCont2 = '';
      this.remarks = 'Remarks';
      this.lpexLoanFor = "1";
      this.loanForFlag = 'C';
      this.temp.forEach(element => {
        if (element.lpexLoanFor == 1)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0)
      {
        this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: 's', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' });
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onEdit(false);
        }
      }
      else
      {
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onload(this.pageAccess);
      }
    }

    } else if (val == 2) {
      this.crop = true;
      this.term = false;
      this.other = true;
      this.comment = true;
      this.freq1 = 'Frequency of ';
      this.freq2 = 'Installment servicing';
      this.os = false;
      this.osCont1 = 'Balance POS as';
      this.osCont2 = ' on date (Rs.)';
      this.remarks = 'Track Status & Remark';
      this.lpexLoanFor = "2";
      this.loanForFlag = 'T';
      this.temp.forEach(element => {

        if (element.lpexLoanFor == 2)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0) { 
        this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '2', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: 's', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: ' ', lpexAnnualInstl: '', lpexCurrOs: '', lpexInstlDue: '', lpexInstlPaid: '', lpexAvgDelayDays: '', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' });
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onEdit(false);
        }
       }
      else {
        this.model.existingExposure.forEach(element => {
          element.lpexLoanAmt = element.lpexLoanAmt != "" ? parseFloat(element.lpexLoanAmt).toFixed(2) : '';
          element.lpexAnnualInstl = element.lpexAnnualInstl != "" ? parseFloat(element.lpexAnnualInstl).toFixed(2) : '';
          element.lpexCurrOs = element.lpexCurrOs != "" && element.lpexCurrOs != 'NaN' ? parseFloat(element.lpexCurrOs).toFixed(2) : '';
        });
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onload(this.pageAccess);
        }
      }

    } else if (val == 3) {
      this.crop = true;
      this.term = true;
      this.other = false;
      this.comment = false;
      this.freq1 = 'Repayment';
      this.freq2 = 'Frequency';
      this.os = true;
      this.remarks = 'Remarks';
      this.lpexLoanFor = "3";
      this.loanForFlag = 'O';
      this.temp.forEach(element => {

        if (element.lpexLoanFor == 3)
          this.model.existingExposure.push(element);
      });
      if (this.model.existingExposure.length == 0) { 
        this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '3', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexAnnualInstl: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' }); 
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onEdit(false);
        }
      }
      else {
        this.model.existingExposure.forEach(element => {
          element.lpexLoanAmt = element.lpexLoanAmt != "" ? parseFloat(element.lpexLoanAmt).toFixed(2) : '';
          element.lpexAnnualInstl = element.lpexAnnualInstl != "" ? parseFloat(element.lpexAnnualInstl).toFixed(2) : '';
        });
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onload(this.pageAccess);
        }
      }

    }
    if (this.pageAccess != 'R') {
      if (this.lpexLoanFor == 's') {
        this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: 's', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' });
        this.disableButtons(true, true, true, true, true);
        this.disableFields = true;
        this.disableLoanFor = false;
      }
      if (this.lpexLoanFor != 's') {
        if (this.existingExposurelen.length != 0) {
          this.disableButtons(true, false, true, true, true);
          this.disableFields = true;
          this.disableLoanFor = false;
        }
        else {
          this.disableButtons(false, true, false, false, false);
          this.disableFields = false;
          this.disableLoanFor = false;
        }
      }
      // if (this.model.existingExposure[0].lpexRowId == null && this.model.existingExposure[0].lpexRowId == "") { 
      //   if (this.modelForChngNote.changeMode == "Y") {
      //     this.changenoteComponent.onEdit(false);
      //   }
      // }
      // else {
      //   if (this.modelForChngNote.changeMode == "Y") {
      //     this.changenoteComponent.onload(this.pageAccess);
      //   }
      // }
    }


  }

  addRow() {
    if (this.lpexLoanFor == "1")
      this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '1', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: 's', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: '', lpexAnnualInstl: '', lpexCurrOs: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexInstlPaid: ' ', lpexAvgDelayDays: ' ', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' });
    else if (this.lpexLoanFor == "2")
      this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '2', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: 's', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexTenor: ' ', lpexAnnualInstl: '', lpexCurrOs: '', lpexInstlDue: '', lpexInstlPaid: '', lpexAvgDelayDays: '', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccChurnPercent: '', lpexKccIntService: '', lpexRemarks: '' });
    else if (this.lpexLoanFor == "3")
      this.model.existingExposure.push({ lpexRowId: '', lpexSeqNum: '', lpexPropNo: '', lpexLoanFor: '3', lpexCustId: 's', lpexFacNature: 's', lpexFacType: 's', lpexFacility: '', lpexOurBank: '', lpexBankName: '', lpexBranch: '', lpexLoanAmt: '', lpexAgrmtYear: '', lpexInstlFreq: 's', lpexAnnualInstl: '', lpexLoanStatus: 's', lpexInstlDue: ' ', lpexLandMortDetails: '', lpexTakeover: 'N', lpexKccIntService: '', lpexKccChurnPercent: '', lpexRemarks: '' });

    this.disableFields = false;
    this.disableNewButton = false;
    this.disableEditButton = true;
    this.disableSaveButton = false;
    this.disableDeleteAllButton = false;
    this.disableCancelButton = false;
  }

  saveExistingExposure() {
    if (this.lpexLoanFor == "1") {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList1);
    }
    else if (this.lpexLoanFor == "2") {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList2);
    }
    else if (this.lpexLoanFor == "3") {
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.existingExposure.length, this.idvalueList3);
    }

    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }

    if (this.flag && flagCM) {

      if (flagCM) {
        if (this.modelForChngNote.changeMode == "Y" && flagCM && this.flag) {
          this.changenoteComponent.onSave();
        }
        this.cropexistingloandetailsService.saveExistingExposure(this.model.existingExposure)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.get();
              successStatus();
              this.onChangeLoanFor(this.lpexLoanFor);
              // this.ngOnInit();
            }
            error => {
              failedStatus();
              // this.alertService.error(error);
            }
          });
      }
    }
  }


  onClickDeleteButton(row: any, id: any, i: any) {
    if (this.disableEditButton) {
      if (confirm("Do you want to Delete?")) {
        if (id == '' || id == undefined) {
          this.model.existingExposure.splice(i, 1);
        }
        else {
          this.cropexistingloandetailsService.deleteExistingExposure(row)
            .subscribe(
            data => { this.data=data;
              if (this.data.success) {
                this.get();
                this.onChangeLoanFor(this.lpexLoanFor);
              }


            },
            error => {
              // this.alertService.error(error);
            });
        }
      }
    }
  }

  onClickDeleteAllButton() {
    if (confirm("Do you want to Delete?")) {
      this.cropexistingloandetailsService.deleteAllExistingExposure(this.model.existingExposure, this.lpexLoanFor)
        .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.get();
            this.onChangeLoanFor(this.lpexLoanFor);
            this.disableButtons(false, true, false, false, false);
            this.disableFields = false;
          }
          else
            alert("Error..");
        },
        error => {
          // this.alertService.error(error);
        });
    }
  }

  onClickEditButton() {

    this.disableButtons(false, true, false, false, false);
    this.disableFields = false;
    this.disableLoanFor = true;
    if (this.model.existingExposure.length > 0) {
     
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onEdit(false);
      }
    }

  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }

    }
    else {
      return false;
    }
  }

  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;


  }
  checkAcreLimit(event: any,i:number) {
    var AcreVal = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (AcreVal > 999.99) {
      this.model.existingExposure[i].lpexLandMortDetails="";
      alert("Enter Acre Limit Below 1000");
      return true;
     
    }
  }
  checkLimit(event: any,i:number) {
    var delay = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (delay > 999.99) {
      if(event.target.id=="lpexAvgDelayDays"+i)
      this.model.existingExposure[i].lpexAvgDelayDays="";
      else if(event.target.id=="lpexKccIntService"+i)
      this.model.existingExposure[i].lpexKccIntService="";
      alert("Enter Avg Limit Below 1000");
      return true;
     
    }
  }
}
