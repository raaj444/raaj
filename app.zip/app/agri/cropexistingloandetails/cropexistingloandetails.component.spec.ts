import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropexistingloandetailsComponent } from './cropexistingloandetails.component';

describe('CropexistingloandetailsComponent', () => {
  let component: CropexistingloandetailsComponent;
  let fixture: ComponentFixture<CropexistingloandetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropexistingloandetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropexistingloandetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
