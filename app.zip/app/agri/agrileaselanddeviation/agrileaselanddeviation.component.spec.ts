import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgrileaselanddeviationComponent } from './agrileaselanddeviation.component';

describe('AgrileaselanddeviationComponent', () => {
  let component: AgrileaselanddeviationComponent;
  let fixture: ComponentFixture<AgrileaselanddeviationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgrileaselanddeviationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgrileaselanddeviationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
