import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { AgrileasedeviationService } from '../../util/service/agriservices/agrileasedeviation.service';
import { SearchComponent } from '../../common/search/search.component';
declare var successStatus: any;
declare var failedStatus: any;
declare var $: any;
@Component({
  selector: 'lp-agrileaselanddeviation',
  templateUrl: './agrileaselanddeviation.component.html',
  styleUrls: ['./agrileaselanddeviation.component.css']
})
export class AgrileaselanddeviationComponent extends Validator  implements OnInit {   data:any; 



  model: any = {};
  private leaselanddeviation: Array<any> = [];
  pageAccess: any;
  fieldDisable: boolean;
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;
  hidStateCode: any = ""; hidDistrictCode: string = "";
  hidStateName: any;
  stateList: any=[];
  @ViewChild(SearchComponent)
  Searchpop: SearchComponent
  leaselandvalueList = ['lldAcrefrom', 'lldAcreto', 'lldDeviationPercent'];
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private AgrileasedeviationService: AgrileasedeviationService) {
    super();
  }

  ngOnInit() {


    this.validators();
    this.newbuttonDisable = true;
    $('#llddevia').hide();

    this.model.leaselanddeviation = [{ lldAcrefrom: '', lldAcreto: '', lldDeviationPercent: '' }];

    this.disableButton(false, true, true, true, true);
    this.AgrileasedeviationService.getLeaseLandDeviationbyState(this.model.lldStateCode)
    .subscribe(
    data => { this.data=data;

      if (this.data.success) {
        this.stateList = this.data.stateList;
      }

    },
    error => {

    });

    $("#lldStateCode").select2();
    $("#lldStateCode").on('change', (e) => {
      this.model.lldStateCode = e.target.value;
      this.getData();
    });
  }
  getData(){
    if (this.model.lldStateCode!= "" && this.model.lldStateCode != 'undefined') {
      $('#llddevia').show();

      this.AgrileasedeviationService.getLeaseLandDeviationbyState(this.model.lldStateCode)
        .subscribe(
        data => { this.data=data;

          if (this.data.success) {
            this.model.leaselanddeviation = this.data.responseData.requestList;
            this.model.leaselanddeviation.forEach(element => {
              element.lldDeviationPercent = this.toFixCall(element.lldDeviationPercent);
              element.lldAcrefrom = this.toFixCall(element.lldAcrefrom);
              element.lldAcreto = this.toFixCall(element.lldAcreto);

            });

            if (this.model.leaselanddeviation.length < 1)
            {
              this.model.leaselanddeviation = [{ lldAcrefrom: '', lldAcreto: '', lldDeviationPercent: '' }];
            }
              this.disableButton(false, true, true, true, true);
          }


        },
        error => {

        });



    }
    }
  saveLeaseLandDeviation() {


    this.flag = this.fieldvalidation.multipleFieldValidation(this.model.leaselanddeviation.length, this.leaselandvalueList);
    if (this.flag) {

      this.AgrileasedeviationService.saveLeaselandDeviation(this.model)
        .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            
            this.newbuttonDisable = true;
            this.disableButton(false, true, true, true, true);
            this.getData();
            successStatus();
          }
        },
        error => {
          failedStatus();
        });

    }
  }


  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }
  onClickEditButton() {
    this.disableButton(true, false, false, false, false);
    this.newbuttonDisable = false;

  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
         this.ngOnInit();
        }
        else
          return false;
  }





  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deletekcc: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deletekcc;
    }
  }


  addFieldValue() {

    this.model.leaselanddeviation.push({ lldAcrefrom: '', lldAcreto: '', lldDeviationPercent: '' });
  }


  callSearch(val: string) {


    var pageid = "StateandDeviation";

    $('#name').text("State Name");
    $('#code').text("State Code");
    $('#header').text("State Search");
    $('#txt_pageid').val(pageid);
    $('#txt_hidCode').val("S");
    this.Searchpop.ngOnInit();
    $('#Search').modal('show');

  }

  modalClosed() {


    let stateName = $('#txt-Searchname').val();
    let stateCode = $('#txt_Searchcode').val();
    if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
      if (stateName != "" && stateCode != "") {
        this.model.lldStateCode = stateCode;

        $('#txt-Searchname').val(stateName);
        this.hidStateCode = stateCode;
        this.hidStateName = stateName;
        $('#llddevia').show();

        this.AgrileasedeviationService.getLeaseLandDeviationbyState(this.hidStateCode)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.model.leaselanddeviation = this.data.responseData.requestList;
              this.model.leaselanddeviation.forEach(element => {
                element.lldDeviationPercent = this.toFixCall(element.lldDeviationPercent);
              });
              if (this.model.leaselanddeviation.length < 1)
                this.model.leaselanddeviation = [{ lldAcrefrom: '', lldAcreto: '', lldDeviationPercent: '' }];
            }

          },
          error => {

          });
      }

    }
    else {
      this.model.lldStateCode = this.hidStateCode;
      $('#txt-Searchname').val(this.hidStateName);
    }
    // if ($('#txt-Searchname').val() == "" && $('#txt_Searchcode').val() == "") {
    //   $('#llddevia').hide();
    // }
  }

  deleteleaselandDeviation(row: any, id: any, i: any) {


    if (id == '' || id == undefined) {
      this.model.leaselanddeviation.splice(i, 1);

    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.AgrileasedeviationService.deleteLeaseLandDeviationdetails(row)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {

          });
      }
    }
  }

  deleteAllLeaseDeviation() {

    this.AgrileasedeviationService.deleteAllLandDeviationdetails(this.model)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {

      });

  }


  rangefrom(id: number) {
    
    var tempid = id - 1;
    if (id != 0) {

      if ($('#lldAcreto' + (id - 1)).val() != "" && $('#lldAcrefrom' + id).val() != "" && $('#lldAcreto' + (id - 1)).val() != undefined && $('#lldAcrefrom' + id).val() != undefined) {
        if (parseFloat($('#lldAcreto' + (id - 1)).val()) >= parseFloat($('#lldAcrefrom' + id).val())) {

          alert("Current  Acre From Range  should  be Greater than Previous  Acre To Range");
          $('#lldAcrefrom' + id).val('');
        }
        else if (parseFloat($('#lldAcreto' + (id)).val()) >= parseFloat($('#lldAcrefrom' + (id + 1)).val())) {

          alert("Current Acre To Range should  be Lesser than Next  Acre From Range");
          $('#lldAcreto' + id).val('');
        }
      }

    }
  }

  rangeto(i: number, e: any) {
    var id = i;
    
    if ($('#' + e.target.id).val() != "" && $('#' + e.target.id).val() != undefined) {
      if ($('#lldAcreto' + id).val() != undefined && $('#lldAcreto' + id).val() != "" && $('#lldAcrefrom' + id).val() != undefined && $('#lldAcrefrom' + id).val() != "") {

        if (parseFloat($('#lldAcrefrom' + id).val()) >= parseFloat($('#lldAcreto' + id).val())) {
          alert(" Acre To Range should  be greater than  Acre From Range");
          $('#lldAcreto' + id).val('');
        }
        else {
          this.rangefrom(id);
        }

      }

      else if (($('#lldAcrefrom' + id).val() != undefined && $('#lldAcrefrom' + id).val() != "") || ($('#lldAcreto' + id).val() != undefined && $('#lldAcreto' + id).val() != "")) {
        this.rangefrom(id);
      }



    }
  }

  percentageCheck(i: number, e: any) {
    var id = i;
    
    if ($('#' + e.target.id).val() != "" && $('#' + e.target.id).val() != undefined) {
      if (!(parseFloat($('#' + e.target.id).val()) <= 100)) {
        alert("Ratio should not exceed 100")
        $('#' + e.target.id).val('');
        this.model.leaselanddeviation[id].lldDeviationPercent = '';
        $('#' + e.target.id).blur();
        return false;
      }

    }
  }

}
