import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KkrpremiumComponent } from './kkrpremium.component';

describe('KkrpremiumComponent', () => {
  let component: KkrpremiumComponent;
  let fixture: ComponentFixture<KkrpremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KkrpremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KkrpremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
