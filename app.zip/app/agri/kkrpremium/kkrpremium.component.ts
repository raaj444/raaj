import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { debuglog } from 'util';
import { Validator } from '../../util/helper/validator';
import { KkrpremiumService } from "../../util/service/agriservices/kkrpremium.service";
import { ChangenoteComponent } from "../../common/changenote/changenote.component";
import { ChangenoteService } from "../../util/service/commonservices/changenote.service";
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-kkrpremium',
  templateUrl: './kkrpremium.component.html',
  styleUrls: ['./kkrpremium.component.css']
})
export class KkrpremiumComponent extends Validator implements OnInit {
  data: any;
  fieldDisableDob: boolean;
  deleteAllbuttonDisable: boolean;
  flag: boolean;
  model: any = {};
  newbuttonDisable: boolean;
  fieldDisabledef: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  idvalueList: any = ['lkpDob', 'lkpPremAmount', 'lkpKkrPremType', 'lkpRelOfNominee', 'lkpNomineeName', 'lkpRelWithBorrower', 'lkpNomineeGender', 'lkpNomineeDob'];
  NomineeList: any = [];
  BorrowerList: any = [];
  BorrowerTypeList: any = [];
  premiumTypeList: any = [];
  RelwithBorrowerList: any = [];
  RelwithBorrowerList1: any = [];
  pageAccess: any;
  modelForChngNote: any;
  partiesCRNList: any = []; gender: any = []; employmenttype: any = [];
  maxDate: Date; minDate: Date;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private kkrpremiumService: KkrpremiumService, private router: Router,
    private fieldvalidation: Fieldvalidation, private changenoteService: ChangenoteService) {
    super();
    this.maxDate = new Date();
    this.minDate = new Date(1900, 12, 1);
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });

    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();
    this.fieldDisabledef = true;
    this.fieldDisableDob = false;
    this.NomineeList = [];
    this.gender = [];
    this.employmenttype = [];
    this.disableButton(true, true, false, true, true)
    this.model = { 'lkpInsuredPerson': "", 'lkpNomineeName': "", 'lkpKkrPremType': "", 'lkpRelOfNominee': "", 'lkpFacAvail': "Y", 'lkpRelWithBorrower': "", lkpNomineeDob: "", lkpNomineeGender: "", lkpGender: "", lkpEmailId: "", lkpOccupation: "", lkpRemarks: "" }

    this.kkrpremiumService.getBorrowerList()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.BorrowerList = this.data.lpcomCustInfoApplist;
         // this.BorrowerTypeList = this.data.lpcomSetBorrMapList;
          this.RelwithBorrowerList = this.data.RelationwithBorrower;
          this.RelwithBorrowerList1 = this.data.RelationwithBorrowerkkr;
          this.premiumTypeList = this.data.kkrpremiumType;
          this.gender = this.data.gender;
          this.employmenttype = this.data.employmenttype;
          this.pageAccess = this.data.pageAccess;
          if (this.data.responseData != null) {
            this.model = this.data.responseData;
            if (this.model.lkpDob != '' && this.model.lkpDob!=null && this.model.lkpDob!=undefined) {
              let dob = this.model.lkpDob.split("-");
              this.model.lkpDob = dob[2] + "/" + dob[1] + "/" + dob[0];
            }
            if (this.model.lkpNomineeDob != "" &&  this.model.lkpNomineeDob!=null  && this.model.lkpNomineeDob!=undefined) {
              let dob = this.model.lkpNomineeDob.split("-");
              this.model.lkpNomineeDob = dob[2] + "/" + dob[1] + "/" + dob[0];
            }
            if (this.model.lkpPremAmount != null && this.model.lkpPremAmount != undefined && this.model.lkpPremAmount != " ") {
              this.model.lkpPremAmount = this.model.lkpPremAmount.toFixed(2);
            }

            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onload(this.pageAccess);
            }
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(true);
            }
            this.disableButton(true, true, false, true, true);
          }
          else {
            this.disableButton(false, false, true, false, true);
            if (this.modelForChngNote.changeMode == "Y") {
              this.changenoteComponent.onEdit(false);
            }
          }

          if (this.pageAccess == "R")
            this.disableButton(true, true, true, true, true);
          if (this.model.lkpFacAvail != null && this.model.lkpFacAvail != undefined && this.model.lkpFacAvail != "") {
            if (this.model.lkpFacAvail == 'Y') {
              this.idvalueList = [ 'lkpPremAmount', 'lkpKkrPremType', 'lkpNomineeName', 'lkpRelWithBorrower', 'lkpNomineeDob', 'lkpNomineeGender'];
            }
            else
              this.idvalueList = [];
          }
        }
      },

      error => {
      });

  }

  saveKkrpremium() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.model.lkpFacAvail == "") {
        this.idvalueList = ['lkpFacAvail'];
      }
      this.flag = this.fieldvalidation.validateField(this.idvalueList);



      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.flag == true) {
        this.changenoteComponent.onSave();
      }
      this.model.lkpNomineeDob = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lkpNomineeDob);
      this.model.lkpDob=this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lkpDob);
      if (this.flag) {

        this.kkrpremiumService.saveKkrpremium(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              this.ngOnInit();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              successStatus();

            }
          },
          error => {
            failedStatus();
          });

      }
    }
  }
  cancelButton() {

    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }

  editkkrpremium() {
    this.disableButton(false, false, true, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean, deleteAllbuttonDisable: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.savebuttonDisable = true;
      this.editbuttonDisable = true;
      this.cancelbuttonDisable = true;
      this.deleteAllbuttonDisable = true;
    }
    else {
      this.fieldDisable = fieldDisable;
      this.savebuttonDisable = savebuttonDisable;
      this.editbuttonDisable = editbuttonDisable;
      this.cancelbuttonDisable = cancelbuttonDisable;
      this.deleteAllbuttonDisable = deleteAllbuttonDisable;

    }
  }

  dodeleteAll() {

    this.kkrpremiumService.deleteAllKkrpremium(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success)
          this.ngOnInit();
      },
      error => {
      });
  }

  validateDate(val) {
    if (val != '' && val != null) {
      let date = val.split("/");
      return date[2] + "-" + date[1] + "-" + date[0];
    }
  }
  validatedate(eventId) {
    this.fieldvalidation.validatedate(eventId);
  }
  validatefuturedate(eventId) {
    this.fieldvalidation.validatefuturedate(eventId);
  }
  checkMandatory(val) {
    if (val == 'Y') {

      this.idvalueList = [ 'lkpPremAmount', 'lkpKkrPremType',  'lkpNomineeName', 'lkpRelWithBorrower', 'lkpNomineeGender', 'lkpNomineeDob'];
    }
    else {
      this.idvalueList.forEach(fieldId => {
        $('#' + fieldId).removeClass("has-error");
        $('#' + fieldId).attr('placeholder', ' ');
      });
      this.idvalueList = [];
      this.model.lkpNomineeName = ""; this.model.lkpKkrPremType = "";  this.model.lkpRelWithBorrower = "";
      this.model.lkpPremAmount = "";  this.model.lkpNomineeGender = "", this.model.lkpNomineeDob = "";

    }
  }

  // changeCustDob(event) {
  //   if (event.target.value != "") {
  //     this.model.lkpDob = this.BorrowerList.find(borrower => borrower.custId == event.target.value).custDob;
  //     this.model.lkpEmailId = this.BorrowerList.find(borrower => borrower.custId == event.target.value).custEmail;
  //     this.model.lkpGender = this.BorrowerList.find(borrower => borrower.custId == event.target.value).custGender;
  //     // this.model.lkpOccupation=this.BorrowerList.find(borrower => borrower.custId == event.target.value).custOccup;

  //   }
  //   else {
  //     this.model.lkpDob = '';
  //     this.model.lkpEmailId = "";
  //     this.model.lkpGender = "";
  //     //this.model.lkpOccupation="";
  //   }
  // }
  NomineeDob: boolean=true;
  InsuredDob:boolean=true;
  rmvErrClass(id: string, value) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    } 
    if (id == "lkpNomineeDob" && value != undefined && value != "") {
      this.NomineeDob = this.fieldvalidation.isValidDOBFrmDP(id, value);
    }
    if (id == "lkpDob" && value != undefined && value != "") {
      this.InsuredDob = this.fieldvalidation.isValidDOBFrmDP(id, value);
    }
  }

  onInputChanged(event) {
 
    if (!this.NomineeDob) {
      this.model.lkpNomineeDob = "";
      $("#lkpNomineeDob").val(" ");
    }

  
    if (!this.InsuredDob) {
      this.model.lkpDob = "";
      $("#lkpDob").val(" ");
    }


  }

  checkManualEntry(event: any) {

    let blFlag = this.fieldvalidation.validatedate(event.target.id);
    if (blFlag) {
      this.futRestrict(event);
      this.fieldvalidation.isValidDOB(event.target.id);
    }

  }
  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.futureDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).attr("placeholder", "Future date not allowed here");
      }
    }
  }
}



