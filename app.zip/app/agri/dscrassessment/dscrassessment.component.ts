import { Component, OnInit, ViewChild } from '@angular/core';
import { DscrService } from "../../util/service/agriservices/dscr.service";
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
@Component({
  selector: 'lp-dscrassessment',
  templateUrl: './dscrassessment.component.html',
  styleUrls: ['./dscrassessment.component.css']
})
export class DscrassessmentComponent extends Validator implements OnInit {
  data: any;
  model: any = {};
  incomeAgriList: any = [];
  yeildMasterList: any = [];
  incomeOtherList: any = [];
  expenseAgriList: any = [];
  familyExpenseList: any = [];
  loanLiabilityList: any = [];
  currentcorpPatternList: any = [];
  listOfValuesList: any = [];
  cropYieldMasterList: any = [];
  cropIncomeList: any = [];
  facilityList: any = [];
  repayfreqList: any = [];
  totIncomeConsi: any = 0.00;
  disableEditButton: boolean = false;
  disableSaveButton: boolean = true;
  disableCancelButton: boolean = true;
  disableFields: boolean = true;
  disableLLFields: boolean = true;
  totIncome: any = 0.00;
  totOtherIncome: any = 0.00;
  totExpense: any = 0.00;
  totFamilyExpense: any = 0.00;
  totLoanLiability: any = 0.00;
  finTotExpense: any = 0.00;
  netTotSurpulus: any = 0.00;
  dscrRatio: any = 0.00;
  totincomeAgri: any = 0.00;
  totofferedKccAmt: any;
  loanLListLength: any;
  getDataLoanLength: any;
  idvalueList1 = ['value1_'];
  idvalueList2 = ['header2_', 'comments2_', 'value2_'];
  idvalueList3 = ['header3_', 'comments3_', 'value3_'];
  // 'feInpval1_', 'feInpval2_',
  idvalueList4 = ['header4_', 'comments4_', 'value4_'];
  idvalueList5 = ['header5_', 'comments5_', 'ldLlInpval5_', 'value5_'];
  pageAccess: any;
  modelForChngNote: any;
  loanComments: string = "Principle Repayment + Interest";
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private dscrService: DscrService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) { super(); }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.cropIncomeList = [];
    this.model.exposures = [];
    this.disableEditButton = false;
    this.disableSaveButton = true;
    this.disableCancelButton = true;
    this.disableFields = true;
    this.disableLLFields = true;
    this.totIncomeConsi = 0.00;
    this.totIncome = 0.00;
    this.totOtherIncome = 0.00;
    this.totExpense = 0.00;
    this.totFamilyExpense = 0.00;
    this.totLoanLiability = 0.00;
    this.finTotExpense = 0.00;
    this.netTotSurpulus = 0.00;
    this.dscrRatio = 0.00;
    this.dscrService.getAllDscrData().subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          this.incomeAgriList = this.data.responseData.incomeAgriExpenseList;
          this.incomeOtherList = this.data.responseData.incomeOtherExpenseList;
          this.expenseAgriList = this.data.responseData.expenseAgriList;
          this.familyExpenseList = this.data.responseData.familyExpenseList;
          this.loanLiabilityList = this.data.responseData.loanLiabilityList;
          this.getDataLoanLength = this.loanLiabilityList.length;
          this.currentcorpPatternList = this.data.responseData.lpagriCurrCropPatternList;
          this.yeildMasterList = this.data.responseData.lpagriYieldMasterList;
          this.listOfValuesList = this.data.responseData.lpmasListofvalueList;
          this.facilityList = this.data.responseData.facilityList;
          this.repayfreqList = this.data.responseData.repayfreqList;
          this.totofferedKccAmt = this.data.responseData.totOfferedKccAmt;
          this.totIncomeConsi = 0.00;
          this.dscrService.getExistingExposure(this.model)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.pageAccess = this.data.pageAccess;
                if (this.pageAccess == 'R') {
                  this.disableEditButton = true;
                  this.disableSaveButton = true;
                  this.disableCancelButton = true;
                  this.disableFields = true;
                  this.disableLLFields = true;
                }
                this.model.exposures = [];
                this.model.exposures = this.data.responseData.exposures;
              }
            });
          for (let i = 0; i < this.currentcorpPatternList.length; i++) {
            var flag = false;
            for (let j = 0; j < this.yeildMasterList.length; j++) {
              if (this.currentcorpPatternList[i].lpcpStateId == this.yeildMasterList[j].lymStatecode && this.currentcorpPatternList[i].lpcpCropId == this.yeildMasterList[j].lymCropcode) {
                this.cropYieldMasterList.push({ 'acres': this.yeildMasterList[j].lymPeracres, 'price': this.yeildMasterList[j].lymRateQt });
                flag = true;
              }
            }
            if (!flag) {
              this.cropYieldMasterList.push({ 'acres': '0', 'price': '0' });
            }
          }

          for (let i = 0; i < this.currentcorpPatternList.length; i++) {
            for (let j = 0; j < this.listOfValuesList.length; j++)
              if (this.currentcorpPatternList[i].lpcpCropId == this.listOfValuesList[j].llvOptionVal)
                this.cropIncomeList.push({ 'cropName': this.listOfValuesList[j].llvOptionDesc, 'totalAcres': this.currentcorpPatternList[i].lpcpAreaCultivated, 'yieldPerAcre': this.cropYieldMasterList[i].acres, 'pricePerAcre': this.cropYieldMasterList[i].price, 'expectedIncome': (this.parseEmptytoFloat(this.currentcorpPatternList[i].lpcpAreaCultivated) * this.parseEmptytoFloat(this.cropYieldMasterList[i].acres) * this.parseEmptytoFloat(this.cropYieldMasterList[i].price)).toFixed(2) })
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);

          }
          var time = setInterval(() => {

            this.totIncomeConsi = 0.00;
            this.totIncome = 0.00;
            this.totOtherIncome = 0.00;
            this.totExpense = 0.00;
            this.totFamilyExpense = 0.00;
            this.totLoanLiability = 0.00;
            this.finTotExpense = 0.00;
            this.netTotSurpulus = 0.00;
            this.dscrRatio = 0.00;
            var total = 0.00;
            this.cropIncomeList.forEach(currentCrop => {
              total += this.parseEmptytoFloat(currentCrop.expectedIncome);
              this.totIncomeConsi = total.toFixed(2);

            });
            if (this.incomeAgriList.length == 0) {
              let modelincomeAgri = {
                ldComments: "As per above calculations", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IAE",
                ldHeader: "Income from Agri land", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: this.totIncomeConsi, lpcomProposal: ""
              }
              this.totincomeAgri = this.totIncomeConsi;
              this.incomeAgriList.push(modelincomeAgri);
            }
            else {
              this.totincomeAgri = 0.00;
              var total = 0.00;
              this.incomeAgriList.forEach((inc, index) => {
                if (index == 0) {
                  inc.ldValue = this.totIncomeConsi;
                }
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totincomeAgri = total.toFixed(2);
              });
            }

            if (this.incomeOtherList.length == 0) {
              let modelincomeOther = {
                ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IOE",
                ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", lpcomProposal: ""
              }
              this.incomeOtherList.push(modelincomeOther);
            } else {
              this.totOtherIncome = 0.00;
              var total = 0.00;
              this.incomeOtherList.forEach((inc, index) => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totOtherIncome = total.toFixed(2);
              });
            }
            if (this.expenseAgriList.length == 0) {
              let modelexpenseAgri = {
                ldComments: "Cost of cultivation of Crops to be funded", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "AE",
                ldHeader: "Agri Expenses", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: this.totofferedKccAmt, lpcomProposal: ""
              }
              this.expenseAgriList.push(modelexpenseAgri);
              this.totExpense = 0.00;
              var total = 0.00;
              this.expenseAgriList.forEach(inc => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totExpense = total.toFixed(2);
              });
              if (this.totofferedKccAmt == '0')
                alert("Kindly please Freeze the KCC Assessment to auto populate Expense value.");
            } else {
              this.totExpense = 0.00;
              var total = 0.00;
              this.expenseAgriList.forEach((inc, index) => {
                if (index == 0) {
                  inc.ldValue = this.totofferedKccAmt;
                }
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totExpense = total.toFixed(2);
              });
            }
            if (this.familyExpenseList.length == 0) {
              let modelfamilyExpense = {
                ldComments: "No of Dependents -", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "FE", ldFeInpval1: "", ldFeComments: "Per Person Per Month Expenses Rs.",
                ldHeader: "Other Expenses", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", lpcomProposal: ""
              }
              this.familyExpenseList.push(modelfamilyExpense);
              this.totFamilyExpense = 0.00;
              var total = 0.00;
              this.familyExpenseList.forEach(inc => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totFamilyExpense = total.toFixed(2);
              });
            } else {
              this.totFamilyExpense = 0.00;
              var total = 0.00;
              this.familyExpenseList.forEach(inc => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totFamilyExpense = total.toFixed(2);
              });
            }
            if (this.loanLiabilityList.length == 0) {
              let modelloanLiability = {
                ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "LL",
                ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: "", ldLlInpval: "", lpcomProposal: "",
              }
              //this.loanLiabilityList.push(modelloanLiability);
              var busApp = false;
              this.calculateLoanLiabilityList();
              this.totLoanLiability = 0.00;
              var total = 0.00;
              this.loanLiabilityList.forEach(inc => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totLoanLiability = total.toFixed(2);
                if (inc.ldLlInpval == '0') {
                  busApp = true;
                }
              });
              if (busApp)
                alert("Kindly please fill the Business Approval to auto populate the Loan Liability values.");
            } else {
              this.totLoanLiability = 0.00;
              var total = 0.00;
              this.loanLListLength = this.facilityList.length - 1;
              this.calculateLoanLiabilityList();
              this.loanLiabilityList.forEach(inc => {
                total += this.parseEmptytoFloat(inc.ldValue);
                this.totLoanLiability = total.toFixed(2);

              });
            }
            this.totIncome = this.parseEmptytoFloat(this.totincomeAgri) + this.parseEmptytoFloat(this.totOtherIncome);
            this.totIncome = this.parseEmptytoFloat(this.totIncome).toFixed(2);
            var tot = this.parseEmptytoFloat(this.totExpense) + this.parseEmptytoFloat(this.totFamilyExpense) + this.parseEmptytoFloat(this.totLoanLiability);
            this.finTotExpense = tot.toFixed(2);
            this.netTotSurpulus = (this.totIncome - this.finTotExpense).toFixed(2);
            // calculation for dscr 
            var totincome = ((this.parseEmptytoFloat(this.totincomeAgri) / 100000) + (this.parseEmptytoFloat(this.totOtherIncome) / 100000));
            var totexpensess = ((this.parseEmptytoFloat(this.totExpense) / 100000) + (this.parseEmptytoFloat(this.totFamilyExpense) / 100000) + (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
            var netsurpulus = (totincome - totexpensess);
            var netIncome = (totincome - (this.parseEmptytoFloat(this.totExpense) / 100000) - (this.parseEmptytoFloat(this.totFamilyExpense) / 100000));
            var dscrratio = (netIncome / (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
            dscrratio = this.parseEmptytoFloat(dscrratio);
            if (dscrratio < 0 || dscrratio == Infinity) {
              dscrratio = 0.00;
            }
            this.dscrRatio = dscrratio.toFixed(2);

            clearInterval(time);
          }, 600);
        }
      },
      error => {
      });

  }

  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

  addNewRow(entryType: any) {
    if (entryType == 'IOE') {
      let modelincomeOther = {
        ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IOE",
        ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: this.incomeOtherList.length + 1, ldValue: "", lpcomProposal: ""
      }
      this.incomeOtherList.push(modelincomeOther);
    } else if (entryType == 'AE') {
      let modelexpenseAgri = {
        ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "AE",
        ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: this.expenseAgriList.length + 1, ldValue: "", lpcomProposal: ""
      }
      this.expenseAgriList.push(modelexpenseAgri);
    } else if (entryType == 'FE') {
      let modelfamilyExpense = {
        ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "FE",
        ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: this.familyExpenseList.length + 1, ldValue: "", lpcomProposal: ""
      }
      this.familyExpenseList.push(modelfamilyExpense);
    } else if (entryType == 'LL') {
      let modelloanLiability = {
        ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "LL",
        ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: this.loanLiabilityList.length + 1, ldValue: "", lpcomProposal: ""
      }
      this.loanLiabilityList.push(modelloanLiability);
      this.disableFields = false;
    }
    else if (entryType == 'IAE') {
      let modelincomeAgri = {
        ldComments: "", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "IAE",
        ldHeader: "", ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: this.incomeAgriList.length + 1, ldValue: "", lpcomProposal: ""
      }
      this.incomeAgriList.push(modelincomeAgri);
    }

  }

  onClickEditButton() {
    this.disableFields = false;
    this.disableEditButton = true;
    this.disableSaveButton = false;
    this.disableCancelButton = false;
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  saveDscrAssessment() {

    let flag1 = true, flag2 = true, flag3 = true, flag4 = true, flag5 = true;
    flag1 = this.fieldvalidation.multipleFieldValidation(this.incomeAgriList.length, this.idvalueList1);
    flag3 = this.fieldvalidation.multipleFieldValidation(this.expenseAgriList.length, this.idvalueList3);
    flag5 = this.fieldvalidation.multipleFieldValidation(this.loanLiabilityList.length, this.idvalueList5);
    if (this.incomeOtherList.length == 1) {
      if (this.incomeOtherList[0].ldHeader != null && this.incomeOtherList[0].ldHeader != "" && this.incomeOtherList[0].ldHeader != undefined) {
        if (this.incomeOtherList[0].ldValue != "" && this.incomeOtherList[0].ldValue != null && this.incomeOtherList[0].ldValue != undefined) {
          flag2 = true;
        }
        else {
          flag2 = this.fieldvalidation.multipleFieldValidation(this.incomeOtherList.length, this.idvalueList2);
        }
      }
    }
    else if (this.incomeOtherList.length > 1) {
      flag2 = this.fieldvalidation.multipleFieldValidation(this.incomeOtherList.length, this.idvalueList2);

    }
    if (this.familyExpenseList.length == 1) {
      if (this.familyExpenseList[0].ldHeader != null && this.familyExpenseList[0].ldHeader != "" && this.familyExpenseList[0].ldHeader != undefined) {
        if (this.familyExpenseList[0].ldValue != "" && this.familyExpenseList[0].ldValue != null && this.familyExpenseList[0].ldValue != undefined) {
          flag4 = true;
        }
      }
    }
    else if (this.familyExpenseList.length > 1) {
      flag4 = this.fieldvalidation.multipleFieldValidation(this.familyExpenseList.length, this.idvalueList4);
    }

    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && flag1 && flag2 && flag3 && flag4 && flag5) {
        this.changenoteComponent.onSave();
      }
      if (flag1 && flag2 && flag3 && flag4 && flag5) {
        this.dscrService.saveDscrData(this.incomeAgriList, this.incomeOtherList, this.expenseAgriList, this.familyExpenseList, this.loanLiabilityList)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
              successStatus();
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
            else
              alert("Error..");
          },
          error => {
            failedStatus();
            // this.alertService.error(error);
          });
      }
    }
  }
  onClickCancelButton() {
    if (confirm("Do you want to cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  onClickDeleteButton(item: any, entryType: any, id: any, index: any) {

    if (id == '' || id == undefined || id == '0') {
      if (entryType == 'IOE') {
        if (this.incomeOtherList.length != 1) {
          this.incomeOtherList.splice(index, 1);
          this.totOtherIncome = 0.00;
          var total = 0.00;
          this.incomeOtherList.forEach(inc => {
            total += this.parseEmptytoFloat(inc.ldValue);
            this.totOtherIncome = this.parseEmptytoFloat(total).toFixed(2);
          });
        } else {
          alert("Atleast one entry is mandatory");
          return;
        }
      } else if (entryType == 'AE') {
        if (this.expenseAgriList.length != 1) {
          this.expenseAgriList.splice(index, 1);
          this.totExpense = 0.00;
          var total = 0.00;
          this.expenseAgriList.forEach(inc => {
            total += this.parseEmptytoFloat(inc.ldValue);
            this.totExpense = this.parseEmptytoFloat(total).toFixed(2);
          });

        } else {
          alert("Atleast one entry is mandatory");
          return;
        }
      } else if (entryType == 'FE') {
        if (this.familyExpenseList.length != 1) {
          this.totFamilyExpense = 0.00;
          var total = 0.00;
          this.familyExpenseList.splice(index, 1);
          this.familyExpenseList.forEach(inc => {
            total += this.parseEmptytoFloat(inc.ldValue);
            this.totFamilyExpense = this.parseEmptytoFloat(total).toFixed(2);
          });
        } else {
          alert("Atleast one entry is mandatory");
          return;
        }

      } else if (entryType == 'LL') {
        if (this.loanLiabilityList.length != 1) {
          var total = 0.00;
          this.loanLiabilityList.splice(index, 1);
          this.totLoanLiability = 0.00;
          this.loanLiabilityList.forEach(inc => {
            total += this.parseEmptytoFloat(inc.ldValue);
            this.totLoanLiability = this.parseEmptytoFloat(total).toFixed(2);
          });
        } else {
          alert("Atleast one entry is mandatory");
          return;
        }

      }
      else if (entryType == 'IAE') {
        if (this.incomeAgriList.length != 1) {
          var total = 0.00;
          this.incomeAgriList.splice(index, 1);
          this.totincomeAgri = 0.00;
          this.incomeAgriList.forEach(inc => {
            total += this.parseEmptytoFloat(inc.ldValue);
            this.incomeAgriList = this.parseEmptytoFloat(total).toFixed(2);
          });
        } else {
          alert("Atleast one entry is mandatory");
          return;
        }

      }

      this.totIncome = this.parseEmptytoFloat(this.totincomeAgri) + this.parseEmptytoFloat(this.totOtherIncome);
      this.totIncome = this.parseEmptytoFloat(this.totIncome).toFixed(2);
      var finalTotal = this.parseEmptytoFloat(this.totOtherIncome) + this.parseEmptytoFloat(this.totFamilyExpense) + this.parseEmptytoFloat(this.totLoanLiability);
      this.finTotExpense = finalTotal.toFixed(2);
      this.netTotSurpulus = (this.totIncome - this.finTotExpense).toFixed(2);
      // calculation for dscr 
      var totincome = ((this.parseEmptytoFloat(this.totincomeAgri) / 100000) + (this.parseEmptytoFloat(this.totOtherIncome) / 100000));
      var totexpensess = ((this.parseEmptytoFloat(this.totExpense) / 100000) + (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
      var netsurpulus = (totincome - totexpensess);
      var netIncome = (totincome - (this.parseEmptytoFloat(this.totExpense) / 100000) - (this.parseEmptytoFloat(this.totFamilyExpense) / 100000));
      var dscrratio = (netIncome / (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
      dscrratio = this.parseEmptytoFloat(dscrratio);
      if (dscrratio < 0 || dscrratio == Infinity) {
        dscrratio = 0.00;
      }
      this.dscrRatio = dscrratio.toFixed(2);

    } else {
      let flag = false;
      if (entryType == 'IOE') {
        if (this.incomeOtherList.length != 1) {
          flag = true;
        } else {
          flag = false;
          alert("Atleast one entry is mandatory");
          return;
        }
      } else if (entryType == 'AE') {
        if (this.expenseAgriList.length != 1) {
          flag = true;
        } else {
          flag = false;
          alert("Atleast one entry is mandatory");
          return;
        }
      } else if (entryType == 'FE') {
        if (this.familyExpenseList.length != 1) {
          flag = true;
        } else {
          flag = false;
          alert("Atleast one entry is mandatory");
          return;
        }
      } else if (entryType == 'LL') {
        if (this.loanLiabilityList.length != 1) {
          flag = true;
        } else {
          flag = false;
          alert("Atleast one entry is mandatory");
          return;
        }
      }
      else if (entryType == 'IAE') {
        if (this.incomeAgriList.length != 1) {
          flag = true;
        } else {
          flag = false;
          alert("Atleast one entry is mandatory");
          return;
        }
      }
      if (flag) {
        this.dscrService.deleteDscrData(item)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
            }
            else
              alert("Error..");
          },
          error => {
            // this.alertService.error(error);
          });
      }

    }

  }
  calcluateTotal(index: any, entryType: any) {

    if (entryType == 'IOE') {
      this.totOtherIncome = 0.00;
      var total = 0.00;
      this.incomeOtherList.forEach(inc => {
        total += this.parseEmptytoFloat(inc.ldValue);
        this.totOtherIncome = this.parseEmptytoFloat(total).toFixed(2);
      });
    } else if (entryType == 'AE') {
      this.totExpense = 0.00;
      var total = 0.00;
      this.expenseAgriList.forEach(inc => {
        total += this.parseEmptytoFloat(inc.ldValue);
        this.totExpense = this.parseEmptytoFloat(total).toFixed(2);
      });
    } else if (entryType == 'FE') {
      this.totFamilyExpense = 0.00;
      var total = 0.00;
      this.familyExpenseList.forEach(inc => {
        total += this.parseEmptytoFloat(inc.ldValue);
        this.totFamilyExpense = this.parseEmptytoFloat(total).toFixed(2);
      });
    } else if (entryType == 'LL') {
      this.totLoanLiability = 0.00;
      var total = 0.00;
      this.loanLiabilityList.forEach(inc => {
        total += this.parseEmptytoFloat(inc.ldValue);
        this.totLoanLiability = this.parseEmptytoFloat(total).toFixed(2);
      });
    }
    else if (entryType == 'IAE') {
      this.totincomeAgri = 0.00;
      var total = 0.00;
      this.incomeAgriList.forEach(inc => {
        total += this.parseEmptytoFloat(inc.ldValue);
        this.totincomeAgri = this.parseEmptytoFloat(total).toFixed(2);
      });
    }
    // this.totOtherIncome=this.parseEmptytoFloat(this.totOtherIncome) + this.parseEmptytoFloat(this.totincomeAgri);
    this.totIncome = this.parseEmptytoFloat(this.totincomeAgri) + this.parseEmptytoFloat(this.totOtherIncome);
    this.totIncome = this.parseEmptytoFloat(this.totIncome).toFixed(2);
    var finalTotal = this.parseEmptytoFloat(this.totExpense) + this.parseEmptytoFloat(this.totFamilyExpense) + this.parseEmptytoFloat(this.totLoanLiability);
    this.finTotExpense = finalTotal.toFixed(2);
    this.netTotSurpulus = (this.totIncome - this.finTotExpense).toFixed(2);
    // calculation for dscr 
    var totincome = ((this.parseEmptytoFloat(this.totincomeAgri) / 100000) + (this.parseEmptytoFloat(this.totOtherIncome) / 100000));
    var totexpensess = ((this.parseEmptytoFloat(this.totExpense) / 100000) + (this.parseEmptytoFloat(this.totFamilyExpense) / 100000) + (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
    var netsurpulus = (totincome - totexpensess);
    var netIncome = (totincome - (this.parseEmptytoFloat(this.totExpense) / 100000) - (this.parseEmptytoFloat(this.totFamilyExpense) / 100000));
    var dscrratio = (netIncome / (this.parseEmptytoFloat(this.totLoanLiability) / 100000));
    dscrratio = this.parseEmptytoFloat(dscrratio);
    if (dscrratio < 0 || dscrratio == Infinity) {
      dscrratio = 0.00;
    }

    this.dscrRatio = dscrratio.toFixed(2);
  }

  calculateFExp() {

    this.familyExpenseList.forEach((inc, index) => {
      if (index == 0 && (inc.ldFeInpval1 != "" && inc.ldFeInpval2 != "")) {
        var totfamExp = this.parseEmptytoFloat(inc.ldFeInpval1) * this.parseEmptytoFloat(inc.ldFeInpval2) * 12;
        inc.ldValue = totfamExp.toFixed(2);
      }
      if (index == 0 && (inc.ldFeInpval1 == "" || inc.ldFeInpval2 == "")) {
        inc.ldValue = "";
      }

      this.totFamilyExpense = 0.00;
      var total = 0.00;
      total += this.parseEmptytoFloat(inc.ldValue);
      this.totFamilyExpense = total.toFixed(2);
    });

  }

  calculateLoanLiabilityList() {
    this.facilityList.forEach(fcList => {
      //Annual Installment Calculation 
      if (fcList.prdDesc == "KCC") {
       var tempInstAmt = fcList.proposalLimit * (fcList.intrate)/100;
        // var monthlyInterestRatio = (fcList.intrate / 100) / 12;
        // var top = Math.pow((1 + monthlyInterestRatio), fcList.tenor);
        // var bottom = top - 1;
        // var emi = ((fcList.proposalLimit * monthlyInterestRatio * top) / bottom);
        // var repay = emi;
        // var a = (repay * fcList.tenor);
        // var b = (a - fcList.proposalLimit);
        // var tempInstAmt = (b / (fcList.tenor / 12));
        if (tempInstAmt < 0 || tempInstAmt == Infinity) {
          tempInstAmt = 0.00;
        } 
        var InstallmentAmt = tempInstAmt.toFixed(2);
      }
      else {
        var applicableInt = (fcList.tenor / 12);
        var emi =(fcList.proposalLimit)/applicableInt;
        var tempInstAmt = emi +(fcList.proposalLimit * (fcList.intrate)/100);
          if (tempInstAmt < 0 || tempInstAmt == Infinity) {
          tempInstAmt = 0.00;
        }
        var InstallmentAmt = tempInstAmt.toFixed(2);
      }
      // // Default
      // else if (fcList.prdDesc != "KCC" && fcList.repayFreq == "0") {
      //   var tempInstAmt = 0.00;
      //   var InstallmentAmt = tempInstAmt.toFixed(2);
      // }

      // else {
      //   var monthlyInterestRatio = (fcList.intrate / 100) / 12;
      //   var top = Math.pow((1 + monthlyInterestRatio), fcList.tenor);
      //   var bottom = top - 1;
      //   var emi = ((fcList.proposalLimit * monthlyInterestRatio * top) / bottom);
      //   var tempInstAmt = emi * 12;
      //   if (tempInstAmt < 0 || tempInstAmt == Infinity) {
      //     tempInstAmt = 0.00;
      //   }
      //   var InstallmentAmt = tempInstAmt.toFixed(2);
      // }

     if (this.getDataLoanLength > 1) {
        for (let i = 0; i < this.loanLiabilityList.length; i++) {
          var proddesc = fcList.prdDesc + " Annual Installment";
          if (proddesc == this.loanLiabilityList[i].ldHeader) {
            this.loanLiabilityList[i].ldValue = InstallmentAmt;
            this.loanLiabilityList[i].ldLlInpval = fcList.intrate;
            break;
          }

        }
      }
      else {
        this.loanLiabilityList.push({
          ldHeader: fcList.prdDesc + " Annual Installment", ldCreatedBy: "", ldCreatedOn: "", ldEntryType: "LL",
          ldComments: this.loanComments, ldModifiedBy: "", ldModifiedOn: "", ldRowId: "0", ldRowNo: "1", ldValue: InstallmentAmt, ldLlInpval: fcList.intrate, lpcomProposal: ""
        });
      }

    });

    this.loanLListLength = this.facilityList.length - 1;
  }
  rmvErr(event: any) {
    var value = (<HTMLInputElement>document.getElementById(event.target.id)).value;
    if (value != "" && value != null && value != undefined) {
      if ($('#' + event.target.id).hasClass("has-error")) {
        $('#' + event.target.id).removeClass("has-error");
        $('#' + event.target.id).attr("placeholder", "");
      }
    }
  }
}
