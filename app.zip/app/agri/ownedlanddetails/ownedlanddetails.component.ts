import { Component, OnInit, ViewChild } from '@angular/core';
import { OwnedlanddetailsService } from "../../util/service/agriservices/ownedlanddetails.service";
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive'
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;

import { IndividualappdetService } from '../../util/service/corporateservices/individualappdet.service';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { SearchComponent } from '../../common/search/search.component';
import { StgeographymasterService } from '../../util/service/setupservices/stgeographymaster.service';
@Component({
  selector: 'lp-ownedlanddetails',
  templateUrl: './ownedlanddetails.component.html',
  styleUrls: ['./ownedlanddetails.component.css']
})
export class OwnedlanddetailsComponent extends Validator implements OnInit {
  data: any;
  flag: boolean;
  flag1: boolean;
  model: any = {};
  private landDetailsArray: Array<any> = [];
  fieldDisable: boolean;
  additional: boolean;
  total: any; itr: number;
  mortagetotal: any;
  aldNonCultivabletotal: any;
  governtotal: any;
  lcaSrovaluation: any;
  ownland: any;
  plm: any;
  stateFlag: boolean;
  cityFlag: boolean;
  relationList: any = [];
  irrigationList: any = [];
  statusList: any = [];
  temp: any = [];
  tempVal: any = [];
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  pageAccess: any;
  savebuttonDisable: boolean; districtFlag: boolean = false;
  hidCityCode: string = "";
  idvalueList = ['aldAddress', 'aldVillage', 'hidaldStateId_', 'hidaldCityId_', 'hidaldTalukId_', 'aldSurveyNo', 'aldCultivable', 'aldBorrRelation', 'aldGovtValuation', 'aldStatus', 'aldKasarano', 'aldKhatano'];
  borrowerType = [];
  totallandList = ['lcaBorrowerownland', 'lcaMarketvaluation'];
  statelist: any;
  hidStateCode: any = ""; hidDistrictCode: string = "";
  modelForChngNote: any;
  totalCultivable: any;
  totalNoncul: any;
  portaldisable: boolean;
  totalAcreConsAss: any;
  borrowerFlag: any;
  cityDetails: any = [];
  //districtList: any = [];
  talukList: any = [];
  stateList: any = []; copyLandIndex: any; cityDetailsCopy: any = []; talukListCopy: any = [];
  copyArrayList: any = []; showCopy: boolean = true; copybuttonDisable: boolean;
  surveyDedupeList: any = [];
  surveySecurityDedupeList: any = [];
  surveyDedupeCheck: any = {};
  croppingPattern: any = [];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  @ViewChild(SearchComponent)
  Searchpop: SearchComponent
  constructor(private ownedlanddetailsService: OwnedlanddetailsService, private router: Router,
    private fieldvalidation: Fieldvalidation, private individualappdetService: IndividualappdetService,
    private changenoteService: ChangenoteService, private stgeographymasterService: StgeographymasterService) {
    super();
  }
  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();
    this.additional = true;
    this.portaldisable = true;
    this.borrowerFlag = true;
    this.disableButtons(true, true, false, true, true, true, true);
    this.model = { lcaFamilyland: '', lcaBorrowerownland: '', lcaLandmortgage: '', lcaSrovaluation: '', lcaMarketvaluation: '', lcaLandverification: 's', lcaLanddocsverfy: 's', lcaTalathiname: '', lcaTalathicontact: '', lcaLandverfonlinesite: 's', lcaPartiallandmort: 's', lcaPlm: '', lcaRemarks: "" };
    this.model.landDetailsArray = [{ aldAddress: '', aldDistrict: 's', aldstate: 's', aldvillage: '', aldSurveyNo: '', aldCultivable: '', aldNonCultivable: '', aldIrrigationSrc: 's', aldOwnerId: 's', aldBorrRelation: 's', aldPropMortgage: 'N', aldAcreMortgaged: '', aldGovtValuation: '', aldStatus: 's', aldPortalCultivable: '', aldtaluk: 's', aldCropPattern: "" }];
    this.showCopy = true;
    this.copyArrayList = []; this.cityDetailsCopy = []; this.talukListCopy = [];
    this.ownedlanddetailsService.getLandDetails()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.relationList = this.data.responseData.RelationmasterList;
          this.irrigationList = this.data.responseData.IrrigationmasterList;
          this.statusList = this.data.responseData.StatusmasterList;
          this.stateList = this.data.stateList;
          this.cityDetails = this.data.cityList;
          this.croppingPattern = this.data.responseData.croppingPattern;
          //this.districtList = this.data.districtList;//
          this.talukList = this.data.talukList;
          this.model.landDetailsArray = [];
          this.borrowerType = this.data.ownerName;
          if (this.data.responseData.lpcorpAdditionaldetail != null) {
            this.model.lcaFamilyland = this.data.responseData.lpcorpAdditionaldetail.lcaFamilyland;
            this.model.lcaBorrowerownland = this.data.responseData.lpcorpAdditionaldetail.lcaBorrowerownland;
            this.model.lcaLandmortgage = this.data.responseData.lpcorpAdditionaldetail.lcaLandmortgage;
            this.model.lcaSrovaluation = this.data.responseData.lpcorpAdditionaldetail.lcaSrovaluation;
            this.model.lcaMarketvaluation = this.toFixCall(this.data.responseData.lpcorpAdditionaldetail.lcaMarketvaluation);
            this.model.lcaLandverification = this.data.responseData.lpcorpAdditionaldetail.lcaLandverification;
            this.model.lcaLanddocsverfy = this.data.responseData.lpcorpAdditionaldetail.lcaLanddocsverfy;
            this.model.lcaTalathiname = this.data.responseData.lpcorpAdditionaldetail.lcaTalathiname;
            this.model.lcaTalathicontact = this.data.responseData.lpcorpAdditionaldetail.lcaTalathicontact;
            this.model.lcaLandverfonlinesite = this.data.responseData.lpcorpAdditionaldetail.lcaLandverfonlinesite;
            this.model.lcaPartiallandmort = this.data.responseData.lpcorpAdditionaldetail.lcaPartiallandmort;
            this.model.lcaPlm = this.data.responseData.lpcorpAdditionaldetail.lcaPlm;
            this.model.lcaRowId = this.data.responseData.lpcorpAdditionaldetail.lcaRowId;
            this.model.lcaRemarks = this.data.responseData.lpcorpAdditionaldetail.lcaRemarks;
          }
          this.model.landDetailsArray = this.data.responseData.reqDueDataList;
          this.statelist = this.data.responseData.stGeographyMasterList;
          this.model.landDetailsArray.forEach((element, index) => {

            element.aldCultivable = this.toFixCall(element.aldCultivable);
            element.aldNonCultivable = this.toFixCall(element.aldNonCultivable);
            element.aldAcreMortgaged = this.toFixCall(element.aldAcreMortgaged);
            element.aldGovtValuation = this.toFixCall(element.aldGovtValuation);
            element.aldAssessment = this.toFixCall(element.aldAssessment);
            if (element.aldIrrigationSrc != "s" && element.aldIrrigationSrc != "" && element.aldIrrigationSrc != null) {
              this.temp = element.aldIrrigationSrc.split(',');
              element.aldIrrigationSrc = this.temp;
            }

            if (element.aldOwnerId != "" && element.aldOwnerId != "s") {
              this.tempVal = element.aldOwnerId.split(',');
              element.aldOwnerId = this.tempVal;
            }
            if (element.aldOwnerId.includes("0"))
              element.otherBorrowerName = false;
            else
              element.otherBorrowerName = true;

          });
          if (this.model.landDetailsArray.length < 1) {
            this.model.landDetailsArray = [{ aldAddress: '', aldDistrict: 's', aldstate: 's', aldSurveyNo: '', aldCultivable: '', aldNonCultivable: '', aldIrrigationSrc: 's', aldOwnerId: 's', aldBorrRelation: 's', aldPropMortgage: 'N', aldAcreMortgaged: '', aldGovtValuation: '', aldStatus: 's', aldAssessment: '', aldtaluk: 's', otherBorrowerName: true }];
            this.disableButtons(false, false, true, false, true, false, true);
          }
          this.acrecalculate(this.model.landDetailsArray.length - 1);
          this.acremortagecalculate(this.model.landDetailsArray.length - 1);
          this.acreGoverncalculate(this.model.landDetailsArray.length - 1);
          this.acreConsAssessment(this.model.landDetailsArray.length - 1);
          if (this.data.pageAccess == 'R') {
            this.disableButtons(true, true, true, true, true, true, true);
          }

          if (this.data.lpagriKccEligibility != null) {
            this.disableButtons(true, true, true, true, true, true, true);
          }
        }
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onload(this.data.pageAccess);
        }
        setTimeout(() => {
          let i = this.model.landDetailsArray.length - 1;
          for (let i = 0; i < this.model.landDetailsArray.length; i++) {
            $("#hidaldStateId_" + i).select2();
            $("#hidaldCityId_" + i).select2();
            $("#hidaldTalukId_" + i).select2();
            $("#hidaldStateId_" + i).on('change', (e) => {
              this.model.landDetailsArray[i].aldstate = e.target.value;
              this.getCityList(this.model.landDetailsArray[i].aldstate, i);
            });
            $("#hidaldCityId_" + i).on('change', (e) => {
              this.model.landDetailsArray[i].aldDistrict = e.target.value;
              this.getTalukList(this.model.landDetailsArray[i].aldstate, this.model.landDetailsArray[i].aldDistrict, i);
            });
            $("#hidaldTalukId_" + i).on('change', (e) => {
              this.model.landDetailsArray[i].aldtaluk = e.target.value;
            });
          }
        }, 50);
      },
      error => {
      });


    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });

  }
  addFieldValue() {
    this.disableButtons(false, false, true, false, false, false, true);

    this.model.landDetailsArray.push({ aldAddress: '', aldDistrict: 's', aldstate: 's', aldSurveyNo: '', aldCultivable: '', aldNonCultivable: '', aldIrrigationSrc: 's', aldOwnerId: 's', aldBorrRelation: 's', aldPropMortgage: 'N', aldAcreMortgaged: '', aldGovtValuation: '', aldStatus: 's', aldAssessment: '', aldPortalCultivable: '', aldtaluk: 's', otherBorrowerName: true, aldCropPattern: "" });
    setTimeout(() => {
      let i = this.model.landDetailsArray.length - 1;

      $("#hidaldStateId_" + i).select2();
      $("#hidaldCityId_" + i).select2();
      $("#hidaldTalukId_" + i).select2();
      $("#hidaldStateId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldstate = e.target.value;
        this.getCityList(this.model.landDetailsArray[i].aldstate, i);
      });
      $("#hidaldCityId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldDistrict = e.target.value;
        this.getTalukList(this.model.landDetailsArray[i].aldstate, this.model.landDetailsArray[i].aldDistrict, i);
      });
      $("#hidaldTalukId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldtaluk = e.target.value;
      });

    }, 50);

  }
  saveLandDetails() {
    let flagCM = true;
    this.borrowerFlag = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.landDetailsArray.length, this.idvalueList)) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.landDetailsArray.length, this.idvalueList)
      this.flag1 = this.fieldvalidation.validateField(this.totallandList)
      let otherOwnerEmpCount = 0;
      var phCount = 0;
      var phId = 'talathicontact';
      if (this.model.lcaTalathicontact !== "" && this.model.lcaTalathicontact != null) {
        if ((this.model.lcaTalathicontact.toString()).length < 10) {
          phCount++;
          $('#' + phId).addClass("has-error");
        }
      }

      this.model.landDetailsArray.forEach((value, i) => {
        $('#aldOtherOwnername' + i).removeClass("has-error");
        $('#aldOwnerId' + i).removeClass("has-error");

        if (value.aldOwnerId.includes("0") && (value.aldOtherOwnername == "" || value.aldOtherOwnername == null)) {
          otherOwnerEmpCount++;
          $('#aldOtherOwnername' + i).addClass("has-error");
          $('#aldOtherOwnername' + i).attr("placeholder", "Enter Owner Name");
        }
        if (value.aldOwnerId == "0") {
          $('#aldOwnerId' + i).addClass("has-error");
          alert("Select atleast One Borrower");
          this.borrowerFlag = false;
        }
        if (value.aldOwnerId == "s" || value.aldOwnerId == '') {
          $('#aldOwnerId' + i).focus();
          $('#aldOwnerId' + i).addClass("has-error");
          alert("Select atleast One Borrower");
          this.borrowerFlag = false;
        }
      });
      if (this.flag && this.flag1 && phCount == 0 && otherOwnerEmpCount == 0 && this.borrowerFlag) {
        this.model.lcaFamilyland = this.total;
        this.model.lcaLandmortgage = this.mortagetotal;

        this.model.landDetailsArray.forEach((value, i) => {
          if (value.aldIrrigationSrc == "s" || value.aldIrrigationSrc == null || value.aldIrrigationSrc == undefined) {
            value.aldIrrigationSrc = '';
          }
          else {
            var tempval = value.aldIrrigationSrc.join();
            value.aldIrrigationSrc = tempval;
          }

          if (value.aldOwnerId != "s" && value.aldOwnerId != " " && value.aldOwnerId != null) {
            var tempvalue = value.aldOwnerId.join();
            value.aldOwnerId = tempvalue;
          }
        });
        this.ownedlanddetailsService.saveLandDetails(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              this.model.landDetailsArray = this.data.responseData;
              this.disableButtons(true, true, false, true, false, true, true);
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.ngOnInit();
              successStatus();
            }

          },
          error => {
            failedStatus();
          });
      }
    }
  }
  editLandDetails() {
    this.disableButtons(false, false, true, false, false, false, true);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      this.total = '';
      this.mortagetotal = '';
      this.governtotal = '';
      this.aldNonCultivabletotal = '';
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }


  acrecalculate(i) {
    this.total = 0.00;
    this.totalCultivable = 0.00;
    this.ownland = 0.00;
    this.totalNoncul = 0.00;
    this.model.landDetailsArray.forEach(value => {
      if (value.aldCultivable !== "" && value.aldCultivable != null && value.aldCultivable != undefined) {
        this.totalCultivable = parseFloat(value.aldCultivable) + parseFloat(this.totalCultivable);
      }
      if (value.aldNonCultivable !== "" && value.aldNonCultivable != null && value.aldNonCultivable != undefined) {
        this.totalNoncul = parseFloat(value.aldNonCultivable) + parseFloat(this.totalNoncul);
      }
    });
    this.total = parseFloat(this.totalCultivable) + parseFloat(this.totalNoncul);
    this.model.lcaFamilyland = parseFloat(this.total).toFixed(2);
    this.totalCultivable = parseFloat(this.totalCultivable).toFixed(2);
    this.totalNoncul = parseFloat(this.totalNoncul).toFixed(2);

  }
  acreConsAssessment(i) {

    this.totalAcreConsAss = 0.00;
    this.model.landDetailsArray.forEach(value => {
      if (value.aldAssessment !== "" && value.aldAssessment != null && value.aldAssessment != undefined) {
        this.totalAcreConsAss = parseFloat(value.aldAssessment) + parseFloat(this.totalAcreConsAss);
      }

    });

    this.totalAcreConsAss = parseFloat(this.totalAcreConsAss).toFixed(2);

  }
  ownlandcalculate(i) {


    this.ownland = 0.00
    this.model.landDetailsArray.forEach(value => {
      if (value.aldCultivable !== "" && value.aldCultivable != null) {
        if (value.aldBorrRelation == "1") {
          let ownval = parseFloat(value.aldCultivable).toFixed(2);
          this.ownland = parseFloat(this.ownland) + parseFloat(ownval);
          this.ownland = parseFloat(this.ownland).toFixed(2);
          this.model.lcaBorrowerownland = this.ownland;

        }
        else {
          this.model.lcaBorrowerownland = '';
        }
      }

    });
  }

  acreGoverncalculate(i) {
    this.governtotal = 0.00;
    this.model.landDetailsArray.forEach(value => {
      if (value.aldGovtValuation !== "" && value.aldGovtValuation != null && value.aldGovtValuation != undefined) {
        let val1 = parseFloat(value.aldGovtValuation).toFixed(2);
        this.governtotal = parseFloat(this.governtotal) + parseFloat(val1);
        this.governtotal = parseFloat(this.governtotal).toFixed(2);
        this.model.lcaSrovaluation = this.governtotal;

      }

    });
  }

  acremortagecalculate(i) {
    this.mortagetotal = 0.00;

    this.model.landDetailsArray.forEach(value => {
      if (value.aldAcreMortgaged !== "" && value.aldAcreMortgaged != null && value.aldAcreMortgaged != undefined) {
        let val = parseFloat(value.aldAcreMortgaged).toFixed(2);
        this.mortagetotal = parseFloat(this.mortagetotal) + parseFloat(val);
        this.plm = (this.mortagetotal / this.total) * 100;
        this.plm = parseFloat(this.plm).toFixed(2);
        this.model.lcaPlm = this.plm;
      }
    });
    this.mortagetotal = parseFloat(this.mortagetotal).toFixed(2);
  }

  delete(row: any, id: any, i: any) {
    if (id == '' || id == undefined) {
      this.model.landDetailsArray.splice(i, 1);
      if (this.model.landDetailsArray.length == 0) {
        this.total = "";
        this.mortagetotal = "";
      }
      else {
        this.acrecalculate(this.model.landDetailsArray.length - 1);
        this.acremortagecalculate(this.model.landDetailsArray.length - 1);
      }
    }
    else {
      if (confirm("Do you want to Delete?")) {
        if (row.aldIrrigationSrc != "" && row.aldIrrigationSrc != undefined && row.aldIrrigationSrc != null) {
          var tempval = row.aldIrrigationSrc.join();
          row.aldIrrigationSrc = tempval;
        }
        if (row.aldOwnerId != "s" && row.aldOwnerId != " " && row.aldOwnerId != null) {
          var tempvalue = row.aldOwnerId.join();
          row.aldOwnerId = tempvalue;
        }
        this.ownedlanddetailsService.deleteLandDetails(row)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {

          });
      }
    }
  }
  deleteAllLandDetails() {
    if (confirm("Do you want to Delete?")) {
      this.model.landDetailsArray.forEach((value) => {
        if (value.aldIrrigationSrc != "" && value.aldIrrigationSrc != undefined && value.aldIrrigationSrc != null) {
          var tempval = value.aldIrrigationSrc.join();
          value.aldIrrigationSrc = tempval;
        }
        if (value.aldOwnerId != "s" && value.aldOwnerId != " " && value.aldOwnerId != null) {
          var tempvalue = value.aldOwnerId.join();
          value.aldOwnerId = tempvalue;
        }
      });
      this.ownedlanddetailsService.deleteall(this.model)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.ngOnInit();
            this.total = '';
            this.mortagetotal = '';
            this.governtotal = '';
            this.aldNonCultivabletotal = '';
          }
        },
        error => {

        });
    }
  }
  AddcultindNonculti(value, i) {
    this.model.landDetailsArray[i].aldAssessment = this.model.landDetailsArray[i].aldCultivable;
  }

  AddcultindNonculti1(value, i) {
    this.model.landDetailsArray.forEach((value, index) => {
      if (i == index) {
        if (value.aldAssessment != null && value.aldAssessment != '' && value.aldAssessment != undefined) {

          if (value.aldNonCultivable == "") {
            if (parseFloat(value.aldAssessment) > parseFloat(value.aldCultivable)) {
              this.model.landDetailsArray[i].aldAssessment = "";
              $('#aldAcreAssetment' + i).addClass("has-error");
              alert("Acres to be considered for Assessment Should not exceed Check-Cultivable Area");
            }
          }

          if (value.aldNonCultivable != null && value.aldNonCultivable != '' && value.aldNonCultivable != undefined) {
            if (parseFloat(value.aldAssessment) > parseFloat(value.aldCultivable) + parseFloat(value.aldNonCultivable)) {
              this.model.landDetailsArray[i].aldAssessment = "";
              $('#aldAcreAssetment' + i).addClass("has-error");
              alert("Acres to be considered for Assessment Should not exceed Check-Cultivable Area and Uncultivable Area");
            }
          }

        }
      }
    });

  }

  AddcultindNoncultiMorg(value, i) {

    if (value == "N") {
      alert("All security details related to this record will be deleted.");
    }

    this.model.landDetailsArray.forEach((value, index) => {
      if (i == index) {
        if (value.aldPropMortgage == "Y") {
          if (value.aldNonCultivable == "") {
            var tempval = JSON.parse(value.aldCultivable);
            value.aldAcreMortgaged = parseFloat(tempval).toFixed(2);
            (<HTMLInputElement>document.getElementById("aldAcreMortgaged" + i)).disabled = false;
            this.acremortagecalculate(i);

          }
          if (value.aldCultivable !== "" && value.aldNonCultivable !== "") {
            var tempval = JSON.parse(value.aldCultivable) + JSON.parse(value.aldNonCultivable);
            value.aldAcreMortgaged = parseFloat(tempval).toFixed(2);
            (<HTMLInputElement>document.getElementById("aldAcreMortgaged" + i)).disabled = false;
            this.acremortagecalculate(i);
          }
        }

        if (value.aldPropMortgage == "N") {
          value.aldAcreMortgaged = 0;
          this.acremortagecalculate(i);
          (<HTMLInputElement>document.getElementById("aldAcreMortgaged" + i)).disabled = true;

        }
      }

    });

  }

  AddcultindNoncultiArcMor(value, i) {
    this.model.landDetailsArray.forEach((value, index) => {
      if (i == index) {
        if (value.aldNonCultivable == "") {
          if (JSON.parse(value.aldAcreMortgaged) > JSON.parse(value.aldCultivable)) {
            this.model.landDetailsArray[i].aldAcreMortgaged = "";
            $('#aldAcreMortgaged' + i).addClass("has-error");
          }
        }
        if (value.aldCultivable !== "" && value.aldNonCultivable !== "") {
          if (JSON.parse(value.aldAcreMortgaged) > JSON.parse(value.aldCultivable) + JSON.parse(value.aldNonCultivable)) {
            this.model.landDetailsArray[i].aldAcreMortgaged = "";
            $('#aldAcreMortgaged' + i).addClass("has-error");

          }
        }
      }
    });

  }

  toFixCall(value) {
    let temp = "";
    if (value !== "" && value != null) {
      temp = parseFloat(value).toFixed(2);
    }
    return temp;
  }


  checkAcreLimit(value: any, i: number, label: string) {
    var AcreVal = parseFloat(parseFloat(value).toFixed(2));

    if (AcreVal > 999.99) {
      if (label == "C") {
        this.model.landDetailsArray[i].aldCultivable = "";
        $('#aldCultivable' + i).addClass("has-error");
        return true;

      }
      else if (label == "UC") {
        this.model.landDetailsArray[i].aldNonCultivable = "";
        $('#aldNonCultivable' + i).addClass("has-error");
        return true;
      }
      else if (label == "M") {
        this.model.landDetailsArray[i].aldAcreMortgaged = "";
        $('#aldAcreMortgaged' + i).addClass("has-error");
        return true;

      }

    } else { return false; }

  }


  validate(e: any, i: number, label: string) {


    var valFlag;
    if (e != "") {
      valFlag = this.checkAcreLimit(e, i, label);
      if (valFlag) {
        alert("Enter Acre Limit Below 1000");
      }
      else {
        if (label == 'C') {
          this.model.landDetailsArray[i].aldCultivable = this.toFixCall(e);
          this.acrecalculate(i);
          this.acremortagecalculate(i);
        }
        else if (label == "UC") {
          this.model.landDetailsArray[i].aldNonCultivable = this.toFixCall(e);

        }
        else if (label == "M") {
          this.model.landDetailsArray[i].aldAcreMortgaged = this.toFixCall(e);
          this.acremortagecalculate(i);

        }
        else if (label == "G") {

          this.model.landDetailsArray[i].aldGovtValuation = this.toFixCall(e);
          this.acreGoverncalculate(i);
        }
        else if (label == "O") {

          this.ownlandcalculate(i);
        }

      }
    }
  }

  callSearch(val: string, i, event) {

    this.itr = i;
    if (val == "City") {
      this.cityFlag = true;
      var pageid = "City";
      $('#name').text("District Name");
      $('#code').text("District code");
      $('#header').text("District Search");
      $('#txt_pageid').val(pageid);
      let rowCount = event.target.id.split("_");

      if ($('#hidaldStateId' + rowCount[1]).val() !== "" && $('#hidaldStateId' + this.itr).val() !== "") {
        this.hidStateCode = this.model.landDetailsArray[this.itr].aldstate;
        $('#txt_hidCode').val("S:" + this.hidStateCode);
      }
      else if ($('#hidaldStateId' + this.itr).val() == "" && $('#hidaldTalukId' + this.itr).val() == "") {
        $('#txt_hidCode').val("C");

      }
      else if (($('#hidaldStateId' + this.itr).val() != "" && $('#hidaldTalukId' + this.itr).val() == "")) {
        $('#txt_hidCode').val("S:" + this.hidStateCode);

      }
      else if ($('#hidaldStateId' + this.itr).val() == "" && $('#hidaldTalukId' + this.itr).val() != "") { $('#txt_hidCode').val("D:" + this.hidDistrictCode); }

      else if ($('#hidaldStateId' + this.itr).val() != "" && $('#hidaldTalukId' + this.itr).val() != "" && $('#hidaldCityId' + this.itr).val() == "") {
        $('#txt_hidCode').val("SD:" + this.hidStateCode + "/" + this.hidDistrictCode);


      }
      else {
        $('#txt_hidCode').val("S:" + this.hidStateCode);
      }

      this.Searchpop.ngOnInit();
      $('#Search').modal('show');
    }
    else if (val == 'State') {
      this.stateFlag = true;
      var pageid = "State";
      $('#name').text("State Name");
      $('#code').text("State Code");
      $('#header').text("State Search");
      $('#txt_pageid').val(pageid);
      $('#txt_hidCode').val("S");
      this.Searchpop.ngOnInit();
      $('#Search').modal('show');

    }
    else if (val == "District") {
      this.districtFlag = true;
      var pageid = "District";
      $('#name').text("Taluk Name");
      $('#code').text("Taluk Code");
      $('#header').text("Taluk Search");
      $('#txt_pageid').val(pageid);
      if ($('#hidaldStateId' + this.itr).val() == "" && $('#hidaldCityId' + this.itr).val() == "") {
        $('#txt_hidCode').val("D");

      }
      else if ($('#hidaldStateId' + this.itr).val() != "" && $('#hidaldCityId' + this.itr).val() == "") {
        this.hidStateCode = this.model.landDetailsArray[this.itr].aldstate;
        $('#txt_hidCode').val("S:" + this.hidStateCode);
      }
      else if ($('#hidaldStateId' + this.itr).val() != "" && $('#hidaldCityId' + this.itr).val() != "") {
        this.hidCityCode = this.model.landDetailsArray[this.itr].aldDistrict;
        $('#txt_hidCode').val("C:" + this.hidCityCode);

      }
      else if ($('#hidaldStateId' + this.itr).val() != "" && $('#hidaldCityId' + this.itr).val() != "" && $('#hidaldTalukId' + this.itr).val() != "") {
        $('#txt_hidCode').val("S:" + this.hidStateCode);


      }
      this.Searchpop.ngOnInit();
      $('#Search').modal('show');
    }

  }

  modalClosed() {

    if (this.stateFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
        var stateName = $('#txt-Searchname').val();
        var stateCode = $('#txt_Searchcode').val();
        if (stateName != "" && stateCode != "") {
          this.model.landDetailsArray[this.itr].aldstate = stateCode;

          $('#hidaldStateId' + this.itr).val(stateName);
          this.hidStateCode = stateCode;

        }
        this.model.landDetailsArray[this.itr].aldDistrict = "";
        $('#hidaldCityId' + this.itr).val("");
        this.hidCityCode = "";
        this.model.landDetailsArray[this.itr].aldtaluk = "";
        $('#hidaldTalukId' + this.itr).val("");
        this.hidDistrictCode = "";

      }
      this.stateFlag = false;
    }


    else if (this.districtFlag) {
      if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
        var districtName = $('#txt-Searchname').val();
        var districtCode = $('#txt_Searchcode').val();
        if (districtName != "" && districtCode != "") {
          this.model.landDetailsArray[this.itr].aldtaluk = districtCode;
          $('#hidaldTalukId' + this.itr).val(districtName);
          this.hidDistrictCode = districtCode;

        }
        if ($('#txt_hidCode').val() == "D") {
          let temp = $('#txt_hidValue').val().split("@");
          this.model.landDetailsArray[this.itr].aldstate = temp[0];
          this.hidStateCode = temp[0];
          var varTemp = temp[1].split("/");
          $('#hidaldCityId' + this.itr).val(temp[2]);
          $('#hidaldStateId' + this.itr).val(varTemp[0]);
          this.model.landDetailsArray[this.itr].aldDistrict = varTemp[1];
          this.hidCityCode = varTemp[1];



        }
        else if ($('#txt_hidCode').val().match("^S:")) {
          let temp = $('#txt_hidValue').val().split("@");
          this.model.landDetailsArray[this.itr].aldDistrict = temp[0];
          $('#hidaldCityId' + this.itr).val(temp[1]);
          this.hidCityCode = temp[0];;
        }

      }
      this.districtFlag = false;
    }
    else if (this.cityFlag) {

      if ($('#txt-Searchname').val() != "" && $('#txt_Searchcode').val() != "") {
        var cityName = $('#txt-Searchname').val();
        var cityCode = $('#txt_Searchcode').val();

        if (cityName != "" && cityCode != "") {
          this.model.landDetailsArray[this.itr].aldDistrict = cityCode;

          $('#hidaldCityId' + this.itr).val(cityName);
          this.hidCityCode = cityCode;
          if (!$('#txt_hidCode').val().match("^SD")) {
            this.hidDistrictCode = "";
            this.model.landDetailsArray[this.itr].aldtaluk = "";
            $('#hidaldTalukId' + this.itr).val("");
          }
        }
        if ($('#txt_hidCode').val() == "C") {
          var strState = $('#txt_hidValue').val().split("@");
          this.model.landDetailsArray[this.itr].aldstate = strState[0];
          $('#hidaldStateId' + this.itr).val(strState[1]);
          this.hidStateCode = strState[0];
        }


      }
      this.cityFlag = false;
    }
  }


  checkAcreLimit1(value: any) {
    var AcreVal = parseFloat(parseFloat(value).toFixed(2));
    if (AcreVal > 999.99) {
      this.model.lcaBorrowerownland = "";
      $('#lcaBorrowerownland').adslgdClass("has-error");
      return true;
    }
  }
  checkAcreLimitForCopyRecord(event: any) {
    var AcreVal = parseFloat(parseFloat(event.target.value).toFixed(2));
    if (AcreVal > 999.99) {
      alert("Enter Acre Limit Below 1000");
      return true;
    }
  }

  disableButtons(field: boolean, add: boolean, edit: boolean, save: boolean, deleteAll: boolean, cancel: boolean, copy: boolean) {
    this.fieldDisable = field;
    this.newbuttonDisable = add;
    this.editbuttonDisable = edit;
    this.savebuttonDisable = save;
    this.cancelbuttonDisable = cancel;
    this.deleteAllbuttonDisable = deleteAll;
    this.copybuttonDisable = copy;
  }

  getCityList(stateCode, index) {
    this.cityDetails[index] = [];
    this.stgeographymasterService.getCityListBasedOnStateCode(stateCode)
      .subscribe(
      data => {
        this.data = data;
        this.cityDetails[index] = this.data.cityList;
        this.talukList[index] = [];
        //this.districtList[index] = [];
      },
      error => {

      }
      );
  }


  getTalukList(stateCode, cityCode, index) {

    let parentIdForTaluk = this.cityDetails[index].find(city => city.sgmStateCode == stateCode && city.sgmCityCode == cityCode).sgmRowId;
    let codeDetail = cityCode + ":" + stateCode + ":" + parentIdForTaluk;

    this.talukList[index] = [];
    // this.districtList[index] = [];
    this.stgeographymasterService.getDistinctTalukList(codeDetail)
      .subscribe(
      data => {
        this.data = data;
        this.talukList[index] = this.data.distinctTalukList;
        // this.districtList[index] = this.data.distinctTalukList;
      },
      error => {

      }
      );
  }


  doCopyRow(index) {
    $('input.checkbox').on('change', function () {
      $('input.checkbox').not(this).prop('checked', false);

    });
    if ($("#selCopyLandDet_" + index).is(":checked")) {
      this.copybuttonDisable = false;
      this.copyLandIndex = index;
    }
    else {
      this.copybuttonDisable = true;
      this.copyLandIndex = null;
    }
    //this.copyArrayList = [];
    if (this.copyLandIndex == null) {
      let spliceIndex;
      this.model.landDetailsArray.forEach((element,index) => {
        if(element.copyRecord==true){
          spliceIndex=index;
        }
      });


      if(this.model.landDetailsArray[spliceIndex].aldRowId==null && this.model.landDetailsArray[spliceIndex].copyRecord==true)
         {
           this.model.landDetailsArray.splice(spliceIndex, 1);
          }
    }

  }


  copyLandDetails() {

    // this.copyArrayList = [];
    //   this.model.landDetailsArray[this.model.landDetailsArray.length+1]=[];  
    this.model.landDetailsArray.push(JSON.parse(JSON.stringify(this.model.landDetailsArray[this.copyLandIndex])));
    //this.copyArrayList.push(JSON.parse(JSON.stringify(this.model.landDetailsArray[this.copyLandIndex])));
    // this.cityDetailsCopy = [];
    this.model.landDetailsArray[this.model.landDetailsArray.length - 1].aldRowId = null;
    this.model.landDetailsArray[this.model.landDetailsArray.length - 1].copyRecord=true;
    this.cityDetails[this.model.landDetailsArray.length - 1] = [];

    let stateCode = this.model.landDetailsArray[this.copyLandIndex].aldstate;
    let cityCode = this.model.landDetailsArray[this.copyLandIndex].aldDistrict;


    this.stgeographymasterService.getCityListBasedOnStateCode(stateCode)
      .subscribe(
      data => {
        this.data = data;
        //  this.cityDetailsCopy = this.data.cityList;
        this.cityDetails[this.model.landDetailsArray.length - 1] = this.data.cityList;
        //  this.talukListCopy = [];
        this.talukList[this.model.landDetailsArray.length - 1] = [];
        let parentIdForTaluk = this.cityDetails[this.model.landDetailsArray.length - 1].find(city => city.sgmStateCode == stateCode && city.sgmCityCode == cityCode).sgmRowId;
        let codeDetail = cityCode + ":" + stateCode + ":" + parentIdForTaluk;
        // this.talukListCopy = [];

        this.stgeographymasterService.getDistinctTalukList(codeDetail)
          .subscribe(
          data => {
            this.data = data;
            this.talukList[this.model.landDetailsArray.length - 1] = this.data.distinctTalukList;

          },
          error => {

          }
          );
      },
      error => {

      }
      );

    // setTimeout(() => {
    //   $("#hidaldStateId_copy").select2();
    //   $("#hidaldCityId_copy").select2();
    //   $("#hidaldTalukId_copy").select2();
    //   $("#hidaldStateId_copy").on('change', (e) => {
    //     this.copyArrayList[0].aldstate = e.target.value;
    //     stateCode = e.target.value;
    //     this.stgeographymasterService.getCityListBasedOnStateCode(stateCode)
    //       .subscribe(
    //       data => {
    //         this.data = data;
    //         this.cityDetailsCopy = this.data.cityList;
    //         this.talukListCopy = [];
    //         this.copyArrayList[0].aldDistrict = "";
    //       });
    //   });
    //   $("#hidaldCityId_copy").on('change', (e) => {
    //     this.copyArrayList[0].aldDistrict = e.target.value;
    //     cityCode = e.target.value;
    //     let parentIdForTaluk = this.cityDetailsCopy.find(city => city.sgmStateCode == stateCode && city.sgmCityCode == cityCode).sgmRowId;
    //     let codeDetail = cityCode + ":" + stateCode + ":" + parentIdForTaluk;
    //     this.talukListCopy = [];
    //     this.copyArrayList[0].aldtaluk = "";

    //     this.stgeographymasterService.getDistinctTalukList(codeDetail)
    //       .subscribe(
    //       data => {
    //         this.data = data;
    //         this.talukListCopy = this.data.distinctTalukList;
    //       });

    //   });
    //   $("#hidaldTalukId_copy").on('change', (e) => {
    //     this.copyArrayList[0].aldtaluk = e.target.value;
    //   });

    // }, 50);
    setTimeout(() => {
      let i = this.model.landDetailsArray.length - 1;

      $("#hidaldStateId_" + i).select2();
      $("#hidaldCityId_" + i).select2();
      $("#hidaldTalukId_" + i).select2();
      $("#hidaldStateId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldstate = e.target.value;
        this.getCityList(this.model.landDetailsArray[i].aldstate, i);
      });
      $("#hidaldCityId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldDistrict = e.target.value;
        this.getTalukList(this.model.landDetailsArray[i].aldstate, this.model.landDetailsArray[i].aldDistrict, i);
      });
      $("#hidaldTalukId_" + i).on('change', (e) => {
        this.model.landDetailsArray[i].aldtaluk = e.target.value;
      });

    }, 50);
    this.acrecalculate(this.model.landDetailsArray.length - 1);
    this.acremortagecalculate(this.model.landDetailsArray.length - 1);
    this.acreGoverncalculate(this.model.landDetailsArray.length - 1);
    this.acreConsAssessment(this.model.landDetailsArray.length - 1);

  }
  selectOtherBorrowerName(val, i) {
    if (val.includes("0")) {
      this.model.landDetailsArray[i].otherBorrowerName = false;
      // this.model.landDetailsArray[i].aldOtherOwnername = "";
    }
    else
      this.model.landDetailsArray[i].otherBorrowerName = true;
  }

  surveyNoDedupe(item) {
    this.surveySecurityDedupeList = [];
    this.surveyDedupeList = [];
    if (item.aldSurveyNo != '') {
      if (item.aldkasarano != '') {
        if (item.aldkhatano != '') {
          this.surveyDedupeCheck = { aldPropMortgage: item.aldPropMortgage, aldAcreMortgaged: item.aldAcreMortgaged, aldGovtValuation: item.aldGovtValuation, aldAssessment: item.aldAssessment, aldCultivable: item.aldNonCultivable, aldNonCultivable: item.aldNonCultivable, aldDistrict: item.aldDistrict, aldstate: item.aldstate, aldSurveyNo: item.aldSurveyNo, aldtaluk: item.aldtaluk,aldkasarano:item.aldkasarano ,aldkhatano:item.aldkhatano};
          this.ownedlanddetailsService.surveyNoDedupeCheck(this.surveyDedupeCheck)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.surveyDedupeList = this.data.responseData;
                this.surveySecurityDedupeList = this.data.securitySurveyList;
                $('#surveyDedupe').modal('show');
              }
            });
        }
        else {
          alert("Enter the Revenue Record Year.");
        }
      }
      else {
        alert("Enter the Khata/Khewat/Khatoni/P2 No.");
      }
    }
    else {
      alert("Enter the Survey No./Hadbast No./B1.");
    }
  }
  callClose() {
    $('#surveyDedupe').modal('hide');
  }

}


