import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunitymasterComponent } from './communitymaster.component';

describe('CommunitymasterComponent', () => {
  let component: CommunitymasterComponent;
  let fixture: ComponentFixture<CommunitymasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommunitymasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunitymasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
