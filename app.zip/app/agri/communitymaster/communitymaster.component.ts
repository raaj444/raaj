import { Component, OnInit } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive';
import { CommunitymasterService } from '../../util/service/agriservices/communitymaster.service';

declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
@Component({
  selector: 'lp-communitymaster',
  templateUrl: './communitymaster.component.html',
  styleUrls: ['./communitymaster.component.css']
})
export class CommunitymasterComponent extends Validator  implements OnInit {   data:any; 
  model: any = {};
  communityList: any = [];
  religionList: any = [];
  categoryList: any = [];
  tempList: any = [];
  checkList: any = [];
  communityCode: any = [];
  pageAccess: any;
  fieldDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  deletebuttonDisable: boolean;
  flag: boolean;
  categoryFlag: boolean;
  religionFlag: boolean;

  idvalueList = ['lcReligionType_', 'lcCategory_', 'lcCommunityCode_'];
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private communitymasterService: CommunitymasterService) {
    super();
  }

  ngOnInit() {
    this.disableButton(false, true, true, true, true);
    this.communitymasterService.getCommunityMaster(this.communityList)
      .subscribe(
      data => { this.data=data;

        if (this.data.success) {
          this.communityList = this.data.communityList;
          this.religionList = this.data.religionList;
          this.categoryList = this.data.categoryList;
          this.communityCode = this.data.communityCode;
          if (this.communityList.length == 0) {
            this.addNewRow();
          }
        }

      },
      error => {

      });

    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });


  }
  saveCommunityMaster() {
    var dupCheck = this.validateCheck();
    this.flag = this.fieldvalidation.multipleFieldValidation(this.communityList.length, this.idvalueList);
    if (!dupCheck) {
      if (this.flag) {
        progressStatus()
        this.communitymasterService.saveCommunityMaster(this.communityList)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              successStatus();

              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');

              this.ngOnInit();

            }
          },
          error => {
            failedStatus();
          });

      }
    }
  }
  addNewRow() {
    this.communityList.push({
      lcRowId: "", lcReligionType: "", lcCategory: "", lcCreatedBy: "", lcCreatedOn: "", lcCommunityCode: "", lcModifiedBy: "", lcModifiedOn: ""
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteA: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deletebuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.deletebuttonDisable = deleteA;
    }
  }

  onClickEditButton() {
    this.disableButton(true, false, false, false, false);


  }

  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      this.ngOnInit()

    }
    else {
      this.saveCommunityMaster();
    }
  }
  deleteCommunityMaster(row: any, id: any, i: any) {

    if (id == '' || id == undefined) {
      this.communityList.splice(i, 1);
    }
    else {
      if (confirm("Do you want to Delete?")) {
        this.communitymasterService.deleteCommunityMaster(row)
          .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              this.ngOnInit();
            }
          },
          error => {
          });
      }
    }
  }

  deleteAllVehIncDeviation() {

    this.communitymasterService.deleteAll(this.communityList)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {

      });

  }

  religionChange(relid: any, index: any) {

    if (this.communityList.length > 1) {
      for (let j = 0; j < this.communityList.length - 1; j++) {
        this.checkList = this.communityList[index];
        this.tempList = this.communityList[j];
        if ((this.checkList.lcReligionType != "" && this.checkList.lcCategory != "")) {
          if (j == index) {
            this.tempList = this.communityList[j + 1];
          }
          if ((this.tempList.lcReligionType == this.checkList.lcReligionType) && (this.tempList.lcCategory == this.checkList.lcCategory)) {
            alert("Already same Religion and Category exists");
            this.communityList[index].lcReligionType = "s";
            $('#lcReligionType_' + index).val("s");
            break;
          }

        }
      }
    }
  }
  categoryChange(catid: any, index: any) {

    if (this.communityList.length > 1) {
      for (let j = 0; j < this.communityList.length - 1; j++) {
        this.checkList = this.communityList[index];
        this.tempList = this.communityList[j];
        if ((this.checkList.lcReligionType != "" && this.checkList.lcCategory != "")) {
          if (j == index) {
            this.tempList = this.communityList[j + 1];
          }
          if ((this.tempList.lcReligionType == this.checkList.lcReligionType) && (this.tempList.lcCategory == this.checkList.lcCategory)) {
            alert("Already same Religion and Category exists");
            this.communityList[index].lcCategory = "s";
            $('#lcCategory_' + index).val("s");
            break;
          }

        }
      }
    }
  }
  validateCheck() {
    for (let j = 0; j < this.communityList.length; j++) {
      this.checkList = this.communityList[j];
      for (let d = j + 1; d < this.communityList.length; d++) {
        this.tempList = this.communityList[d];
        if ((this.checkList.lcReligionType != "" && this.checkList.lcCategory != ""
          && this.tempList.lcReligionType != "" && this.tempList.lcCategory != "")) {

          if ((this.tempList.lcReligionType == this.checkList.lcReligionType) && (this.tempList.lcCategory == this.checkList.lcCategory)) {
            this.communityList[d].lcCategory = "s";
            this.communityList[d].lcReligionType = "s";
            $('#lcReligionType_' + d).val("s");
            $('#lcCategory_' + d).val("s");
            this.categoryFlag = true;
            break;
          }
          else if(this.tempList.lcCommunityCode == this.checkList.lcCommunityCode)
          {
            this.communityList[d].lcCommunityCode = "s";
            $('#lcCommunityCode_'+d).val("s");
            this.categoryFlag = true;
            break;
          }
          else
            this.categoryFlag = false;
        }
      }
    }
    return this.categoryFlag;
  }
  rmvErr(event: any) {
    var value = (<HTMLInputElement>document.getElementById(event.target.id)).value;
    if (value != "" && value != null && value != undefined) {
      if ($('#' + event.target.id).hasClass("has-error")) {
        $('#' + event.target.id).removeClass("has-error");
        $('#' + event.target.id).attr("placeholder", "");
      }
    }
  }
}
