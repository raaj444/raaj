import { Component, OnInit, ViewChild } from '@angular/core';
import { Validator } from "../../util/helper/validator";
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { RestrictinputDirective } from '../../util/helper/restrictinput.directive'

import { AgritermloanService } from "../../util/service/agriservices/agritermloan.service";
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var successStatus: any;
declare var failedStatus: any;

declare var $: any;

@Component({
  selector: 'lp-agritermloan',
  templateUrl: './agritermloan.component.html',
  styleUrls: ['./agritermloan.component.css']
})
export class AgritermloanComponent extends Validator implements OnInit {
  data: any;
  model: any = {};
  pageAccess: any;
  flag: boolean;
  flag1: boolean;
  flag2: boolean;
  fieldDisable: boolean;
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  deleteAllbuttonDisable: boolean;
  savebuttonDisable: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  agriflag: any;
  Surrogateflag: any;
  AgriSurroflag: any;
  tenorDisable: boolean;
  amount: any;
  fundingAmt: any;
  fundper: any;
  fundPerDisable: boolean;
  AgrivalueList = ['aldpurpose', 'aldquotation', 'lcaQuotedate', 'aldquoteAmount', 'aldFunding', 'aldFundingPer', 'alRepayfreq', 'alRepaymonths', 'alMoratorium', 'alFirstinstalldue', 'alLastinstalldue'];
  private AgritermloanList: Array<any> = [];
  private facilityDetailsList: Array<any> = [];
  listOfValuesList = [];
  tempagritermloanList: Array<any> = [];
  modelForChngNote: any;
  maxDate: Date;
  minDate: Date;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private router: Router,
    private fieldvalidation: Fieldvalidation, private AgritermloanService: AgritermloanService,
    private changenoteService: ChangenoteService) {
    super();
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(1899, 12, 1);
    this.minDate.setDate(this.minDate.getDate());
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.model.AgritermloanList = [];
    this.model.facilityDetailsList = [];
    this.validators();
    this.disableButton(true, true, true, true, true);
    this.AgritermloanService.getAgritermloanDetails()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.model.facilityDetailsList = this.data.responseData.FacilityList;
          this.listOfValuesList = this.data.lpmasListofvalueList;
          if (this.data.Agri) {            
            this.tenorDisable = true;            
            this.agriflag = 'Y';
            this.model.AgritermloanList = this.data.responseData.AgritermloanList;            
            if (this.model.AgritermloanList.length >0)
              this.disableButton(false, true, true, true, false);
            else
              this.disableButton(true, false, false, false, true);
            this.pageAccess = this.data.pageAccess;
            this.model.facilityDetailsList.forEach(facility => {
              let count = 0;
              this.model.AgritermloanList.forEach(agritermloan => {
                if (agritermloan.lcaFacno == facility.lfFacNo) {
                  ++count;
                  agritermloan.facName = facility.facName;
                  agritermloan.lfProposedLimit = facility.lfProposedLimit;
                  if (agritermloan.lcaQuotedate != "" && agritermloan.lcaQuotedate != undefined) {
                    var quotedate = agritermloan.lcaQuotedate;
                    var matudate = quotedate.split("-");
                    agritermloan.lcaQuotedate = matudate[2] + '/' + matudate[1] + '/' + matudate[0];
                  }
                  if (agritermloan.lcaFirstinstalldue != "" && agritermloan.lcaFirstinstalldue != undefined) {
                    var duedate = agritermloan.lcaFirstinstalldue;
                    var datearray = duedate.split("-");
                    agritermloan.lcaFirstinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                  }
                  if (agritermloan.lcaLastinstalldue != "" && agritermloan.lcaLastinstalldue != undefined) {
                    var lastduedate = agritermloan.lcaLastinstalldue;
                    var datearray = lastduedate.split("-");
                    agritermloan.lcaLastinstalldue = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                  }
                }
              });
              if (count == 0) {
                this.model.AgritermloanList.push({
                  lcaPurpose: '', lcaQuoteby: '', lcaQuotedate: '', lcaQuoteamt: '', lcaQuotefund: '', lcaQuotefundper: '',
                  lcaRepayfreq: '', lcaRepaymonths: '', lcaTenor: facility.lfTenor, lcaMoratorium: '', lcaFirstinstalldue: '', lcaLastinstalldue: '',
                  lcaFacno: facility.lfFacNo, facName: facility.facName, lfProposedLimit: facility.lfProposedLimit,
                });
              }
              this.tenorDisable = true;
            });
            var btnfunc = true;
            this.model.AgritermloanList.forEach(element => {
              if (element.lcaPurpose == "") {
                btnfunc = false;
              }
            });
            if (!btnfunc)
              this.disableButton(true, false, false, false, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
            this.disableButton(false, true, true, true, true);
          }
          if (this.pageAccess == 'R')
            this.disableButton(true, true, true, true, true)
        }
      },
      error => {
      });
  }
  addFieldValue() {
    this.fieldDisable = false;
    this.fundPerDisable = true;
    this.editbuttonDisable = true;
    this.cancelbuttonDisable = false;
    this.deleteAllbuttonDisable = false;
    this.savebuttonDisable = false;
    this.model.AgritermloanList.push({ lcaPurpose: '', lcaQuoteby: '', lcaQuotedate: '', lcaQuoteamt: '', lcaQuotefund: '', lcaQuotefundper: '' });
  }
  validatefuturedate(eventId) {
    this.fieldvalidation.isValidDOB(eventId);
  }
  saveAgritermloanValidation() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.fieldvalidation.multipleFieldValidation(this.model.AgritermloanList.length, this.AgrivalueList)) {
        this.changenoteComponent.onSave();
      }
      this.flag = this.fieldvalidation.multipleFieldValidation(this.model.AgritermloanList.length, this.AgrivalueList)
      var dateComp = this.compareDates();
      if (this.flag && dateComp) {
        this.saveAgriTermLoan();
      }
    }
  }
  saveAgriTermLoan() {
    this.model.AgritermloanList.forEach(element => {
      element.lcaQuotedate = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaQuotedate);
      element.lcaFirstinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaFirstinstalldue);
      element.lcaLastinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaLastinstalldue);
    });
    this.AgritermloanService.saveAgritermLoan(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.model.AgritermloanList = this.data.responseData;
          this.fieldDisable = true;
          this.fundPerDisable = true;
          this.editbuttonDisable = false;
          this.cancelbuttonDisable = true;
          this.deleteAllbuttonDisable = false;
          this.savebuttonDisable = true;
          this.ngOnInit();
          sessionStorage.setItem("editMode", "N");
          $('input,select,textarea').removeClass('ng-dirty');
          successStatus();
        }
      },
      error => {
        failedStatus();
      });
  }
  onClickEditButton() {
    this.disableButton(true, false, false, false, true);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  onClickCancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }
    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }
  delete(row: any, id: any, i: any) {
    if (id == '' || id == undefined) {
      this.model.newLineArray.splice(i, 1);
    }
    else {
      this.AgritermloanService.deleteAgritermdetails(row)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.ngOnInit();
          }
        },
        error => {
        });
    }
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean, field: boolean, deleteall: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.fundPerDisable = true;
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
      this.deleteAllbuttonDisable = true;
    }
    else {
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
      this.fieldDisable = field;
      this.fundPerDisable = true;
      this.deleteAllbuttonDisable = deleteall;
    }
  }
  deleteAgritermdetails() {
    this.model.AgritermloanList.forEach(element => {
      element.lcaQuotedate = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaQuotedate);
      element.lcaFirstinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaFirstinstalldue);
      element.lcaLastinstalldue = this.fieldvalidation.dPDateConversionFromIndianStd(element.lcaLastinstalldue);
    });
    this.AgritermloanService.deleteall(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.ngOnInit();
        }
      },
      error => {
      });
  }
  fundingPerCalc(i) {
    this.amount = 0.00;
    this.fundingAmt = 0.00;
    this.model.tempAgriList = [];
    this.model.tempAgriList = this.model.AgritermloanList[i];
    if (this.model.tempAgriList.lcaQuoteamt !== "" && this.model.tempAgriList.lcaQuotefund != "") {
      let val = parseFloat(this.model.tempAgriList.lcaQuoteamt).toFixed(2);
      this.amount = parseFloat(this.amount) + parseFloat(val); this.amount = parseFloat(this.amount).toFixed(2);
      let val1 = parseFloat(this.model.tempAgriList.lcaQuotefund).toFixed(2);
      this.fundingAmt = parseFloat(this.fundingAmt) + parseFloat(val1); this.fundingAmt = parseFloat(this.fundingAmt).toFixed(2);
      this.fundper = (this.fundingAmt / this.amount) * 100;
      this.fundper = parseFloat(this.fundper).toFixed(2);
      this.model.AgritermloanList[i].lcaQuotefundper = this.fundper;
    }
  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }
  effDateRes(id: any) {
    var futdate = (<HTMLInputElement>document.getElementById(id)).value;
    var dateParts = futdate.split("/");
    new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]);
    return new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]).getTime() < new Date().getTime();
  }
  compareDates() {
    var dateCheck = true;
    this.model.AgritermloanList.forEach((element, i) => {
      if (element.lcaFirstinstalldue != "" && element.lcaLastinstalldue != "") {
        let lfrm = this.fieldvalidation.validatedate('alFirstinstalldue' + i);
        let lto = this.fieldvalidation.validatedate('alLastinstalldue' + i);
        if (lfrm && lto) {
          let vallfrm = this.effDateRes('alFirstinstalldue' + i);
          let vallto = this.effDateRes('alLastinstalldue' + i);
          if (!vallfrm && !vallto) {
            var alFirstinstalldue = (<HTMLInputElement>document.getElementById('alFirstinstalldue' + i)).value;
            var alLastinstalldue = (<HTMLInputElement>document.getElementById('alLastinstalldue' + i)).value;
            //LeadFrom Date
            var firstDue = alFirstinstalldue.split("/");
            alFirstinstalldue = firstDue[1] + '/' + firstDue[0] + '/' + firstDue[2];
            var firstDueDate = new Date(alFirstinstalldue);
            //LeadTo Date
            var lastDue = alLastinstalldue.split("/");
            alLastinstalldue = lastDue[1] + '/' + lastDue[0] + '/' + lastDue[2];
            var lastDueDate = new Date(alLastinstalldue);
            if (firstDueDate.getTime() > lastDueDate.getTime()) {
              $('#alFirstinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "From date must be less than To date");
              dateCheck = false;
            }
            else if (firstDueDate.getTime() == lastDueDate.getTime()) {
              $('#alFirstinstalldue' + i).val("");
              $('#alLastinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alLastinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "Enter valid date");
              $('#alLastinstalldue' + i).attr("placeholder", "Enter valid date");
              dateCheck = false;
            }
          }
          else {
            if (vallfrm) {
              $('#alFirstinstalldue' + i).val("");
              $('#alFirstinstalldue' + i).addClass("has-error");
              $('#alFirstinstalldue' + i).attr("placeholder", "Past date not allowed here");
              dateCheck = false;
            }
            else {
              $('#alLastinstalldue' + i).val("");
              $('#alLastinstalldue' + i).addClass("has-error");
              $('#alLastinstalldue' + i).attr("placeholder", "Past date not allowed here");
              dateCheck = false;
            }
          }
        }
        else {
          $('#alFirstinstalldue' + i).val("");
          $('#alLastinstalldue' + i).val("");
          $('#alFirstinstalldue' + i).attr("placeholder", "Enter valid date");
          $('#alLastinstalldue' + i).attr("placeholder", "Enter valid date");
          dateCheck = false;
        }
      }
    });
    return dateCheck;
  }
}