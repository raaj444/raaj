import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgritermloanComponent } from './agritermloan.component';

describe('AgritermloanComponent', () => {
  let component: AgritermloanComponent;
  let fixture: ComponentFixture<AgritermloanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgritermloanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgritermloanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
