import { Component, OnInit, ViewChild } from '@angular/core';
import { AgridroplineodService } from "../../util/service/agriservices/agridroplineod.service";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Validator } from '../../util/helper/validator';
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any

@Component({
  selector: 'lp-agridroplineod',
  templateUrl: './agridroplineod.component.html',
  styleUrls: ['./agridroplineod.component.css']
})
export class AgridroplineodComponent extends Validator implements OnInit {
  data: any;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private agridroplineodService: AgridroplineodService, private fieldvalidation: Fieldvalidation,
    private changenoteService: ChangenoteService) {
    super();
  }

  FacilityList: any = [];
  newbuttonDisable: boolean;
  editDisabled: boolean;
  cancelDisabled: boolean;
  saveDisabled: boolean;
  deleteDisabled: boolean;
  fieldDisable: boolean;
  pageAccess: any;
  FacilityTypeList: any = [];
  idvalueList = ['lfDisbursMethd'];
  lfDisbursMethdList: any = [];
  model: any = [];
  customArray: any = [];
  duparry: any = [];
  indexval: any;
  modelForChngNote: any;


  ngOnInit() {
    this.fieldDisable = true;
    this.disableButton(true, true, false, true);
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.lfDisbursMethdList = [{ "DisbusID": 0, "DisbursVal": "Type" }, { "DisbusID": 5, "DisbursVal": "DL OD1" }, { "DisbusID": 6, "DisbursVal": "DL OD2" },
    { "DisbusID": 7, "DisbursVal": "DL OD3" }, { "DisbusID": 8, "DisbursVal": "DL OD4" }, { "DisbusID": 9, "DisbursVal": "DL OD5" },
    { "DisbusID": 10, "DisbursVal": "DL OD6" }, { "DisbusID": 11, "DisbursVal": "DL OD7" }, { "DisbusID": 12, "DisbursVal": "DL OD8" },
    { "DisbusID": 13, "DisbursVal": "DL OD9" }, { "DisbusID": 14, "DisbursVal": "DL OD10" }];
    this.agridroplineodService.getAgriDropLineOD()
      .subscribe(
      data => {
        this.data = data;
        let flag = false;
        if (this.data.success) {
          this.FacilityList = this.data.responseData.FacilityList;
          this.FacilityTypeList = this.data.responseData.FacilityTypeList;
          var i = 0;
          this.FacilityList.forEach(element => {

            this.model.demo = [];
            this.FacilityList[i].Type = this.FacilityTypeList[i].Type;
            this.FacilityList[i].PrdDesc = this.FacilityTypeList[i].PrdDesc;
            this.FacilityList[i].LoanType = this.FacilityTypeList[i].LoanType;
            this.FacilityList[i].BorrowerName = this.FacilityTypeList[i].BorrowerName;
            this.FacilityList[i].CustId = this.FacilityTypeList[i].CustId;
            this.FacilityList[i].LoanTypeId = this.FacilityTypeList[i].LoanTypeId;
            this.lfDisbursMethdList[0].DisbusID = this.FacilityList[i].LoanTypeId;
            this.lfDisbursMethdList[0].DisbursVal = this.FacilityList[i].LoanType;
            var dynamicid = this.lfDisbursMethdList[0].DisbusID;

            this.customArray.push(JSON.parse(JSON.stringify(this.lfDisbursMethdList)));
            i++;
          });


          this.FacilityList.forEach(element => {
            if (element.lfDisbursMethd == "" || element.lfDisbursMethd == null) {
              element.lfDisbursMethd = "s";
            }
          });
          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess == 'R') {
            this.disableButton(true, true, true, true);
          }
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
        }
      });


  }

  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean) {
    this.fieldDisable = fieldDisable;
    this.saveDisabled = savebuttonDisable;
    this.editDisabled = editbuttonDisable;
    this.cancelDisabled = cancelbuttonDisable;
  }
  editdropline() {
    this.disableButton(false, false, true, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  savedropline() {

    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      if (this.fieldvalidation.multipleFieldValidation(this.FacilityList.length, this.idvalueList)) {

        this.agridroplineodService.saveDropLineOD(this.FacilityList)
          .subscribe(
          data => {
            this.data = data;
            progressStatus()
            if (this.data.success == true) {
              successStatus()
              this.ngOnInit();
            }
            else {
              failedStatus()
            }
          });
      }
    }
  }

  canceldropline() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

  compareBorrName(custid: any, value, event, index) {
    for (var i = 0; i < this.FacilityList.length; i++) {
      if (this.FacilityList[i].lfDisbursMethd == value && this.FacilityList[i].lfDisbursMethd != "s" && this.FacilityList[i].CustId != custid) {
        alert("You cannot choose same DL OD with different Borrowers");
        event.target.value = 's';
        i = this.FacilityList.length;
        break;
      }
    }
  }

  viewRepayChart(field: any, index: any) {
    this.agridroplineodService.viewRepayChart(field)
      .subscribe(
      data => {
        this.data = data;
        let flag = false;
        if (this.data.success) {
          this.FacilityList = this.data.responseData.FacilityList;
          this.FacilityTypeList = this.data.responseData.FacilityTypeList;
        }
      });
  }



}