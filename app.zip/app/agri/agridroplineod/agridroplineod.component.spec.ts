import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgridroplineodComponent } from './agridroplineod.component';

describe('AgridroplineodComponent', () => {
  let component: AgridroplineodComponent;
  let fixture: ComponentFixture<AgridroplineodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgridroplineodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgridroplineodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
