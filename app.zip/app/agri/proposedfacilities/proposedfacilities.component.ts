import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { ExposuredetserviceService } from '../../util/service/corporateservices/exposuredetservice.service';
declare var $: any;
declare var successStatus: any;
declare var failedStatus: any;
import { Validator } from "../../util/helper/validator";
import { ChangenoteComponent } from '../../common/changenote/changenote.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';

@Component({
  selector: 'lp-proposedfacilities',
  templateUrl: './proposedfacilities.component.html',
  styleUrls: ['./proposedfacilities.component.css']
})
export class ProposedfacilitiesComponent extends Validator implements OnInit {
  data: any;
  totalOutStandingLimit: any = 0;
  totalProposedLimit: any = 0;
  totalExposure: any = 0;
  model: any = {};
  facilityId: number = 0;
  pageAccess: string;
  prodDescDisable: boolean = true;
  private facilityAgriDetailsLev1: Array<any> = [];
  private facilityAgriDetailsLev2: Array<any> = [];
  private facilityAgriDetailsLev3: Array<any> = [];
  facNo: number = 0;
  fieldDisable: boolean = true;
  newbuttonDisable: boolean = true;
  editbuttonDisable: boolean = true;
  savebuttonDisable: boolean = true;
  cancelbuttonDisable: boolean = true;
  pushDisable: boolean = true;
  disableFlag: boolean;
  totalExistingLimit: any = 0;
  purposeLoanList = [];
  vertical: any;
  modelForChngNote: any;
  kccProdExist: boolean = false;
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private router: Router, private fieldvalidation: Fieldvalidation, private exposuredetserviceService: ExposuredetserviceService,
    private changenoteService: ChangenoteService) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";

    this.validators();
    this.model.exposures = [];
    this.model.mainfacilityDetails = [];
    this.model.FacilityDetailsList = [];
    this.model.subfacilityDetails = [];
    this.facilityAgriDetailsLev2 = [];
    this.facilityAgriDetailsLev3 = [];

    this.pushDisable = true;
    this.model.mainfacId = "s";
    this.model.subfacId = "s";
    this.model.pagelink = "exposuredetails";
    this.disableFlag = true;
    this.prodDescDisable = true;
    this.fieldDisable = true;
    this.kccProdExist = false;

    this.getExposuredetails();
    this.exposuredetserviceService.getFacCategoryDetails(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.model.mainfacilityDetails = this.data.responseData.LpstpMainFacilitylist;
          this.model.FacilityDetailsList = this.data.responseData.LpstpFacilitylist;
          this.vertical = this.data.responseData.vertical;
        }
        // else
        //   alert("Error..");
      },
      error => {
        // this.alertService.error(error);
      });
  }

  addFacilityAgriLev1() {
    if (this.pageAccess != "R") {
      this.model.exposures.push({ lfProdId: "", lpdPrdDesc: "", lfMainCat: "", lfSubCat: "", lfFacType: "", lfFacNature: "", lpdTenorFrom: 0, lpdTenorTo: 0, lfRowId: '', lfFacNo: ++this.facNo, lfFacParent: 0, lfFacLevel: 1, lfFacRating: '', lfFacCmbdRating: "", lfTakeovrSancLimit: '', lfTakeovrOsLimit: '', lfLoanType: "s", lfExistLimit: '', lfOsLimit: '', lfProposedLimit: "", lfTenor: "", lfMargin: "", lfOtherTerms: '', lfReExposure: '', lfFacSecure: '', lpdAmtFrom: 0, lpdAmtTo: 0, facilityAgriDetailsLev2: [], lfTotExposure: 0, disabletkover: false, lfPurposeLoan: 's' });
      this.buttonAccess(false, true, false, false);
      this.fieldDisable = false;
    }
  }

  addFacilityAgriLev2(i: number) {
    if (this.pageAccess != "R" && this.disableFlag == false) {
      this.model.exposures[i].facilityAgriDetailsLev2.push({ lfProdId: "", lpdPrdDesc: "", lfMainCat: "", lfSubCat: "", lfFacType: "", lfFacNature: "", lpdTenorFrom: 0, lpdTenorTo: 0, lfRowId: '', lfFacNo: ++this.facNo, lfFacParent: this.model.exposures[i].lfFacNo, lfFacLevel: 2, lfFacRating: '', lfFacCmbdRating: "", lfTakeovrSancLimit: '', lfTakeovrOsLimit: '', lfLoanType: "s", lfExistLimit: '', lfOsLimit: '', lfProposedLimit: "", lfTenor: "", lfMargin: "", lfOtherTerms: '', lfReExposure: '', lfFacSecure: '', lpdAmtFrom: 0, lpdAmtTo: 0, facilityAgriDetailsLev3: [], lfTotExposure: 0, lfPurposeLoan: 's' });
    }
  }
  addFacilityAgriLev3(i: number, j: number) {
    if (this.pageAccess != "R" && this.disableFlag == false) {
      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3.push({ lfProdId: "", lpdPrdDesc: "", lfMainCat: "", lfSubCat: "", lfFacType: "", lfFacNature: "", lpdTenorFrom: 0, lpdTenorTo: 0, lfRowId: '', lfFacNo: ++this.facNo, lfFacParent: this.model.exposures[i].facilityAgriDetailsLev2[j].lfFacNo, lfFacLevel: 3, lfFacRating: '', lfFacCmbdRating: "", lfTakeovrSancLimit: '', lfTakeovrOsLimit: '', lfLoanType: "s", lfExistLimit: '', lfOsLimit: '', lfProposedLimit: "", lfTenor: "", lfMargin: "", lfOtherTerms: '', lfReExposure: '', lfFacSecure: '', lpdAmtFrom: 0, lpdAmtTo: 0, lfTotExposure: 0, lfPurposeLoan: 's' });
    }
  }

  deleteFacilityAgriLev1(row: any, id: any, i: any) {
    if (this.pageAccess != "R" && this.disableFlag == false) {
      if (confirm("Do you want to delete?")) {
        if (id == '') {
          this.model.exposures.splice(i, 1);
        } else {
          if (row.lfMargin == null || row.lfMargin == "NaN" || row.lfMargin == undefined) {
            row.lfMargin = "";
          }

          this.exposuredetserviceService.deleteFacAgriLev1(row)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.getExposuredetails();
              }
              // else
              //   alert("Error..");
            },
            error => {
              // this.alertService.error(error);
            });
        }
      }
    }
  }
  deleteFacilityAgriLev2(row: any, id: any, i: any, j: any) {
    if (this.pageAccess != "R" && this.disableFlag == false) {
      if (confirm("Do you want to delete?")) {
        if (id == '') {
          this.model.exposures[i].facilityAgriDetailsLev2.splice(j, 1);
        }
        else {
          if (row.lfMargin == null || row.lfMargin == "NaN" || row.lfMargin == undefined) {
            row.lfMargin = "";
          }

          this.exposuredetserviceService.deleteFacAgriLev2(row)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.getExposuredetails();
              }
              // else
              //   alert("Error..");
            },
            error => {
              // this.alertService.error(error);
            });
        }
      }
    }
  }

  deleteFacilityAgriLev3(row: any, id: any, i: number, j: number, k: number) {
    if (this.pageAccess != "R" && this.disableFlag == false) {
      if (confirm("Do you want to delete?")) {
        if (id == '') {
          this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3.splice(k, 1);
        }
        else {
          if (row.lfMargin == null || row.lfMargin == "NaN" || row.lfMargin == undefined) {
            row.lfMargin = "";
          }
          this.exposuredetserviceService.deleteFacAgriLev3(row)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.getExposuredetails();
              }
              // else
              //   alert("Error..");
            },
            error => {
              // this.alertService.error(error);
            });
        }
      }
    }
  }



  saveExposureDetailsData() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    this.model.exposures.forEach(field1 => {
      if (field1.lfMargin == "NaN" || field1.lfMargin == undefined || field1.lfMargin == null)
      { field1.lfMargin = ""; }
      field1.facilityAgriDetailsLev2.forEach(field2 => {
        if (field2.lfMargin == "NaN" || field2.lfMargin == undefined || field2.lfMargin == null)
        { field2.lfMargin = ""; }
        field2.facilityAgriDetailsLev3.forEach(field3 => {
          if (field3.lfMargin == "NaN" || field3.lfMargin == undefined || field3.lfMargin == null)
          { field3.lfMargin = ""; }
        });
      });
    });
    if (flagCM) {
      if (this.modelForChngNote.changeMode == "Y" && flagCM) {
        this.changenoteComponent.onSave();
      }
      this.getfacorder()
      this.exposuredetserviceService.saveExistingExposure(this.model)
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            sessionStorage.setItem("editMode", "N");
            $('input,select,textarea').removeClass('ng-dirty');
            this.getExposuredetails();
          }
        },
        error => {
          // this.alertService.error(error);
        });
    }
  }
  getExposuredetails() {
    this.fieldDisable = true;
    this.kccProdExist = false;
    this.exposuredetserviceService.getExistingExposure(this.model)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.model.exposures = [];
          this.model.exposures = this.data.responseData.exposures;
          this.purposeLoanList = this.data.responseData.loanPurposeList;
          if (this.model.exposures.length > 0) {
            this.model.exposures.forEach(field1 => {
              field1.disabletkover = true;

            });
            this.model.exposures.forEach(field1 => {
              if (field1.lpdAgriLoanType == "KCC") {
                this.kccProdExist = true;
              }
              field1.lfExistLimit = parseFloat(field1.lfExistLimit).toFixed(2);
              field1.lfOsLimit = parseFloat(field1.lfOsLimit).toFixed(2);
              field1.lfProposedLimit = parseFloat(field1.lfProposedLimit).toFixed(2);
              field1.lfMargin = parseFloat(field1.lfMargin).toFixed(2);
              field1.lfTotExposure = parseFloat(field1.lfTotExposure).toFixed(2);
              field1.facilityAgriDetailsLev2.forEach(field2 => {

                // if (field2.lpdAgriLoanType == "KCC") {
                //   this.kccProdExist = true;
                // }

                field2.lfExistLimit = parseFloat(field2.lfExistLimit).toFixed(2);
                field2.lfOsLimit = parseFloat(field2.lfOsLimit).toFixed(2);
                field2.lfProposedLimit = parseFloat(field2.lfProposedLimit).toFixed(2);
                field2.lfMargin = parseFloat(field2.lfMargin).toFixed(2);
                field2.lfTotExposure = parseFloat(field2.lfTotExposure).toFixed(2);
                field2.disabletkover = true;
                field2.facilityAgriDetailsLev3.forEach(field3 => {
                  // if (field3.lpdAgriLoanType == "KCC") {
                  //   this.kccProdExist = true;
                  // }
                  field3.lfExistLimit = parseFloat(field3.lfExistLimit).toFixed(2);
                  field3.lfOsLimit = parseFloat(field3.lfOsLimit).toFixed(2);
                  field3.lfProposedLimit = parseFloat(field3.lfProposedLimit).toFixed(2);
                  field3.lfMargin = parseFloat(field3.lfMargin).toFixed(2);
                  field3.lfTotExposure = parseFloat(field3.lfTotExposure).toFixed(2);
                  field3.disabletkover = true;
                });
              });
            });
          }
          this.totalLimit();
          this.pageAccess = this.data.pageAccess;
          this.facNo = this.data.responseData.facNo;
          this.buttonAccess(true, false, true, true);
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);

          }
        }

      },
      error => {
        // this.alertService.error(error);
      });
  }
  editExposureDetailsData() {
    this.disableFlag = false;
    this.buttonAccess(false, true, false, false);
    this.fieldDisable = false;
    if (this.model.exposures.length > 0) {
      this.model.exposures.forEach(field1 => {
        if (field1.lfLoanType == "T") {
          field1.disabletkover = true;
        }
        else {
          field1.disabletkover = false;
        }
        field1.facilityAgriDetailsLev2.forEach(field2 => {
          if (field2.lfLoanType == "T") {
            field2.disabletkover = true;
          }
          else {
            field2.disabletkover = false;
          }
          field2.facilityAgriDetailsLev3.forEach(field3 => {
            if (field3.lfLoanType == "T") {
              field3.disabletkover = true;
            }
            else {
              field3.disabletkover = false;
            }
          });
        });
      });
    }
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else {
      return false;
    }
  }
  pushLevel1(i: any, disabletkover: boolean) {
    if (!disabletkover) {
      if (this.pageAccess != "R" && this.disableFlag == false) {
        this.model.level = "level1";
        this.model.index1 = i;
        $('#Product').modal('show');
      }
    }
  }

  pushLevel2(i: any, j: any, disabletkover: boolean) {
    if (this.pageAccess != "R" && this.disableFlag == false && !disabletkover) {
      this.model.level = "level2";
      this.model.index1 = i;
      this.model.index2 = j;
      $('#Product').modal('show');
    }
  }
  pushLevel3(i: any, j: any, k: any, disabletkover: boolean) {
    if (this.pageAccess != "R" && this.disableFlag == false && !disabletkover) {
      this.model.level = "level3";
      this.model.index1 = i;
      this.model.index2 = j;
      this.model.index3 = k;
      $('#Product').modal('show');
    }
  }
  subFacility(mainfacId: any) {
    this.model.subfacilityDetails = [];
    if (mainfacId != "s") {
      this.model.FacilityDetailsList.forEach(element => {
        if (mainfacId == element.lsfFacParentId) {
          this.model.subfacilityDetails.push(element);
        }
      });

    }
    else {
      alert("Please Choose MainFacility");
    }
  }
  getProductDet() {
    this.model.LpstpProductDetailsList = [];
    if (this.model.mainfacId != "s" && this.model.subfacId != "s") {
      this.exposuredetserviceService.getProductDetails(this.model).subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.model.tempLpstpProductDetailsList = this.data.responseData.LpstpProductDetailsList;
            this.model.tempLpstpProductDetailsList.forEach(element => {
              element.color = 'white';
              this.model.LpstpProductDetailsList.push(element);
            });


          }
          // else
          //   alert("Error..");
        },
        error => {
          // this.alertService.error(error);
        });

    }
  }
  pushProductDetails() {




    if (this.model.level == "level1") {

      this.model.exposures[this.model.index1].lfProdId = this.model.tempProdNewId;
      this.model.exposures[this.model.index1].lpdPrdDesc = this.model.tempPrdDesc;
      this.model.exposures[this.model.index1].lfMainCat = this.model.tempPrdMainCat;
      this.model.exposures[this.model.index1].lfSubCat = this.model.tempPrdSubCat;
      this.model.exposures[this.model.index1].lfFacType = this.model.tempPrdType;
      this.model.exposures[this.model.index1].lfFacNature = this.model.tempPrdNature;
      this.model.exposures[this.model.index1].lpdTenorFrom = this.model.tempTenorFrom;
      this.model.exposures[this.model.index1].lpdTenorTo = this.model.tempTenorTo;
      this.model.exposures[this.model.index1].lpdAmtFrom = this.model.templpdAmtFrom;
      this.model.exposures[this.model.index1].lpdAmtTo = this.model.templpdAmtTo;

    }
    if (this.model.level == "level2") {
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lfProdId = this.model.tempProdNewId;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lpdPrdDesc = this.model.tempPrdDesc;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lfMainCat = this.model.tempPrdMainCat;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lfSubCat = this.model.tempPrdSubCat;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lfFacType = this.model.tempPrdType;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lfFacNature = this.model.tempPrdNature;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lpdTenorFrom = this.model.tempTenorFrom;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lpdTenorTo = this.model.tempTenorTo;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lpdAmtFrom = this.model.templpdAmtFrom;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].lpdAmtTo = this.model.templpdAmtTo;
    }
    if (this.model.level == "level3") {
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lfProdId = this.model.tempProdNewId;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lpdPrdDesc = this.model.tempPrdDesc;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lfMainCat = this.model.tempPrdMainCat;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lfSubCat = this.model.tempPrdSubCat;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lfFacType = this.model.tempPrdType;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lfFacNature = this.model.tempPrdNature;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lpdTenorFrom = this.model.tempTenorFrom;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lpdTenorTo = this.model.tempTenorTo;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lpdAmtFrom = this.model.templpdAmtFrom;
      this.model.exposures[this.model.index1].facilityAgriDetailsLev2[this.model.index2].facilityAgriDetailsLev3[this.model.index3].lpdAmtTo = this.model.templpdAmtTo;
    }


    $('#Product').modal('hide');
    this.model.mainfacId = "s";
    this.model.subfacId = "s";
    this.pushDisable = true;
    this.model.LpstpProductDetailsList = [];
  }
  attachProdDetails(i: any) {
    if (this.model.LpstpProductDetailsList.length >= 1) {

      if (this.model.LpstpProductDetailsList[i].lpdAgriLoanType == "KCC" && this.kccProdExist) {
        alert("KCC facility already exists");
        return;
      }


      this.model.tempProdNewId = this.model.LpstpProductDetailsList[i].lpdProdNewId;
      this.model.tempPrdDesc = this.model.LpstpProductDetailsList[i].lpdPrdDesc;
      this.model.tempPrdMainCat = this.model.LpstpProductDetailsList[i].lpdPrdMainCat;
      this.model.tempPrdSubCat = this.model.LpstpProductDetailsList[i].lpdPrdSubCat;
      this.model.tempPrdType = this.model.LpstpProductDetailsList[i].lpdPrdType;
      this.model.tempPrdNature = this.model.LpstpProductDetailsList[i].lpdPrdNature;
      this.model.tempTenorFrom = this.model.LpstpProductDetailsList[i].lpdTenorFrom;
      this.model.tempTenorTo = this.model.LpstpProductDetailsList[i].lpdTenorTo;
      this.model.templpdAmtFrom = this.model.LpstpProductDetailsList[i].lpdAmtFrom;
      this.model.templpdAmtTo = this.model.LpstpProductDetailsList[i].lpdAmtTo;

      this.model.LpstpProductDetailsList.forEach(element => {
        element.color = 'white';
      });
      this.model.LpstpProductDetailsList[i].color = 'Pink';
      this.pushDisable = false;
    }
  }
  OnClickedSave() {
    let fieldMandptory = ["level1", "level2", "level3"];
    let saveFlag = false;
    var err = false;


    let tempArray = [];
    var rowCount1 = 0;
    this.model.exposures.forEach(field1 => {
      if (this.vertical == 7)
        tempArray.push('level1_' + rowCount1 + "_" + 15);

      if (field1.lfLoanType == "s") {
        tempArray.push('level1_' + rowCount1 + "_" + 6);
      }
      else if (field1.lfLoanType == "R") {
        tempArray.push('level1_' + rowCount1 + "_" + 7);
        tempArray.push('level1_' + rowCount1 + "_" + 8);
        tempArray.push('level1_' + rowCount1 + "_" + 9);
        tempArray.push('level1_' + rowCount1 + "_" + 10);
        // tempArray.push('level1_' + rowCount1 + "_" + 11);
      } else if (field1.lfLoanType == "T") {
        tempArray.push('level1_' + rowCount1 + "_" + 7);
        tempArray.push('level1_' + rowCount1 + "_" + 8);
        tempArray.push('level1_' + rowCount1 + "_" + 9);
        tempArray.push('level1_' + rowCount1 + "_" + 10);
        //tempArray.push('level1_' + rowCount1 + "_" + 11);
      } else if (field1.lfLoanType == "F") {
        tempArray.push('level1_' + rowCount1 + "_" + 9);
        tempArray.push('level1_' + rowCount1 + "_" + 10);
        // tempArray.push('level1_' + rowCount1 + "_" + 11);
      }
      var rowCount2 = 0;
      field1.facilityAgriDetailsLev2.forEach(field2 => {
        if (this.vertical == 7)
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 15);
        if (field2.lfLoanType == "s") {
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 6);
        } else if (field2.lfLoanType == "R") {
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 7);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 8);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 9);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 10);
          //tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 11);
        } else if (field2.lfLoanType == "T") {
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 7);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 8);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 9);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 10);
          // tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 11);
        } else if (field2.lfLoanType == "F") {
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 9);
          tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 10);
          //tempArray.push('level2_' + rowCount1 + rowCount2 + "_" + 11);
        }
        var rowCount3 = 0;
        field2.facilityAgriDetailsLev3.forEach(field3 => {
          if (this.vertical == 7)
            tempArray.push('level3' + rowCount1 + rowCount2 + rowCount3);
          if (field3.lfLoanType == "s") {
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 6);
          } else if (field3.lfLoanType == "R") {
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 7);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 8);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 9);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 10);
            //tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 11);
          } else if (field3.lfLoanType == "T") {
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 7);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 8);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 9);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 10);
            //tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 11);
          } else if (field3.lfLoanType == "F") {
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 9);
            tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 10);
            //tempArray.push('level3_' + rowCount1 + rowCount2 + rowCount3 + "_" + 11);
          }
          rowCount3++;
        });
        rowCount2++;
      });
      rowCount1++;
    });
    saveFlag = this.fieldvalidation.validateField(tempArray);
    if (saveFlag) {
      this.saveExposureDetailsData();
    }


  }


  validateFacilityDetails(i: any, j: any, k: any, label: any) {
    var err = true;
    var err1 = true;
    var err2 = true;
    if (label == "Tenor") {
      if (i !== '' && j === '' && k === '') {

        if (this.model.exposures[i].lpdTenorTo !== 0) {
          if (this.model.exposures[i].lfTenor == "")
            this.model.exposures[i].lfTenor = 0;
          err = (parseInt(this.model.exposures[i].lfTenor) >= parseInt(this.model.exposures[i].lpdTenorFrom) && parseInt(this.model.exposures[i].lfTenor) <= parseInt(this.model.exposures[i].lpdTenorTo))
          if (!err) {

            this.model.exposures[i].lfTenor = "";
            $('#level1_' + i + "_" + 10).addClass("has-error");
            $('#level1_' + i + "_" + 10).blur();
            alert("Tenor should Starts From " + this.model.exposures[i].lpdTenorFrom + "To " + this.model.exposures[i].lpdTenorTo);
          }

        }
        else {
          $('#level1_' + i + "_" + 10).addClass("has-error");
          alert("Facility Details Should be added " + i);
        }
      }
      else if (i !== '' && j !== '' && k === '') {

        if (this.model.exposures[i].facilityAgriDetailsLev2[j].lpdTenorTo !== 0) {
          if (this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor == "")
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor = 0;
          err = (parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor) >= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lpdTenorFrom) && parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lpdTenorTo))
          err1 = parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor) <= parseInt(this.model.exposures[i].lfTenor)
          if (!err) {
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor = "";
            $('#level2_' + i + "" + j + "_" + 10).addClass("has-error");
            $('#level2_' + i + "" + j + "_" + 10).blur();
            alert("Tenor should Starts From " + this.model.exposures[i].facilityAgriDetailsLev2[j].lpdTenorFrom + "To " + this.model.exposures[i].facilityAgriDetailsLev2[j].lpdTenorTo);
          }
          else if (!err1) {
            alert("Sub Facility's Tenor Should not Exceeds Main Facility's Tenor");
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor = "";
          }
        }
        else {
          var id = '#level2_' + i + "_" + 10;
          $('#level2_' + i + "" + j + "_" + 10).addClass("has-error");
          alert("Facility Details Should be added " + id);
        }
      }
      else if (i !== '' && j !== '' && k !== '') {
        if (this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdTenorTo !== 0) {
          if (this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor == "")
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor = 0;
          err = (parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor) >= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdTenorFrom) && parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdTenorTo))
          err2 = parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor);
          if (!err) {
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor = "";
            $('#level3_' + i + "" + j + "" + k + "_" + 10).addClass("has-error");
            $('#level3_' + i + "" + j + "" + k + "_" + 10).blur();
            alert("Tenor should Starts From " + this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdTenorFrom + "To " + this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdTenorTo);

          }
          else if (!err2) {
            alert("Sub Facility's Tenor Should not Exceeds Main Facility's Tenor");
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor = "";
          }
        }
        else {
          $('#level3_' + i + "" + j + "" + k + "_" + 10).addClass("has-error");
          alert("Facility Details Should be added " + i + "" + j + "" + k);
        }
      }
    }
    else if (label == "Amt") {

      if (i !== '' && j === '' && k === '') {

        if (this.model.exposures[i].lpdAmtTo !== 0) {
          if (this.model.exposures[i].lfProposedLimit == "")
            this.model.exposures[i].lfProposedLimit = 0;
          err = (parseInt(this.model.exposures[i].lfProposedLimit) >= parseInt(this.model.exposures[i].lpdAmtFrom) && parseInt(this.model.exposures[i].lfProposedLimit) <= parseInt(this.model.exposures[i].lpdAmtTo))

          if (!err) {

            this.model.exposures[i].lfProposedLimit = "";
            $('#level1_' + i + "_" + 9).addClass("has-error");
            $('#level1_' + i + "_" + 9).blur();
            alert("ProposedLimit should Starts From " + this.model.exposures[i].lpdAmtFrom + "To " + this.model.exposures[i].lpdAmtTo);

          }
        }
        else {
          $('#level1_' + i + "_" + 9).addClass("has-error");
          alert("Facility Details Should be added " + i);
        }
      }
      else if (i !== '' && j !== '' && k === '') {

        if (this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtTo !== 0) {
          if (this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit == "")
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit = 0;
          err = (parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit) >= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtFrom) && parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtTo))
          err1 = parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit) <= parseInt(this.model.exposures[i].lfProposedLimit)
          if (!err) {

            this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit = "";
            $('#level2_' + i + "" + j + "_" + 9).addClass("has-error");
            $('#level2_' + i + "" + j + "_" + 9).blur();
            alert("ProposedLimit should Starts From " + this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtFrom + "To " + this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtTo);

          }
          else if (!err1) {
            alert("Sub Facility's Proposed Limit Should not Exceeds Main Facility's Proposed Limit");
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit = "";
            this.model.exposures[i].facilityAgriDetailsLev2[j].lfTotExposure = "";
          }
        }
        else {
          var id = '#level2_' + i + "_" + 9;
          $(id).blur();
          $('#level2_' + i + "" + j + "_" + 9).addClass("has-error");
          alert("Facility Details Should be added " + id);
        }
      }
      else if (i !== '' && j !== '' && k !== '') {
        if (this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtTo !== 0) {
          if (this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit == "")
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit = 0;
          err = (parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit) >= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtFrom) && parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtTo))
          err2 = parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit) <= parseInt(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit)
          if (!err) {
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit = "";
            $('#level3_' + i + "" + j + "" + k + "_" + 9).addClass("has-error");
            $('#level3_' + i + "" + j + "" + k + "_" + 9).blur();
            alert("ProposedLimit should Starts From " + this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtFrom + "To " + this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtTo);

          }
          else if (!err2) {
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit = "";
            this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTotExposure = "";
            alert("Sub Facility's Proposed Limit Should not Exceeds Main Facility's Proposed Limit");
          }
        }
        else {
          $('#level3_' + i + "" + j + "" + k + "_" + 9).addClass("has-error");
          alert("ProposedLimit Details Should be added " + i + "" + j + "" + k);
        }
      }
    }
  }
  onFocusProductDetails(i: any, j: any, k: any, e: any) {
    var id = e.target.id;

    if (i !== '' && j === '' && k === '') {
      if (this.model.exposures[i].lpdAmtTo == 0) {
        alert("facilty should be added");
        (<HTMLInputElement>document.getElementById(id)).blur();
      }
    }
    else if (i !== '' && j !== '' && k === '') {
      if (this.model.exposures[i].facilityAgriDetailsLev2[j].lpdAmtTo == 0) {
        alert("facilty should be added");
        (<HTMLInputElement>document.getElementById(id)).blur();
      }
    }
    else if (i !== '' && j !== '' && k !== '') {
      if (this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lpdAmtTo == 0) {
        alert("facilty should be added");
        (<HTMLInputElement>document.getElementById(id)).blur();
      }
    }
  }
  toFixedOnBlur(e: any) {
    if (e.target.value != "") {
      var value = parseFloat(e.target.value).toFixed(2);
      $('#' + e.target.id).val(value);
    }

  }
  removeclass(e: any) {
    $('#' + e.target.id).removeClass("has-error");
  }

  callClose() {
    $('#mainfacId').val("s");
    $('#subfacId').val("s");
    $('#Product').modal('hide');
    this.model.LpstpProductDetailsList = [];
    this.pushDisable = true;
  }
  buttonAccess(val1: boolean, val2: boolean, val3: boolean, val4: boolean) {
    if (this.pageAccess == "R") {

      this.newbuttonDisable = true;
      this.editbuttonDisable = true;
      this.savebuttonDisable = true;
      this.cancelbuttonDisable = true;
    }
    else {

      this.newbuttonDisable = val1;
      this.editbuttonDisable = val2;
      this.savebuttonDisable = val3;
      this.cancelbuttonDisable = val4;
    }
  }
  onChangeProduct(event: any, value: any, i: any, j: any, k: any) {

    if (i !== '' && j === '' && k === '') {



      $('#level1_' + i + "_" + 7).removeClass('has-error'); //exist
      $('#level1_' + i + "_" + 8).removeClass('has-error'); //existing os
      $('#level1_' + i + "_" + 9).removeClass('has-error');  //pL
      $('#level1_' + i + "_" + 10).removeClass('has-error'); //tenor
      $('#level1_' + i + "_" + 11).removeClass('has-error'); //margin

      this.model.exposures[i].lfExistLimit = "";
      this.model.exposures[i].lfOsLimit = ""
      this.model.exposures[i].lfProposedLimit = "";
      this.model.exposures[i].lfTenor = "";
      this.model.exposures[i].lfMargin = "";
      this.model.exposures[i].lfTotExposure = "";
      if (value == 's') {


        $('#level1_' + i + "_" + 7).attr('disabled', true);  //exist
        $('#level1_' + i + "_" + 8).attr('disabled', true);  //existing os
        $('#level1_' + i + "_" + 9).attr('disabled', true);  //pL
        $('#level1_' + i + "_" + 10).attr('disabled', true); //tenor
        $('#level1_' + i + "_" + 11).attr('disabled', true); //margin
      } else
        if (value == 'R') {

          $('#level1_' + i + "_" + 7).attr('disabled', false);  //exist
          $('#level1_' + i + "_" + 8).attr('disabled', false);  //existing os
          $('#level1_' + i + "_" + 9).attr('disabled', false);  //pL
          $('#level1_' + i + "_" + 10).attr('disabled', false); //tenor
          $('#level1_' + i + "_" + 11).attr('disabled', false); //margin
        } else if (value == "T") {
          $('#level1_' + i + "_" + 7).attr('disabled', true);  //exist
          $('#level1_' + i + "_" + 8).attr('disabled', true); //existing os
          $('#level1_' + i + "_" + 9).attr('disabled', false);  //pL
          $('#level1_' + i + "_" + 10).attr('disabled', false); //tenor
          $('#level1_' + i + "_" + 11).attr('disabled', false); //margin
        } else if (value == "F") {
          $('#level1_' + i + "_" + 7).attr('disabled', true);  //exist
          $('#level1_' + i + "_" + 8).attr('disabled', true); //existing os
          $('#level1_' + i + "_" + 9).attr('disabled', false);  //pL
          $('#level1_' + i + "_" + 10).attr('disabled', false); //tenor
          $('#level1_' + i + "_" + 11).attr('disabled', false); //margin
        }

    } else if (i !== '' && j !== '' && k === '') {
      $('#level2_' + i + "" + j + "_" + 7).removeClass('has-error'); //exist
      $('#level2_' + i + "" + j + "_" + 8).removeClass('has-error'); //existing os
      $('#level2_' + i + "" + j + "_" + 9).removeClass('has-error');  //pL
      $('#level2_' + i + "" + j + "_" + 10).removeClass('has-error'); //tenor
      $('#level2_' + i + "" + j + "_" + 11).removeClass('has-error'); //margin
      $('#level2_' + i + "" + j + "_" + 15).removeClass('has-error'); //margin


      $('#level2_' + i + "" + j + "_" + 7).attr('placeholder', ''); //exist
      $('#level2_' + i + "" + j + "_" + 8).attr('placeholder', ''); //existing os
      $('#level2_' + i + "" + j + "_" + 9).attr('placeholder', '');  //pL
      $('#level2_' + i + "" + j + "_" + 10).attr('placeholder', ''); //tenor
      $('#level2_' + i + "" + j + "_" + 11).attr('placeholder', ''); //margin


      this.model.exposures[i].facilityAgriDetailsLev2[j].lfExistLimit = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].lfOsLimit = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].lfTenor = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].lfMargin = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].lfTotExposure = "";

      if (value == 's') {
        $('#level2_' + i + "" + j + "_" + 7).attr('disabled', true); //exist
        $('#level2_' + i + "" + j + "_" + 8).attr('disabled', true); //existing os
        $('#level2_' + i + "" + j + "_" + 9).attr('disabled', true); //pL
        $('#level2_' + i + "" + j + "_" + 10).attr('disabled', true); //tenor
        $('#level2_' + i + "" + j + "_" + 11).attr('disabled', true); //margin
      } else
        if (value == 'R') {
          $('#level2_' + i + "" + j + "_" + 7).attr('disabled', false); //exist
          $('#level2_' + i + "" + j + "_" + 8).attr('disabled', false); //existing os
          $('#level2_' + i + "" + j + "_" + 9).attr('disabled', false); //pL
          $('#level2_' + i + "" + j + "_" + 10).attr('disabled', false); //tenor
          $('#level2_' + i + "" + j + "_" + 11).attr('disabled', false); //margin
        } else if (value == "T") {
          $('#level2_' + i + "" + j + "_" + 7).attr('disabled', true);  //exist
          $('#level2_' + i + "" + j + "_" + 8).attr('disabled', true); //existing os
          $('#level2_' + i + "" + j + "_" + 9).attr('disabled', false);//pL
          $('#level2_' + i + "" + j + "_" + 10).attr('disabled', false); //tenor
          $('#level2_' + i + "" + j + "_" + 11).attr('disabled', false);//margin
        } else if (value == "F") {
          $('#level2_' + i + "" + j + "_" + 7).attr('disabled', true);  //exist
          $('#level2_' + i + "" + j + "_" + 8).attr('disabled', true); //existing os
          $('#level2_' + i + "" + j + "_" + 9).attr('disabled', false);  //pL
          $('#level2_' + i + "" + j + "_" + 10).attr('disabled', false); //tenor
          $('#level2_' + i + "" + j + "_" + 11).attr('disabled', false); //margin
        }

    } else if (i !== '' && j !== '' && k !== '') {
      $('#level3_' + i + "" + j + "" + k + "_" + 7).removeClass('has-error'); //exist
      $('#level3_' + i + "" + j + "" + k + "_" + 8).removeClass('has-error'); //existing os
      $('#level3_' + i + "" + j + "" + k + "_" + 9).removeClass('has-error');  //pL
      $('#level3_' + i + "" + j + "" + k + "_" + 10).removeClass('has-error'); //tenor
      $('#level3_' + i + "" + j + "" + k + "_" + 11).removeClass('has-error'); //margin
      $('#level3_' + i + "" + j + "" + k + "_" + 15).removeClass('has-error');

      $('#level3_' + i + "" + j + "" + k + "_" + 7).attr('placeholder', ''); //exist
      $('#level3_' + i + "" + j + "" + k + "_" + 8).attr('placeholder', ''); //existing os
      $('#level3_' + i + "" + j + "" + k + "_" + 9).attr('placeholder', '');  //pL
      $('#level3_' + i + "" + j + "" + k + "_" + 10).attr('placeholder', ''); //tenor
      $('#level3_' + i + "" + j + "" + k + "_" + 11).attr('placeholder', ''); //margin



      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfExistLimit = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfOsLimit = "";

      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTenor = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfMargin = "";
      this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTotExposure = "";

      if (value == 's') {
        $('#level3_' + i + "" + j + "" + k + "_" + 7).attr('disabled', true);  //exist
        $('#level3_' + i + "" + j + "" + k + "_" + 8).attr('disabled', true);  //existing os
        $('#level3_' + i + "" + j + "" + k + "_" + 9).attr('disabled', true);  //pL
        $('#level3_' + i + "" + j + "" + k + "_" + 10).attr('disabled', true);//tenor
        $('#level3_' + i + "" + j + "" + k + "_" + 11).attr('disabled', true); //margin
      } else if (value == 'R') {
        $('#level3_' + i + "" + j + "" + k + "_" + 7).attr('disabled', false);  //exist
        $('#level3_' + i + "" + j + "" + k + "_" + 8).attr('disabled', false);  //existing os
        $('#level3_' + i + "" + j + "" + k + "_" + 9).attr('disabled', false);  //pL
        $('#level3_' + i + "" + j + "" + k + "_" + 10).attr('disabled', false);//tenor
        $('#level3_' + i + "" + j + "" + k + "_" + 11).attr('disabled', false); //margin
      } else if (value == "T") {
        $('#level3_' + i + "" + j + "" + k + "_" + 7).attr('disabled', true);  //exist
        $('#level3_' + i + "" + j + "" + k + "_" + 8).attr('disabled', true); //existing os
        $('#level3_' + i + "" + j + "" + k + "_" + 9).attr('disabled', false); //pL
        $('#level3_' + i + "" + j + "" + k + "_" + 10).attr('disabled', false); //tenor
        $('#level3_' + i + "" + j + "" + k + "_" + 11).attr('disabled', false); //margin
      } else if (value == "F") {
        $('#level3_' + i + "" + j + "" + k + "_" + 7).attr('disabled', true);  //exist
        $('#level3_' + i + "" + j + "" + k + "_" + 8).attr('disabled', true); //existing os
        $('#level3_' + i + "" + j + "" + k + "_" + 9).attr('disabled', false); //pL
        $('#level3_' + i + "" + j + "" + k + "_" + 10).attr('disabled', false); //tenor
        $('#level3_' + i + "" + j + "" + k + "_" + 11).attr('disabled', false); //margin
      }

    }

  }
  calculateExposureAmount(i: any, j: any, k: any, obj: any) {
    if (i !== '' && j === '' && k === '') {
      if (obj.lfLoanType == "T" || obj.lfLoanType == "F") {
        this.model.exposures[i].lfTotExposure = this.parseEmptytoFloat(this.model.exposures[i].lfProposedLimit).toFixed(2);

      }
      else if (obj.lfLoanType == "R") {
        let value = this.findMaxValue(this.parseEmptytoFloat(this.model.exposures[i].lfProposedLimit).toFixed(2), this.parseEmptytoFloat(this.model.exposures[i].lfOsLimit).toFixed(2));
        this.model.exposures[i].lfTotExposure = value;
      }
    }
    else if (i !== '' && j !== '' && k === '') {
      if (obj.lfLoanType == "T" || obj.lfLoanType == "F") {
        this.model.exposures[i].facilityAgriDetailsLev2[j].lfTotExposure = this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit).toFixed(2);

      }
      else if (obj.lfLoanType == "R") {
        let value = this.findMaxValue(this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].lfProposedLimit).toFixed(2), this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].lfOsLimit).toFixed(2));
        this.model.exposures[i].facilityAgriDetailsLev2[j].lfTotExposure = value;
      }



    } else if (i !== '' && j !== '' && k !== '') {
      if (obj.lfLoanType == "T" || obj.lfLoanType == "F") {
        this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTotExposure = this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit).toFixed(2);
      }
      else if (obj.lfLoanType == "R") {
        let value = this.findMaxValue(this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfProposedLimit).toFixed(2), this.parseEmptytoFloat(this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfOsLimit).toFixed(2));
        this.model.exposures[i].facilityAgriDetailsLev2[j].facilityAgriDetailsLev3[k].lfTotExposure = value;
      }


    }
  }

  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

  findMaxValue(value1: any, value2: any) {
    if (this.parseEmptytoFloat(value1) >= this.parseEmptytoFloat(value2)) {
      return value1;
    }
    else
      return value2;
  }
  totalLimit() {
    var rowCount1 = 0;
    var rowCount2 = 0;
    var rowCount3 = 0;
    this.totalExistingLimit = 0;
    this.totalOutStandingLimit = 0;
    this.totalProposedLimit = 0;
    this.totalExposure = 0;

    var totalExistingLimit = 0;
    var totalOutStandingLimit = 0;
    var totalProposedLimit = 0;
    var totalExposure = 0;

    this.model.exposures.forEach(field1 => {

      if (field1.lfExistLimit != "")
        totalExistingLimit += parseFloat(field1.lfExistLimit);
      if (field1.lfOsLimit != "")
        totalOutStandingLimit += parseFloat(field1.lfOsLimit);
      if (field1.lfProposedLimit != "")
        totalProposedLimit += parseFloat(field1.lfProposedLimit);
      if (field1.lfTotExposure != "")
        totalExposure += parseFloat(field1.lfTotExposure);
      rowCount1++;
    });

    this.totalExistingLimit = totalExistingLimit.toFixed(2);
    this.totalOutStandingLimit = totalOutStandingLimit.toFixed(2);
    this.totalProposedLimit = totalProposedLimit.toFixed(2);
    this.totalExposure = totalExposure.toFixed(2);
  }
  getfacorder()
  {
    this.model.exposures.forEach((field1,index) => {
     field1.lfFacOrderno=index+1;
      field1.facilityAgriDetailsLev2.forEach((field2,index) => {
       field2.lfFacOrderno=field1.lfFacOrderno+"."+(index+1);
        field2.facilityAgriDetailsLev3.forEach((field3,index) => {
          field3.lfFacOrderno=field2.lfFacOrderno+"."+(index+1);
         });
      });
    });
  }

}
