import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposedfacilitiesComponent } from './proposedfacilities.component';

describe('ProposedfacilitiesComponent', () => {
  let component: ProposedfacilitiesComponent;
  let fixture: ComponentFixture<ProposedfacilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposedfacilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposedfacilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
