import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ExistingbankdetComponent } from './agri/existingbankdet/existingbankdet.component';
import { LpagrireferencedetComponent } from './agri/lpagrireferencedet/lpagrireferencedet.component';
import { ApplicantplaceComponent } from './agri/applicantplace/applicantplace.component';
import { OwnedlanddetailsComponent } from './agri/ownedlanddetails/ownedlanddetails.component';
import { CurrentcroppatternComponent } from './agri/currentcroppattern/currentcroppattern.component';
import { ExistingcroppatternComponent } from './agri/existingcroppattern/existingcroppattern.component';
import { CropexistingloandetailsComponent } from './agri/cropexistingloandetails/cropexistingloandetails.component';
import { FleetandloandetailsComponent} from './agri/fleetandloandetails/fleetandloandetails.component';
import { AdditionalincomeComponent } from './corporate/additionalincome/additionalincome.component';
import { LeaselanddetailsComponent } from './agri/leaselanddetails/leaselanddetails.component';
import { AgripslclassificationComponent } from './agri/agripslclassification/agripslclassification.component';
import { KkrpremiumComponent } from './agri/kkrpremium/kkrpremium.component';
@NgModule({
  imports:[RouterModule.forChild([
    { path: 'existingbankdet', component: ExistingbankdetComponent },
    { path: 'Reference', component: LpagrireferencedetComponent },
    { path: 'applicantplace', component: ApplicantplaceComponent },
    { path: 'ownedlanddetails', component: OwnedlanddetailsComponent },
    { path: 'currentcroppattern', component: CurrentcroppatternComponent },
    { path: 'existingcroppattern', component: ExistingcroppatternComponent },
    { path: 'cropexistingotherbank', component: CropexistingloandetailsComponent },
    { path: 'fleetandloandetails', component: FleetandloandetailsComponent },
    { path: 'additionalinc', component: AdditionalincomeComponent },
    { path: 'leaselanddetails', component: LeaselanddetailsComponent },  
    { path: 'agripsl', component: AgripslclassificationComponent },  
   { path: 'kkrpremium', component: KkrpremiumComponent },
  ])
],
exports: [
  RouterModule
]
})
export class AgripropdataentryroutingModule { }
