import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './shared.module';
import { AgripropdataentryroutingModule } from './agripropdataentryrouting.module';
import { ExistingbankdetComponent } from './agri/existingbankdet/existingbankdet.component';
import { ExistingbankdetService } from './util/service/agriservices/existingbankdet.service';
import { LpagrireferencedetComponent } from './agri/lpagrireferencedet/lpagrireferencedet.component';
import { LpagrireferenceService } from './util/service/agriservices/lpagrireference.service';
import { ApplicantplaceComponent } from './agri/applicantplace/applicantplace.component';
import { ApplicantplaceService } from './util/service/agriservices/applicantplace.service';
import { OwnedlanddetailsComponent } from './agri/ownedlanddetails/ownedlanddetails.component';
import { OwnedlanddetailsService } from './util/service/agriservices/ownedlanddetails.service';
import { CurrentcroppatternComponent } from './agri/currentcroppattern/currentcroppattern.component';
import { CurrentcroppatternService } from './util/service/agriservices/currentcroppattern.service';
import { ExistingcroppatternComponent } from './agri/existingcroppattern/existingcroppattern.component';
import { ExistingcroppatternService } from './util/service/agriservices/existingcroppattern.service';
import { CropexistingloandetailsComponent } from './agri/cropexistingloandetails/cropexistingloandetails.component';
import { CropexistingloandetailsService } from './util/service/agriservices/cropexistingloandetails.service';
import { FleetandloandetailsComponent} from './agri/fleetandloandetails/fleetandloandetails.component';
import { FleetandloandetailsService } from './util/service/agriservices/fleetandloandetails.service';
import { AdditionalincomeComponent } from './corporate/additionalincome/additionalincome.component';
import { AdditionalincService } from './util/service/agriservices/additionalinc.service';
import { LeaselanddetailsComponent } from './agri/leaselanddetails/leaselanddetails.component';
import { LeaselanddetService } from './util/service/agriservices/leaselanddet.service';
import { AgripslclassificationComponent } from './agri/agripslclassification/agripslclassification.component';
import { AgripslclassificationService } from './util/service/agriservices/agripslclassification.service';
import { StgeographymasterService } from './util/service/setupservices/stgeographymaster.service';
import { KkrpremiumComponent } from './agri/kkrpremium/kkrpremium.component';
import { KkrpremiumService } from './util/service/agriservices/kkrpremium.service';
@NgModule({
  imports: [
    SharedModule,
    AgripropdataentryroutingModule
  ],
  declarations: [ExistingbankdetComponent,LpagrireferencedetComponent,ApplicantplaceComponent,OwnedlanddetailsComponent,
    CurrentcroppatternComponent,ExistingcroppatternComponent,CropexistingloandetailsComponent,FleetandloandetailsComponent,AdditionalincomeComponent,
    LeaselanddetailsComponent,AgripslclassificationComponent,KkrpremiumComponent],
  providers:[ExistingbankdetService,LpagrireferenceService,ApplicantplaceService,OwnedlanddetailsService,
    CurrentcroppatternService,ExistingcroppatternService,CropexistingloandetailsService,FleetandloandetailsService,AdditionalincService,
    LeaselanddetService,AgripslclassificationService,StgeographymasterService,KkrpremiumService]
})
export class AgripropdataentryModule { }
