import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApplicationcontroldataComponent } from './master/applicationcontroldata/applicationcontroldata.component';
import { ListvaluemasterComponent } from './setup/listvaluemaster/listvaluemaster.component';
import { DenominationmasterComponent } from './setup/denominationmaster/denominationmaster.component';
import { InterfacelinkComponent } from './master/interfacelink/interfacelink.component';
import { GeographymasterComponent } from './setup/geographymaster/geographymaster.component';
import { TakeovermasterComponent } from './setup/takeovermaster/takeovermaster.component';
import { DocumentmastersComponent } from "./setup/documentmasters/documentmasters.component";
import { TermsandconditionmasterComponent } from './setup/termsandconditionmaster/termsandconditionmaster.component';
import { OrganizationlevelComponent } from './setup/organizationlevel/organizationlevel.component';
import { OrganizationComponent } from './setup/organization/organization.component';
import { UsersgroupComponent } from './setup/usersgroup/usersgroup.component';
import { UsersComponent } from './setup/users/users.component';
import { UserClassComponent } from './setup/userclass/userclass.component';
import { LocationmappingComponent } from './setup/locationmapping/locationmapping.component';
import { MailtemplateComponent } from './setup/mailtemplate/mailtemplate.component';
import { EmailtemplatemappingComponent } from "./setup/emailtemplatemapping/emailtemplatemapping.component";

import { ApplicationcontroldataService } from "./util/service/masterservices/applicationcontroldata.service";
import {DenominationService} from "./util/service/setupservices/denomination.service";
import { InterfacelinkService } from './util/service/masterservices/interfacelink.service';
import { ListValueMasterService } from "./util/service/setupservices/listvaluemaster.service";
import { StgeographymasterService } from "./util/service/setupservices/stgeographymaster.service";
import { TakeovermasterService } from "./util/service/setupservices/takeovermaster.service";
import { DocumentmastersService } from "./util/service/setupservices/documentmasters.service";
import { TermsandconditionmasterService } from "./util/service/setupservices/termsandconditionmaster.service";
import { OrganizationlevelService } from "./util/service/setupservices/organizationlevel.service";
import { MailtemplateService } from "./util/service/setupservices/mailtemplate.service";
import { OrganizationService } from "./util/service/setupservices/organization.service";
import { UsersService } from "./util/service/setupservices/users.service";
import { UsersgroupService } from "./util/service/setupservices/usersgroup.service";
import { UserClassService } from "./util/service/setupservices/userclass.service";
import { LocationmappingService } from "./util/service/setupservices/locationmapping.service";
import { EmailtemplatemappingService } from "./util/emailtemplatemapping.service";

import { Fieldvalidation } from "./util/helper/fieldvalidation";
import { AppmasterroutingModule } from './appmasterrouting.module';
import { SharedModule } from './shared.module';
import { BrowserModule } from '@angular/platform-browser'; 
import { TalukmasterComponent } from './setup/talukmaster/talukmaster.component';




@NgModule({
  imports: [
    AppmasterroutingModule,
    SharedModule
  ],
  declarations: [ListvaluemasterComponent,ApplicationcontroldataComponent,InterfacelinkComponent,
    DenominationmasterComponent, 
    GeographymasterComponent,
    TakeovermasterComponent,
    DocumentmastersComponent,
    TermsandconditionmasterComponent,OrganizationlevelComponent,OrganizationComponent,UsersgroupComponent,UsersComponent,LocationmappingComponent,MailtemplateComponent,
    UserClassComponent,EmailtemplatemappingComponent,TalukmasterComponent
   ],
    providers: [ApplicationcontroldataService,DenominationService,InterfacelinkService,ListValueMasterService,
      ApplicationcontroldataService,DenominationService,InterfacelinkService,ListValueMasterService,Fieldvalidation,
      StgeographymasterService,TakeovermasterService,DocumentmastersService,TermsandconditionmasterService,OrganizationService,MailtemplateService,UsersService,UsersgroupService,
      UserClassService,OrganizationlevelService,LocationmappingService,EmailtemplatemappingService]
  
})
export class AppmasterModule { }
