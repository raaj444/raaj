import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SecuritymasterComponent } from "./setup/securitymaster/securitymaster.component";
import { CmaformulamasterComponent } from './setup/cmaformulamaster/cmaformulamaster.component';
import { CmaFinmasterComponent } from './setup/cmamaster/cmamaster.component';
import { AssessmentComponent } from './setup/assessment/assessment.component';
import { AnnexuremasterComponent } from "./setup/annexuremaster/annexuremaster.component";
import { CranmasterComponent } from './setup/cranmaster/cranmaster.component';
import { DeviationmasterComponent } from './setup/deviationmaster/deviationmaster.component';
import { WorkflowmasterComponent } from './setup/workflowmaster/workflowmaster.component';
import { FacilitydetailsComponent } from "./setup/facilitydetails/facilitydetails.component";
import { SchememasterComponent } from './setup/schememaster/schememaster.component';
import { ProductsearchComponent } from "./setup/productsearch/productsearch.component";
import { ScorecardmasterComponent } from './setup/scorecardmaster/scorecardmaster.component';
import { QualitativemasterComponent } from "./setup/qualitativemaster/qualitativemaster.component";
import { PSLLovMasterComponent } from './master/psllovmaster/psllovmaster.component';
import { PSLMasterComponent } from './setup/pslmaster/pslmaster.component';
import { SofmasterComponent } from './master/sofmaster/sofmaster.component';
import { LpyieldmasterComponent } from './master/lpyieldmaster/lpyieldmaster.component';
import { ScorecardbusinessruleComponent } from "./setup/agriscorecardbusinessrule/agriscorecardbusinessrule.component";
import { AgrisofdeviationComponent } from './agri/agrisofdeviation/agrisofdeviation.component';
import { AgrileaselanddeviationComponent } from './agri/agrileaselanddeviation/agrileaselanddeviation.component';
import { StlvehincdeviationComponent } from './agri/stlvehincdeviation/stlvehincdeviation.component';
import { MclrmasterComponent } from './master/mclrmaster/mclrmaster.component';
import { PslclassificationmastComponent } from './master/pslclassificationmast/pslclassificationmast.component';
import { CommunitymasterComponent } from './agri/communitymaster/communitymaster.component';
import { AtlfacpurposemasterComponent } from './agri/atlfacpurposemaster/atlfacpurposemaster.component';
import { PslautomationComponent } from './agri/pslautomation/pslautomation.component';
import { HolidaymasterComponent } from "./setup/holidaymaster/holidaymaster.component";
import { SltemplatemasterComponent } from "./setup/sltemplatemaster/sltemplatemaster.component";
import { AssessmentconfigComponent } from './setup/assessmentconfig/assessmentconfig.component';
import { FlowpointComponent } from './setup/flowpoint/flowpoint.component';
import { PagelistComponent } from './setup/pagelist/pagelist.component';
import { ProducttabnavigationComponent } from './setup/producttabnavigation/producttabnavigation.component';
import { UdfmasterComponent } from './setup/udfmaster/udfmaster.component';
import { InternalratingmasterComponent } from './setup/internalratingmaster/internalratingmaster.component';
import { PeercomparisonorderingComponent } from './setup/peercomparisonordering/peercomparisonordering.component';
import { ManualdopComponent } from './common/manualdop/manualdop.component';

@NgModule({
  imports: [
    RouterModule.forChild([

      { path: 'atlpurposemaster', component: AtlfacpurposemasterComponent },
      { path: 'pslautomaster', component: PslautomationComponent },
      { path: 'securitymaster', component: SecuritymasterComponent },
      { path: 'deviationmaster', component: DeviationmasterComponent },
      { path: 'pslmaster', component: PSLMasterComponent },
      { path: 'productsearch', component: ProductsearchComponent },
      { path: 'scheme', component: SchememasterComponent },
      { path: 'holiday', component: HolidaymasterComponent },
      { path: 'sofmaster', component: SofmasterComponent },
      { path: 'pslclassificationmast', component: PslclassificationmastComponent },
      { path: 'Yieldmaster', component: LpyieldmasterComponent },
      { path: 'cranmaster', component: CranmasterComponent },
      { path: 'psllovmaster', component: PSLLovMasterComponent },
      { path: 'assessment', component: AssessmentComponent },
      { path: 'sltemplatemaster', component: SltemplatemasterComponent },
      { path: 'scorecardbusinessrule', component: ScorecardbusinessruleComponent },
      { path: 'facilitydetails', component: FacilitydetailsComponent },
      { path: 'qualitativemaster', component: QualitativemasterComponent },
      { path: 'scorecardmaster', component: ScorecardmasterComponent },
      { path: 'annexuremaster', component: AnnexuremasterComponent },
      { path: 'formulamaster', component: CmaformulamasterComponent },
      { path: 'workflowmaster', component: WorkflowmasterComponent },
      { path: 'finmaster', component: CmaFinmasterComponent },
      { path: 'sofdeviation', component: AgrisofdeviationComponent },
      { path: 'leaselanddeviation', component: AgrileaselanddeviationComponent },
      { path: 'communitymaster', component: CommunitymasterComponent },
      { path: 'mclrmaster', component: MclrmasterComponent },
      { path: 'stlvehincdev', component: StlvehincdeviationComponent },
      { path: 'assessmentconfig', component: AssessmentconfigComponent },
      { path: 'flowpoint', component: FlowpointComponent },
      { path: 'pagelist', component: PagelistComponent },
      { path: 'tabnavigation', component: ProducttabnavigationComponent },
      { path: 'udfmaster', component: UdfmasterComponent },
      { path: 'internalrating', component: InternalratingmasterComponent },
      { path: 'peercomparisonordering', component: PeercomparisonorderingComponent },
      { path: 'manualdop', component: ManualdopComponent },
    ])
  ],
  exports: [
    RouterModule
  ]
})

export class BusisetuproutingModule { }
