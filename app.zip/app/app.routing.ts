import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
//                ---------------AGRICULTURE---------------
import { CurrentcroppatternComponent } from './agri/currentcroppattern/currentcroppattern.component';
import { ExistingcroppatternComponent } from './agri/existingcroppattern/existingcroppattern.component';
import { FleetandloandetailsComponent } from './agri/fleetandloandetails/fleetandloandetails.component';
import { LpagrireferencedetComponent } from './agri/lpagrireferencedet/lpagrireferencedet.component';
import { OwnedlanddetailsComponent } from './agri/ownedlanddetails/ownedlanddetails.component';
import { ExistingexposureComponent } from './agri/existingexposure/existingexposure.component';
import { ProposedfacilitiesComponent } from './agri/proposedfacilities/proposedfacilities.component';
import { KccassessmentComponent } from './agri/kccassessment/kccassessment.component';
import { DscrassessmentComponent } from './agri/dscrassessment/dscrassessment.component';
import { ExistingcustrefComponent } from './agri/existingcustref/existingcustref.component';
import { AgritermloanComponent } from './agri/agritermloan/agritermloan.component';
import { KccacuntmaturityComponent } from './agri/kccacuntmaturity/kccacuntmaturity.component';
import { AgridroplineodComponent } from "./agri/agridroplineod/agridroplineod.component";
import { AgridroplinedetailsComponent } from "./agri/agridroplinedetails/agridroplinedetails.component";
import { AgrisofdeviationComponent } from './agri/agrisofdeviation/agrisofdeviation.component';
import { AgrileaselanddeviationComponent } from './agri/agrileaselanddeviation/agrileaselanddeviation.component';
import { StlvehincdeviationComponent } from './agri/stlvehincdeviation/stlvehincdeviation.component';
import { CommunitymasterComponent } from './agri/communitymaster/communitymaster.component';
import { AtlfacpurposemasterComponent } from './agri/atlfacpurposemaster/atlfacpurposemaster.component';
import { PslautomationComponent } from './agri/pslautomation/pslautomation.component';
import { AgripslclassificationComponent } from './agri/agripslclassification/agripslclassification.component';
//                ---------------CORPORATE---------------
import { AgrilandholdingComponent } from './corporate/agrilandholding/agrilandholding.component';
import { BuyersupplierComponent } from './corporate/buyersupplier/buyersupplier.component';
import { CallreportComponent } from './corporate/callreport/callreport.component';
import { CropselectionComponent } from './corporate/cropselection/cropselection.component';
import { DebtorsComponent } from './corporate/debtors/debtors.component';
import { GuaranteedetailsComponent } from './corporate/guaranteedetails/guaranteedetails.component';
import { LpcorpexistingexposureComponent } from './corporate/lpcorpexistingexposure/lpcorpexistingexposure.component';
import { LpcropmodelsalesComponent } from './corporate/lpcropmodelsales/lpcropmodelsales.component';
import { RatingComponent } from './corporate/rating/rating.component';
import { RbipslclauseComponent } from './corporate/rbipslclause/rbipslclause.component';
import { TaratingscreenComponent } from './corporate/taratingscreen/taratingscreen.component';
import { WcanalysisComponent } from './corporate/wcanalysis/wcanalysis.component';
import { WcchurncfComponent } from './corporate/wcchurncf/wcchurncf.component';
import { AccountconductcommentComponent } from "./corporate/accountconductcomment/accountconductcomment.component";
import { PartyotherinfoComponent } from "./corporate/partyotherinfo/partyotherinfo.component";
import { CustomerdetailsComponent } from "./corporate/customerdetails/customerdetails.component";
import { FxexposureComponent } from "./corporate/fxexposure/fxexposure.component";
import { CirannxComponent } from "./corporate/cirannx/cirannx.component";
import { CompsheetannexComponent } from "./corporate/compsheetannex/compsheetannex.component";
import { BcacannexComponent } from "./corporate/bcacannex/bcacannex.component";
import { CompcpannexComponent } from "./corporate/compcpannex/compcpannex.component";
import { Sales26asgstComponent } from './corporate/sales26asgst/sales26asgst.component';
import { ExposuredetailsComponent } from "./corporate/exposuredetails/exposuredetails.component";
import { DynmassessmntComponent } from "./corporate/dynmassessmnt/dynmassessmnt.component";
import { AccountconductanalysisComponent } from "./corporate/accountconductanalysis/accountconductanalysis.component";
import { IpletterComponent } from './corporate/ipletter/ipletter.component';
import { FinancialsComponent } from './corporate/financials/financials.component';
import { GrpfinancialsComponent } from './corporate/grpfinancials/grpfinancials.component';
import { GrpcmpyfinancialsComponent } from './corporate/grpcmpyfinancials/grpcmpyfinancials.component';
import { PeerfinancialsComponent } from './corporate/peerfinancials/peerfinancials.component';
import { FinancialratioComponent } from './corporate/financialratio/financialratio.component';
import { WorkingcapitalComponent } from './corporate/workingcapital/workingcapital.component';
import { SalesvalidationComponent } from './corporate/salesvalidation/salesvalidation.component';
import { UploadformatComponent } from './corporate/uploadformat/uploadformat.component';
import { TaproductComponent } from './corporate/taproduct/taproduct.component';
import { TasalesComponent } from './corporate/ta/tasales/tasales.component';
import { TaretailComponent } from './corporate/ta/taretail/taretail.component';
import { TaprojectedsalesComponent } from './corporate/ta/taprojectedsales/taprojectedsales.component';
import { CropdscrassessmentComponent } from './corporate/cropdscrassessment/cropdscrassessment.component';
import { CropmpbffassessmentComponent } from './corporate/cropmpbffassessment/cropmpbffassessment.component';
import { AdditionalincomeComponent } from './corporate/additionalincome/additionalincome.component';
//              --------------- COMMON  -------------------
import { LoginComponent } from './common/login/login.component';
import { HomeComponent } from './common/home/home.component';
import { CasedetailsrmComponent } from './common/casedetailsrm/casedetailsrm.component';
import { CasedetailcreditComponent } from './common/casedetailcredit/casedetailcredit.component';
import { TakeoverComponent } from './common/takeover/takeover.component';
import { SourcingdetailsComponent } from './common/sourcingdetails/sourcingdetails.component';
import { ShareholdingpatternComponent } from './common/shareholdingpattern/shareholdingpattern.component';
import { VehicledetailsComponent } from './common/vehicledetails/vehicledetails.component'
import { PlntmchnrydetComponent } from './common/plntmchnrydet/plntmchnrydet.component';
import { BankdepositsComponent } from "./common/bankdeposits/bankdeposits.component";
import { FindoctrdtrnComponent } from "./common/findoctrdtrn/findoctrdtrn.component";
import { FindocntrdntrnComponent } from "./common/findocntrdntrn/findocntrdntrn.component";
import { FurniturefixturesComponent } from "./common/furniturefixtures/furniturefixtures.component";
import { PropertydetailsComponent } from "./common/propertydetails/propertydetails.component";
import { SecuritydetailsComponent } from "./common/securitydetails/securitydetails.component";
import { DocumentdetailsComponent } from "./common/documentdetails/documentdetails.component";
import { SearchmasterComponent } from "./common/searchmaster/searchmaster.component";
import { GoodsdetailsComponent } from "./common/goodsdetails/goodsdetails.component";
import { JeweldetailsComponent } from "./common/jeweldetails/jeweldetails.component";
import { BankingarrangementComponent } from "./common/bankingarrangement/bankingarrangement.component";
import { FacilityborrowermappingComponent } from "./common/facilityborrowermapping/facilityborrowermapping.component";
import { SearchComponent } from "./common/search/search.component";
import { NewproposalComponent } from './common/newproposal/newproposal.component';
import { ProprecommendComponent } from "./common/proprecommend/proprecommend.component";
import { AdditionalinfoComponent } from './common/additionalinfo/additionalinfo.component';
import { FacilityRecommendComponent } from "./common/facilityrecommend/facilityrecommend.component";
import { ProposalloginComponent } from './common/proposallogin/proposallogin.component';
import { TemplateloaderComponent } from "./common/cranformat/templateloader/templateloader.component";
import { QueryrequestComponent } from "./common/queryrequest/queryrequest.component";
import { QueryresponseComponent } from './common/queryresponse/queryresponse.component';
import { ProposalsecuritiesComponent } from './common/proposalsecurities/proposalsecurities.component';
import { PropassignedmeComponent } from './common/propassignedme/propassignedme.component';
import { AssignedtogroupComponent } from './common/assignedtogroup/assignedtogroup.component';
import { DedupescreenComponent } from './common/dedupescreen/dedupescreen.component';
import { PSLClassificationComponent } from './common/pslclassification/pslclassification.component';
import { SeccomfortComponent } from './common/seccomfort/seccomfort.component';
import { FacilitysecmappingComponent } from './common/facilitysecmapping/facilitysecmapping.component';
import { SecuritycoverageComponent } from './common/securitycoverage/securitycoverage.component';
import { Prev3sanctionComponent } from './common/prev3sanction/prev3sanction.component';
import { EligibilityComponent } from './common/eligibility/eligibility.component';
import { InternalratingComponent } from './common/internalrating/internalrating.component';
import { BasedonfacComponent } from './common/basedonfac/basedonfac.component';
import { JustificationpointsComponent } from './common/justificationpoints/justificationpoints.component';
import { RcuComponent } from './common/rcu/rcu.component';
import { LegaldetailsComponent } from './common/legaldetails/legaldetails.component';
import { TechnicaldetailsComponent } from './common/technicaldetails/technicaldetails.component';
import { DeviationtrackingComponent } from './common/deviationtracking/deviationtracking.component';
import { BusinessapprovalComponent } from './common/businessapproval/businessapproval.component';
import { ChangenoteComponent } from './common/changenote/changenote.component';
import { QueryhistoryComponent } from './common/queryhistory/queryhistory.component';
import { WorkflowhistoryComponent } from './common/workflowhistory/workflowhistory.component';
import { PagecommentComponent } from './common/pagecomment/pagecomment.component';
import { ResponsereceivedComponent } from "./common/responsereceived/responsereceived.component";
import { QueriesreceivedComponent } from "./common/queriesreceived/queriesreceived.component";
import { HeaderpagenavComponent } from './common/headerpagenav/headerpagenav.component';
import { DynamiccomponentComponent } from './common/dynamiccomponent/dynamiccomponent.component';
import { MailboxComponent } from './common/mailbox/mailbox.component';
import { IpComponent } from './common/ip/ip.component';
import { IpacceptanceComponent } from './common/ipacceptance/ipacceptance.component';
import { UploadfileComponent } from './common/uploadfile/uploadfile.component';
import { BorrowerrelationshipComponent } from "./common/borrowerrelationship/borrowerrelationship.component";
import { BuisnessupdatesComponent } from './common/buisnessupdates/buisnessupdates.component';
import { ExposuredetComponent } from './common/exposuredet/exposuredet.component';
import { RcudocumentComponent } from './common/rcudocument/rcudocument.component';
import { RcusupervisorComponent } from './common/rcusupervisor/rcusupervisor.component';
import { RcuprofiledetComponent } from './common/rcuprofiledet/rcuprofiledet.component';
import { WorkflowComponent } from './common/workflow/workflow.component';
import { ProposaldetailsComponent } from './common/proposaldetails/proposaldetails.component';
import { ExternalagencyComponent } from './common/externalagency/externalagency.component';
import { RmdocumentComponent } from './common/rmdocument/rmdocument.component';
import { ProptermsandconditionsComponent } from './common/proptermsandconditions/proptermsandconditions.component';
import { StatusbarComponent } from './common/statusbar/statusbar.component';
import { TermsearchComponent } from "./common/termsearch/termsearch.component";
import { PrdassearchComponent } from "./common/prdassearch/prdassearch.component";
import { TeaminboxComponent } from './common/teaminbox/teaminbox.component';
import { TatComponent } from './common/tat/tat.component';
import { HygeinechkComponent } from "./common/hygeinechk/hygeinechk.component";
import { ScorecardcalcComponent } from "./common/scorecardcalc/scorecardcalc.component";
import { FinancialanalysisComponent } from "./common/financialanalysis/financialanalysis.component";
import { SemsComponent } from "./common/sems/sems.component";
import { RcuproposallistComponent } from './common/rcuproposallist/rcuproposallist.component';
import { LegalproposallistComponent } from './common/legalproposallist/legalproposallist.component';
import { TechnicalproposallistComponent } from './common/technicalproposallist/technicalproposallist.component';
import { ManualassessmentComponent } from './common/manualassessment/manualassessment.component';
import { TechnicalinboxComponent } from './common/technicalinbox/technicalinbox.component';
import { PropertyscoreComponent } from './common/Propertyscore/Propertyscore.component';
import { CrancommentsComponent } from "./common/crancomments/crancomments.component";
import { ExternalvaluerComponent } from "./common/externalvaluer/externalvaluer.component";
import { TechnicalvaluationComponent } from "./common/technicalvaluation/technicalvaluation.component";
import { InternalvaluationComponent } from "./common/internalvaluation/internalvaluation.component";
import { SlpreparationComponent } from "./common/slpreparation/slpreparation.component";
import { HyginepopupComponent } from "./common/hyginepopup/hyginepopup.component";
import { SlgenerateComponent } from "./common/slgenerate/slgenerate.component";
import { TechnicalreportComponent } from './common/technicalreport/technicalreport.component';
import {RcureportComponent} from './common/rcureport/rcureport.component';
import { LegalverificationComponent } from './common/legalverification/legalverification.component';
import { ProposalrenewalComponent } from "./common/proposalrenewal/proposalrenewal.component";
import { PerfiosComponent } from './common/perfios/perfios.component';
import { LegalreportComponent } from './common/legalreport/legalreport.component';
import { AddendumslComponent } from './common/addendumsl/addendumsl.component';
import {GroupcrantemplateComponent } from './common/groupcrantemplate/groupcrantemplate.component';
import {ExternallegalreportComponent } from './common/externallegalreport/externallegalreport.component';
import {InternallegalreportComponent } from './common/internallegalreport/internallegalreport.component';
import { QuerypopupComponent } from './common/querypopup/querypopup.component';
import {RbireportscreenComponent} from './common/rbireportscreen/rbireportscreen.component';
import { RaisedbymeComponent } from './common/raisedbyme/raisedbyme.component';
import { RaisedresponseComponent } from './common/raisedresponse/raisedresponse.component';
import { CopyproposalComponent } from "./common/copyproposal/copyproposal.component";
import { GrpfinancialComponent } from "./common/grpfinancial/grpfinancial.component";



//                 ---------------SETUP---------------
import { AssessmentmasterComponent } from './setup/assessmentmaster/assessmentmaster.component';
import { BusinessrulemasterComponent } from './setup/businessrulemaster/businessrulemaster.component';
import { CmaFinmasterComponent } from './setup/cmamaster/cmamaster.component';
import { FacilitydetailsComponent } from "./setup/facilitydetails/facilitydetails.component";
import { FacilitymasterComponent } from './setup/facilitymaster/facilitymaster.component';
import { GeographymasterComponent } from './setup/geographymaster/geographymaster.component';
import { ListvaluemasterComponent } from './setup/listvaluemaster/listvaluemaster.component';
import { MailtemplateComponent } from './setup/mailtemplate/mailtemplate.component';
import { OrganizationlevelComponent } from './setup/organizationlevel/organizationlevel.component';
import { OrganizationComponent } from './setup/organization/organization.component';
import { QualitativemasterComponent } from "./setup/qualitativemaster/qualitativemaster.component";
import { RbichecklistComponent } from "./setup/rbichecklist/rbichecklist.component";
import { ScorecardmasterComponent } from './setup/scorecardmaster/scorecardmaster.component';
import { TakeovermasterComponent } from './setup/takeovermaster/takeovermaster.component';
import { TermsandconditionmasterComponent } from './setup/termsandconditionmaster/termsandconditionmaster.component';
import { UsersComponent } from './setup/users/users.component';
import { UsersgroupComponent } from './setup/usersgroup/usersgroup.component';
import { WorkflowconfigurationComponent } from './setup/workflowconfiguration/workflowconfiguration.component';
import { SecuritymasterComponent } from "./setup/securitymaster/securitymaster.component";
import { InterestrateComponent } from "./setup/interestrate/interestrate.component";
import { ProductComponent } from "./setup/product/product.component";
import { DocumentmastersComponent } from "./setup/documentmasters/documentmasters.component";
import { ProductdocumentComponent } from "./setup/productdocument/productdocument.component";
import { ProducttermsComponent } from "./setup/productterms/productterms.component";
import { AnnexuremasterComponent } from "./setup/annexuremaster/annexuremaster.component";
import { FinancialmasterComponent } from './setup/financialmaster/financialmaster.component';
import { CmaformulamasterComponent } from './setup/cmaformulamaster/cmaformulamaster.component';
import { WorkflowmasterComponent } from './setup/workflowmaster/workflowmaster.component';
import { FlowpointComponent } from './setup/flowpoint/flowpoint.component';
import { PagelistComponent } from './setup/pagelist/pagelist.component';
import { FlowpointsearchComponent } from './setup/flowpointsearch/flowpointsearch.component';
import { SchememasterComponent } from './setup/schememaster/schememaster.component';
import { SchemetermsComponent } from './setup/schemeterms/schemeterms.component';
import { SchemedocumentComponent } from './setup/schemedocument/schemedocument.component';
import { CranmasterComponent } from './setup/cranmaster/cranmaster.component';
import { AssessmentComponent } from './setup/assessment/assessment.component';
import { AssessmentconfigComponent } from './setup/assessmentconfig/assessmentconfig.component';
import { GroupfinancialmasterComponent } from './setup/groupfinancialmaster/groupfinancialmaster.component';
import { ProductassessmentComponent } from './setup/productassessment/productassessment.component';
import { DeviationmasterComponent } from './setup/deviationmaster/deviationmaster.component';
import { LocationmappingComponent } from './setup/locationmapping/locationmapping.component';
import { PSLMasterComponent } from './setup/pslmaster/pslmaster.component';
import { FinancialRatioMasterComponent } from './setup/financialratiomaster/financialratiomaster.component';
import { UserClassComponent } from './setup/userclass/userclass.component';
import { ProductsearchComponent } from "./setup/productsearch/productsearch.component";
import { ProducttabnavigationComponent } from "./setup/producttabnavigation/producttabnavigation.component";
import { BusinessdelegationComponent } from "./setup/businessdelegation/businessdelegation.component";
import { SltemplatemasterComponent } from "./setup/sltemplatemaster/sltemplatemaster.component";
import { HolidaymasterComponent } from "./setup/holidaymaster/holidaymaster.component";
import {DenominationmasterComponent} from "./setup/denominationmaster/denominationmaster.component";
//                ---------------MASTER---------------

import { LpyieldmasterComponent } from './master/lpyieldmaster/lpyieldmaster.component';
import { InterfacelinkComponent } from './master/interfacelink/interfacelink.component';
import { PSLLovMasterComponent } from './master/psllovmaster/psllovmaster.component';
import { ApplicationcontroldataComponent } from "./master/applicationcontroldata/applicationcontroldata.component";
import { SofmasterComponent } from './master/sofmaster/sofmaster.component';
//added keerthi 
//import { DsamasterComponent } from './master/dsamaster/dsamaster.component';

import { BcifdedupeviewComponent } from "./common/bcifdedupeview/bcifdedupeview.component";
import { CorpmonthsalesComponent } from "./corporate/corpmonthsales/corpmonthsales.component";
import { CorppartysalesComponent } from "./corporate/corppartysales/corppartysales.component";
import { NcifdedupeviewComponent } from "./common/ncifdedupeview/ncifdedupeview.component";
import { PostsanctionComponent } from "./common/postsanction/postsanction.component";
import { Accountconductanalysis2Component } from "./corporate/accountconductanalysis2/accountconductanalysis2.component";
import { Accountconductanalysis1Component } from "./corporate/accountconductanalysis1/accountconductanalysis1.component";
import { ApplicantplaceComponent } from "./agri/applicantplace/applicantplace.component";
import { ExistingkccrepaymentComponent } from "./agri/existingkccrepayment/existingkccrepayment.component";
import { CreditvisitreportComponent } from "./agri/creditvisitreport/creditvisitreport.component";
import { ExistingbankdetComponent } from './agri/existingbankdet/existingbankdet.component';
import { KkrpremiumComponent } from "./agri/kkrpremium/kkrpremium.component";
import { CibilreportviewComponent } from "./common/cibilreportview/cibilreportview.component";
import { ValuationandcollateralComponent } from "./agri/valuationandcollateral/valuationandcollateral.component";
import { CropexistingloandetailsComponent } from "./agri/cropexistingloandetails/cropexistingloandetails.component";
import { CropsurrogatetermComponent } from "./agri/cropsurrogateterm/cropsurrogateterm.component";
import { AgriscorecardComponent } from "./agri/agriscorecard/agriscorecard.component";
import { ScorecardbusinessruleComponent } from "./setup/agriscorecardbusinessrule/agriscorecardbusinessrule.component";
//-------------------------CONSUMER-------------------
import { ConsSourcingdetailsComponent } from './cons/conssourcingdetails/conssourcingdetails.component';
import { ConsCasedetailsrmComponent } from './cons/conscasedetailsrm/conscasedetailsrm.component';
import { ConsCustomerdetailsComponent } from './cons/conscustomerdetails/conscustomerdetails.component';
import { ConsAdditionalinfoComponent } from './cons/consadditionalinfo/consadditionalinfo.component';
import { ConsExposuredetComponent } from './cons/consexposuredet/consexposuredet.component';
import { ConsLpcorpexistingexposureComponent } from './cons/conslpcorpexistingexposure/conslpcorpexistingexposure.component';
import { ConsExposuredetailsComponent } from './cons/consexposuredetails/consexposuredetails.component';
import { ConsDocumentdetailsComponent } from './cons/consdocumentdetails/consdocumentdetails.component';
import { ConsProposalsecuritiesComponent } from './cons/consproposalsecurities/consproposalsecurities.component';
import { ConsGuaranteedetailsComponent } from './cons/consguaranteedetails/consguaranteedetails.component';
import { ConsBusinessapprovalComponent } from './cons/consbusinessapproval/consbusinessapproval.component';
import { ConsFacilityborrowermappingComponent } from './cons/consfacilityborrowermapping/consfacilityborrowermapping.component';
import { ConsSecuritycoverageComponent } from './cons/conssecuritycoverage/conssecuritycoverage.component';
import { ConsShareholdingpatternComponent } from './cons/consshareholdingpattern/consshareholdingpattern.component';
import { ConsIpacceptanceComponent } from './cons/consipacceptance/consipacceptance.component';
import { ConsFinancialmasterComponent } from './cons/consfinancialmaster/consfinancialmaster.component';
import { ConsGroupfinancialmasterComponent } from './cons/consgroupfinancial/consgroupfinancial.component';
import { ConsFinancialRatioMasterComponent } from './cons/consfinancialratiomaster/consfinancialratiomaster.component';
import { ConsAccountconductanalysis1Component } from './cons/consaccountconductanalysis1/consaccountconductanalysis1.component';
import { ConsEligibilityComponent } from './cons/conseligibility/conseligibility.component';
import { ConsBasedonfacComponent } from './cons/consbasedonfac/consbasedonfac.component';
import { ConsDscrassessmentComponent } from './cons/consdscrassessment/consdscrassessment.component';
import { ConsDeviationtrackingComponent } from './cons/consdeviationtracking/consdeviationtracking.component';
import { ConsWorkflowComponent } from './cons/consworkflow/consworkflow.component';
import { ConsFacilityRecommendComponent } from './cons/consfacilityrecommend/consfacilityrecommend.component';
import { ConsSlgenerateComponent } from './cons/consslgenerate/consslgenerate.component';
import { ConsSlpreparationComponent } from './cons/consslpreparation/consslpreparation.component';
import { ConsproptermsandconditionsComponent } from './cons/consproptermsandconditions/consproptermsandconditions.component';
import { ConsScorecardComponent } from './cons/consscorecard/consscorecard.component';
import { ConsproprecommendComponent } from './cons/consproprecommend/consproprecommend.component';
import { ConsAccountconductanalysis2Component } from './cons/consaccountconductanalysis2/consaccountconductanalysis2.component';
import { ConsJustificationComponent } from './cons/consjustification/consjustification.component';
import { ConsCVsummaryComponent } from './cons/conscvsummary/conscvsummary.component';
import { ConsBusinessUpdateComponent } from './cons/consbusinessupdate/consbusinessupdate.component';
import { ConsborrowerrelationshipComponent } from './cons/consborrowerrelationship/consborrowerrelationship.component';
import { ConspslclassificationComponent } from './cons/conspslclassification/conspslclassification.component';
import { ConsRcureportComponent } from './cons/consrcureport/consrcureport.component'
import { ConsTechnicalreportComponent } from './cons/constechnicalreport/constechnicalreport.component'
import { ConsLegalreportComponent } from './cons/conslegalreport/conslegalreport.component';
import { ConsverificationdataComponent } from "./cons/consverificationdata/consverificationdata.component";

import { LeaselanddetailsComponent } from './agri/leaselanddetails/leaselanddetails.component';
import { RenewalparameterComponent } from "./common/renewalparameter/renewalparameter.component";
import { PslclassificationmastComponent } from './master/pslclassificationmast/pslclassificationmast.component';
import { ProposalbasedpslclassificationComponent } from './common/proposalbasedpslclassification/proposalbasedpslclassification.component';
import { MclrmasterComponent } from './master/mclrmaster/mclrmaster.component';
import { Glems2Component } from './common/glems2/glems2.component';






export const appRoutes: Routes = [

  { path: 'login', component: LoginComponent },
  //                ---------------AGRICULTURE---------------
  { path: 'currentcroppattern', component: CurrentcroppatternComponent },
  { path: 'existingcroppattern', component: ExistingcroppatternComponent },
  { path: 'fleetandloandetails', component: FleetandloandetailsComponent },
  { path: 'Reference', component: LpagrireferencedetComponent },
  { path: 'ownedlanddetails', component: OwnedlanddetailsComponent },
  { path: 'existingexposure', component: ExistingexposureComponent },
  { path: 'proposedfacilities', component: ProposedfacilitiesComponent },
  { path: 'kccassessment', component: KccassessmentComponent },
  { path: 'dscrassessment', component: DscrassessmentComponent },
  { path: 'exicustref', component: ExistingcustrefComponent },
  { path: 'existingkccrepayment', component: ExistingkccrepaymentComponent },
  { path: 'creditvisitreport', component: CreditvisitreportComponent },
  { path: 'agritermloan', component: AgritermloanComponent },
  { path: 'existingbankdet', component: ExistingbankdetComponent },
  { path: 'kkrpremium', component: KkrpremiumComponent },
  { path: 'valuation', component: ValuationandcollateralComponent },
  { path: 'exposuredet', component: ExposuredetComponent },
  { path: 'cropexistingotherbank', component: CropexistingloandetailsComponent },
  { path: 'securitycoverage', component: SecuritycoverageComponent },
  { path: 'cropsurrogatetermloan', component: CropsurrogatetermComponent },
  { path: 'kccacuntmaturity', component: KccacuntmaturityComponent },
  { path: 'agridroplineod', component: AgridroplineodComponent },
  { path: 'agridroplinedetails', component: AgridroplinedetailsComponent },                    
  { path: 'leaselanddetails', component: LeaselanddetailsComponent },  
  { path: 'stlvehincdev', component: StlvehincdeviationComponent },  
  { path: 'communitymaster', component: CommunitymasterComponent },  
  { path: 'atlpurposemaster', component: AtlfacpurposemasterComponent },  
  { path: 'pslautomaster', component: PslautomationComponent },  
  { path: 'agripsl', component: AgripslclassificationComponent },  
  
  //                ---------------CORPORATE---------------
  { path: 'agrilandholding', component: AgrilandholdingComponent },
  { path: 'buyersupplier', component: BuyersupplierComponent },
  { path: 'callreport', component: CallreportComponent },
  { path: 'cropselection', component: CropselectionComponent },
  { path: 'Debtors', component: DebtorsComponent },
  { path: 'guaranteedetails', component: GuaranteedetailsComponent },
  { path: 'lpcorpexistingexposure', component: LpcorpexistingexposureComponent },
  { path: 'ModelSales', component: LpcropmodelsalesComponent },
  { path: 'rating', component: RatingComponent },
  { path: 'rbipslclause', component: RbipslclauseComponent },
  { path: 'taratingscreen', component: TaratingscreenComponent },
  { path: 'wcanalysis', component: WcanalysisComponent },
  { path: 'wcchurncf', component: WcchurncfComponent },
  { path: 'partyotherinfo', component: PartyotherinfoComponent },
  { path: 'customerdetails', component: CustomerdetailsComponent },
  { path: 'dynamicassessment', component: DynmassessmntComponent },
  { path: 'Account', component: Accountconductanalysis2Component },

  { path: 'forxexposure', component: FxexposureComponent },
  { path: 'cirannx', component: CirannxComponent },
  { path: 'compsheetannex', component: CompsheetannexComponent },
  { path: 'bcacannex', component: BcacannexComponent },
  { path: 'compcpannex', component: CompcpannexComponent },
  { path: 'accountconductcomment', component: AccountconductcommentComponent },
  { path: 'dynamiccomponent', component: DynamiccomponentComponent },
  { path: 'uploadformat', component: UploadformatComponent },
  { path: 'monthsales', component: CorpmonthsalesComponent },
  { path: 'partysales', component: CorppartysalesComponent },
  { path: 'accountconductanalysis1', component: Accountconductanalysis1Component },
  { path: 'additionalinc', component: AdditionalincomeComponent },



  //              --------------- COMMON  -------------------
  { path: 'casedetailsrm', component: CasedetailsrmComponent },
  { path: 'casedetailcredit', component: CasedetailcreditComponent },
  { path: 'sourcingdetails', component: SourcingdetailsComponent },
  { path: 'shareholdingpattern', component: ShareholdingpatternComponent },
  { path: 'takeover', component: TakeoverComponent },
  { path: 'existingexposure', component: ExistingexposureComponent },
  { path: 'vehicledetails', component: VehicledetailsComponent },
  { path: 'plntmchnrydetails', component: PlntmchnrydetComponent },
  { path: 'bankdeposits', component: BankdepositsComponent },
  { path: 'findoctrdtrn', component: FindoctrdtrnComponent },
  { path: 'findocntrdntrn', component: FindocntrdntrnComponent },
  { path: 'furniturefixtures', component: FurniturefixturesComponent },
  { path: 'propertydetails', component: PropertydetailsComponent },
  { path: 'securitymaster', component: SecuritymasterComponent },
  { path: 'documentdetails', component: DocumentdetailsComponent },
  { path: 'searchmaster', component: SearchmasterComponent },
  { path: 'goodsdetails', component: GoodsdetailsComponent },
  { path: 'jeweldetails', component: JeweldetailsComponent },
  { path: 'proprecommend', component: ProprecommendComponent },
  { path: 'securitydetails', component: SecuritydetailsComponent },
  { path: 'Search', component: SearchComponent },
  { path: 'additionalinfo', component: AdditionalinfoComponent },
  { path: 'proposallogin', component: ProposalloginComponent },
  { path: 'cranformat/:id', component: TemplateloaderComponent },
  { path: 'cranformatsss', component: TemplateloaderComponent },
  { path: 'facilityborrowermapping', component: FacilityborrowermappingComponent },
  { path: 'basedonfac', component: BasedonfacComponent },
  { path: 'ip', component: IpComponent },
  { path: 'ipacceptance', component: IpacceptanceComponent },
  { path: 'headerpagenav', component: HeaderpagenavComponent },
  { path: 'upload', component: UploadfileComponent },
  { path: 'queryrequest', component: QueryrequestComponent },
  { path: 'queryresponse', component: QueryresponseComponent },
  { path: 'pagecomment', component: PagecommentComponent },
  { path: 'queryhistory', component: QueryhistoryComponent },
  { path: 'queriesreceived', component: QueriesreceivedComponent },
  { path: 'responsereceived', component: ResponsereceivedComponent },
  { path: 'proposalsecurities', component: ProposalsecuritiesComponent },
  { path: 'securitycoverage', component: SecuritycoverageComponent },
  { path: 'pslclass', component: PSLClassificationComponent },
  { path: 'prev3sanction', component: Prev3sanctionComponent },
  { path: 'rcudocument', component: RcudocumentComponent },
  { path: 'rcuagency', component: RcuComponent },
  { path: 'rcufinal', component: RcusupervisorComponent },
  { path: 'rmdoc', component: RmdocumentComponent },
  { path: 'statusbar', component: StatusbarComponent },
  { path: 'businessapproval', component: BusinessapprovalComponent },
  { path: 'internalrating', component: InternalratingComponent },
  { path: 'jusificationPoints', component: JustificationpointsComponent },
  { path: 'Hygeinechk', component: HygeinechkComponent },
  { path: 'scorecardcal', component: ScorecardcalcComponent },
  { path: 'finalaysis', component: FinancialanalysisComponent },
  { path: 'sems', component: SemsComponent },
  { path: 'postsanction', component: PostsanctionComponent },
  { path: 'crancomments', component: CrancommentsComponent },
  { path: 'legaldetails', component: LegaldetailsComponent },
{path :'groupcrantemplates',component :GroupcrantemplateComponent},

  { path: 'proposallogin', component: ProposalloginComponent },
  { path: 'cranformat/:id', component: TemplateloaderComponent },
  { path: 'cranformatsss', component: TemplateloaderComponent },
  { path: 'facilityborrowermapping', component: FacilityborrowermappingComponent },
  { path: 'basedonfac', component: BasedonfacComponent },
  { path: 'ip', component: IpComponent },
  { path: 'ipacceptance', component: IpacceptanceComponent },
  { path: 'headerpagenav', component: HeaderpagenavComponent },
  { path: 'upload', component: UploadfileComponent },
  { path: 'queryrequest', component: QueryrequestComponent },
  { path: 'queryresponse', component: QueryresponseComponent },
  { path: 'pagecomment', component: PagecommentComponent },
  { path: 'queryhistory', component: QueryhistoryComponent },
  { path: 'queriesreceived', component: QueriesreceivedComponent },
  { path: 'responsereceived', component: ResponsereceivedComponent },
  { path: 'proposalsecurities', component: ProposalsecuritiesComponent },
  { path: 'securitycoverage', component: SecuritycoverageComponent },
  { path: 'pslclass', component: PSLClassificationComponent },
  { path: 'prev3sanction', component: Prev3sanctionComponent },
  { path: 'rcudocument', component: RcudocumentComponent },
  { path: 'rcuagency', component: RcuComponent },
  { path: 'rcufinal', component: RcusupervisorComponent },
  { path: 'rmdoc', component: RmdocumentComponent },
  { path: 'statusbar', component: StatusbarComponent },
  { path: 'businessapproval', component: BusinessapprovalComponent },
  { path: 'internalrating', component: InternalratingComponent },
  { path: 'jusificationPoints', component: JustificationpointsComponent },
  { path: 'Hygeinechk', component: HygeinechkComponent },
  { path: 'scorecardcal', component: ScorecardcalcComponent },
  { path: 'finalaysis', component: FinancialanalysisComponent },
  { path: 'sems', component: SemsComponent },
  { path: 'postsanction', component: PostsanctionComponent },
  { path: 'crancomments', component: CrancommentsComponent },
  { path: 'externalvaluer', component: ExternalvaluerComponent },
  { path: 'slgenerate', component: SlgenerateComponent },
  { path: 'slpreparation', component: SlpreparationComponent },
  { path: 'popup', component: HyginepopupComponent },
  { path: 'rcureport', component: RcureportComponent },
  { path: 'legalverification', component: LegalverificationComponent },
  { path: 'perfios', component: PerfiosComponent },
  { path: 'glems2', component: Glems2Component },

  

  //                 ---------------SETUP---------------
  { path: 'assessmentmaster', component: AssessmentmasterComponent },
  { path: 'businessrulemaster', component: BusinessrulemasterComponent },
  { path: 'finmaster', component: CmaFinmasterComponent },
  { path: 'facilitymaster', component: FacilitymasterComponent },
  { path: 'facilitydetails', component: FacilitydetailsComponent },
  { path: 'geographymaster', component: GeographymasterComponent },
  { path: 'listvaluemaster', component: ListvaluemasterComponent },
  { path: 'mailtemplate', component: MailtemplateComponent },
  { path: 'organizationlevel', component: OrganizationlevelComponent },
  { path: 'organization', component: OrganizationComponent },
  { path: 'qualitativemaster', component: QualitativemasterComponent },
  { path: 'rbichecklist', component: RbichecklistComponent },
  { path: 'scorecardmaster', component: ScorecardmasterComponent },
  { path: 'takeovermaster', component: TakeovermasterComponent },
  { path: 'users', component: UsersComponent },
  { path: 'usersgroup', component: UsersgroupComponent },
  { path: 'workflowconfiguration', component: WorkflowconfigurationComponent },
  { path: 'Terms', component: TermsandconditionmasterComponent },
  { path: 'interestrate', component: InterestrateComponent },
  { path: 'product', component: ProductComponent },
  { path: 'documentmasters', component: DocumentmastersComponent },
  { path: 'productdocument', component: ProductdocumentComponent },
  { path: 'productterms', component: ProducttermsComponent },
  { path: 'annexuremaster', component: AnnexuremasterComponent },
  { path: 'financialmaster', component: FinancialmasterComponent },
  { path: 'formulamaster', component: CmaformulamasterComponent },
  { path: 'workflowmaster', component: WorkflowmasterComponent },
  { path: 'flowpoint', component: FlowpointComponent },
  { path: 'pagelist', component: PagelistComponent },
  { path: 'flowsearch', component: FlowpointsearchComponent },
  { path: 'scheme', component: SchememasterComponent },
  { path: 'schemeterms', component: SchemetermsComponent },
  { path: 'schemedocument', component: SchemedocumentComponent },
  { path: 'assessment', component: AssessmentComponent },
  { path: 'assessmentconfig', component: AssessmentconfigComponent },
  { path: 'groupfinancial', component: GroupfinancialmasterComponent },
  { path: 'prdassessment', component: ProductassessmentComponent },
  { path: 'financialmaster', component: FinancialmasterComponent },
  { path: 'deviationmaster', component: DeviationmasterComponent },
  { path: 'pslmaster', component: PSLMasterComponent },
  { path: 'financialratiomaster', component: FinancialRatioMasterComponent },
  { path: 'userclass', component: UserClassComponent },
  { path: 'productsearch', component: ProductsearchComponent },
  { path: 'applicantplace', component: ApplicantplaceComponent },
  { path: 'propertyscore', component: PropertyscoreComponent },
  { path: 'agriscorecard', component: AgriscorecardComponent },
  { path: 'sltemplatemaster', component: SltemplatemasterComponent },
  { path: 'scorecardbusinessrule', component: ScorecardbusinessruleComponent },


  //                 ---------------SETUP---------------
  { path: 'assessmentmaster', component: AssessmentmasterComponent },
  { path: 'businessrulemaster', component: BusinessrulemasterComponent },
  { path: 'finmaster', component: CmaFinmasterComponent },
  { path: 'facilitymaster', component: FacilitymasterComponent },
  { path: 'facilitydetails', component: FacilitydetailsComponent },
  { path: 'geographymaster', component: GeographymasterComponent },
  { path: 'listvaluemaster', component: ListvaluemasterComponent },
  { path: 'mailtemplate', component: MailtemplateComponent },
  { path: 'organizationlevel', component: OrganizationlevelComponent },
  { path: 'organization', component: OrganizationComponent },
  { path: 'qualitativemaster', component: QualitativemasterComponent },
  { path: 'rbichecklist', component: RbichecklistComponent },
  { path: 'scorecardmaster', component: ScorecardmasterComponent },
  { path: 'takeovermaster', component: TakeovermasterComponent },
  { path: 'users', component: UsersComponent },
  { path: 'usersgroup', component: UsersgroupComponent },
  { path: 'workflowconfiguration', component: WorkflowconfigurationComponent },
  { path: 'Terms', component: TermsandconditionmasterComponent },
  { path: 'interestrate', component: InterestrateComponent },
  { path: 'product', component: ProductComponent },
  { path: 'documentmasters', component: DocumentmastersComponent },
  { path: 'productdocument', component: ProductdocumentComponent },
  { path: 'productterms', component: ProducttermsComponent },
  { path: 'annexuremaster', component: AnnexuremasterComponent },
  { path: 'financialmaster', component: FinancialmasterComponent },
  { path: 'formulamaster', component: CmaformulamasterComponent },
  { path: 'workflowmaster', component: WorkflowmasterComponent },
  { path: 'flowpoint', component: FlowpointComponent },
  { path: 'pagelist', component: PagelistComponent },
  { path: 'flowsearch', component: FlowpointsearchComponent },
  { path: 'scheme', component: SchememasterComponent },
  { path: 'schemeterms', component: SchemetermsComponent },
  { path: 'schemedocument', component: SchemedocumentComponent },
  { path: 'assessment', component: AssessmentComponent },
  { path: 'assessmentconfig', component: AssessmentconfigComponent },
  { path: 'groupfinancial', component: GroupfinancialmasterComponent },
  { path: 'prdassessment', component: ProductassessmentComponent },
  { path: 'financialmaster', component: FinancialmasterComponent },
  { path: 'deviationmaster', component: DeviationmasterComponent },
  { path: 'pslmaster', component: PSLMasterComponent },
  { path: 'financialratiomaster', component: FinancialRatioMasterComponent },
  { path: 'userclass', component: UserClassComponent },
  { path: 'productsearch', component: ProductsearchComponent },
  { path: 'applicantplace', component: ApplicantplaceComponent },
  { path: 'holiday',component:HolidaymasterComponent},
  //                ---------------MASTER---------------
  { path: 'Yieldmaster', component: LpyieldmasterComponent },
  { path: 'cranmaster', component: CranmasterComponent },
  { path: 'bankingarrangement', component: BankingarrangementComponent },
  { path: 'locationmapping', component: LocationmappingComponent },
  { path: 'interfacelink', component: InterfacelinkComponent },
  { path: 'psllovmaster', component: PSLLovMasterComponent },
  { path: 'tasales', component: TasalesComponent },
  { path: 'taretail', component: TaretailComponent },
  { path: 'taprojectedsales', component: TaprojectedsalesComponent },
  { path: 'proposaldetails', component: ProposaldetailsComponent },
  { path: 'applicationcontroldata', component: ApplicationcontroldataComponent },
  { path: 'bcifdedupeview', component: BcifdedupeviewComponent },
  { path: 'sofmaster', component: SofmasterComponent },
  { path: 'pslclassificationmast', component: PslclassificationmastComponent },
  
  // added keerthi 
  //{ path: 'dsamaster', component: DsamasterComponent },

  { path: 'ncifdedupeview', component: NcifdedupeviewComponent },
  { path: 'cibilreportview', component: CibilreportviewComponent },
  { path: 'internalvaluation', component: InternalvaluationComponent },

  //              -------------------------CONSUMER---------------
  { path: 'conssourcingdetails', component: ConsSourcingdetailsComponent },
  


  //DASHBOARD
  {
    path: 'home', component: HomeComponent, children: [
      // //                ---------------AGRICULTURE---------------
      { path: 'currentcroppattern', component: CurrentcroppatternComponent, outlet: 'home' },
      { path: 'existingcroppattern', component: ExistingcroppatternComponent, outlet: 'home' },
      { path: 'fleetandloandetails', component: FleetandloandetailsComponent, outlet: 'home' },
      { path: 'Reference', component: LpagrireferencedetComponent, outlet: 'home' },
      { path: 'Yieldmaster', component: LpyieldmasterComponent, outlet: 'home' },
      { path: 'ownedlanddetails', component: OwnedlanddetailsComponent, outlet: 'home' },
      { path: 'applicantplace', component: ApplicantplaceComponent, outlet: 'home' },
      { path: 'existingkccrepayment', component: ExistingkccrepaymentComponent, outlet: 'home' },
      { path: 'creditvisitreport', component: CreditvisitreportComponent, outlet: 'home' },
      { path: 'existingbankdet', component: ExistingbankdetComponent, outlet: 'home' },
      { path: 'proposedfacilities', component: ProposedfacilitiesComponent, outlet: 'home' },
      { path: 'additionalinc', component: AdditionalincomeComponent, outlet: 'home' },
      { path: 'kkrpremium', component: KkrpremiumComponent, outlet: 'home' },
      { path: 'creditvisitreport', component: CreditvisitreportComponent, outlet: 'home' },
      { path: 'valuation', component: ValuationandcollateralComponent, outlet: 'home' },
      { path: 'agritermloan', component: AgritermloanComponent, outlet: 'home' },
      { path: 'dscrassessment', component: DscrassessmentComponent, outlet: 'home' },
      { path: 'cropexistingotherbank', component: CropexistingloandetailsComponent, outlet: 'home' },
      { path: 'sofmaster', component: SofmasterComponent, outlet: 'home' },
      { path: 'stlvehincdev', component: StlvehincdeviationComponent ,outlet:'home'},  
      { path: 'communitymaster', component: CommunitymasterComponent,outlet:'home' },  
      { path: 'atlpurposemaster', component: AtlfacpurposemasterComponent,outlet:'home' },
      { path: 'pslautomaster', component: PslautomationComponent,outlet:'home' },
      { path: 'agripsl', component: AgripslclassificationComponent,outlet:'home' },
      //added keerthi 
      //{ path: 'dsamaster', component: DsamasterComponent, outlet: 'home' },

      { path: 'kccassessment', component: KccassessmentComponent, outlet: 'home' },
      { path: 'securitycoverage', component: SecuritycoverageComponent, outlet: 'home' },
      { path: 'cropsurrogatetermloan', component: CropsurrogatetermComponent, outlet: 'home' },
      { path: 'kccacuntmaturity', component: KccacuntmaturityComponent, outlet: 'home' },
      { path: 'agriscorecard', component: AgriscorecardComponent, outlet: 'home' },
      { path: 'agridroplineod', component: AgridroplineodComponent, outlet: 'home' },
      { path: 'agridroplinedetails', component: AgridroplinedetailsComponent, outlet: 'home' },
      { path: 'leaselanddetails', component: LeaselanddetailsComponent, outlet: 'home' },
      { path: 'sofdeviation', component: AgrisofdeviationComponent , outlet: 'home' },
      { path: 'leaselanddeviation', component: AgrileaselanddeviationComponent, outlet: 'home' },

      
      // //                ---------------CORPORATE---------------
      { path: 'agrilandholding', component: AgrilandholdingComponent, outlet: 'home' },
      { path: 'buyersupplier', component: BuyersupplierComponent, outlet: 'home' },
      { path: 'callreport', component: CallreportComponent, outlet: 'home' },
      { path: 'cropselection', component: CropselectionComponent, outlet: 'home' },
      { path: 'Debtors', component: DebtorsComponent, outlet: 'home' },
      { path: 'guaranteedetails', component: GuaranteedetailsComponent, outlet: 'home' },
      { path: 'lpcorpexistingexposure', component: LpcorpexistingexposureComponent, outlet: 'home' },
      { path: 'ModelSales', component: LpcropmodelsalesComponent, outlet: 'home' },
      { path: 'rating', component: RatingComponent, outlet: 'home' },
      { path: 'rbipslclause', component: RbipslclauseComponent, outlet: 'home' },
      { path: 'taratingscreen', component: TaratingscreenComponent, outlet: 'home' },
      { path: 'wcanalysis', component: WcanalysisComponent, outlet: 'home' },
      { path: 'wcchurncf', component: WcchurncfComponent, outlet: 'home' },
      { path: 'accountconductcomment', component: AccountconductcommentComponent, outlet: 'home' },
      { path: 'partyotherinfo', component: PartyotherinfoComponent, outlet: 'home' },
      { path: 'customerdetails', component: CustomerdetailsComponent, outlet: 'home' },
      { path: 'forxexposure', component: FxexposureComponent, outlet: 'home' },
      { path: 'exposuredetails', component: ExposuredetailsComponent, outlet: 'home' },
      { path: 'cirannx', component: CirannxComponent, outlet: 'home' },
      { path: 'compsheetannex', component: CompsheetannexComponent, outlet: 'home' },
      { path: 'bcacannex', component: BcacannexComponent, outlet: 'home' },
      { path: 'compcpannex', component: CompcpannexComponent, outlet: 'home' },
      { path: 'accountconductanalysis2', component: Accountconductanalysis2Component, outlet: 'home' },
      { path: 'ipletter', component: IpletterComponent, outlet: 'home' },
      { path: 'financials', component: FinancialsComponent, outlet: 'home' },
      { path: 'groupfinancial', component: GroupfinancialmasterComponent, outlet: 'home' },
      { path: 'grpfinancials', component: GrpfinancialsComponent, outlet: 'home' },
      { path: 'grpcmpyfinancials', component: GrpcmpyfinancialsComponent, outlet: 'home' },
      { path: 'financialratio', component: FinancialratioComponent, outlet: 'home' },
      { path: 'workingcapital', component: WorkingcapitalComponent, outlet: 'home' },
      { path: 'uploadformat', component: UploadformatComponent, outlet: 'home' },
      { path: 'taproduct', component: TaproductComponent, outlet: 'home' },
      { path: 'dynamicassessment', component: DynmassessmntComponent, outlet: 'home' },
      { path: 'sales26', component: Sales26asgstComponent, outlet: 'home' },
      { path: 'partysales', component: CorppartysalesComponent, outlet: 'home' },
      { path: 'monthsales', component: CorpmonthsalesComponent, outlet: 'home' },
      { path: 'cropdscrassessment', component: CropdscrassessmentComponent, outlet: 'home' },
      { path: 'cropmpbffassessment', component: CropmpbffassessmentComponent, outlet: 'home' },
      { path: 'accountconductanalysis1', component: Accountconductanalysis1Component, outlet: 'home' },
      { path: 'exicustref', component: ExistingcustrefComponent, outlet: 'home' },

      // //              --------------- COMMON  -------------------
      { path: 'casedetailsrm', component: CasedetailsrmComponent, outlet: 'home' },
      { path: 'casedetailcredit', component: CasedetailcreditComponent, outlet: 'home' },
      { path: 'sourcingdetails', component: SourcingdetailsComponent, outlet: 'home' },
      { path: 'shareholdingpattern', component: ShareholdingpatternComponent, outlet: 'home' },
      { path: 'takeover', component: TakeoverComponent, outlet: 'home' },
      { path: 'vehicledetails', component: VehicledetailsComponent, outlet: 'home' },
      { path: 'plntmchnrydet', component: PlntmchnrydetComponent, outlet: 'home' },
      { path: 'bankdeposits', component: BankdepositsComponent, outlet: 'home' },
      { path: 'findoctrdtrn', component: FindoctrdtrnComponent, outlet: 'home' },
      { path: 'findocntrdntrn', component: FindocntrdntrnComponent, outlet: 'home' },
      { path: 'furniturefixtures', component: FurniturefixturesComponent, outlet: 'home' },
      { path: 'propertydetails', component: PropertydetailsComponent, outlet: 'home' },
      { path: 'securitymaster', component: SecuritymasterComponent, outlet: 'home' },
      { path: 'documentdetails', component: DocumentdetailsComponent, outlet: 'home' },
      { path: 'searchmaster', component: SearchmasterComponent, outlet: 'home' },
      { path: 'goodsdetails', component: GoodsdetailsComponent, outlet: 'home' },
      { path: 'jeweldetails', component: JeweldetailsComponent, outlet: 'home' },
      { path: 'newproposal', component: NewproposalComponent, outlet: 'home' },
      { path: 'proprecommend', component: ProprecommendComponent, outlet: 'home' },
      { path: 'additionalinfo', component: AdditionalinfoComponent, outlet: 'home' },
      { path: 'buisnessupdates', component: BuisnessupdatesComponent, outlet: 'home' },
      { path: 'bankingarrangement', component: BankingarrangementComponent, outlet: 'home' },
      { path: 'documentdetails', component: DocumentdetailsComponent, outlet: 'home' },
      { path: 'propassignedme', component: PropassignedmeComponent, outlet: 'home' },
      { path: 'assignedtogroup', component: AssignedtogroupComponent, outlet: 'home' },
      { path: 'dedupescreen', component: DedupescreenComponent, outlet: 'home' },
      { path: 'seccomfort', component: SeccomfortComponent, outlet: 'home' },
      { path: 'facilitysecmapping', component: FacilitysecmappingComponent, outlet: 'home' },
      { path: 'securitycoverage', component: SecuritycoverageComponent, outlet: 'home' },
      { path: 'prev3sanction', component: Prev3sanctionComponent, outlet: 'home' },
      { path: 'eligibility', component: EligibilityComponent, outlet: 'home' },
      { path: 'internalrating', component: InternalratingComponent, outlet: 'home' },
      { path: 'basedonfac', component: BasedonfacComponent, outlet: 'home' },
      { path: 'justificationpoints', component: JustificationpointsComponent, outlet: 'home' },
      { path: 'rcu', component: RcuComponent, outlet: 'home' },
      { path: 'legaldetails', component: LegaldetailsComponent, outlet: 'home' },
      { path: 'deviationtracking', component: DeviationtrackingComponent, outlet: 'home' },
      { path: 'businessapproval', component: BusinessapprovalComponent, outlet: 'home' },
      { path: 'changenote', component: ChangenoteComponent, outlet: 'home' },
      { path: 'queryhistory', component: QueryhistoryComponent, outlet: 'home' },
      { path: 'workflowhistory', component: WorkflowhistoryComponent, outlet: 'home' },
      { path: 'technicaldetails', component: TechnicaldetailsComponent, outlet: 'home' },
      { path: 'facilityrecommend', component: FacilityRecommendComponent, outlet: 'home' },
      { path: 'dedupescreen', component: DedupescreenComponent, outlet: 'home' },
      { path: 'seccomfort', component: SeccomfortComponent, outlet: 'home' },
      { path: 'facilitysecmapping', component: FacilitysecmappingComponent, outlet: 'home' },
      { path: 'securitycoverage', component: SecuritycoverageComponent, outlet: 'home' },
      { path: 'prev3sanction', component: Prev3sanctionComponent, outlet: 'home' },
      { path: 'eligibility', component: EligibilityComponent, outlet: 'home' },
      { path: 'internalrating', component: InternalratingComponent, outlet: 'home' },
      { path: 'basedonfac', component: BasedonfacComponent, outlet: 'home' },
      { path: 'justificationpoints', component: JustificationpointsComponent, outlet: 'home' },
      { path: 'rcu', component: RcuComponent, outlet: 'home' },
      { path: 'legaldetails', component: LegaldetailsComponent, outlet: 'home' },
      { path: 'deviationtracking', component: DeviationtrackingComponent, outlet: 'home' },
      { path: 'businessapproval', component: BusinessapprovalComponent, outlet: 'home' },
      { path: 'changenote', component: ChangenoteComponent, outlet: 'home' },
      { path: 'queryhistory', component: QueryhistoryComponent, outlet: 'home' },
      { path: 'workflowhistory', component: WorkflowhistoryComponent, outlet: 'home' },
      { path: 'technicaldetails', component: TechnicaldetailsComponent, outlet: 'home' },
      { path: 'facilityrecommend', component: FacilityRecommendComponent, outlet: 'home' },
      { path: 'homepage', component: MailboxComponent, outlet: 'home' },
      { path: 'ip', component: IpComponent, outlet: 'home' },
      { path: 'ipacceptance', component: IpacceptanceComponent, outlet: 'home' },
      { path: 'queryrequest', component: QueryrequestComponent, outlet: 'home' },
      { path: 'queryresponse', component: QueryresponseComponent, outlet: 'home' },
      { path: 'queriesreceived', component: QueriesreceivedComponent, outlet: 'home' },
      { path: 'responsereceived', component: ResponsereceivedComponent, outlet: 'home' },
      { path: 'proposalsecurities', component: ProposalsecuritiesComponent, outlet: 'home' },
      { path: 'exposuredet', component: ExposuredetComponent, outlet: 'home' },
      { path: 'borrowerrelationship', component: BorrowerrelationshipComponent, outlet: 'home' },
      { path: 'workflow', component: WorkflowComponent, outlet: 'home' },
      { path: 'proptermsandconditions', component: ProptermsandconditionsComponent, outlet: 'home' },
      { path: 'termsearchmaster', component: TermsearchComponent, outlet: 'home' },
      { path: 'asssearchmaster', component: PrdassearchComponent, outlet: 'home' },
      { path: 'teaminbox', component: TeaminboxComponent, outlet: 'home' },
      { path: 'tat', component: TatComponent, outlet: 'home' },
      { path: 'Hygeinechk', component: HygeinechkComponent, outlet: 'home' },
      { path: 'peerfinancials', component: PeerfinancialsComponent, outlet: 'home' },
      { path: 'scorecardcal', component: ScorecardcalcComponent, outlet: 'home' },
      { path: 'finalaysis', component: FinancialanalysisComponent, outlet: 'home' },
      { path: 'sems', component: SemsComponent, outlet: 'home' },
      { path: 'postsanction', component: PostsanctionComponent, outlet: 'home' },
      { path: 'tasales', component: TasalesComponent, outlet: 'home' },
      { path: 'taretail', component: TaretailComponent, outlet: 'home' },
      { path: 'taprojectedsales', component: TaprojectedsalesComponent, outlet: 'home' },
      { path: 'rcuproposallist', component: RcuproposallistComponent, outlet: 'home' },
      { path: 'legalproposallist', component: LegalproposallistComponent, outlet: 'home' },
      { path: 'technicalproposallist', component: TechnicalproposallistComponent, outlet: 'home' },
      { path: 'manualassessment', component: ManualassessmentComponent, outlet: 'home' },
      { path: 'propertyscore', component: PropertyscoreComponent, outlet: 'home' },
      { path: 'externalvaluer', component: ExternalvaluerComponent, outlet: 'home' },
      { path: 'crancomments', component: CrancommentsComponent, outlet: 'home' },
      { path: 'technicalinbox', component: TechnicalinboxComponent, outlet: 'home' },
      { path: 'legaldetails', component: LegaldetailsComponent, outlet: 'home' },
      { path: 'technicalvaluation', component: TechnicalvaluationComponent, outlet: 'home' },
      { path: 'internalvaluation', component: InternalvaluationComponent, outlet: 'home' },
      { path: 'slgenerate', component: SlgenerateComponent, outlet: 'home' },
      { path: 'slpreparation', component: SlpreparationComponent, outlet: 'home' },
      { path: 'technicalreport', component: TechnicalreportComponent, outlet: 'home' },
      { path: 'rcureport', component: RcureportComponent, outlet: 'home' },
      { path: 'rcureport', component: RcureportComponent},
      { path: 'legalverification', component: LegalverificationComponent, outlet: 'home' },
      { path: 'proposalrenewal', component: ProposalrenewalComponent, outlet: 'home' },
      { path: 'simplerenewal', component: RenewalparameterComponent, outlet: 'home' },
      { path: 'perfios', component: PerfiosComponent, outlet: 'home' },
      { path: 'glems2', component: Glems2Component, outlet: 'home' },



      { path: 'legalreport', component: LegalreportComponent, outlet: 'home' },
      {path :'groupcrantemplates',component :GroupcrantemplateComponent, outlet: 'home' },
      { path: 'propbasedpslclass', component: ProposalbasedpslclassificationComponent, outlet: 'home' },
      { path: 'externallegalreport', component: ExternallegalreportComponent, outlet: 'home' },
      { path: 'internallegalreport', component: InternallegalreportComponent, outlet: 'home' },
      {path: 'rbireportscreen', component:RbireportscreenComponent, outlet:'home'},
      {path: 'raisedbyme', component:RaisedbymeComponent, outlet:'home'},
      {path: 'raisedresponse', component:RaisedresponseComponent, outlet:'home'},
      {path: 'copyproposal', component:CopyproposalComponent, outlet:'home'},
      {path: 'grpcompaniesfinancial', component:GrpfinancialComponent, outlet:'home'},
      
    
      // //                 ---------------SETUP---------------
      { path: 'assessmentmaster', component: AssessmentmasterComponent, outlet: 'home' },
      { path: 'businessrulemaster', component: BusinessrulemasterComponent, outlet: 'home' },
      { path: 'finmaster', component: CmaFinmasterComponent, outlet: 'home' },
      { path: 'formulamaster', component: CmaformulamasterComponent, outlet: 'home' },
      { path: 'facilitymaster', component: FacilitymasterComponent, outlet: 'home' },
      { path: 'facilitydetails', component: FacilitydetailsComponent, outlet: 'home' },
      { path: 'geographymaster', component: GeographymasterComponent, outlet: 'home' },
      { path: 'listvaluemaster', component: ListvaluemasterComponent, outlet: 'home' },
      { path: 'mailtemplate', component: MailtemplateComponent, outlet: 'home' },
      { path: 'organizationlevel', component: OrganizationlevelComponent, outlet: 'home' },
      { path: 'organization', component: OrganizationComponent, outlet: 'home' },
      { path: 'qualitativemaster', component: QualitativemasterComponent, outlet: 'home' },
      { path: 'rbichecklist', component: RbichecklistComponent, outlet: 'home' },
      { path: 'scorecardmaster', component: ScorecardmasterComponent, outlet: 'home' },
      { path: 'takeovermaster', component: TakeovermasterComponent, outlet: 'home' },
      { path: 'usersgroup', component: UsersgroupComponent, outlet: 'home' },
      { path: 'workflowconfiguration', component: WorkflowconfigurationComponent, outlet: 'home' },
      { path: 'Terms', component: TermsandconditionmasterComponent, outlet: 'home' },
      { path: 'interestrate', component: InterestrateComponent, outlet: 'home' },
      { path: 'product', component: ProductComponent, outlet: 'home' },
      { path: 'documentmasters', component: DocumentmastersComponent, outlet: 'home' },
      { path: 'productdocument', component: ProductdocumentComponent, outlet: 'home' },
      { path: 'productterms', component: ProducttermsComponent, outlet: 'home' },
      { path: 'users', component: UsersComponent, outlet: 'home' },
      { path: 'workflowmaster', component: WorkflowmasterComponent, outlet: 'home' },
      { path: 'assessment', component: AssessmentComponent, outlet: 'home' },
      { path: 'annexuremaster', component: AnnexuremasterComponent, outlet: 'home' },
      { path: 'deviationmaster', component: DeviationmasterComponent, outlet: 'home' },
      { path: 'scheme', component: SchememasterComponent, outlet: 'home' },
      { path: 'financialmaster', component: FinancialmasterComponent, outlet: 'home' },
      { path: 'facilityborrowermapping', component: FacilityborrowermappingComponent, outlet: 'home' },
      { path: 'locationmapping', component: LocationmappingComponent, outlet: 'home' },
      { path: 'prdassessment', component: ProductassessmentComponent, outlet: 'home' },
      { path: 'pslmaster', component: PSLMasterComponent, outlet: 'home' },
      { path: 'financialratiomaster', component: FinancialRatioMasterComponent, outlet: 'home' },
      { path: 'userclass', component: UserClassComponent, outlet: 'home' },
      { path: 'productsearch', component: ProductsearchComponent, outlet: 'home' },
      { path: 'tabnavigation', component: ProducttabnavigationComponent, outlet: 'home' },
      { path: 'charges', component: ProducttermsComponent, outlet: 'home' },
      { path: 'businessdel', component: BusinessdelegationComponent, outlet: 'home' },
      { path: 'rcudocument', component: RcudocumentComponent, outlet: 'home' },
      { path: 'rcuagency', component: RcuComponent, outlet: 'home' },
      { path: 'rcufinal', component: RcusupervisorComponent, outlet: 'home' },
      { path: 'scorecardbusinessrule', component: ScorecardbusinessruleComponent, outlet: 'home' },
      { path: 'sltemplatemaster', component: SltemplatemasterComponent, outlet: 'home' }, 
      { path: 'holiday',component:HolidaymasterComponent,outlet:'home'},
      { path: 'denomination',component:DenominationmasterComponent,outlet:'home'},
      { path: 'psllovmaster', component: PSLLovMasterComponent,outlet:'home' },
   
      //                ---------------MASTER---------------
      { path: 'cranmaster', component: CranmasterComponent, outlet: 'home' },
      { path: 'Yieldmaster', component: LpyieldmasterComponent, outlet: 'home' },
      { path: 'pslclassificationmast', component: PslclassificationmastComponent, outlet: 'home' },
      { path: 'interfacelink', component: InterfacelinkComponent, outlet: 'home' },
      { path: 'applicationcontroldata', component: ApplicationcontroldataComponent, outlet: 'home' },
      { path: 'mclrmaster', component: MclrmasterComponent, outlet: 'home' },

//-------------------CONSUMER----------------
{ path: 'conssourcingdetails', component: ConsSourcingdetailsComponent, outlet: 'home' },
{ path: 'conscasedetailsrm', component: ConsCasedetailsrmComponent, outlet: 'home' },
{ path: 'conscustomerdetails', component: ConsCustomerdetailsComponent, outlet: 'home' },
{ path: 'consadditionalinfo', component: ConsAdditionalinfoComponent, outlet: 'home' },
{ path: 'consexposuredet', component: ConsExposuredetComponent, outlet: 'home' },
{ path: 'conslpcorpexistingexposure', component: ConsLpcorpexistingexposureComponent, outlet: 'home' }, 
{ path: 'consexposuredetails', component: ConsExposuredetailsComponent, outlet: 'home' }, 
{ path: 'consdocumentdetails', component: ConsDocumentdetailsComponent, outlet: 'home' }, 
{ path: 'consproposalsecurities', component: ConsProposalsecuritiesComponent, outlet: 'home' }, 
{ path: 'consguaranteedetails', component: ConsGuaranteedetailsComponent, outlet: 'home' }, 
{ path: 'consbusinessapproval', component: ConsBusinessapprovalComponent, outlet: 'home' }, 
{ path: 'consfacilityborrowermapping', component: ConsFacilityborrowermappingComponent, outlet: 'home' }, 
{ path: 'conssecuritycoverage', component: ConsSecuritycoverageComponent, outlet: 'home' }, 
{ path: 'consshareholdingpattern', component: ConsShareholdingpatternComponent, outlet: 'home' }, 
{ path: 'consipacceptance', component: ConsIpacceptanceComponent, outlet: 'home' }, 
{ path: 'consfinancialmaster', component: ConsFinancialmasterComponent, outlet: 'home' }, 
{ path: 'consgroupfinancial', component: ConsGroupfinancialmasterComponent, outlet: 'home' }, 
{ path: 'consfinancialratiomaster', component: ConsFinancialRatioMasterComponent, outlet: 'home' }, 
{ path: 'consaccountconductanalysis1', component: ConsAccountconductanalysis1Component, outlet: 'home' }, 
{ path: 'conseligibility', component: ConsEligibilityComponent, outlet: 'home' }, 
{ path: 'consbasedonfac', component: ConsBasedonfacComponent, outlet: 'home' }, 
{ path: 'consdscrassessment', component: ConsDscrassessmentComponent, outlet: 'home' }, 
{ path: 'consdeviationtracking', component: ConsDeviationtrackingComponent, outlet: 'home' }, 
{ path: 'consworkflow', component: ConsWorkflowComponent, outlet: 'home' }, 
{ path: 'consfacilityrecommend', component: ConsFacilityRecommendComponent, outlet: 'home' }, 
{ path: 'consslgenerate', component: ConsSlgenerateComponent, outlet: 'home' }, 
{ path: 'consslpreparation', component: ConsSlpreparationComponent, outlet: 'home' }, 
{ path: 'consproptermsandconditions', component: ConsproptermsandconditionsComponent, outlet: 'home' }, 
{ path: 'consscorecard', component: ConsScorecardComponent, outlet: 'home' }, 
{ path: 'consproprecommend', component: ConsproprecommendComponent, outlet: 'home' },
{ path: 'consaccountconductanalysis2', component: ConsAccountconductanalysis2Component, outlet: 'home' }, 
{ path: 'consjustification', component: ConsJustificationComponent, outlet: 'home' }, 
{ path: 'conscvsummary', component: ConsCVsummaryComponent, outlet: 'home' }, 
{ path: 'consbusinessupdate', component: ConsBusinessUpdateComponent, outlet: 'home' }, 
{ path: 'consborrowerrelationship', component: ConsborrowerrelationshipComponent, outlet: 'home' }, 
{ path: 'conspslclassification', component: ConspslclassificationComponent, outlet: 'home' }, 
{path: 'consrcureport', component: ConsRcureportComponent, outlet:'home'},
{path: 'constechnicalreport', component: ConsTechnicalreportComponent, outlet:'home'},
{path: 'conslegalreport', component : ConsLegalreportComponent, outlet:'home'},
{path: 'consverifydata', component : ConsverificationdataComponent, outlet:'home'},

    ]
  },

  // SAMPLE PAGE
  

  { path: 'organization', component: OrganizationComponent },
  { path: '**', redirectTo: '/login' },
  { path: 'bcifdedupeview', component: BcifdedupeviewComponent, outlet: 'home' },
  { path: 'ncifdedupeview', component: NcifdedupeviewComponent, outlet: 'home' },
  { path: 'cibilreportview', component: CibilreportviewComponent, outlet: 'home' },

  

];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);