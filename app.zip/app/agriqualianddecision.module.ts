import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './shared.module';
import { AgriqualianddecisionroutingModule } from './agriqualianddecisionrouting.module';
import { ExistingcustrefComponent } from './agri/existingcustref/existingcustref.component';
import { ExistingkccrepaymentComponent } from './agri/existingkccrepayment/existingkccrepayment.component';
import { AgriscorecardComponent } from './agri/agriscorecard/agriscorecard.component';
import { ExistingcustrefService } from './util/service/agriservices/existingcustref.service';
import { ExistingkccrepaymentService } from './util/service/agriservices/existingkccrepayment.service';
import { ScorecardmasterService } from './util/service/setupservices/scorecardmaster.service';


@NgModule({
  imports: [
    SharedModule,
    AgriqualianddecisionroutingModule
  ],
  declarations: [ExistingcustrefComponent,ExistingkccrepaymentComponent,AgriscorecardComponent],
  providers:[ExistingcustrefService,ExistingkccrepaymentService,ScorecardmasterService]
})
export class AgriqualianddecisionModule { }
