import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangenoteprocessComponent } from './changenoteprocess.component';

describe('ChangenoteprocessComponent', () => {
  let component: ChangenoteprocessComponent;
  let fixture: ComponentFixture<ChangenoteprocessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangenoteprocessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangenoteprocessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
