import { Component, OnInit } from '@angular/core';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { ChangenoteprocessService } from '../../util/service/commonservices/changenoteprocess.service';
import { ViewChild } from '@angular/core';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { HomeComponent } from '../home/home.component';
import { ChangenotepopupComponent } from '../changenotepopup/changenotepopup.component';
import { PropassignedmeComponent } from '../propassignedme/propassignedme.component';
import { Router } from "@angular/router";
import { PropassignedmeService } from "../../util/service/commonservices/propassignedme.service";
declare var $: any

@Component({
  selector: 'lp-changenoteprocess',
  templateUrl: './changenoteprocess.component.html',
  styleUrls: ['./changenoteprocess.component.css']
})
export class ChangenoteprocessComponent extends Validator implements OnInit {
  data: any = {};
  model: any = {};
  modeldoc: any = {};
  imgmodel: any = {};
  validationList: any = ['sel_lchReasonCode'];
  reasonList: any = [];
  historyList: any = [];
  borrowerList: any = [];
  changeNoteDisable: boolean;
  modelForChngNote: any;
  status: String;
  validation: boolean;
  doclist: any = [];
  chgimagedateview: any = {};
  Changenotedcolist: any = [];
  viewmodel: any = {};
  @ViewChild('fileInput') fileInput;
  @ViewChild(ChangenotepopupComponent)
  changenotepopup: ChangenotepopupComponent;
  acceptance: String;
  propno: any;
  restrictFreeze: boolean = true;
  initialFlow:any={};
  constructor(private changeprocess: ChangenoteprocessService, private changenoteService: ChangenoteService, private fieldvalidation: Fieldvalidation
    , private homeComponent: HomeComponent, private router: Router, private source: PropassignedmeComponent, private propassignedmeService: PropassignedmeService, )
  { super(); }

  ngOnInit() {
    this.model = {};
    this.modeldoc = {};
    this.reasonList = [];
    this.historyList = [];
    this.borrowerList = [];
    this.Changenotedcolist = [];
    this.model.lchReasonCode = "s";
    this.modeldoc.lcdCustId = "s";
    this.modeldoc.lcdDocType = "s";
    this.changeNoteDisable = false;

    this.modelForChngNote = this.changenoteService.getProposalData();
    this.changeprocess.getchangenoteprocess().subscribe(
      data => {
        this.data = data;
        this.reasonList = this.data.reasonList;
        this.historyList = this.data.historyList;
        this.status = this.data.status;
        this.propno = this.data.propno;
        this.acceptance = this.data.acceptance;
        this.initialFlow=this.data.initialFlow;
        
        if (this.status == "OP") {
          this.changeNoteDisable = true;
        }
        else {
          if (this.modelForChngNote.useraccess == "C")
          { this.changeNoteDisable = true; }
          else {
            if (this.acceptance == "Y") {
              this.changeNoteDisable = false;
            }
            else {
              this.changeNoteDisable = true;
            }
          }
        }
        if (this.historyList.length == 0) {
          this.model.lchVersion = 1;
          this.modeldoc.lcdVersion = 0;
        }
        else {
          this.model.lchVersion = this.historyList.length + 1;
          this.modeldoc.lcdVersion = this.historyList.length;
        }
        this.getdoclist();
      });


    this.changeprocess.getborrowerList().subscribe(
      data => {
        this.data = data;
        this.borrowerList = this.data.responseData.BorrowerList;
        if (this.data.responseData.restrictFreeze == false)
          this.restrictFreeze = this.data.responseData.restrictFreeze;
      });



  }
  changeNote() {
    this.validationList = [];
    this.validationList = ['sel_lchReasonCode'];
    this.validation = this.fieldvalidation.validateField(this.validationList);
    if (this.validation == true) {
      if (this.restrictFreeze) {
        if (confirm("Do you want to Revert the sanction ?")) {
          $('#reason').modal('show')
        }
        else {
          return false;
        }
      }
      else {
        alert("Please select acceptance either yes or no for borrower(s)");
        return;
      }
    }
  }
  doattached() {
    this.validationList = [];
    this.validationList = ['sel_lcdCustId', 'sel_lcdDocType', 'txt_lcdDocDesc'];
    this.validation = this.fieldvalidation.validateField(this.validationList);
    if (this.validation == true) {
      if ($('#fil_upload_chg').val() == "") {
        alert("Please Choose The File.");
        return;
      }
      else {
        let fileBrowser = this.fileInput.nativeElement;
        if (fileBrowser.files && fileBrowser.files[0]) {
          const formData = new FormData();
          formData.append("file", fileBrowser.files[0]);
          this.modeldoc.lcdDocName = $('#fil_upload_chg').val();
          this.modeldoc.lcdCustName = $('#sel_lcdCustId option:selected').text();
          this.changeprocess.uploadfile(formData, this.modeldoc).subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.getdoclist();
                this.modeldoc.lcdCustId = "s";
                this.modeldoc.lcdDocType = "s";
                this.modeldoc.lcdCustName = "";
                this.modeldoc.lcdDocDesc = "";
                $('#fil_upload_chg').val('');

              }
            });
        }
      }
    }
  }
  getdoclist() {
    this.changeprocess.getdoclist(this.modeldoc).subscribe(
      data => {
        this.data = data;
        this.doclist = this.data.doclist;
      });
  }
  dofreeze() {
    if (this.restrictFreeze) {
      this.model.lchReason = $('#sel_lchReasonCode option:selected').text();
      this.changeprocess.getfreeze(this.model).subscribe(
        data => {
          //get changemode flag
          this.modelForChngNote.changeMode = this.data.changeMode;
          this.modelForChngNote.useraccess = this.data.userType;
          this.model.status = this.data.status;
          this.modelForChngNote.lcmVersion = this.data.version;
          if (this.status == "OP") {
            this.changeNoteDisable = true;
          }
          else {
            if (this.modelForChngNote.useraccess == "C")
              this.changeNoteDisable = true;
            else
              this.changeNoteDisable = false;
          }
          // this.homeComponent.setupPage();
          this.source.getSourcingDetails(this.propno, '', '', '');
          this.router.navigate(['/home/parties/sourcingdetails']);
          $('#reason').modal('hide');
        });
    }
    else {
      alert("Please select acceptance either yes or no for borrower(s)");
      return;
    }
  }
  closeReason() {
    this.modeldoc.lcdCustId = "s";
    this.modeldoc.lcdDocType = "s";
    this.modeldoc.lcdCustName = "";
    this.modeldoc.lcdDocDesc = "";
    $('#fil_upload_chg').val('');
    $('#reason').modal('hide');
  }
  Remove() {
    this.chgimagedateview = {}
    $('#chgmyModal').modal('hide');
  }

  showimg(filename: any, rowid, location) {
    this.chgimagedateview = {};
    this.imgmodel.location = location;
    let strfilespplit = [];
    strfilespplit = location.toString().split(".");
    var fileExtension = strfilespplit[1];
    this.imgmodel.filename = filename;
    this.imgmodel.rowid = rowid;
    this.changeprocess.downloadfile(this.imgmodel).subscribe(

      res => {
        this.data = res;
        fileExtension = fileExtension.trim();
        if (fileExtension == "jpg" || fileExtension == "gif" || fileExtension == "png" ||
          fileExtension == "bmp" || fileExtension == "image_gif" || fileExtension == "image_jpeg" ||
          fileExtension == "image_bmp" || fileExtension == "image_x-png" || fileExtension == "JPG" || fileExtension == "GIF" || fileExtension == "PNG" ||
          fileExtension == "BMP" || fileExtension == "image_GIF" || fileExtension == "image_JPEG" ||
          fileExtension == "image_BMP" || fileExtension == "image_X-PNG" || fileExtension == "JPEG" || fileExtension == "jpeg") {

          //var img = $('<img id="viewimg">'); //Equivalent: $(document.createElement('img'))
          //img.attr('src', this.data.responseData.data);
          //img.width('400px');
          //img.appendTo('#myImgframe');
          this.chgimagedateview = this.data.imageviewdata;
          $("#chgmyModal").show();
        }
        else {
          $('#chgmyModal').modal('hide');
          // using href to display download file...in local machine 
          var link = document.createElement('a');
          link.href = this.data.responseData.data;
          var fileName = filename;
          link.download = fileName;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          alert("File downloaded successfully .Please check downloads folder.");
        }
      });
  }
  doviewdoc(version, type) {
    this.viewmodel.lcdVersion = version;
    this.changeprocess.getdoclist(this.viewmodel).subscribe(
      data => {
        this.data = data;
        this.Changenotedcolist = this.data.doclist;
      });
    $('#docpopup').modal('show')
  }
  closedocpopup() {
    this.Changenotedcolist = [];
    $('#docpopup').modal('hide');

  }
  dochangeterm(version) {
    this.modelForChngNote.currentversion = version;
    this.changenotepopup.ngOnInit();
    $('#chgterms').modal('show')
  }
  docancel() {
    if (confirm("Do you want to Cancel?")) {
      this.modeldoc.lcdCustId = "s";
      this.modeldoc.lcdDocType = "s";
      this.modeldoc.lcdCustName = "";
      this.modeldoc.lcdDocDesc = "";
      $('#fil_upload_chg').val('');
    }
  }

}
