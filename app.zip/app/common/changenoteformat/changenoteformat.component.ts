import { Component, OnInit } from '@angular/core';
import { ChangenoteformatService } from "../../util/service/commonservices/changenoteformat.service";
import { CranService } from "../../util/service/commonservices/cran.service";
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;

@Component({
  selector: 'lp-changenoteformat',
  templateUrl: './changenoteformat.component.html',
  styleUrls: ['./changenoteformat.component.css']
})
export class ChangenoteformatComponent implements OnInit {
  pslMap: any;
  pslMapgrp: any;
  data: any;
  yearSize1: any = [];
  finYrandTypeList1: any = [];
  financialDetails1: any = [];
  showPSL: boolean;
  showPSL2: boolean;
  showPSL2grp: boolean;
  lpcomChangeModeList: any = [];
  exposuredetailsList: any = [];
  exposureView: boolean;
  tempexposuredetailsList: any = [];
  custexposuredetwithKotakList: any = [];
  componentlist: any = [];
  table1: boolean = true;
  masterList: any = [];
  bankingArrangement: any;
  grandTotal: any;
  pgrandTotal: any;
  model: any = {};
  termLoanDetails: any = {};
  private details: Array<any> = [];
  bankNames = [];
  ourBankWCTotal: any;
  ourBankTLTotal: any;
  ourBankNFBTotal: any;
  fbwcTotal: any;
  fbtlTotal: any;
  nfbTotal: any;
  pfbwcTotal: any;
  pfbtlTotal: any;
  pnfbTotal: any;
  totLeeSancAmt: any = 0;
  totLeeOsAmt: any = 0;
  totLeeOverdue: any = 0;
  totROI: any = 0;
  totY1: any = 0;
  totY2: any = 0;
  totY3: any = 0;
  totY4: any = 0;
  exposure: any = [];
  financialDetails: any = [];
  finYrandTypeList: any = [];
  yearSize: any = [];
  finheadView: boolean = false;
  finListView: boolean = true;
  LpcomFacAssessmentMapList: any = [];
  Size: number;
  prodDesc: any = [];
  productDes_: any;
  assessmentView: boolean = true;
  assessmenthead: boolean = false;
  finExpView: boolean = true;
  finExphead: boolean = false;
  recommendAuthorityList: any = [];
  recAuthView: boolean = true;
  bank: any = [];
  lpdate: any;
  year: any;
  counter = 0;
  modelForChngNote: any;
  changechecklist: any;
  vertical: any;
  borrowerList: any = [];
  versionItems: any = [];
  ratingList: any = [];
  disptype: any;

  versionItemsgrp: any = [];
  modelgrp: any = {};
  lpcomChangeModeListgrp: any = [];;
  ratingListgrp: any = [];
  recommendAuthorityListgrp: any = [];
  changechecklistgrp: any = [];
  custlist: any = [];
  pslMapListgrp: any = [];
  recAuthViewgrp: boolean = true;
  pslMapList: any = [];

  constructor(private changenoteformatService: ChangenoteformatService, private pdfdownloadservice: CranService, private changenoteService: ChangenoteService) {
  }

  ngOnInit() {
    this.showPSL = false;
    this.showPSL2 = false;
    // this.showPSL2grp=false;
    this.lpcomChangeModeList = [];
    this.exposuredetailsList = [];
    this.tempexposuredetailsList = [];
    this.custexposuredetwithKotakList = [];
    this.componentlist = [];
    this.masterList = [];
    this.model = {};
    this.termLoanDetails = {};
    this.details = [];
    this.bankNames = [];
    this.exposure = [];
    this.financialDetails = [];
    this.finYrandTypeList = [];
    this.yearSize = [];
    this.LpcomFacAssessmentMapList = [];
    this.prodDesc = [];
    this.recommendAuthorityList = [];
    this.borrowerList = [];
    this.ratingList = [];
    this.versionItemsgrp = [];
    this.modelgrp = [];
    this.lpcomChangeModeListgrp = [];
    this.ratingListgrp = [];
    this.recommendAuthorityListgrp = [];
    this.changechecklistgrp = [];
    this.custlist = [];
    this.pslMapListgrp = [];
    this.pslMapList = [];

    this.counter = 0;
    this.fbwcTotal = 0;
    this.fbtlTotal = 0;
    this.nfbTotal = 0;
    this.pfbwcTotal = 0;
    this.pfbtlTotal = 0;
    this.pnfbTotal = 0;
    this.changechecklist = [];

    if ($('#txt_custId').val() == "") {
      this.model.custId = 0;
    }
    else {
      this.model.custId = $('#txt_custId').val();
    }

    if ($('#txt_setId').val() == "") {
      this.model.setId = 0;
    }
    else {
      this.model.setId = $('#txt_setId').val();
    }
    this.model.disptype = $('#txt_disptype').val();

    this.modelForChngNote = this.changenoteService.getProposalData();
    this.model.currentversion = this.modelForChngNote.lcmVersion;

    this.changenoteformatService.getChangeNoteFormatVertical(this.model)
      .subscribe(
      data => {
        this.data = data;
        this.vertical = this.data.responseData;
        this.versionItems = [];
        this.lpcomChangeModeList = [];

        if (this.vertical == "7") {
          if (this.model.setId != 0 && this.model.custId != 0) {
            this.changenoteformatService.getChangeNoteFormatAgri(this.model)
              .subscribe(
              data => {
                this.data = data;
                if (this.data.success == true) {

                  this.model = this.data.responseData;
                  this.model.KccTotal = this.model.KccTotal.toFixed(2);
                  this.model.FdlTotal = this.model.FdlTotal.toFixed(2);
                  this.model.AtlTotal = this.model.AtlTotal.toFixed(2);
                  this.model.StlTotal = this.model.StlTotal.toFixed(2);
                  this.model.kkrAmount = this.model.kkrAmount.toFixed(2);
                  this.model.Totalsum = this.model.Totalsum.toFixed(2);

                  if (this.data.changenotechecklist.length > 0 && this.data.changenotechecklist != undefined)

                    this.changechecklist = this.data.changenotechecklist;
                  this.borrowerList = this.data.responseData.BorrowerList;
                  this.model.Coborrower = '';
                  this.model.guarantor = '';
                  this.borrowerList.forEach(element => {
                    if (element.BorType == "B") {
                      this.model.BorrowerName = element.Name;
                      this.model.address = element.Address;
                    }
                    if (element.BorType == "C") {
                      if (this.model.Coborrower == '')
                        this.model.Coborrower = element.Name;
                      else
                        this.model.Coborrower = this.model.Coborrower + ',' + element.Name;
                    }
                    if (element.BorType == "G") {
                      if (this.model.guarantor == '')
                        this.model.guarantor = element.Name;
                      else
                        this.model.guarantor = this.model.guarantor + ',' + element.Name;
                    }
                  });

                  //////change not conditions///////
            
                  if (this.data.responseData.lpcomChangeModeList != " " && this.data.responseData.lpcomChangeModeList != undefined) {
                    this.lpcomChangeModeList = this.data.responseData.lpcomChangeModeList;
                    for (var i = this.model.currentversion; i > 0; i--) {
                      this.versionItems.push(i);
                    }
                  }
                  ///Recommandation 
                  this.recommendAuthorityList = this.data.responseData.applicantList;
                }
              });
          }
        }

        if (this.vertical != "7") {
          if (this.model.disptype == "1") {
            this.changenoteformatService.getChangeNoteFormat(this.model)
              .subscribe(
              data => {
                this.versionItems = [];
                this.pslMapList = [];
                this.data = data;
                if (this.data.success == true) {

                  this.model = this.data.responseData;
                  //////change not conditions///////
                  if (this.data.responseData.lpcomChangeModeList.length > 0 && this.data.responseData.lpcomChangeModeList != undefined) {
                    this.lpcomChangeModeList = this.data.responseData.lpcomChangeModeList;
                    for (var j = this.model.currentversion; j > 0; j--) {
                      this.versionItems.push(j);
                    }
                  }

                  if (this.data.changenotechecklist.length > 0 && this.data.changenotechecklist != undefined)
                    this.changechecklist = this.data.changenotechecklist;
                  this.ratingList = this.data.responseData.lpcomIntRatingDetails;
                  // this.pslMapList=this.data.responseData.pslMapList;
                  this.pslMap = this.data.responseData.pslMap;
                  if (this.pslMap == undefined || this.pslMap == null) {
                    this.showPSL = false;
                  }
                  else {
                    this.showPSL = true;
                    if (this.pslMap.psl === true) {
                      this.pslMap.psl = "PSL";
                    }

                    else if (this.pslMap.psl === "") {
                      this.pslMap.psl = "";
                      this.pslMap.catClassify = "";
                    }
                    else if (this.pslMap.psl === false) {
                      this.pslMap.psl = "Non-PSL";
                      this.pslMap.catClassify = "";
                    }
                  }
                  //////////////recommendation//////////////
                  this.recommendAuthorityList = this.data.responseData.applicantList;
                  if (this.recommendAuthorityList != undefined && this.recommendAuthorityList.length > 0) {
                    this.recAuthView = false;

                  }
                  this.counter = 0;
                }
              },
              error => {
              });
          }
          else {

            this.changenoteformatService.getChangeNoteFormatgrp(this.model)
              .subscribe(
              data => {
                this.versionItemsgrp = [];
                this.modelgrp = [];
                this.lpcomChangeModeListgrp = [];
                this.ratingListgrp = [];
                this.recommendAuthorityListgrp = [];
                this.changechecklistgrp = [];
                this.pslMapListgrp = [];
                this.data = data;
                if (this.data.success == true) {

                  this.custlist = this.data.responseData.custuniqList;
                  this.modelgrp = this.data.responseData;
                  //////change not conditions///////
                  this.lpcomChangeModeListgrp = this.data.responseData.lpcomChangeModeList;
                  if (this.data.responseData.lpcomChangeModeList) {
                    for (var j = this.model.currentversion; j > 0; j--) {
                      this.versionItemsgrp.push(j);
                    }
                  }

                  if (this.data.changenotechecklist)
                    this.changechecklistgrp = this.data.changenotechecklist;

                  if (this.data.responseData.lpcomIntRatingDetails)
                    this.ratingListgrp = this.data.responseData.lpcomIntRatingDetails;
                  //  this.pslMapListgrp=this.data.responseData.pslMapList;

                  this.pslMapgrp = this.data.responseData.pslMap;
                  if (this.pslMapgrp == undefined || this.pslMapgrp == null) {
                    this.showPSL2grp = false;
                  }
                  else {
                    this.showPSL2grp = true;
                    if (this.pslMapgrp.psl === true) {
                      this.pslMapgrp.psl = "PSL";
                    }

                    else if (this.pslMapgrp.psl === "") {
                      this.pslMapgrp.psl = "";
                      this.pslMapgrp.catClassify = "";
                    }
                    else if (this.pslMapgrp.psl === false) {
                      this.pslMapgrp.psl = "Non-PSL";
                      this.pslMapgrp.catClassify = "";
                    }

                  }


                  //////////////recommendation//////////////
                  if (this.data.responseData.applicantList)
                    this.recommendAuthorityListgrp = this.data.responseData.applicantList;

                  if (this.recommendAuthorityListgrp != undefined && this.recommendAuthorityListgrp.length > 0) {
                    this.recAuthViewgrp = false;
                  }
                  this.counter = 0;
                }
              });
          }
        }

      });

  }

  closeChangeNoteFormat() {
    $('#changeNoteFormat').modal('hide');
  }
  pdfdownload() {
    var html = "<html><head></head>" + $("#pdf_div3").html() + "</html>";
    var jHtmlObject = $("#pdf_div3").clone();
    // jHtmlObject.find("#tableimg tr:first").remove();
    // jHtmlObject.find("#tableimg tr:last").remove();
    // jHtmlObject.find("#tableimg").remove();
    var htmlString = "<html><head></head>" + jHtmlObject.html() + "</html>";
    var borrDet = { custId: this.model.custId.toString(), attachType: '1' };
    this.pdfdownloadservice.downloadOutputFormat(htmlString, borrDet)
      .subscribe(
      data => {
        this.data = data;
        var link = document.createElement('a');
        link.href = this.data.responseData.data;
        var fileName = this.data.responseData.filename;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      },
      error => {
      });

  }

}


