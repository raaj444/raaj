import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangenoteformatComponent } from './changenoteformat.component';

describe('ChangenoteformatComponent', () => {
  let component: ChangenoteformatComponent;
  let fixture: ComponentFixture<ChangenoteformatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangenoteformatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangenoteformatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
