import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Validator } from "../../util/helper/validator";
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { AdditionalinfoService } from '../../util/service/commonservices/additionalinfo.service';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any


@Component({
  selector: 'lp-additionalinfo',
  templateUrl: './additionalinfo.component.html',
  styleUrls: ['./additionalinfo.component.css']
})
export class AdditionalinfoComponent extends Validator implements OnInit {
  data: any;
  ngAfterViewInit(): void {
    $($('.fr-wrapper').children('div')[0]).hide();
  }
  model: any = {};
  editbuttonDisable: boolean;
  savebuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  newheaderDisable: boolean;
  private additionalInfoArray: Array<any> = [];
  customerList: any = [];
  save: string;
  pageAccess: string;
  headerDisable: boolean;
  flag: boolean;
  idvalueList: any = ['Heading'];
  modelForChngNote: any;
  templateDisable: boolean

  constructor(private additionalinfoService: AdditionalinfoService,
    private router: Router, private fieldvalidation: Fieldvalidation
  ) {
    super();
  }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    this.getQualitativeMasterForAI();
  }
  getQualitativeMasterForAI() {
    loadingStatus();
    this.customerList = [];
    this.model.lpaiCustNewId = "";
    this.model.Heading = "";
    this.headerDisable = true;
    this.newheaderDisable = true;
    this.model.lpaiComments = ""
    // $("#txtEditor").Editor("setText", " ");
    // $("#txtEditor").Editor("setEnable", false);
    this.templateDisable = true
    this.buttonAccess(true, true, true);
    this.model.additionalInfoArray = [];
    let customerdet = { lpaiCustNewId: this.model.lpaiCustNewId };
    this.additionalinfoService.getQualitativeMasterForAI(customerdet)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.pageAccess = this.data.pageAccess;
            this.customerList = this.data.responseData.lpcomCustInfoApplist;
            if (this.customerList != undefined && this.customerList.length == 1) {
              this.model.lpaiCustNewId = this.customerList[0].lciCustId;
              this.getCustomerDetails();
            }
          }
          else {
            this.headerDisable = false;
            this.newheaderDisable = false;
          }
        }, error => {
        }
      )
    hide()
  }
  getCustomerDetails() {
    this.headerDisable = true;
    if (this.model.additionalInfoArray != undefined) {
      this.model.additionalInfoArray.forEach(element => {
        element.color = "white";
      });
    }
    this.model.lpaiComments = "";
    this.model.Heading = "";
    // $("#txtEditor").Editor("setEnable", false);
    this.templateDisable = true
    // $("#txtEditor").Editor("setText","");
    if (this.model.lpaiCustNewId == "" || this.pageAccess == "R") {
      this.newheaderDisable = true;
      this.buttonAccess(true, true, true);
    }
    else {

      this.newheaderDisable = false;
    }
    loadingStatus();
    let customerdet = { lpaiCustNewId: this.model.lpaiCustNewId };
    this.additionalinfoService.getQualitativeMasterForAI(customerdet)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.model.additionalInfoArray = this.data.responseData.headerDataList;
          }
        },
        error => {
          // this.alertService.error(error);
        });
    hide()
  }

  getContent(field: any, i: any) {
    if (field.lpaiRowId != '') {
      if (this.model.lpaiCustNewId != "") {
        let Existing = 0;
        if (this.pageAccess != "R") {
          this.newheaderDisable = false;
          this.headerDisable = true;
        }
        this.model.Heading = "";
        this.model.additionalInfoArray.forEach(element => {
          element.color = 'white';
        });

        this.model.additionalInfoArray.forEach((elementAll, index) => {
        if (field.sqmRowId == elementAll.sqmRowId && elementAll.lpaiCustNewId == this.model.lpaiCustNewId) {
          // if (field.sqmRowId == elementAll.lpaiCmtId && elementAll.lpaiCustNewId == this.model.lpaiCustNewId) {
            this.model.lpaiRowId = elementAll.lpaiRowId;
            this.model.Heading = elementAll.sqmCommentHeader;
            this.model.lpaiComments = elementAll.lpaiComments;
            // $("#txtEditor").Editor("setText", elementAll.lpaiComments);
            // Existing = 1;
          }
        });
        // if (Existing == 0) {
        //   this.model.lpaiComments = ""
        //   // $("#txtEditor").Editor("setText", "");
        //   this.model.Heading = this.model.additionalInfoArray[i].sqmCommentHeader;
        // }
        this.model.additionalInfoArray[i].color = "Pink";
        this.model.index = i;
        this.save = "update";
        if (!this.newheaderDisable) {
          this.buttonAccess(false, true, true);
          // $("#txtEditor").Editor("setEnable", false);
          this.templateDisable = true
        }
        else {
          // $("#txtEditor").Editor("setEnable", true);
          this.templateDisable = false
          this.buttonAccess(true, false, false);
        }
      }
    }
  }
  saveAddinfoDetail() {
    //check on changeMode
    this.flag = this.fieldvalidation.validateField(this.idvalueList)
    //Save on changeMode
    // this.model.lpaiComments = $("#txtEditor").Editor("getText");
    if (this.save == "Insert") {
      this.model.AddInfo = { lpaiComments: this.model.lpaiComments, lpaiCmtFor: "AI", lpaiCmtId: 0, lpaiCmtHeading: this.model.Heading, lpaiRowId: 0, lpaiCustNewId: this.model.lpaiCustNewId };
    }
    if (this.save == "update") {
      this.model.AddInfo = { lpaiComments: this.model.lpaiComments, lpaiCmtFor: "AI", lpaiCmtId: this.model.additionalInfoArray[this.model.index].sqmRowId, lpaiRowId: this.model.lpaiRowId, lpaiCmtHeading: this.model.Heading, lpaiCustNewId: this.model.lpaiCustNewId };
    }
    this.flag = this.fieldvalidation.validateField(this.idvalueList)
    if (this.flag) {
      var regex = /&nbsp;/gi;
      var temp = this.model.lpaiComments;
      temp = temp.replace(regex, " ");
      if (temp.trim() == "" || temp == null || temp == undefined) {
        alert("Please enter the comments");
        return false;
      }
      progressStatus()
      this.additionalinfoService.saveAddInfoDetails(this.model.AddInfo)
        .subscribe(
          data => {
            this.data = data;
            if (this.data.success) {
              this.buttonAccess(true, true, true);
              successStatus()
              let customerdet = { lpaiCustNewId: this.model.lpaiCustNewId };
              this.additionalinfoService.getQualitativeMasterForAI(customerdet)
                .subscribe(
                  data => {
                    this.data = data;
                    if (this.data.success) {
                      if (this.pageAccess == "R")
                        this.newheaderDisable = true;
                      else
                        this.newheaderDisable = false;
                      this.model.additionalInfoArray = this.data.responseData.headerDataList;
                      this.model.additionalInfoArray.forEach(element => {
                        element.color = "white";
                      });
                      // $("#txtEditor").Editor("setEnable", false);
                      this.templateDisable = true
                      // $("#txtEditor").Editor("setText", "");

                      this.model.Heading = "";
                      this.model.lpaiComments = "";
                      this.headerDisable = true;
                    }
                  },
                  error => {
                    failedStatus()
                  });
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
          },
          error => {
            failedStatus()
            // this.alertService.error(error);
          });
    }
  }
  editAddinfoDetail() {
    this.buttonAccess(true, false, false);
    // $("#txtEditor").Editor("setEnable", true);
    this.templateDisable = false
  }

  addCommentheader() {
    this.model.Heading = "";
    this.save = "Insert";
    this.model.lpaiComments = ""
    // $("#txtEditor").Editor("setText", "");
    // $("#txtEditor").Editor("setEnable", true);
    this.templateDisable = false
    this.headerDisable = false;
    this.buttonAccess(true, false, false);
  }

  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.getQualitativeMasterForAI();
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
    }
    else
      return false;
  }
  buttonAccess(val1: boolean, val2: boolean, val3: boolean) {
    if (this.pageAccess == "R") {
      this.editbuttonDisable = true;
      this.savebuttonDisable = true;
      this.cancelbuttonDisable = true;

    }
    else {
      this.editbuttonDisable = val1;
      this.savebuttonDisable = val2;
      this.cancelbuttonDisable = val3;
    }
  }
}
