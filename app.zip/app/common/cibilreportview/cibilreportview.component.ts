import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Router } from '@angular/router';
import { IndividualappdetService } from '../../util/service/corporateservices/individualappdet.service';
import { CranService } from '../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cibilreportview',
  templateUrl: './cibilreportview.component.html',
  styleUrls: ['./cibilreportview.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CibilreportviewComponent  implements OnInit {   data:any; 
  model: any = {};
  cibilReport = "";
  custId: any;
  CRANType: any = "";
  constructor(private individualappdetService: IndividualappdetService,
    private router: Router,
    private fieldvalidation: Fieldvalidation, private cranService: CranService) {

  }

  ngOnInit() {
    // this.cibilReport = this.individualappdetService.getDataForNcifDedupeView();
    this.custId = $('#custId').val();
  }
  callClose() {
    $('#CibilReportView').modal('hide');
    this.cibilReport = "";
    this.custId = "";
  }

  downloadPdf() {
    this.custId = $('#custId').val();
    if (this.cibilReport != "------- No Data Found ---------") {
      //download pdf in server
      var borrDet;
      var jHtmlObject = $("#cibilReportPdf").clone();
      var htmlString = "<html><head></head>" + jHtmlObject.html() + "</html>";
      borrDet = { 'custId': this.custId, attachType: '7' };

      this.cranService.downloadOutputFormat(htmlString, borrDet)
        .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              var link = document.createElement('a');
              link.href = this.data.responseData.data;
              var fileName = this.data.responseData.filename;
              link.download = fileName;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }
          },
          error => {
          });
    } else {
      alert("No Data Found");
    }

  }

}
