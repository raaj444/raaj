import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnexureslComponent } from './annexuresl.component';

describe('AnnexureslComponent', () => {
  let component: AnnexureslComponent;
  let fixture: ComponentFixture<AnnexureslComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnexureslComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnexureslComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
