import { Component, OnInit } from '@angular/core';
import { SltemplateService } from "../../util/service/commonservices/sltemplate.service";
declare var $: any;

@Component({
  selector: 'lp-annexuresl',
  templateUrl: './annexuresl.component.html',
  styleUrls: ['./annexuresl.component.css']
})
export class AnnexureslComponent implements OnInit {
  dinNoList: any=[];
  monitoringConditions: any = [];
  creditConditions: any = [];
  shareHoldingList: any = [];
  data: any;

  EscrowConditionsTable: any;
  propertyDetailsList: any = [];
  model: any = {};
  relevantcolasts: any = [];
  coveragelvl: any = [];
  valderived: any = [];
  glemsBasicData: any = {};

  constructor(private sltemplateService: SltemplateService) { }

  ngOnInit() {
    this.relevantcolasts = [];
    this.coveragelvl = [];
    this.valderived = [];
    this.model.collateralDet = [];
    this.model.collateralFac = [];
    this.model.glemsOthrDet = [];
    this.model.glemsColImmov = [];
    this.model.collateralID = "";
    this.model.collateralAsts = "";
    this.shareHoldingList=[];
    this.model.creditConditions=[];
    this.model.monitoringConditions=[];
    this.model.operatingConditions=[];
    this.model.glemsFac=[];
    this.model.glems3List=[];
    this.dinNoList=[];

    if ($('#txt_custId').val() == "") {
      this.model.custId = 0;
    }
    else {
      this.model.custId = $('#txt_custId').val();
    }

    if ($('#txt_setId').val() == "") {
      this.model.setId = 0;
    }
    else {
      this.model.setId = $('#txt_setId').val();
    }

    this.EscrowConditionsTable = "";
    this.propertyDetailsList = [];

    this.sltemplateService.generateAnnexure(this.model)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {

            this.model = this.data.responseData;

            if(this.model.shareHolderNameList!="" && this.model.shareHolderNameList.length>0)
              {
                 this.shareHoldingList=this.model.shareHolderNameList;
              }

            if(this.model.creditConditions.length>0 && this.model.creditConditions!=undefined)
              {
                this.creditConditions=this.model.creditConditions;
              }

            if(this.model.monitoringConditions.length>0 && this.model.monitoringConditions!=undefined)
              this.monitoringConditions=this.model.monitoringConditions;

            if(this.model.dinNoList.length>0 && this.model.dinNoList!=undefined)
              {
                this.dinNoList=this.model.dinNoList;
              }
                
            this.EscrowConditionsTable = this.data.responseData.EscrowConditionsTable;

            if (this.EscrowConditionsTable != "") {
                $("#escrowCond").html(this.EscrowConditionsTable);
            }

          if(this.model.lpcomExposureDetList!=undefined && this.model.lpcomExposureDetList.length>0)
            {
              this.model.lpcomExposureDetList.forEach(element => {
                element.amount= parseFloat(element.amount).toFixed(2);
              });
            }

            this.propertyDetailsList = [];
            this.propertyDetailsList = this.data.responseData.propertyDetailList;

            this.glemsBasicData = this.data.responseData.lpcomGlemsBasicData;

            if (this.glemsBasicData.lgbdMaturityDate != "" && this.glemsBasicData.lgbdMaturityDate != null && this.glemsBasicData.lgbdMaturityDate != undefined) {
              var lgbdMaturityDate = this.glemsBasicData.lgbdMaturityDate;
              var datearray = lgbdMaturityDate.split("-");
              var datearray = lgbdMaturityDate.split("-");
              this.glemsBasicData.lgbdMaturityDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
            }

            this.model.glemsFac = this.data.responseData.glemsFac;
            this.model.remarks = this.data.responseData.remarks;

            this.model.collateralID = this.data.responseData.pageCommentColId;
            this.model.collateralAsts = this.data.responseData.pageCommentColAst;

            this.model.collateralDet = this.data.responseData.lpcomGlemsCollateralList;
            this.model.collateralFac = this.data.responseData.lpcomGlemsColFacList;
            this.model.glemsOthrDet = this.data.responseData.lpcomGlemsOthrDetList;
            this.model.glemsColImmov = this.data.responseData.lpcomGlemsColImmovableList;

            this.model.glems3List = this.data.responseData.glems3List;

            this.relevantcolasts = this.data.responseData.relevantcolasts;
            this.coveragelvl = this.data.responseData.coveragelvl;
            this.valderived = this.data.responseData.valderived;

            this.model.collateralFac.forEach(element => {
              element.lgcfNomAmt = parseFloat(element.lgcfNomAmt).toFixed(2);
              element.lgcfCovRatio = parseFloat(element.lgcfCovRatio).toFixed(2);

              var temp1 = this.relevantcolasts.findIndex(x => x.llvOptionVal == element.lgcfColAsset);
              if (temp1 >= 0)
                element.lgcfColAsset = this.relevantcolasts[temp1].llvOptionDesc;
              else
                element.lgcfColAsset = "";

              var temp2 = this.coveragelvl.findIndex(x => x.llvOptionVal == element.lgcfCovLvl);
              if (temp2 >= 0)
                element.lgcfCovLvl = this.coveragelvl[temp2].llvOptionDesc;
              else
                element.lgcfCovLvl = "";
            });

            this.model.glemsOthrDet.forEach(element => {
              element.lgodHaircutRatio = parseFloat(element.lgodHaircutRatio).toFixed(2);
              element.lgodShareRatio = parseFloat(element.lgodShareRatio).toFixed(2);
              element.lgodValAccpt = parseFloat(element.lgodValAccpt).toFixed(2);

              var temp1 = this.relevantcolasts.findIndex(x => x.llvOptionVal == element.lgodColAsset);
              if (temp1 >= 0)
                element.lgodColAsset = this.relevantcolasts[temp1].llvOptionDesc;
              else
                element.lgodColAsset = "";

              var temp1 = this.valderived.findIndex(x => x.llvOptionVal == element.lgodValue);
              if (temp1 >= 0)
                element.lgodValue = this.valderived[temp1].llvOptionDesc;
              else
                element.lgodValue = "";
            });

            this.model.glemsColImmov.forEach(element => {
              element.lgciProgRatio = parseFloat(element.lgciProgRatio).toFixed(2);

              var temp1 = this.relevantcolasts.findIndex(x => x.llvOptionVal == element.lgciColAssets);
              if (temp1 >= 0)
                element.lgciColAssets = this.relevantcolasts[temp1].llvOptionDesc;
              else
                element.lgciColAssets = "";
            });
          }

        },
        error => {
        });


  }

}
