import { Component, OnInit } from '@angular/core';
declare var $: any;
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
@Component({
  selector: 'lp-changenote',
  templateUrl: './changenote.component.html',
  styleUrls: ['./changenote.component.css']
})
export class ChangenoteComponent implements OnInit {
    data: any;
  fieldDisable: boolean;
  crdfieldDisable: boolean;
  modelForChngNote: any;
  model: any = {};
  idvalueList: any = ['lcmComments'];
  flag: boolean;
  editorFlag = true;
  usertype: String;
  prechangetermsList: any = [];
  premodel: any;
  constructor(private changenoteService: ChangenoteService, private fieldvalidation: Fieldvalidation) { }

  ngOnInit() {
    // editor added by deepika
    this.fieldDisable = true;
    this.crdfieldDisable = true;
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.model.lcmCustSpecific = this.modelForChngNote.lcmCustSpecific;
    this.usertype = this.modelForChngNote.useraccess;
    this.model.lcmVersion = this.modelForChngNote.lcmVersion;
    if (this.model.lcmCustSpecific == "Y")
      this.model.lcmCustId = this.modelForChngNote.lcmCustId;
    else
      this.model.lcmCustId = '';

    this.changenoteService.getchangemode(this.model).subscribe(
      data => {
      this.data = data;
        this.model = this.data.responseData.lpcomChangeMode;
        if (this.model == null)
          this.setfield();
      });
    for (var i = 0; i < this.idvalueList.length; i++) {
      $('#' + this.idvalueList[i]).removeClass("has-error");
      $('#' + this.idvalueList[i]).attr('placeholder', ' ');
    }

    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
  }
  onload(pageAccess: any) {
    if (pageAccess == "R") {
      this.fieldDisable = true;
      this.crdfieldDisable = true;
    }
    this.ngOnInit();
  }
  onEdit(fieldDisable) {
    this.usertype = this.modelForChngNote.useraccess;
    this.fieldDisable = fieldDisable;
    this.crdfieldDisable = fieldDisable;
    if (this.usertype != 'C') {
      this.crdfieldDisable = true;
    }
  }
  onValidate() {
    this.flag = this.fieldvalidation.validateField(this.idvalueList)
    var regex = /&nbsp;/gi;
    var temp = this.model.lcmExistTerms;
    var tempcomment = this.model.lcmProposedTerms;
    temp = temp.replace(regex, " ");
    tempcomment = tempcomment.replace(regex, " ");
    if (this.usertype == 'C') {

      var tempcreditcmd = this.model.lcmCreditView;
      tempcreditcmd = tempcreditcmd.replace(regex, " ");
      if (temp.trim() != "" && temp != null && temp != undefined && tempcomment.trim() != "" && tempcomment != null && tempcomment != undefined && tempcreditcmd.trim() != "" && tempcreditcmd != null && tempcreditcmd != undefined
        && this.model.lcmComments != null && this.model.lcmComments != undefined && this.model.lcmComments != "") {
        this.flag = true;
      }
      else {
        this.flag = false;
        alert("Please enter Change Note Conditions");
      }
    }
    else {
      if (temp.trim() != "" && temp != null && temp != undefined && tempcomment.trim() != "" && tempcomment != null && tempcomment != undefined && this.model.lcmComments != null && this.model.lcmComments != undefined && this.model.lcmComments != "") {
        this.flag = true;
      }
      else {
        this.flag = false;
        alert("Please enter Change Note Conditions");
      }
    }

    if (this.flag) {
      return this.flag;
    }
  }

  onSave() {
    //call save service 
    if (this.model.lcmCustSpecific == "Y")
      this.model.lcmCustId = this.modelForChngNote.lcmCustId;
    else
      this.model.lcmCustId = '';
    this.changenoteService.savechangenote(this.model).subscribe(
      data => {
      this.data = data;
        this.model = this.data.responseData.lpcomChangeMode;
        if (this.model == null)
          this.setfield();
        this.ngOnInit();
      });
  }
  setfield() {
    this.model = { 'lcmComments': "", 'lcmPrintable': "Y", 'lcmExistTerms': "", 'lcmProposedTerms': "", 'lcmCreditView': "" };
    this.model.lcmComments = "";
    this.model.lcmPrintable = "Y";
    this.model.lcmExistTerms = "";
    this.model.lcmProposedTerms = "";
    this.model.lcmCreditView = "";
    this.model.lcmCustSpecific = this.modelForChngNote.lcmCustSpecific;
    this.usertype = this.modelForChngNote.useraccess;
    this.model.lcmVersion = this.modelForChngNote.lcmVersion;
    this.model.lcmCustId = this.modelForChngNote.lcmCustId;
  }
  doprechg() {
    this.premodel = { 'lcmVersion': '' };
    this.prechangetermsList = [];
    this.premodel.lcmVersion = parseInt(this.model.lcmVersion) - 1;
    this.changenoteService.getoverallchangemode(this.premodel).subscribe(
      data => {
        this.data = data;
        this.prechangetermsList = this.data.changetermsList;
      });
  }
  closeprechg() {
    this.prechangetermsList = [];
    $('#prechg').modal('hide')
  }

}
