import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangenoteComponent } from './changenote.component';

describe('ChangenoteComponent', () => {
  let component: ChangenoteComponent;
  let fixture: ComponentFixture<ChangenoteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangenoteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangenoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
