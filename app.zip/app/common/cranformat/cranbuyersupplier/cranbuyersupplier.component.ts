import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranbuyersupplier',
  templateUrl: './cranbuyersupplier.component.html',
  styleUrls: ['./cranbuyersupplier.component.css']
})
export class CranbuyersupplierComponent implements OnInit {

  pageComments: any;
  data: any;
  componentlist: any = [];
  buyerArray: Array<any> = [];
  supplierArray: Array<any> = [];
  totalCySup: any;
  totalPySup: any;
  totalCyBuy: any;
  totalPyBuy: any;
  Background: any;
  BackgroundCmts: boolean = true;
  buyerSupplierList: boolean = true;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CranbuyersupplierComponent'
      },
    ];

    this.pageComments = "";
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.buyerArray = [];
            this.supplierArray = [];
            this.pageComments = this.data.pageComments;
            var reqDueDataList = this.data.responseData.reqDueDataList;
            this.Background = this.data.responseData.Background;
            if (reqDueDataList != undefined && reqDueDataList.length > 0) {
              this.buyerSupplierList = true;
              reqDueDataList.forEach(element => {
                if (element.lbsEntryFor == "C") {
                  element.lbsCyAmt = this.parseEmptytoFloat(element.lbsCyAmt).toFixed(2);
                  element.lbsCyPercent = this.parseEmptytoFloat(element.lbsCyPercent).toFixed(2);
                  element.lbsPyAmt = this.parseEmptytoFloat(element.lbsPyAmt).toFixed(2);
                  element.lbsPyPercent = this.parseEmptytoFloat(element.lbsPyPercent).toFixed(2);
                  this.buyerArray.push(element)
                }
                else {
                  element.lbsCyAmt = this.parseEmptytoFloat(element.lbsCyAmt).toFixed(2);
                  element.lbsCyPercent = this.parseEmptytoFloat(element.lbsCyPercent).toFixed(2);
                  element.lbsPyAmt = this.parseEmptytoFloat(element.lbsPyAmt).toFixed(2);
                  element.lbsPyPercent = this.parseEmptytoFloat(element.lbsPyPercent).toFixed(2);
                  this.supplierArray.push(element)
                }
                this.supplierTotalCy(this.supplierArray.length - 1)
                this.supplierTotalPy(this.supplierArray.length - 1)
                this.buyerTotalCy(this.buyerArray.length - 1)
                this.buyerTotalPy(this.buyerArray.length - 1)
              });
            }
            else {
              this.buyerSupplierList = false;
            }

            if (this.Background != undefined && this.Background != "") {
              this.BackgroundCmts = true;
              $("#Background").html(this.Background);
            } else {
              this.BackgroundCmts = false;
            }
          }
          else {
            this.buyerSupplierList = false;
            this.BackgroundCmts = false;
          }
        },
        error => {
          this.buyerSupplierList = false;
          this.BackgroundCmts = false;
        });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
  supplierTotalCy(i) {
    this.totalCySup = 0.00;
    for (let j = 0; j <= i; j++) {
      this.totalCySup = parseFloat(this.totalCySup) + parseFloat(this.supplierArray[j].lbsCyAmt);
      if (this.totalCySup == 'NaN')
        this.totalCySup = 0.00;
      this.totalCySup = parseFloat(this.totalCySup).toFixed(2);
    }
  }
  supplierTotalPy(i) {
    this.totalPySup = 0.00;
    for (let j = 0; j <= i; j++) {
      this.totalPySup = parseFloat(this.totalPySup) + parseFloat(this.supplierArray[j].lbsPyAmt);
      if (this.totalPySup == 'NaN')
        this.totalPySup = 0.00;
      this.totalPySup = parseFloat(this.totalPySup).toFixed(2);
    }
  }
  buyerTotalCy(i) {
    this.totalCyBuy = 0.00;
    for (let j = 0; j <= i; j++) {
      this.totalCyBuy = parseFloat(this.totalCyBuy) + parseFloat(this.buyerArray[j].lbsCyAmt);
    }
    if (this.totalCyBuy == 'NaN')
      this.totalCyBuy = 0.00;
    this.totalCyBuy = parseFloat(this.totalCyBuy).toFixed(2);

  }
  buyerTotalPy(i) {
    this.totalPyBuy = 0.00;
    for (let j = 0; j <= i; j++) {
      this.totalPyBuy = parseFloat(this.totalPyBuy) + parseFloat(this.buyerArray[j].lbsPyAmt);
    }
    if (this.totalPyBuy == 'NaN')
      this.totalPyBuy = 0.00;
    this.totalPyBuy = parseFloat(this.totalPyBuy).toFixed(2);

  }

}

