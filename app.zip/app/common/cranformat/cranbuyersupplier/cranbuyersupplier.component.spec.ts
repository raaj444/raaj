import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranbuyersupplierComponent } from './cranbuyersupplier.component';

describe('CranbuyersupplierComponent', () => {
  let component: CranbuyersupplierComponent;
  let fixture: ComponentFixture<CranbuyersupplierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranbuyersupplierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranbuyersupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
