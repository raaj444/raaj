import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-cranaudinfo1',
  templateUrl: './cranaudinfo1.component.html',
  styleUrls: ['./cranaudinfo1.component.css']
})
export class Cranaudinfo1Component  implements OnInit {   data:any; 

  componentlist :any=[];
  audinfo:any={};
  constructor(private cran: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'Cranaudinfo1Component'
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
      
            this.audinfo = this.data.responseData.CaseDetCredit;
           }
          });
  }
}

