import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cranaudinfo1Component } from './cranaudinfo1.component';

describe('Cranaudinfo1Component', () => {
  let component: Cranaudinfo1Component;
  let fixture: ComponentFixture<Cranaudinfo1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cranaudinfo1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cranaudinfo1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
