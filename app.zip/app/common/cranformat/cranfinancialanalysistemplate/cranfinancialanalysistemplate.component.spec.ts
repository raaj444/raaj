import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranfinancialanalysistemplateComponent } from './cranfinancialanalysistemplate.component';

describe('CranfinancialanalysistemplateComponent', () => {
  let component: CranfinancialanalysistemplateComponent;
  let fixture: ComponentFixture<CranfinancialanalysistemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranfinancialanalysistemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranfinancialanalysistemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
