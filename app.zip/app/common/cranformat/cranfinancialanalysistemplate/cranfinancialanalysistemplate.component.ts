import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranfinancialanalysistemplate',
  templateUrl: './cranfinancialanalysistemplate.component.html',
  styleUrls: ['./cranfinancialanalysistemplate.component.css']
})
export class CranfinancialanalysistemplateComponent  implements OnInit {   data:any; 
  componentlist:any=[];
  finlist:any=[];
 finListView:boolean=true;
 @Input()
 cranTypeFromResolver:string;
  constructor(private cran: CranService) { }

  ngOnInit() {
    this.finListView=false;
    this.componentlist = [
      {
        name: 'CranfinancialanalysistemplateComponent', cranType:this.cranTypeFromResolver
      },
    ];
   
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.finlist=this.data.responseData.finlist;
           this.finListView=true;
          }
          else{
            this.finListView=false;
           
           }
         },error=>{
          this.finListView=false;
         
         });
  }

}
