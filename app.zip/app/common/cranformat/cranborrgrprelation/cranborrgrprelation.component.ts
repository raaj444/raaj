import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranborrgrprelation',
  templateUrl: './cranborrgrprelation.component.html',
  styleUrls: ['./cranborrgrprelation.component.css']
})
export class CranborrgrprelationComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  model:any={};
    constructor(private cranService: CranService) { }
    ngOnInit() {
      this.model.response={};
    this.componentlist = [
      {
        name: 'CranborrgrprelationComponent'
      },
    ];

    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        if(this.data.success)
        {
          this.model.response=this.data.responseData;
      }
      },
      error => {
      });
  }
}
