import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranborrgrprelationComponent } from './cranborrgrprelation.component';

describe('CranborrgrprelationComponent', () => {
  let component: CranborrgrprelationComponent;
  let fixture: ComponentFixture<CranborrgrprelationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranborrgrprelationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranborrgrprelationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
