import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandynamicassessmentComponent } from './crandynamicassessment.component';

describe('CrandynamicassessmentComponent', () => {
  let component: CrandynamicassessmentComponent;
  let fixture: ComponentFixture<CrandynamicassessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandynamicassessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandynamicassessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
