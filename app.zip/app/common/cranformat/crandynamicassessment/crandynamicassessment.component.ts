import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-crandynamicassessment',
  templateUrl: './crandynamicassessment.component.html',
  styleUrls: ['./crandynamicassessment.component.css']
})
export class CrandynamicassessmentComponent implements OnInit {

  data: any;
  componentlist: any = [];
  dynamicAssmtList: any = [];
  dynView: boolean = true;

  constructor(private cran: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CrandynamicassessmentComponent'
      },
    ];
    this.cran.getDataForCranList(this.componentlist).subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.dynamicAssmtList = this.data.responseData.dynamicAssessmentList;
          if (this.dynamicAssmtList && this.dynamicAssmtList.length > 0) {
            this.dynView = false;
          }
        }
      },
      error => {
      }
    );
  }
}
