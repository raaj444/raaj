import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranbankingquality',
  templateUrl: './cranbankingquality.component.html',
  styleUrls: ['./cranbankingquality.component.css']
})
export class CranbankingqualityComponent implements OnInit {
  avg: any;
  data: any;
  behaviourView: boolean = true;
  componentlist: any = [];
  bankingQualityList: any = [];
  bankingView: boolean = true;
  comments: any;
  accountBasedTotAvgList: any = [];
  lacaChqRtnIw: any;
  lacaChqRtnIwAmtvalue: any;
  lacaChqRtnOwvalue: any;
  lacaChqRtnOwAmtvalue: any;
  lacaPeakUtilitizevalue: any;
  lacaDaysExcessvalue: any;
  lacaLowUtilizevalue: any;
  lacaAvgCcodvalue: any;
  lacaAvgbalCcodvalue: any;
  lacaMinbalCcodvalue: any;
  lacaMaxbalCcodvalue: any;
  aluTot: any;
  accwiseData = [];
  newMonthwiseList: any = [];
  monthForTotAvg = [];
  monthForCRANTemp = [];
  monthForCRAN = [];

  @Input()
  cranTypeFromResolver: string;

  constructor(private cran: CranService) { }

  ngOnInit() {
    this.aluTot = 0;
    this.avg = 0;
    this.bankingQualityList = [];
    this.componentlist = [
      {
        name: 'CranbankingqualityComponent', cranType: this.cranTypeFromResolver
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.comments = this.data.responseData.comments;
            this.bankingQualityList = this.data.responseData.bankingQuality;
            // this.accwiseData = this.data.responseData.accwiseAccCondAnlsList;
            this.monthForCRAN = this.data.responseData.monthMapList;

            if (this.comments != undefined && this.comments != "") {
              this.behaviourView = true;
              $("#bankquality").html(this.comments);
            } else {
              this.behaviourView = false;
            }
            if (this.bankingQualityList != undefined && this.bankingQualityList.length > 0) {
              this.bankingView = true;
              this.bankingQualityList.forEach(bnkQlty => {
                bnkQlty.bankingQuality.forEach(element => {
                  if (element.bankingQuality != undefined && element.bankingQuality.length > 0) {
                    element.bankingQuality.forEach(bankObj => {
                      bankObj.lacaChqRtnIwAmt = this.parseEmptytoFloat(bankObj.lacaChqRtnIwAmt).toFixed(2);
                      bankObj.lacaChqRtnOwAmt = this.parseEmptytoFloat(bankObj.lacaChqRtnOwAmt).toFixed(2);
                      bankObj.lacaAvgCcod = this.parseEmptytoFloat(bankObj.lacaAvgCcod).toFixed(2);
                      bankObj.lacaPeakUtilitize = this.parseEmptytoFloat(bankObj.lacaPeakUtilitize).toFixed(2);
                      bankObj.lacaLowUtilize = this.parseEmptytoFloat(bankObj.lacaLowUtilize).toFixed(2);
                      bankObj.lacaAvgbalCcod = this.parseEmptytoFloat(bankObj.lacaAvgbalCcod).toFixed(2);
                      bankObj.lacaMinbalCcod = this.parseEmptytoFloat(bankObj.lacaMinbalCcod).toFixed(2);
                      bankObj.lacaMaxbalCcod = this.parseEmptytoFloat(bankObj.lacaMaxbalCcod).toFixed(2);
                    });
                  }
                });
                bnkQlty.accwiseAccCondAnlsList.forEach(element => {
                  this.aluTot = 0;
                  this.avg = 0;
                  element.forEach(accDet => {
                    this.aluTot = this.aluTot + accDet.lacardAvgCcod;
                  });
                  var tot = parseFloat(this.aluTot).toFixed(2);
                  this.avg = this.aluTot / element.length;

                  element.push({ lacardAccNo: '', lacardCustId: '', lacardChqRtnIw: '', lacardFacilityName: '', lacardChqRtnIwAmt: '', lacardMonth: "Grand Total", lacardMonthCounter: "98", lacardChqRtnOw: '', lacardRowId: '', lacardVersionNo: '', lacardChqRtnOwAmt: '', lacardAvgCcod: tot, lacardPeakUtilitize: '', lacardLowUtilize: '', lacardDaysExcess: '' })
                  element.push({ lacardAccNo: '', lacardCustId: '', lacardChqRtnIw: '', lacardFacilityName: '', lacardChqRtnIwAmt: '', lacardMonth: "Average of above Months", lacardMonthCounter: "99", lacardChqRtnOw: '', lacardRowId: '', lacardVersionNo: '', lacardChqRtnOwAmt: '', lacardAvgCcod: parseFloat(this.avg).toFixed(2), lacardPeakUtilitize: '', lacardLowUtilize: '', lacardDaysExcess: '' })
                });
              });
            }
            else {
              this.bankingView = false;
            }
            // if (this.accwiseData.length > 0) {
            //   for (let i = 0; i < this.accwiseData.length; i++) {
            //     this.newMonthwiseList = [];
            //     this.newMonthwiseList.push({ lacardAccNo: '', lacardCustId: '', lacardChqRtnIw: '', lacardFacilityName: '', lacardChqRtnIwAmt: '', lacardMonth: "Grand Total", lacardMonthCounter: "98", lacardChqRtnOw: '', lacardRowId: '', lacardVersionNo: '', lacardChqRtnOwAmt: '', lacardAvgCcod: '', lacardPeakUtilitize: '', lacardLowUtilize: '', lacardDaysExcess: '' });
            //     this.newMonthwiseList.push({ lacardAccNo: '', lacardCustId: '', lacardChqRtnIw: '', lacardFacilityName: '', lacardChqRtnIwAmt: '', lacardMonth: "Average of above Months", lacardMonthCounter: "99", lacardChqRtnOw: '', lacardRowId: '', lacardVersionNo: '', lacardChqRtnOwAmt: '', lacardAvgCcod: '', lacardPeakUtilitize: '', lacardLowUtilize: '', lacardDaysExcess: '' });
            //     this.accountBasedTotAvgList.push(this.newMonthwiseList);
            //   }
            //   this.monthForTotAvg.push({ monthid: "98", monthName: "Grand Total" });
            //   this.monthForTotAvg.push({ monthid: "99", monthName: "Average of above Months" });

            //   for (let i = 0; i < this.accwiseData.length; i++) {
            //     this.totAvgCalculationForAcctwise(i);
            //   }
            //   this.monthForCRANTemp = this.monthForCRAN;
            // }
          }
          else {
            this.behaviourView = false;
            this.bankingView = false;
          }
        }, error => {
          this.behaviourView = false;
          this.bankingView = false;
        });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

  totAvgCalculationForAcctwise(index) {
    this.accountBasedTotAvgList[index][0].lacardAvgCcod = 0;

    this.accwiseData[index].forEach(element => {
      this.accountBasedTotAvgList[index][0].lacardAvgCcod = this.parseFloatForData(this.accountBasedTotAvgList[index][0].lacardAvgCcod) + this.parseFloatForData(element.lacardAvgCcod);
    });
    this.accountBasedTotAvgList[index][0].lacardAvgCcod = this.parseFloatForData(this.accountBasedTotAvgList[index][0].lacardAvgCcod).toFixed(2);
    this.accountBasedTotAvgList[index][1].lacardAvgCcod = this.accountBasedTotAvgList[index][0].lacardAvgCcod / this.accwiseData[index].length;
    this.accountBasedTotAvgList[index][1].lacardAvgCcod = this.parseFloatForData(this.accountBasedTotAvgList[index][1].lacardAvgCcod).toFixed(2);
  }

  parseFloatForData(det) {
    if (det != null && det != undefined && det != "")
      return parseFloat(det);
    else
      return parseFloat("0");
  }
}

