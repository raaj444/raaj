import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranbankingqualityComponent } from './cranbankingquality.component';

describe('CranbankingqualityComponent', () => {
  let component: CranbankingqualityComponent;
  let fixture: ComponentFixture<CranbankingqualityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranbankingqualityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranbankingqualityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
