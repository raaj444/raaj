import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cranaccconductanalysis2Component } from './cranaccconductanalysis2.component';

describe('Cranaccconductanalysis2Component', () => {
  let component: Cranaccconductanalysis2Component;
  let fixture: ComponentFixture<Cranaccconductanalysis2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cranaccconductanalysis2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cranaccconductanalysis2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
