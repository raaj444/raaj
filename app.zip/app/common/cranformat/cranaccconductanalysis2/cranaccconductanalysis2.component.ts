import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranaccconductanalysis2',
  templateUrl: './cranaccconductanalysis2.component.html',
  styleUrls: ['./cranaccconductanalysis2.component.css']
})
export class Cranaccconductanalysis2Component  implements OnInit {   data:any; 
  churnListView:boolean=true;
  componentlist: any = [];
  model:any={};
  @Input()
  cranTypeFromResolver:string;
  finalAccconductanalysisList=[];
  propDenom:any;
  lacaNetCreditKmblvalue :any;
  lacaNetCreditOthervalue :any;
  lacaTotalChurnvalue:any;
    constructor(private cranService: CranService) { }


  ngOnInit() {
    this.model.LpcorpReferenceDetlist=[];
    this.componentlist = [
      {
        name: 'CranaccconductanalysisComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
    data => { this.data=data;
      if(this.data.success){
        this.finalAccconductanalysisList=this.data.responseData.finalAccconductanalysisList;
        if( this.finalAccconductanalysisList!=undefined && this.finalAccconductanalysisList.length>0)
        {
          this.finalAccconductanalysisList.forEach(element => {
          this.churnListView=true;
          element.churnAnalysis.forEach(churnObj => {
            churnObj.lacaNetCreditKmbl= this.parseEmptytoFloat(churnObj.lacaNetCreditKmbl).toFixed(2);
            churnObj.lacaNetCreditOther=this.parseEmptytoFloat(churnObj.lacaNetCreditOther).toFixed(2);
            churnObj.lacaTotalChurn= this.parseEmptytoFloat(churnObj.lacaTotalChurn).toFixed(2);

          });
          this.lacaNetCreditKmblvalue = 0;
          this.lacaNetCreditOthervalue = 0;
          this.lacaTotalChurnvalue = 0;
          let totalindex=(element.churnAnalysis.length-2);
          let avgindex=(element.churnAnalysis.length-2)+1;
            for (let i = 0; i <  element.churnAnalysis.length-2; i++) {
              if(element.churnAnalysis[i].lacaMonthNo !=13 && element.churnAnalysis[i].lacaMonthNo !=14){
              if ( element.churnAnalysis[i].lacaNetCreditKmbl != null &&  element.churnAnalysis[i].lacaNetCreditKmbl != '' &&  element.churnAnalysis[i].lacaNetCreditKmbl != undefined &&  element.churnAnalysis[i].lacaNetCreditKmbl != NaN)
                this.lacaNetCreditKmblvalue += parseFloat( element.churnAnalysis[i].lacaNetCreditKmbl);
              if ( element.churnAnalysis[i].lacaNetCreditOther != null &&  element.churnAnalysis[i].lacaNetCreditOther != '' &&  element.churnAnalysis[i].lacaNetCreditOther != undefined &&  element.churnAnalysis[i].lacaNetCreditOther != NaN)
                this.lacaNetCreditOthervalue += parseFloat( element.churnAnalysis[i].lacaNetCreditOther);
              if ( element.churnAnalysis[i].lacaTotalChurn != null &&  element.churnAnalysis[i].lacaTotalChurn != '' &&  element.churnAnalysis[i].lacaTotalChurn != undefined &&  element.churnAnalysis[i].lacaTotalChurn != NaN)
                this.lacaTotalChurnvalue += parseFloat( element.churnAnalysis[i].lacaTotalChurn);
              }
           }
         
            element.churnAnalysis[totalindex].lacaNetCreditKmbl = parseFloat(this.lacaNetCreditKmblvalue).toFixed(2);
            element.churnAnalysis[totalindex].lacaNetCreditOther = parseFloat(this.lacaNetCreditOthervalue) .toFixed(2);
            element.churnAnalysis[totalindex].lacaTotalChurn = parseFloat(this.lacaTotalChurnvalue) .toFixed(2);
       
            element.churnAnalysis[avgindex].lacaNetCreditKmbl = (parseFloat(this.lacaNetCreditKmblvalue) /totalindex).toFixed(2);
            element.churnAnalysis[avgindex].lacaNetCreditOther = (parseFloat(this.lacaNetCreditOthervalue) /totalindex).toFixed(2);
            element.churnAnalysis[avgindex].lacaTotalChurn = (parseFloat(this.lacaTotalChurnvalue) /totalindex).toFixed(2);
          });
        }
        else{
          this.churnListView=false;
        }
  }
  else{
    this.churnListView=false;
  }
  },
  error => {
    this.churnListView=false;
  });
}
parseEmptytoFloat(value: any) {
  let value1 = parseFloat(value);
  if (isNaN(value1)) {
    return 0;
  } else {
    return value1;
  }
}
}


  

