import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crangrpexposure2',
  templateUrl: './crangrpexposure2.component.html',
  styleUrls: ['./crangrpexposure2.component.css']
})
export class Crangrpexposure2Component  implements OnInit {   data:any; 
  componentlist :any=[];
  grpcranExposuredetwithKotakList:any=[];
  outstandingDate:any;
  @Input()
  cranTypeFromResolver :string;
  cranView:boolean=true;
  constructor(private cranService: CranService) { }


  ngOnInit() {
    this.cranView=false;
    this.componentlist = [
      {
        name: 'ExposurewithkotakgrptemplateComponent',cranType:this.cranTypeFromResolver
      },
    ];
  
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
              this.outstandingDate=this.data.responseData.OsDate;
    this.grpcranExposuredetwithKotakList=this.data.responseData.finalExposureMapList;
    if( this.grpcranExposuredetwithKotakList!=undefined &&  this.grpcranExposuredetwithKotakList.length >0)
    {
      this.cranView=true;
    this.grpcranExposuredetwithKotakList.forEach(element1 => {
      if(element1.exposureDetList!=undefined && element1.exposureDetList.length>0){
      element1.exposureDetList.forEach(element2 => {
     element2.ledSancLimit= this.parseEmptytoFloat(element2.ledSancLimit).toFixed(2);
     element2.ledExposure= this.parseEmptytoFloat(element2.ledExposure).toFixed(2);
     element2.ledOsAmt= this.parseEmptytoFloat(element2.ledOsAmt).toFixed(2);
    });
  }
  });
   }
   else{
    this.cranView=false;
   }
  
  }   
         },
       error => {
        this.cranView=false;
       });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}

