import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Crangrpexposure2Component } from './crangrpexposure2.component';

describe('Crangrpexposure2Component', () => {
  let component: Crangrpexposure2Component;
  let fixture: ComponentFixture<Crangrpexposure2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Crangrpexposure2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Crangrpexposure2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
