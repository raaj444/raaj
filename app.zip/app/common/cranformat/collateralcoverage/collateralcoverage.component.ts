import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-collateralcoverage',
  templateUrl: './collateralcoverage.component.html',
  styleUrls: ['./collateralcoverage.component.css']
})
export class CollateralcoverageComponent  implements OnInit {   data:any; 
  componentlist :any=[];
  comments:any;
  securitycomfortslist:any=[];
  totalSecCoveragePostHairCut: any;
  totalSecValPostHairCut: any;
  totalSecCoverage: any;
  totSecVal: any;
  private partiesDetails: Array<any> = [];
  totalLimits: any;   
  securityCoverageList: Array<any> = [];
  secCoverage: any;   
  secCoveragePostHairCut: any;
  totSecValPostHairCut: any;
  colCoverView:boolean=true;
  collcoverHead:boolean=true;
  collcoverList:boolean=true;
  constructor(private cran: CranService) { }
 

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CollateralcoverageComponent'
      },
    ];

    this.partiesDetails = [];
    this.cran.getDataForCranList(this.componentlist)
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.partiesDetails = this.data.securityCoverageList;
            this.totalLimits = parseInt("0");
            this.comments=this.data.responseData.comments;
            if( this.comments!=undefined && this.comments!="")
            {
              this.colCoverView=true;
              $("#colCover").html(this.comments);
            }else{
          this.colCoverView=false;
        }
            this.securityCoverageList = [];
            for (var i = 0; i < this.partiesDetails.length; i++) {
              this.secCoverage = this.parseEmptytoFloat((this.partiesDetails[i].secTotNetValue).toFixed(2)) / this.parseEmptytoFloat((this.partiesDetails[i].totalProposedLimit).toFixed(2)) * 100;
              this.secCoveragePostHairCut = this.parseEmptytoFloat((this.partiesDetails[i].totSecPostHairCut).toFixed(2)) / this.parseEmptytoFloat((this.partiesDetails[i].totalProposedLimit).toFixed(2)) * 100;

              this.securityCoverageList.push({ "partyName": this.partiesDetails[i].partyName, "totalProposedLimit": this.parseEmptytoFloat(this.partiesDetails[i].totalProposedLimit).toFixed(2), "secTotNetValue": this.parseEmptytoFloat(this.partiesDetails[i].secTotNetValue).toFixed(2), "secCoverage": this.parseEmptytoFloat(this.secCoverage).toFixed(2), "totSecPostHairCut": this.parseEmptytoFloat(this.partiesDetails[i].totSecPostHairCut).toFixed(2), "secCoveragePostHairCut": this.parseEmptytoFloat(this.secCoveragePostHairCut).toFixed(2) });
            }

            if (this.partiesDetails !=undefined && this.partiesDetails.length > 0) {
              this.collcoverHead=true;
              this.collcoverList=true;
              this.totSecVal = this.parseEmptytoFloat(this.data.totSecVal).toFixed(2);
              this.totSecValPostHairCut = this.parseEmptytoFloat(this.data.totalSecValPostHairCut).toFixed(2);
              //Group Position
              for (var i = 0; i < this.partiesDetails.length; i++) {
                this.totalLimits = this.totalLimits + this.parseEmptytoFloat(this.securityCoverageList[i].totalProposedLimit);
              }
              this.totalLimits = this.parseEmptytoFloat(this.totalLimits).toFixed(2);
              if(this.totalLimits!=0 && this.totalLimits!=0.00 )
              {
              this.totalSecCoverage = (this.totSecVal / this.totalLimits) * 100;
              this.totalSecCoveragePostHairCut = (this.totSecValPostHairCut / this.totalLimits) * 100;

              this.totalSecCoverage = this.parseEmptytoFloat(this.totalSecCoverage).toFixed(2);
              this.totalSecCoveragePostHairCut = this.parseEmptytoFloat(this.totalSecCoveragePostHairCut).toFixed(2);
              }
              else
              {
                this.totalSecCoverage = 0;
              this.totalSecCoveragePostHairCut = 0; 
              }
            }

            else {
              this.totSecValPostHairCut = 0;
              this.totalSecCoverage = 0;
              this.totalSecCoveragePostHairCut = 0;
              this.totalSecCoverage = 0;
              this.totalSecCoveragePostHairCut = 0;
              this.collcoverHead=false;
              this.collcoverList=false;
            }
          }
          else{
            this.collcoverHead=false;
            this.collcoverList=false;
            this.colCoverView=false;
          }
        },
        error => {
          this.collcoverHead=false;
          this.collcoverList=false;
          this.colCoverView=false;
        });
      }


      parseEmptytoFloat(value: any) {
        let value1 = parseFloat(value);
        if (isNaN(value1)) {
          return 0;
        } else {
          return value1;
        }
      }
  }
