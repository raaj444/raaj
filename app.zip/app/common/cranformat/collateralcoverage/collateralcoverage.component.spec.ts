import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollateralcoverageComponent } from './collateralcoverage.component';

describe('CollateralcoverageComponent', () => {
  let component: CollateralcoverageComponent;
  let fixture: ComponentFixture<CollateralcoverageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollateralcoverageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollateralcoverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
