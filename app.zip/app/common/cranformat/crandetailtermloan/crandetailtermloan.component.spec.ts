import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandetailtermloanComponent } from './crandetailtermloan.component';

describe('CrandetailtermloanComponent', () => {
  let component: CrandetailtermloanComponent;
  let fixture: ComponentFixture<CrandetailtermloanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandetailtermloanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandetailtermloanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
