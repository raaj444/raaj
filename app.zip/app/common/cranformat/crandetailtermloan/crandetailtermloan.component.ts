import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lp-crandetailtermloan',
  templateUrl: './crandetailtermloan.component.html',
  styleUrls: ['./crandetailtermloan.component.css']
})
export class CrandetailtermloanComponent  implements OnInit {   data:any; 

  constructor() { }

  ngOnInit() {
  }

}
