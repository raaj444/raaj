import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranbriefbglessorComponent } from './cranbriefbglessor.component';

describe('CranbriefbglessorComponent', () => {
  let component: CranbriefbglessorComponent;
  let fixture: ComponentFixture<CranbriefbglessorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranbriefbglessorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranbriefbglessorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
