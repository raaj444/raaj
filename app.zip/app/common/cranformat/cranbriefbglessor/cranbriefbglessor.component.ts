import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranbriefbglessor',
  templateUrl: './cranbriefbglessor.component.html',
  styleUrls: ['./cranbriefbglessor.component.css']
})
export class CranbriefbglessorComponent  implements OnInit {   data:any; 

  briefbgView:boolean=true;
  briefbglessorList:any;
  componentlist=[];
  @Input()
cranTypeFromResolver :string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.briefbgView=true;
    this.componentlist = [
      {
        name: 'CranbriefbglessorComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.briefbglessorList=this.data.responseData.briefbglessorMapList;
           if(this.briefbglessorList!=undefined && this.briefbglessorList.length>0)
            {
              this.briefbgView=true;
            }else{
               this.briefbgView=false;
             }
          }
          else{
            this.briefbgView=false;
        }
         },error =>{
          this.briefbgView=false;
         });
  }

}

