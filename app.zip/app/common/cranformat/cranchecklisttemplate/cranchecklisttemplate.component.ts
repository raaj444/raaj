import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranchecklisttemplate',
  templateUrl: './cranchecklisttemplate.component.html',
  styleUrls: ['./cranchecklisttemplate.component.css']
})
export class CranchecklisttemplateComponent  implements OnInit {   data:any; 
  componentlist :any=[];
comments:any;
chkCmts:boolean=false;
  preparedby:any;
  CheckedBy:any;
  model:any={};
  checklist:any=[]
  cranChecklist:any=[]
  annexureDesc:any=[]
  @Input()
  cranTypeFromResolver :string;
  constructor(private cran: CranService) { }

  ngOnInit() {
    this.preparedby="";
    this.CheckedBy="";
    this.comments="";
    this.model.response={};
    this.checklist=[]
    this.componentlist = [
      {
        name: 'CranchecklisttemplateComponent',cranType:this.cranTypeFromResolver
      }
     
    ];
 
    this.cran.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
            this.model.response=this.data.responseData;
            this.checklist=this.data.checklist;
            this.annexureDesc= this.data.annexureDesc;
            this.checklist.forEach(element => {
              this.annexureDesc.forEach(element1 => {
                if(element.lccChecklistId==element1.lamRowId)
                {
              this.cranChecklist.push({'lccBizVertical':element.lccBizVertical,'lccSchemeId':element.lccSchemeId,'lamDescription':element1.lamDescription,'lccRowId':element.lccRowId,'lccActive':element.lccActive,'lccChecklistId':element.lccChecklistId,'lccCreatedBy':element.lccCreatedBy,'lccCreatedOn':element.lccCreatedOn,'lccModifiedBy':element.lccModifiedBy,'lccModifiedOn':element.lccModifiedOn})
              } 
          });
          });


            if( this.model.response.comments!="")
            {
              this.chkCmts=false;
            $("#crancheck").html(this.model.response.comments);
            }else{
          this.chkCmts=true;
        }
           }
          });
  }


}
