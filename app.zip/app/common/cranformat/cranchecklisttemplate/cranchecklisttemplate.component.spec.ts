import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranchecklisttemplateComponent } from './cranchecklisttemplate.component';

describe('CranchecklisttemplateComponent', () => {
  let component: CranchecklisttemplateComponent;
  let fixture: ComponentFixture<CranchecklisttemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranchecklisttemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranchecklisttemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
