import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranexposureassessment',
  templateUrl: './cranexposureassessment.component.html',
  styleUrls: ['./cranexposureassessment.component.css']
})
export class CranexposureassessmentComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  LpcomFacAssessmentMapList: any = [];
  assessmentView: boolean = true;
  assessmenthead: boolean = false;
  finExpView: boolean = false;
  finExphead: boolean = false;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CranexposureassessmentComponent'
      },
    ];
    this.LpcomFacAssessmentMapList = [];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        if (this.data.success == true) {
          this.LpcomFacAssessmentMapList = this.data.responseData.finalexposureMaplist;
          if (this.LpcomFacAssessmentMapList != undefined && this.LpcomFacAssessmentMapList.length > 0) {
            this.assessmentView = true;
            this.LpcomFacAssessmentMapList.forEach(element1=> {
              if( element1.prodList!=undefined && element1.prodList.length>0){
                element1.prodList.forEach(element2 => {
             if( element2.assesNameList!=undefined && element2.assesNameList.length>0){
              element2.assesNameList.forEach(element3 => {
                element3[10]=this.parseEmptytoFloat(element3[10]).toFixed(2);
            });
          }
          element2[10]=this.parseEmptytoFloat(element2[10]).toFixed(2);
        });
      }
          });
        }
          else {
            this.assessmentView = false;
          }
        }
        else {
          this.assessmentView = false;
        }
      },
      error => {
        this.assessmentView = false;
      });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}