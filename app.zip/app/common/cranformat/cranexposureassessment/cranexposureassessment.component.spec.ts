import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranexposureassessmentComponent } from './cranexposureassessment.component';

describe('CranexposureassessmentComponent', () => {
  let component: CranexposureassessmentComponent;
  let fixture: ComponentFixture<CranexposureassessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranexposureassessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranexposureassessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
