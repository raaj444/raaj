import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BriefbackgroundofborrowertemplateComponent } from './briefbackgroundofborrowertemplate.component';

describe('BriefbackgroundofborrowertemplateComponent', () => {
  let component: BriefbackgroundofborrowertemplateComponent;
  let fixture: ComponentFixture<BriefbackgroundofborrowertemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BriefbackgroundofborrowertemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BriefbackgroundofborrowertemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
