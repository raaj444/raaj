import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $ :any;
@Component({
  selector: 'lp-briefbackgroundofborrowertemplate',
  templateUrl: './briefbackgroundofborrowertemplate.component.html',
  styleUrls: ['./briefbackgroundofborrowertemplate.component.css']
})
export class BriefbackgroundofborrowertemplateComponent  implements OnInit {   data:any; 
  componentlist :any=[];
  BackgroundList: any=[] ;
  backgroundView:boolean=true;
  @Input()
  cranTypeFromResolver :string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.BackgroundList=[];
    this.backgroundView=false;
    this.componentlist = [
      {
        name: 'BriefbackgroundofborrowertemplateComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.BackgroundList=this.data.responseData.BackgroundList;
           if(this.BackgroundList!=undefined && this.BackgroundList.length>0)
            {
              this.backgroundView=true;
            }else{
               this.backgroundView=false;
             }
          }
          else{
            this.backgroundView=false;
          }
         },error =>{
          this.backgroundView=false;
         });
  }

}
