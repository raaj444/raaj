import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-bankingarrangementtemplate',
  templateUrl: './bankingarrangementtemplate.component.html',
  styleUrls: ['./bankingarrangementtemplate.component.css']
})
export class BankingarrangementtemplateComponent implements OnInit {

  data: any;
  componentlist: any = [];
  table1: boolean = true;
  dateStr: any;
  termLoanDetails: any = [];
  totLeeSancAmt: any = 0;
  totLeeOsAmt: any = 0;
  totLeeOverdue: any = 0;
  masterList: any = [];
  // bankingArrangement: any;
  bankarrange: any;
  grandTotal: any;
  pgrandTotal: any;
  pgrandshare: any;
  model: any = [];
  private details: Array<any> = [];
  ourBankWCTotal: any;
  ourBankTLTotal: any;
  ourBankNFBTotal: any;
  fbwcTotal: any;
  fbtlTotal: any;
  nfbTotal: any;
  pfbwcTotal: any;
  pfbtlTotal: any;
  pnfbTotal: any;
  totROI: any = 0;
  totY1: any = 0;
  totY2: any = 0;
  totY3: any = 0;
  totY4: any = 0;
  exposure: any = [];
  bnkArgmtDet: any = [];
  bankArgmViewData: any = [];
  otherBankDet: any = [];
  repayY1: any;
  repayY2: any;
  repayY3: any;
  repayY4: any;
  repayY5: any;
  repayY6: any;
  osAsOnDate: any;
  sharetot: any;

  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.sharetot = 0;
    this.repayY1 = "";
    this.repayY2 = "";
    this.repayY3 = "";
    this.repayY4 = "";
    this.repayY5 = "";
    this.repayY6 = "";
    this.otherBankDet = [];
    this.model = [];
    this.exposure = [];
    this.termLoanDetails = [];
    this.bankArgmViewData = [];
    this.fbwcTotal = 0;
    this.fbtlTotal = 0;
    this.nfbTotal = 0;
    this.pfbwcTotal = 0;
    this.pfbtlTotal = 0;
    this.pnfbTotal = 0;
    this.pgrandshare = 0;
    this.bnkArgmtDet = [];
    this.osAsOnDate = "";

    this.componentlist = [
      {
        name: 'BankingarrangementtemplateComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          // var currentExposure = this.data.responseData.proposedExposure.currentExposure;
          // var proposedExposure = this.data.responseData.proposedExposure.proposedExposure;
          // var bankingarrangement = this.data.responseData.bankingarrangement;
          this.bankarrange = this.data.responseData.bankarrange;
          this.osAsOnDate = this.data.responseData.osAsOnDate;

          this.bnkArgmtDet = this.data.responseData.bankingArgmntDet;
          // Term Loan Details
          this.termLoanDetails = this.data.responseData.termLoanDetails;
          if (this.termLoanDetails != undefined && this.termLoanDetails.length > 0) {
            this.termLoanDetails.forEach(tlDet => {
              tlDet.termLoanDetailsList.forEach((element, index) => {
                if (index == 0) {
                  this.repayY1 = element.leeRepayYear1;
                  this.repayY2 = element.leeRepayYear2;
                  this.repayY3 = element.leeRepayYear3;
                  this.repayY4 = element.leeRepayYear4;
                  this.repayY5 = element.leeRepayYear5;
                  this.repayY6 = element.leeRepayYear6;
                }
                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.leeSancAmt);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.leeOsAmt);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.leeOverdue);

                element.leeSancAmt = parseFloat(element.leeSancAmt).toFixed(2);
                element.leeOsAmt = parseFloat(element.leeOsAmt).toFixed(2);
                element.leeOverdue = parseFloat(element.leeOverdue).toFixed(2);
                element.leeRepayY1 = parseFloat(element.leeRepayY1).toFixed(2);
                element.leeRepayY2 = parseFloat(element.leeRepayY2).toFixed(2);
                element.leeRepayY3 = parseFloat(element.leeRepayY3).toFixed(2);
                element.leeRepayY4 = parseFloat(element.leeRepayY4).toFixed(2);
                element.leeRepayY5 = parseFloat(element.leeRepayY5).toFixed(2);
                element.leeRepayY6 = parseFloat(element.leeRepayY6).toFixed(2);

                if (element.leeRoi == NaN || element.leeRoi == null || element.leeRoi == undefined)
                  element.leeRoi = "0.00";
              });
            });

            this.termLoanDetails.forEach(exposure => {
              exposure.exposureDet.forEach(element => {

                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.ledSancLimit);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.ledOsAmt);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.ledOverdue);

                element.ledSancLimit = parseFloat(element.ledSancLimit).toFixed(2);
                element.ledOsAmt = parseFloat(element.ledOsAmt).toFixed(2);
                element.ledOverdue = parseFloat(element.ledOverdue).toFixed(2);
                element.ledRepayY1 = parseFloat(element.ledRepayY1).toFixed(2);
                element.ledRepayY2 = parseFloat(element.ledRepayY2).toFixed(2);
                element.ledRepayY3 = parseFloat(element.ledRepayY3).toFixed(2);
                element.ledRepayY4 = parseFloat(element.ledRepayY4).toFixed(2);
                element.ledRepayY5 = parseFloat(element.ledRepayY5).toFixed(2);
                element.ledRepayY6 = parseFloat(element.ledRepayY6).toFixed(2);

                if (element.ledRoi == NaN || element.ledRoi == null || element.ledRoi == undefined)
                  element.ledRoi = "0.00";

              });

            });

            this.termLoanDetails.forEach(fac => {
              fac.facility.forEach(element => {

                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.lfSancLimit);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.lfOsLimit);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.lfOverdue);

                element.lfOsLimit = parseFloat(element.lfOsLimit).toFixed(2);
                element.lfSancLimit = parseFloat(element.lfSancLimit).toFixed(2);
                element.lfOverdue = parseFloat(element.lfOverdue).toFixed(2);
                element.lfRepayY1 = parseFloat(element.lfRepayY1).toFixed(2);
                element.lfRepayY2 = parseFloat(element.lfRepayY2).toFixed(2);
                element.lfRepayY3 = parseFloat(element.lfRepayY3).toFixed(2);
                element.lfRepayY4 = parseFloat(element.lfRepayY4).toFixed(2);
                element.lfRepayY5 = parseFloat(element.lfRepayY5).toFixed(2);
                element.lfRepayY6 = parseFloat(element.lfRepayY6).toFixed(2);

                if (element.lfExistLmtROI == NaN || element.lfExistLmtROI == null || element.lfExistLmtROI == undefined)
                  element.lfExistLmtROI = "0.00";

              });
            });

            if (this.data.responseData.repaymentYear) {

              let year = this.data.responseData.repaymentYear;

              if (year.leeRepayYear1)
                this.repayY1 = year.leeRepayYear1;
              if (year.leeRepayYear2)
                this.repayY2 = year.leeRepayYear2;
              if (year.leeRepayYear3)
                this.repayY3 = year.leeRepayYear3;
              if (year.leeRepayYear4)
                this.repayY4 = year.leeRepayYear4;
              if (year.leeRepayYear5)
                this.repayY5 = year.leeRepayYear5;
              if (year.leeRepayYear6)
                this.repayY6 = year.leeRepayYear6;
            }

          }
          this.totLeeSancAmt = parseFloat(this.totLeeSancAmt).toFixed(2);
          this.totLeeOsAmt = parseFloat(this.totLeeOsAmt).toFixed(2);
          this.totLeeOverdue = parseFloat(this.totLeeOverdue).toFixed(2);

          if (this.data.responseData.caseDetSale.lpcdsCaseType == "1" && this.data.responseData.caseDetSale.lpcdsTakeover == "N") {
            this.table1 = true;
          }
          else {
            this.table1 = false;
          }

          //Banking Arrangements for KMBL
          this.bnkArgmtDet.forEach(element => {
            this.model = [];
            var currentExposure = element.KMBLDet.currentExposure;
            var proposedExposure = element.KMBLDet.proposedExposure;
            this.exposure = [];
            this.exposure.push(currentExposure[0]);
            this.exposure.push(currentExposure[1]);
            this.exposure.push(currentExposure[2]);
            this.exposure.push(proposedExposure[3]);
            this.exposure.push(proposedExposure[4]);
            this.exposure.push(proposedExposure[5]);

            var KMBLtotal = this.exposure[0] + this.exposure[1] + this.exposure[2];
            var KMBLptotal = this.exposure[3] + this.exposure[4] + this.exposure[5];

            var val0 = "0", val1 = "0", val2 = "0", val3 = "0", val4 = "0", val5 = "0";

            val0 = parseFloat(this.exposure[0]).toFixed(2);
            val1 = parseFloat(this.exposure[1]).toFixed(2);
            val2 = parseFloat(this.exposure[2]).toFixed(2);
            val3 = parseFloat(this.exposure[3]).toFixed(2);
            val4 = parseFloat(this.exposure[4]).toFixed(2);
            val5 = parseFloat(this.exposure[5]).toFixed(2);

            this.exposure = [];
            this.exposure.push(val0);
            this.exposure.push(val1);
            this.exposure.push(val2);
            this.exposure.push(val3);
            this.exposure.push(val4);
            this.exposure.push(val5);

            this.fbwcTotal = parseFloat(this.fbwcTotal) + parseFloat(this.exposure[0]);
            this.fbtlTotal = parseFloat(this.fbtlTotal) + parseFloat(this.exposure[1])
            this.nfbTotal = parseFloat(this.nfbTotal) + parseFloat(this.exposure[2]);

            this.pfbwcTotal = parseFloat(this.pfbwcTotal) + parseFloat(this.exposure[3]);
            this.pfbtlTotal = parseFloat(this.pfbtlTotal) + parseFloat(this.exposure[4]);
            this.pnfbTotal = parseFloat(this.pnfbTotal) + parseFloat(this.exposure[5]);
            this.model.push({ bankName: "KMBL", data: this.exposure, total: parseFloat(KMBLtotal).toFixed(2), ptotal: parseFloat(KMBLptotal).toFixed(2), share: "" });

            //Banking Arrangements for Other Bank
            for (var prop in element.bankingarrangement) {
              var value = element.bankingarrangement[prop];
              var total = value[0] + value[1] + value[2];

              var temp = value;
              this.fbwcTotal = parseFloat(this.fbwcTotal) + temp[0];
              this.fbtlTotal = parseFloat(this.fbtlTotal) + temp[1];
              this.nfbTotal = parseFloat(this.nfbTotal) + temp[2];

              var val1 = "0", val2 = "0", val3 = "0";
              val1 = parseFloat(temp[0]).toFixed(2);
              val2 = parseFloat(temp[1]).toFixed(2);
              val3 = parseFloat(temp[2]).toFixed(2);

              this.otherBankDet[prop] = [];
              this.otherBankDet[prop].push(val1);
              this.otherBankDet[prop].push(val2);
              this.otherBankDet[prop].push(val3);
              this.otherBankDet[prop].push("0.00");
              this.otherBankDet[prop].push("0.00");
              this.otherBankDet[prop].push("0.00");
              this.model.push({ bankName: prop, data: this.otherBankDet[prop], total: parseFloat(total).toFixed(2), ptotal: "0.00", share: "0.00" });
            }
            this.bankArgmViewData.push({ custName: element.custName, model: this.model })
          });

          this.fbwcTotal = parseFloat(this.fbwcTotal).toFixed(2);
          this.fbtlTotal = parseFloat(this.fbtlTotal).toFixed(2);
          this.nfbTotal = parseFloat(this.nfbTotal).toFixed(2);

          this.grandTotal = parseFloat(this.fbwcTotal) + parseFloat(this.fbtlTotal) + parseFloat(this.nfbTotal);
          this.grandTotal = parseFloat(this.grandTotal).toFixed(2);

          this.pfbwcTotal = parseFloat(this.pfbwcTotal).toFixed(2);
          this.pfbtlTotal = parseFloat(this.pfbtlTotal).toFixed(2);
          this.pnfbTotal = parseFloat(this.pnfbTotal).toFixed(2);

          this.pgrandTotal = parseFloat(this.pfbwcTotal) + parseFloat(this.pfbtlTotal) + parseFloat(this.pnfbTotal);
          this.pgrandTotal = parseFloat(this.pgrandTotal).toFixed(2);

          this.bankArgmViewData.forEach(element => {
            element.model.forEach(det => {
              if (det.bankName == "KMBL") {
                var proposedLmt = det.data;
                this.sharetot = (parseFloat(det.ptotal) / parseFloat(this.pgrandTotal)) * 100;
                det.share = parseFloat(this.sharetot).toFixed(2);
                this.pgrandshare = (parseFloat(this.pgrandshare) + parseFloat(det.share)).toFixed(2);
              }
            });
          });
          this.pgrandshare = Math.round(this.pgrandshare).toFixed(2);
        }
      },
      error => {
      });
  }
}
