import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingarrangementtemplateComponent } from './bankingarrangementtemplate.component';

describe('BankingarrangementtemplateComponent', () => {
  let component: BankingarrangementtemplateComponent;
  let fixture: ComponentFixture<BankingarrangementtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingarrangementtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingarrangementtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
