import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranliquidcollateralComponent } from './cranliquidcollateral.component';

describe('CranliquidcollateralComponent', () => {
  let component: CranliquidcollateralComponent;
  let fixture: ComponentFixture<CranliquidcollateralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranliquidcollateralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranliquidcollateralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
