import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranliquidcollateral',
  templateUrl: './cranliquidcollateral.component.html',
  styleUrls: ['./cranliquidcollateral.component.css']
})
export class CranliquidcollateralComponent  implements OnInit {   data:any; 
  liquidSecView:boolean=true;
  liquidPropList:any=[];
  componentlist=[];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
   
    this.componentlist = [
      {
        name: 'CranliquidsecurityComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.liquidPropList=this.data.responseData.liquidPropList;
           if(this.liquidPropList!=undefined && this.liquidPropList.length>0)
            {
            this.liquidSecView=true;
            this.liquidPropList.forEach(element1 => {
              if(element1.securityMapList!=undefined && element1.securityMapList.length>0)
              {
                element1.securityMapList.forEach(element => {
                  if(element.FaceValue!='NA')
              element.FaceValue= this.parseEmptytoFloat(element.FaceValue).toFixed(2);
              if(element.CurrentValue!='NA')
              element.CurrentValue= this.parseEmptytoFloat(element.CurrentValue).toFixed(2);
            });
          }
            });
            }else{
               this.liquidSecView=false;
             }
          }
          else{
            this.liquidSecView=false;
          }
         },error =>{
          this.liquidSecView=false;
         });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}

