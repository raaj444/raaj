import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranbankingbehavcommentsComponent } from './cranbankingbehavcomments.component';

describe('CranbankingbehavcommentsComponent', () => {
  let component: CranbankingbehavcommentsComponent;
  let fixture: ComponentFixture<CranbankingbehavcommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranbankingbehavcommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranbankingbehavcommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
