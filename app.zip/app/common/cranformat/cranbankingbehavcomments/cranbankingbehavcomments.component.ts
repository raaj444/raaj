import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranbankingbehavcomments',
  templateUrl: './cranbankingbehavcomments.component.html',
  styleUrls: ['./cranbankingbehavcomments.component.css']
})
export class CranbankingbehavcommentsComponent  implements OnInit {   data:any; 
  behaviourView:boolean=true;
  componentlist :any=[];
comments:any=[];
@Input()
cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.behaviourView=false;
 this.componentlist = [
      {
        name: 'CranbankingbehavcommentsComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
            this.comments=this.data.responseData.bankingBehaviour;
            if(  this.comments!=undefined && this.comments.length>0)
            {
              this.behaviourView=true;
          
            }else{
            this.behaviourView=false;
            }
          }   
          else{
            this.behaviourView=false;
            }
         },
       error => {
        this.behaviourView=false;
       }); 
    
  }

}

