import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-bcacannextemplate',
  templateUrl: './bcacannextemplate.component.html',
  styleUrls: ['./bcacannextemplate.component.css']
})
export class BcacannextemplateComponent  implements OnInit {   data:any; 
  model: any = {};
  componentlist: any = [];
  bcacAnnex : any = {};
  bcacView:boolean=false;
  bcacAnnexList:boolean=true;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.model.bcacAnnexHeadingList = [];
    this.model.bcacAnnexContentListObject = {};

    this.componentlist = [
      {
        name: 'BcacannextemplateComponent'
      },
    ];

    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          var resbcacAnnex= this.data.responseData.BcacAnnex;
          if(resbcacAnnex!=undefined && resbcacAnnex.length >0)
          {
            this.bcacView=true;
          resbcacAnnex.forEach(annx => {
            if (annx.lbaParentId == 0)
              this.model.bcacAnnexHeadingList.push({ lbaDesc: annx.lbaDesc, lbaNorms: annx.lbaNorms, lbaAdherence: "Y", lbaParentId: annx.lbaParentId, lbaOrderNo: annx.lbaOrderNo, lbaRowId: annx.lbaRowId });
            else {
              if (this.model.bcacAnnexContentListObject[annx.lbaParentId] == undefined) {
                this.model.bcacAnnexContentListObject[annx.lbaParentId] = [];
                this.model.bcacAnnexContentListObject[annx.lbaParentId].push({ lbaDesc: annx.lbaDesc, lbaNorms: annx.lbaNorms, lbaAdherence: annx.lbaAdherence, lbaParentId: annx.lbaParentId, lbaOrderNo: annx.lbaOrderNo, lbaRowId: annx.lbaRowId });
              }
              else {
                this.model.bcacAnnexContentListObject[annx.lbaParentId].push({ lbaDesc: annx.lbaDesc, lbaNorms: annx.lbaNorms, lbaAdherence: annx.lbaAdherence, lbaParentId: annx.lbaParentId, lbaOrderNo: annx.lbaOrderNo, lbaRowId: annx.lbaRowId });
              }
            }
          });
        }
        else{
          this.bcacView=false;
        }
        }
        else{
          this.bcacView=false;
        }
      },
      error => {
        this.bcacView=false;
      });
  }

}
