import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BcacannextemplateComponent } from './bcacannextemplate.component';

describe('BcacannextemplateComponent', () => {
  let component: BcacannextemplateComponent;
  let fixture: ComponentFixture<BcacannextemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BcacannextemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BcacannextemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
