import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranaccountconductcomments',
  templateUrl: './cranaccountconductcomments.component.html',
  styleUrls: ['./cranaccountconductcomments.component.css']
})
export class CranaccountconductcommentsComponent  implements OnInit {   data:any; 
  accComments:boolean=true;
  componentlist :any=[];
  accountconductList:any=[];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.accComments=false;
    this.componentlist = [
      {
        name: 'CranaccountconductcommentsComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.accountconductList=this.data.responseData.accountconductMapList;
           if(this.accountconductList!=undefined && this.accountconductList.length>0)
            {
              this.accComments=true;
            }else{
               this.accComments=false;
             }
          }
          else{
            this.accComments=false;
          }
         },error =>{
          this.accComments=false;
         });
  }

}

