import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranaccountconductcommentsComponent } from './cranaccountconductcomments.component';

describe('CranaccountconductcommentsComponent', () => {
  let component: CranaccountconductcommentsComponent;
  let fixture: ComponentFixture<CranaccountconductcommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranaccountconductcommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranaccountconductcommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
