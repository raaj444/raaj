import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cranaudinfo2Component } from './cranaudinfo2.component';

describe('Cranaudinfo2Component', () => {
  let component: Cranaudinfo2Component;
  let fixture: ComponentFixture<Cranaudinfo2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cranaudinfo2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cranaudinfo2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
