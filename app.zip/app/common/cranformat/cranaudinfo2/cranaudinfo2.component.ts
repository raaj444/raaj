import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranaudinfo2',
  templateUrl: './cranaudinfo2.component.html',
  styleUrls: ['./cranaudinfo2.component.css']
})
export class Cranaudinfo2Component  implements OnInit {   data:any; 

  componentlist :any=[];
audinfo:any={};
ews:any;
@Input()
cranTypeFromResolver :string;
  constructor(private cran: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'Cranaudinfo2Component', cranType:this.cranTypeFromResolver
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
            this.audinfo = this.data.responseData.CaseDetCredit;
            this.ews=this.data.responseData.EWS;
           }
          });
  }
}


