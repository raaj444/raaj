import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranguaranteeComponent } from './cranguarantee.component';

describe('CranguaranteeComponent', () => {
  let component: CranguaranteeComponent;
  let fixture: ComponentFixture<CranguaranteeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranguaranteeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranguaranteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
