import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranguarantee',
  templateUrl: './cranguarantee.component.html',
  styleUrls: ['./cranguarantee.component.css']
})
export class CranguaranteeComponent  implements OnInit {   data:any; 
  guaranteeView:boolean=true;
  componentlist :any=[];
  Guaranteeslist: Array<any> = [];
  constitution: Array<any> = [];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }
  ngOnInit() {
    this.componentlist = [
      {
        name:'CranguaranteeComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
            this.Guaranteeslist=this.data.responseData.finalGuaranteeMapList;
    if(this.Guaranteeslist!=undefined &&  this.Guaranteeslist.length >0 )
    {
      this.guaranteeView=true;
      this.Guaranteeslist.forEach(element1 => {
        if(element1.GuarnteeDetForCustList!=undefined &&  element1.GuarnteeDetForCustList.length >0 )
        {
          element1.GuarnteeDetForCustList.forEach(element => {
        element.lgdGuarAmt =this.parseEmptytoFloat(element.lgdGuarAmt).toFixed(2);
        element.lgdGuarNetworth =this.parseEmptytoFloat(element.lgdGuarNetworth).toFixed(2);
      });
    }
    });
  }
    
    else{
      this.guaranteeView=false;
    }
          }
          else{
            this.guaranteeView=false;
          }
         },
       error => {
        this.guaranteeView=false;
       });
 }
 parseEmptytoFloat(value: any) {
  let value1 = parseFloat(value);
  if (isNaN(value1)) {
    return 0;
  } else {
    return value1;
  }
}
  }

