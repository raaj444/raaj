import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranaccountanalysistemplate',
  templateUrl: './cranaccountanalysistemplate.component.html',
  styleUrls: ['./cranaccountanalysistemplate.component.css']
})
export class CranaccountanalysistemplateComponent  implements OnInit {   data:any; 

  componentlist :any=[];
  AccountList:any=[];
 

  constructor(private cran: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CranaccountanalysistemplateComponent'
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
            //this.AccountList=this.data.responseData.AccountList;
            
           }
          });
  }

}
