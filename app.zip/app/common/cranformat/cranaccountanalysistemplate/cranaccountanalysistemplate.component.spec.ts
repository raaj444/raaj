import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranaccountanalysistemplateComponent } from './cranaccountanalysistemplate.component';

describe('CranaccountanalysistemplateComponent', () => {
  let component: CranaccountanalysistemplateComponent;
  let fixture: ComponentFixture<CranaccountanalysistemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranaccountanalysistemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranaccountanalysistemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
