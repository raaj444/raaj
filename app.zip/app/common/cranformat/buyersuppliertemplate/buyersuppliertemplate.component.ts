import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-buyersuppliertemplate',
  templateUrl: './buyersuppliertemplate.component.html',
  styleUrls: ['./buyersuppliertemplate.component.css']
})
export class BuyersuppliertemplateComponent implements OnInit {

  data: any;
  componentlist: any = [];
  buyerArray: Array<any> = [];
  supplierArray: Array<any> = [];
  finalbuyierSupplierList: any = [];
  totalCySup: any;
  PercentCySup: any;
  totalPySup: any;
  PercentPySup: any;
  totalCyBuy: any;
  PercentCyBuy: any;
  totalPyBuy: any;
  PercentPyBuy: any;
  pageComments: any;
  buyerCmtsView: boolean = true;
  buyerSupplierListView: boolean = true;
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.pageComments = "";
    this.buyerCmtsView = false;
    this.buyerSupplierListView = false;
    this.componentlist = [
      {
        name: 'CranbuyersupplierComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)

      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.buyerArray = [];
            this.supplierArray = [];
            this.pageComments = this.data.pageComments;
            this.finalbuyierSupplierList = this.data.responseData.finalbuyierSupplierList;
            if (this.finalbuyierSupplierList != undefined && this.finalbuyierSupplierList.length > 0) {
              this.buyerSupplierListView = true;
              this.finalbuyierSupplierList.forEach((element1, index1) => {
                //    this.finalbuyierSupplierList[index1].buyerArray[index]

                if (element1.buyerArray != undefined && element1.buyerArray.length > 0) {
                  element1.totalCyBuy = 0.00; element1.PercentCyBuy = 0.00;
                  element1.totalPyBuy = 0.00; element1.PercentPyBuy = 0.00;


                  for (let j = 0; j < element1.buyerArray.length; j++) {
                    if (element1.buyerArray[j].lbsCyAmt != null && element1.buyerArray[j].lbsCyAmt != "") {
                      element1.totalCyBuy = parseFloat(element1.totalCyBuy) + parseFloat(element1.buyerArray[j].lbsCyAmt);
                    }
                    else {
                      element1.totalCyBuy = element1.totalCyBuy + 0.00;
                    }
                    if (element1.buyerArray[j].lbsPyAmt != null && element1.buyerArray[j].lbsPyAmt != "") {
                      element1.totalPyBuy = parseFloat(element1.totalPyBuy) + parseFloat(element1.buyerArray[j].lbsPyAmt);
                    }
                    else {
                      element1.totalPyBuy = element1.totalPyBuy + 0.00;
                    }
                  }
                  element1.totalCyBuy = parseFloat(element1.totalCyBuy).toFixed(2);
                  element1.totalPyBuy = parseFloat(element1.totalPyBuy).toFixed(2);
                  let PercyBuy = 0;
                  let PerPyBuy = 0;

                  element1.buyerArray.forEach((element, index) => {

                    element1.buyerArray[index].lbsCyPercent = isNaN(element.lbsCyAmt) ? 0 : (parseFloat(element.lbsCyAmt) / parseFloat(element1.totalCyBuy)) * 100;
                    PercyBuy = isNaN(PercyBuy + parseFloat(element1.buyerArray[index].lbsCyPercent)) ? PercyBuy + 0 : PercyBuy + parseFloat(element1.buyerArray[index].lbsCyPercent);
                    element1.buyerArray[index].lbsPyPercent = isNaN(element.lbsPyAmt) ? 0 : (parseFloat(element.lbsPyAmt) / parseFloat(element1.totalPyBuy)) * 100;
                    PerPyBuy = isNaN(PerPyBuy + parseFloat(element1.buyerArray[index].lbsPyPercent)) ? PerPyBuy + 0 : PerPyBuy + parseFloat(element1.buyerArray[index].lbsPyPercent);
                  });
                  element1.PercentCyBuy = PercyBuy.toFixed(2);
                  element1.PercentPyBuy = PerPyBuy.toFixed(2);

                  element1.buyerArray.forEach((element, index) => {

                    element.lbsCyAmt = this.parseEmptytoFloat(element.lbsCyAmt).toFixed(2);
                    element.lbsCyPercent = this.parseEmptytoFloat(element.lbsCyPercent).toFixed(2);
                    element.lbsPyAmt = this.parseEmptytoFloat(element.lbsPyAmt).toFixed(2);
                    element.lbsPyPercent = this.parseEmptytoFloat(element.lbsPyPercent).toFixed(2);
                  });
                }
                if (element1.buyerTotal) {
                  element1.totalPlCyBuy = parseFloat(element1.buyerTotal.lbsCyAmtPl ? element1.buyerTotal.lbsCyAmtPl : 0).toFixed(2);
                  element1.totalPlPyBuy = parseFloat(element1.buyerTotal.lbsPyAmtPl ? element1.buyerTotal.lbsPyAmtPl : 0).toFixed(2);
                  if (element1.totalPlCyBuy && element1.totalCyBuy) {
                    element1.PercentPlCyBuy = (parseFloat(element1.totalCyBuy) / parseFloat(element1.totalPlCyBuy)) * 100;
                    element1.PercentPlCyBuy = isNaN(element1.PercentPlCyBuy) ? 0.00 : parseFloat(element1.PercentPlCyBuy).toFixed(2);
                  }
                  if (element1.totalPlPyBuy && element1.totalPyBuy) {
                    element1.PercentPlPyBuy = (parseFloat(element1.totalPyBuy) / parseFloat(element1.totalPlPyBuy)) * 100;
                    element1.PercentPlPyBuy = isNaN(element1.PercentPlPyBuy) ? 0.00 : parseFloat(element1.PercentPlPyBuy).toFixed(2);
                  }
                }
                if (element1.supplierArray != undefined && element1.supplierArray.length > 0) {
                  element1.totalCySup = 0.00; element1.PercentCySup = 0.00;
                  element1.totalPySup = 0.00; element1.PercentPySup = 0.00;


                  for (let j = 0; j < element1.supplierArray.length; j++) {
                    if (element1.supplierArray[j].lbsCyAmt != null && element1.supplierArray[j].lbsCyAmt != "") {
                      element1.totalCySup = parseFloat(element1.totalCySup) + parseFloat(element1.supplierArray[j].lbsCyAmt);
                    }
                    else {
                      element1.totalCySup = element1.totalCySup + 0.00;
                    }
                    if (element1.supplierArray[j].lbsPyAmt != null && element1.supplierArray[j].lbsPyAmt != "") {
                      element1.totalPySup = parseFloat(element1.totalPySup) + parseFloat(element1.supplierArray[j].lbsPyAmt);
                    }
                    else {
                      element1.totalPySup = element1.totalPySup + 0.00;
                    }
                  }
                  element1.totalCySup = parseFloat(element1.totalCySup).toFixed(2);
                  element1.totalPySup = parseFloat(element1.totalPySup).toFixed(2);
                  let PerCySup = 0;
                  let SuppPercPy = 0;
                  element1.supplierArray.forEach((supplierObj, index) => {

                    element1.supplierArray[index].lbsCyPercent = isNaN(supplierObj.lbsCyAmt) ? 0 : (parseFloat(supplierObj.lbsCyAmt) / parseFloat(element1.totalCySup)) * 100;
                    PerCySup = isNaN(SuppPercPy + parseFloat(element1.supplierArray[index].lbsCyPercent)) ? SuppPercPy + 0 : SuppPercPy + parseFloat(element1.supplierArray[index].lbsCyPercent);
                    element1.supplierArray[index].lbsPyPercent = isNaN(supplierObj.lbsPyAmt) ? 0 : (parseFloat(supplierObj.lbsPyAmt) / parseFloat(element1.totalPySup)) * 100;
                    SuppPercPy = isNaN(SuppPercPy + parseFloat(element1.supplierArray[index].lbsPyPercent)) ? SuppPercPy + 0 : SuppPercPy + parseFloat(element1.supplierArray[index].lbsPyPercent);
                  });
                  element1.PercentCySup = PerCySup.toFixed(2);
                  element1.PercentPySup = SuppPercPy.toFixed(2);

                  element1.supplierArray.forEach((element, index) => {
                    element.lbsCyAmt = this.parseEmptytoFloat(element.lbsCyAmt).toFixed(2);
                    element.lbsCyPercent = this.parseEmptytoFloat(element.lbsCyPercent).toFixed(2);
                    element.lbsPyAmt = this.parseEmptytoFloat(element.lbsPyAmt).toFixed(2);
                    element.lbsPyPercent = this.parseEmptytoFloat(element.lbsPyPercent).toFixed(2);
                  });




                }
                if (element1.supplierTotal) {
                  element1.totalPlCySup = parseFloat(element1.supplierTotal.lbsCyAmtPl ? element1.supplierTotal.lbsCyAmtPl : 0).toFixed(2);
                  element1.totalPlPySup = parseFloat(element1.supplierTotal.lbsPyAmtPl ? element1.supplierTotal.lbsPyAmtPl : 0).toFixed(2);
                  if (element1.totalPlCySup && element1.totalCySup) {
                    element1.PercentPlCySup = (parseFloat(element1.totalCySup) / parseFloat(element1.totalPlCySup)) * 100;
                    element1.PercentPlCySup = isNaN(element1.PercentPlCySup) ? 0.00 : parseFloat(element1.PercentPlCySup).toFixed(2);
                  }
                  if (element1.totalPlPySup && element1.totalPySup) {
                    element1.PercentPlPySup = (parseFloat(element1.totalPySup) / parseFloat(element1.totalPlPySup)) * 100;
                    element1.PercentPlPySup = isNaN(element1.PercentPlPySup) ? 0.00 : parseFloat(element1.PercentPlPySup).toFixed(2);
                  }
                }

              });
            }
            else {
              this.buyerSupplierListView = false;
            }
          }
          else {
            this.buyerSupplierListView = false;
            this.buyerCmtsView = false;
          }
        },
        error => {
          this.buyerCmtsView = false;
          this.buyerSupplierListView = false;
        });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }












}
