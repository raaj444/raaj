import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyersuppliertemplateComponent } from './buyersuppliertemplate.component';

describe('BuyersuppliertemplateComponent', () => {
  let component: BuyersuppliertemplateComponent;
  let fixture: ComponentFixture<BuyersuppliertemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyersuppliertemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyersuppliertemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
