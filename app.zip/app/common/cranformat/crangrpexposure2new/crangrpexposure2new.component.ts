import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-crangrpexposure2new',
  templateUrl: './crangrpexposure2new.component.html',
  styleUrls: ['./crangrpexposure2new.component.css']
})
export class Crangrpexposure2newComponent implements OnInit {

  data: any;
  componentlist: any = [];
  finalGrpExposureList: any = [];
  outstandingDate: any;
  @Input()
  cranTypeFromResolver: string;
  constructor(private cranService: CranService) { }
  ngOnInit() {
    this.componentlist = [
      {
        name: 'Crangrpexposure1newComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.finalGrpExposureList = [];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.outstandingDate = this.data.responseData.OsDate;
            this.finalGrpExposureList = this.data.responseData.finalGrpExposureList;
            this.finalGrpExposureList.forEach(element => {
              if (element.exposureList != undefined && element.exposureList.length > 0) {
                element.exposureList.forEach(element2 => {
                  element2.sancLimit = this.parseEmptytoFloat(element2.sancLimit).toFixed(2);
                  element2.OSLimit = this.parseEmptytoFloat(element2.OSLimit).toFixed(2);
                  element2.proposedLimit = this.parseEmptytoFloat(element2.proposedLimit).toFixed(2);
                });
              }
            });
          }
        },
        error => {

        });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}

