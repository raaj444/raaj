import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Crangrpexposure2newComponent } from './crangrpexposure2new.component';

describe('Crangrpexposure2newComponent', () => {
  let component: Crangrpexposure2newComponent;
  let fixture: ComponentFixture<Crangrpexposure2newComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Crangrpexposure2newComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Crangrpexposure2newComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
