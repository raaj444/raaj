import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranbankingarrangement',
  templateUrl: './cranbankingarrangement.component.html',
  styleUrls: ['./cranbankingarrangement.component.css']
})
export class CranbankingarrangementComponent implements OnInit {
  termLoanDetails: any = [];
  commentsList: any = [];
  repayY1: any;
  repayY2: any;
  repayY3: any;
  repayY4: any;
  repayY5: any;
  repayY6: any;
  bankDetails: any = [];
  bankDetailsModel: any = [];
  totShare: any;
  share: any;
  totPropLmtBnkwise: any;
  componentlist: any = [];
  bankFacColDetails: any = [];
  table1: boolean = true;
  bankView: boolean = true;
  data: any;
  bankarrange: any;
  grandTotal: any;
  pgrandTotal: any;
  pgrandshare: any;
  model: any = [];
  modelTotal: any = [];
  OBDCmts: any;
  OBDCmtsView: boolean = true;
  STLCmts: any;
  STLCmtsView: boolean = true;
  CTFCmts: any;
  CTFCmtsView: boolean = true;
  ACCmts: any;
  ACCmtsView: boolean = true;
  osAsOnDate: any;
  exposure: any = [];
  overAllTot: any = [];
  preLmtTotFB: any;
  preLmtTotNFB: any;
  osLmtTotFB: any;
  osLmtTotNFB: any;
  propLmtTotFB: any;
  propLmtTotNFB: any;
  shareTot: any;
  totProLmt: any;
  tableViewFlag: boolean;
  totLeeSancAmt: any = 0;
  totLeeOsAmt: any = 0;
  totLeeOverdue: any = 0;

  constructor(private cranService: CranService) { }
  @Input()
  cranTypeFromResolver: string;

  ngOnInit() {
    this.tableViewFlag = false;
    this.osAsOnDate = "";
    this.model = [];
    this.modelTotal = [];
    this.bankFacColDetails = [];
    this.OBDCmtsView = true;
    this.STLCmtsView = true;
    this.CTFCmtsView = true;
    this.ACCmtsView = true;
    this.exposure = [];
    this.bankDetails = [];
    this.bankDetailsModel = [];
    this.preLmtTotFB = 0;
    this.preLmtTotNFB = 0;
    this.osLmtTotFB = 0;
    this.osLmtTotNFB = 0;
    this.propLmtTotFB = 0;
    this.propLmtTotNFB = 0;
    this.totShare = 0;

    this.componentlist = [
      {
        name: 'CranbankingarrangementComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          //   this.OBDCmts = this.data.responseData.OBDCmts;
          // this.STLCmts = this.data.responseData.STLCmts;
          //  this.CTFCmts = this.data.responseData.CTFCmts;
          //  this.ACCmts = this.data.responseData.ACCmts;
          //this.commentsList=this.data.responseData.commentsHashMapList;
          this.osAsOnDate = this.data.responseData.osAsOnDate;
          this.bankFacColDetails = this.data.responseData.bankFacColDetails;

          // if (this.OBDCmts != undefined && this.OBDCmts != "") {
          //   this.OBDCmtsView = true;
          //   $("#OBDCmts").html(this.OBDCmts);
          // } else {
          //   this.OBDCmtsView = false;
          // }
          // if (this.STLCmts != undefined && this.STLCmts != "") {
          //   this.STLCmtsView = true;
          //   $("#STLCmts").html(this.STLCmts);
          // } else {
          //   this.STLCmtsView = false;
          // }
          // if (this.CTFCmts != undefined && this.CTFCmts != "") {
          //   this.CTFCmtsView = true;
          //   $("#CTFCmts").html(this.CTFCmts);
          // } else {
          //   this.CTFCmtsView = false;
          // }
          // if (this.ACCmts != undefined && this.ACCmts != "") {
          //   this.ACCmtsView = true;
          //   $("#ACCmts").html(this.ACCmts);
          // } else {
          //   this.ACCmtsView = false;
          // }
          var bankingarrangement = this.data.responseData.bankingarrangement;

          this.bankarrange = this.data.responseData.bankarrange;
          if (this.data.responseData.caseDetSale.lpcdsCaseType == "1" && this.data.responseData.caseDetSale.lpcdsTakeover == "N") {
            this.table1 = true;
          }
          else {
            this.table1 = false;
          }

          this.bankDetails = this.data.responseData.bankDetails;

          this.bankDetails.forEach(element => {
            this.model = [];
            var val0 = "0", val1 = "0", val2 = "0", val3 = "0", val4 = "0", val5 = "0";

            //Banking Arrangements for KMBL
            if (element.KMBLList.length > 0) {
              this.tableViewFlag = true;
              val0 = parseFloat(element.KMBLList[0]).toFixed(2);
              val1 = parseFloat(element.KMBLList[1]).toFixed(2);
              val2 = parseFloat(element.KMBLList[2]).toFixed(2);
              val3 = parseFloat(element.KMBLList[3]).toFixed(2);
              val4 = parseFloat(element.KMBLList[4]).toFixed(2);
              val5 = parseFloat(element.KMBLList[5]).toFixed(2);

              this.preLmtTotFB = this.preLmtTotFB + element.KMBLList[0];
              this.preLmtTotNFB = this.preLmtTotNFB + element.KMBLList[1];
              this.osLmtTotFB = this.osLmtTotFB + element.KMBLList[2];
              this.osLmtTotNFB = this.osLmtTotNFB + element.KMBLList[3];
              this.propLmtTotFB = this.propLmtTotFB + element.KMBLList[4];
              this.propLmtTotNFB = this.propLmtTotNFB + element.KMBLList[5];

              this.exposure = [];
              this.exposure.push(val0);
              this.exposure.push(val1);
              this.exposure.push(val2);
              this.exposure.push(val3);
              this.exposure.push(val4);
              this.exposure.push(val5);

              this.model.push({ bankName: "KMBL", data: this.exposure, secured: "", share: "" });
            }
            //Banking Arrangements for Other Bank
            var otherBankDet = element.otherBankList;
            for (var prop in otherBankDet) {
              this.tableViewFlag = true;
              var temp = otherBankDet[prop];
              otherBankDet[prop] = [];
              otherBankDet[prop].push(parseFloat(temp[0]).toFixed(2));
              otherBankDet[prop].push(parseFloat(temp[1]).toFixed(2));
              otherBankDet[prop].push(parseFloat(temp[2]).toFixed(2));
              otherBankDet[prop].push(parseFloat(temp[3]).toFixed(2));
              otherBankDet[prop].push(parseFloat(temp[4]).toFixed(2));
              otherBankDet[prop].push(parseFloat(temp[5]).toFixed(2));

              this.preLmtTotFB = parseFloat(this.preLmtTotFB) + parseFloat(temp[0]);
              this.preLmtTotNFB = parseFloat(this.preLmtTotNFB) + parseFloat(temp[1]);
              this.osLmtTotFB = parseFloat(this.osLmtTotFB) + parseFloat(temp[2]);
              this.osLmtTotNFB = parseFloat(this.osLmtTotNFB) + parseFloat(temp[3]);
              this.propLmtTotFB = parseFloat(this.propLmtTotFB) + parseFloat(temp[4]);
              this.propLmtTotNFB = parseFloat(this.propLmtTotNFB) + parseFloat(temp[5]);

              var secured;
              secured = temp[6];
              this.model.push({ bankName: prop, data: otherBankDet[prop], secured: secured, share: "0.00" });
            }
            this.bankDetailsModel.push({ custName: element.custName, model: this.model, ACCmts: element.ACCmts })
          });

          this.overAllTot = [];
          this.overAllTot.push(parseFloat(this.preLmtTotFB).toFixed(2));
          this.overAllTot.push(parseFloat(this.preLmtTotNFB).toFixed(2));
          this.overAllTot.push(parseFloat(this.osLmtTotFB).toFixed(2));
          this.overAllTot.push(parseFloat(this.osLmtTotNFB).toFixed(2));
          this.overAllTot.push(parseFloat(this.propLmtTotFB).toFixed(2));
          this.overAllTot.push(parseFloat(this.propLmtTotNFB).toFixed(2));
          this.totProLmt = parseFloat(this.propLmtTotFB) + parseFloat(this.propLmtTotNFB);

          this.modelTotal.push({ bankName: "Total", data: this.overAllTot, secured: "", share: "0.00" });


          this.bankDetailsModel.forEach(element => {
            this.totPropLmtBnkwise = 0;
            element.model.forEach(det => {
              this.totPropLmtBnkwise = parseFloat(det.data[4]) + parseFloat(det.data[5]);
              this.share = (parseFloat(this.totPropLmtBnkwise) / parseFloat(this.totProLmt)) * 100;
              det.share = parseFloat(this.share).toFixed(2);
              this.totShare = this.totShare + this.share;
            });
          });
          this.modelTotal[0].share = parseFloat(this.totShare).toFixed(2);

          // Term Loan Details
          this.termLoanDetails = this.data.responseData.termLoanDetails;
          if (this.termLoanDetails != undefined && this.termLoanDetails.length > 0) {
            this.termLoanDetails.forEach(tlDet => {
              tlDet.termLoanDetailsList.forEach((element, index) => {
                if (index == 0) {
                  this.repayY1 = element.leeRepayYear1;
                  this.repayY2 = element.leeRepayYear2;
                  this.repayY3 = element.leeRepayYear3;
                  this.repayY4 = element.leeRepayYear4;
                  this.repayY5 = element.leeRepayYear5;
                  this.repayY6 = element.leeRepayYear6;
                }
                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.leeSancAmt);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.leeOsAmt);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.leeOverdue);

                element.leeSancAmt = parseFloat(element.leeSancAmt).toFixed(2);
                element.leeOsAmt = parseFloat(element.leeOsAmt).toFixed(2);
                element.leeOverdue = parseFloat(element.leeOverdue).toFixed(2);
                element.leeRepayY1 = parseFloat(element.leeRepayY1).toFixed(2);
                element.leeRepayY2 = parseFloat(element.leeRepayY2).toFixed(2);
                element.leeRepayY3 = parseFloat(element.leeRepayY3).toFixed(2);
                element.leeRepayY4 = parseFloat(element.leeRepayY4).toFixed(2);
                element.leeRepayY5 = parseFloat(element.leeRepayY5).toFixed(2);
                element.leeRepayY6 = parseFloat(element.leeRepayY6).toFixed(2);

                if (element.leeRoi == NaN || element.leeRoi == null || element.leeRoi == undefined)
                  element.leeRoi = "0.00";
              });
            });

            this.termLoanDetails.forEach(exposure => {
              exposure.exposureDet.forEach(element => {

                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.ledSancLimit);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.ledOsAmt);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.ledOverdue);

                element.ledSancLimit = parseFloat(element.ledSancLimit).toFixed(2);
                element.ledOsAmt = parseFloat(element.ledOsAmt).toFixed(2);
                element.ledOverdue = parseFloat(element.ledOverdue).toFixed(2);
                element.ledRepayY1 = parseFloat(element.ledRepayY1).toFixed(2);
                element.ledRepayY2 = parseFloat(element.ledRepayY2).toFixed(2);
                element.ledRepayY3 = parseFloat(element.ledRepayY3).toFixed(2);
                element.ledRepayY4 = parseFloat(element.ledRepayY4).toFixed(2);
                element.ledRepayY5 = parseFloat(element.ledRepayY5).toFixed(2);
                element.ledRepayY6 = parseFloat(element.ledRepayY6).toFixed(2);

                if (element.ledRoi == NaN || element.ledRoi == null || element.ledRoi == undefined)
                  element.ledRoi = "0.00";

              });

            });

            this.termLoanDetails.forEach(fac => {
              fac.facility.forEach(element => {

                this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.lfSancLimit);
                this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.lfOsLimit);
                this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.lfOverdue);


                element.lfOsLimit = parseFloat(element.lfOsLimit).toFixed(2);
                element.lfSancLimit = parseFloat(element.lfSancLimit).toFixed(2);
                element.lfOverdue = parseFloat(element.lfOverdue).toFixed(2);
                element.lfRepayY1 = parseFloat(element.lfRepayY1).toFixed(2);
                element.lfRepayY2 = parseFloat(element.lfRepayY2).toFixed(2);
                element.lfRepayY3 = parseFloat(element.lfRepayY3).toFixed(2);
                element.lfRepayY4 = parseFloat(element.lfRepayY4).toFixed(2);
                element.lfRepayY5 = parseFloat(element.lfRepayY5).toFixed(2);
                element.lfRepayY6 = parseFloat(element.lfRepayY6).toFixed(2);

                if (element.lfExistLmtROI == NaN || element.lfExistLmtROI == null || element.lfExistLmtROI == undefined)
                  element.lfExistLmtROI = "0.00";

              });
            });

            if (this.data.responseData.repaymentYear) {

              let year = this.data.responseData.repaymentYear;

              if (year.leeRepayYear1)
                this.repayY1 = year.leeRepayYear1;
              if (year.leeRepayYear2)
                this.repayY2 = year.leeRepayYear2;
              if (year.leeRepayYear3)
                this.repayY3 = year.leeRepayYear3;
              if (year.leeRepayYear4)
                this.repayY4 = year.leeRepayYear4;
              if (year.leeRepayYear5)
                this.repayY5 = year.leeRepayYear5;
              if (year.leeRepayYear6)
                this.repayY6 = year.leeRepayYear6;
            }

            this.totLeeSancAmt = parseFloat(this.totLeeSancAmt).toFixed(2);
            this.totLeeOsAmt = parseFloat(this.totLeeOsAmt).toFixed(2);
            this.totLeeOverdue = parseFloat(this.totLeeOverdue).toFixed(2);

          }

        }
        else {
          this.table1 = false;
          this.bankView = false;
        }
      },
      error => {
        this.table1 = false;
      });
  }

}