import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranbankingarrangementComponent } from './cranbankingarrangement.component';

describe('CranbankingarrangementComponent', () => {
  let component: CranbankingarrangementComponent;
  let fixture: ComponentFixture<CranbankingarrangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranbankingarrangementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranbankingarrangementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
