import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crandscr',
  templateUrl: './crandscr.component.html',
  styleUrls: ['./crandscr.component.css']
})
export class CrandscrComponent  implements OnInit {   data:any; 
  dscrView:boolean=true;
  componentlist :any=[];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }
  finalCustMapList: any = [];

  ngOnInit() {
    
    this.componentlist = [
      {
        name: 'CrandscrComponent', cranType:this.cranTypeFromResolver
      },
    ];
     this.cranService.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
          this.finalCustMapList=this.data.responseData.finalCustMapList;
          if( this.finalCustMapList!=undefined && this.finalCustMapList.length >0)
          {
          
            this.dscrView=true;
            this.finalCustMapList.forEach(element1 => {
              if( element1.customerDetailsListNew!=undefined && element1.customerDetailsListNew.length >0)
          {
            element1.customerDetailsListNew.forEach(financialDetail => {
              if(financialDetail.style!="head"){
              if( element1.yearSize!=undefined &&  element1.yearSize.length>0){
                element1.yearSize.forEach((yearSizeItem,index) => {
                  var year="lpdYear"+(index+1).toString();
                  financialDetail[year]=this.parseEmptytoFloat(financialDetail[year]).toFixed(2);
                });
              }
              if(financialDetail.style=="head")
              financialDetail.color = "addBorder";
              else
              financialDetail.color = 'noBorder';
            }
          });
        }
            });
          }
          else{
            this.dscrView=false;
          }
        
          
         
          
           }   
           else{
            this.dscrView=false;
           }
          },
        error => {
          this.dscrView=false;
        }); 
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }

}

