import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandscrComponent } from './crandscr.component';

describe('CrandscrComponent', () => {
  let component: CrandscrComponent;
  let fixture: ComponentFixture<CrandscrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandscrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandscrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
