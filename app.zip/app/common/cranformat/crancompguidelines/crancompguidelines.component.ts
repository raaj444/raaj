import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crancompguidelines',
  templateUrl: './crancompguidelines.component.html',
  styleUrls: ['./crancompguidelines.component.css']
})
export class CrancompguidelinesComponent  implements OnInit {   data:any; 

  accCmtsView:boolean=true;
  componentlist :any=[];
  compguidelinesList:any=[];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.compguidelinesList=[];
    this.accCmtsView=false;
    this.componentlist = [
      {
        name: 'CrancompguidelinesComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
            this.compguidelinesList=this.data.responseData.compguidelinesList;
            if(this.compguidelinesList!=undefined && this.compguidelinesList.length>0)
            {
              this.accCmtsView=true;
            }else{
               this.accCmtsView=false;
             }
          }

         },error =>{
          this.accCmtsView=false;
         });
  }

}

