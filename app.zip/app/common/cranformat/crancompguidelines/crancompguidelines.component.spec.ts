import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrancompguidelinesComponent } from './crancompguidelines.component';

describe('CrancompguidelinesComponent', () => {
  let component: CrancompguidelinesComponent;
  let fixture: ComponentFixture<CrancompguidelinesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrancompguidelinesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrancompguidelinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
