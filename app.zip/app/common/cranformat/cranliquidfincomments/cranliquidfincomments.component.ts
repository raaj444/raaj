import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranliquidfincomments',
  templateUrl: './cranliquidfincomments.component.html',
  styleUrls: ['./cranliquidfincomments.component.css']
})
export class CranliquidfincommentsComponent  implements OnInit {   data:any; 
  componentlist=[];
  finlcbdCmts: any =[];
  finlcbdcmtsView:boolean=true;
  @Input()
  cranTypeFromResolver:string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.finlcbdCmts=[];
    this.finlcbdcmtsView=false;
    this.componentlist = [
      {
        name: 'CranliquidfincommentsComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.finlcbdCmts=this.data.responseData.finlcbdCmts;
           if(this.finlcbdCmts!=undefined && this.finlcbdCmts.length>0)
            {
              this.finlcbdcmtsView=true;
            
            }else{
               this.finlcbdcmtsView=false;
             }
          }
          else{
            this.finlcbdcmtsView=false;
          }
         },error =>{
          this.finlcbdcmtsView=false;
         });
  }

}

