import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranliquidfincommentsComponent } from './cranliquidfincomments.component';

describe('CranliquidfincommentsComponent', () => {
  let component: CranliquidfincommentsComponent;
  let fixture: ComponentFixture<CranliquidfincommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranliquidfincommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranliquidfincommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
