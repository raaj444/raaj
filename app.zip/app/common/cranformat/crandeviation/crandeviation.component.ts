import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;

@Component({
  selector: 'lp-crandeviation',
  templateUrl: './crandeviation.component.html',
  styleUrls: ['./crandeviation.component.css']
})
export class CrandeviationComponent implements OnInit {
  data: any;

  @Input()
  cranTypeFromResolver: string;
  componentlist: any = [];
  deviationList: any = [];
  custDeviationList: any = [];
  facDeviationList: any = [];
  // listofvalueList:any=[];
  userDefinedDevList: any = [];
  // lpstpuserDeviationList:any=[];
  customerNameList: any = [];
  deviationDetList: any = [];
  FacList; any = [];
  prodListView: boolean = true;
  custListView: boolean = true;
  facListView: boolean = true;
  userDefListView: boolean = true;
  constructor(private cran: CranService) { }

  ngOnInit() {

    this.componentlist = [
      {
        name: 'CrandeviationComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.deviationDetList = [];

    this.cran.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.deviationDetList = this.data.responseData;
            
          }

        }, error => {

        });
  }

}
