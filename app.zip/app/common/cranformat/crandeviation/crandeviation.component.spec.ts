import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandeviationComponent } from './crandeviation.component';

describe('CrandeviationComponent', () => {
  let component: CrandeviationComponent;
  let fixture: ComponentFixture<CrandeviationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandeviationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandeviationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
