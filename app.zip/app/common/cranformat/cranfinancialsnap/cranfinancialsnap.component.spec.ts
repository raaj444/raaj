import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranfinancialsnapComponent } from './cranfinancialsnap.component';

describe('CranfinancialsnapComponent', () => {
  let component: CranfinancialsnapComponent;
  let fixture: ComponentFixture<CranfinancialsnapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranfinancialsnapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranfinancialsnapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
