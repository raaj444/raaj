import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranfinancialsnap',
  templateUrl: './cranfinancialsnap.component.html',
  styleUrls: ['./cranfinancialsnap.component.css']
})
export class CranfinancialsnapComponent  implements OnInit {   data:any; 
  bglesseeView:boolean=true;
  bglesseeList:any;
  componentlist=[];
  @Input()
cranTypeFromResolver :string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.bglesseeView=false;
    this.componentlist = [
      {
        name: 'CranfinancialsnapComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.bglesseeList=this.data.responseData.bglesseMapList;
           if(this.bglesseeList!=undefined && this.bglesseeList.length>0)
            {
              this.bglesseeView=true;
            }else{
               this.bglesseeView=false;
             }
          }
          else{
            this.bglesseeView=false;
        }
         },error =>{
          this.bglesseeView=false;
         });
  }

}

