import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-borrowerprofiletemplate',
  templateUrl: './borrowerprofiletemplate.component.html',
  styleUrls: ['./borrowerprofiletemplate.component.css']
})
export class BorrowerprofiletemplateComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  model:any={};
  lpcorpMeetingNameList:any=[]
  lpcorpVisitNameList:any=[]
  lpcorpReferenceNameList:any=[]
    constructor(private cranService: CranService) { }

  ngOnInit() {
    this.model.LpcorpMeetingDetlist=[];
    this.model.LpcorpVisitDetlist=[];
    this.model.response={};
    
    this.componentlist = [
      {
        name: 'BorrowerprofiletemplateComponent'
      },
    ];

    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        if(this.data.success)
        {
          this.model.response=this.data.responseData;
          this.model.LpcorpReferenceDetlist=this.data.responseData.LpcorpReferenceDetlist;
          this.model.tempLpcorpMeetingDetlist=this.data.responseData.LpcorpMeetingDetlist;
          this.model.tempLpcorpVisitDetlist=this.data.responseData.LpcorpVisitDetlist;
          this.lpcorpMeetingNameList=this.data.lpcorpMeetingNameList;
          this.lpcorpVisitNameList=this.data.lpcorpVisitNameList
          this.lpcorpReferenceNameList=this.data.lpcorpReferenceNameList
          var lpmasListofvalueHashMapMetBy = this.data.responseData.lpmasListofvalueHashMapMetBy;
          var lpmasListofvalueHashMapVisitBy = this.data.responseData.lpmasListofvalueHashMapVisitBy;
          $("#bcac").html(this.model.response.BCAC);
          $("#sems").html(this.model.response.SEMS);
          $("#rbi").html(this.model.response.RBI);
          $("#nature").html(this.model.response.Nature);
          $("#risk").html(this.model.response.risk);
          if( this.model.tempLpcorpMeetingDetlist!=undefined)
          {
          setTimeout(() => {
            this.model.tempLpcorpMeetingDetlist.forEach((element,index) => {
              this.lpcorpMeetingNameList.forEach(element1 => {
                if(element.lmdMetByName===element1.userId)
                element.lmdMetByName= element1.userName
              });
            });
          }, 50);
        }
        if(this.model.tempLpcorpVisitDetlist!=undefined)
        {
          setTimeout(() => {
            this.model.tempLpcorpVisitDetlist.forEach((element,index) => {
              this.lpcorpVisitNameList.forEach(element1 => {
                if(element.lvdVisitor===element1.userId)
                element.lvdVisitor= element1.userName
              });
            });
          }, 50);
        }
        if(this.model.LpcorpReferenceDetlist)
        {
          setTimeout(() => {
            this.model.LpcorpReferenceDetlist.forEach((element,index) => {
              this.lpcorpReferenceNameList.forEach(element1 => {
                if(element.lrRefTakenBy===element1.userId)
                element.lrRefTakenBy= element1.userName
              });
            });
          }, 50);
        }

          if( this.model.tempLpcorpMeetingDetlist!=undefined)
          {
          this.model.tempLpcorpMeetingDetlist.forEach(element => {           
             element.lmdMetBy = lpmasListofvalueHashMapMetBy[element.lmdMetBy];
             this.model.LpcorpMeetingDetlist.push(element);
          });
        }
        else{
          this.model.LpcorpMeetingDetlist=[];
        }
        if( this.model.tempLpcorpVisitDetlist!=undefined)
        {
        this.model.tempLpcorpVisitDetlist.forEach(element => {         
           element.lvdVisitBy = lpmasListofvalueHashMapVisitBy[element.lvdVisitBy];
           this.model.LpcorpVisitDetlist.push(element);
        });
      }
      else{
        this.model.LpcorpVisitDetlist=[];
      }
      }
      },
      error => {
      });
  }

}
