import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BorrowerprofiletemplateComponent } from './borrowerprofiletemplate.component';

describe('BorrowerprofiletemplateComponent', () => {
  let component: BorrowerprofiletemplateComponent;
  let fixture: ComponentFixture<BorrowerprofiletemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BorrowerprofiletemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BorrowerprofiletemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
