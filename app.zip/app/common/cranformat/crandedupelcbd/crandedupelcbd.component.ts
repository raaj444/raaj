import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $ :any;


@Component({
  selector: 'lp-crandedupelcbd',
  templateUrl: './crandedupelcbd.component.html',
  styleUrls: ['./crandedupelcbd.component.css']
})
export class CrandedupelcbdComponent  implements OnInit {   data:any; 

  componentlist :any=[];
  hygienelist :any=[];
  BorrowerList :any=[];
  dedupeList:boolean=true;
  dedupeheadView:boolean=true;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CrandedupechkComponent'
      },
    ];
     this.cranService.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data;   
           if (this.data.success == true) {
             this.hygienelist=this.data.responseData.lpcomHygeineChkList;
           
             if( this.hygienelist !=undefined && this.hygienelist.length >0 )
             {
              this.dedupeList=true;
              this.dedupeheadView=true;
             }
             else{
              this.dedupeList=false;
              this.dedupeheadView=false;
             }
           } 
           else{
            this.dedupeList=false;
            this.dedupeheadView=false;
           }
          },
        error => {
          this.dedupeList=false;      
          this.dedupeheadView=false;         
        }); 

  }

}