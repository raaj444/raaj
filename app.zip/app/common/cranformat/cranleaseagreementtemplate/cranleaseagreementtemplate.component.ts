import { Component, OnInit } from '@angular/core';
import { CranleaseagreementtemplateService } from "../../../util/service/commonservices/cranleaseagreementtemplate.service";

@Component({
  selector: 'lp-cranleaseagreementtemplate',
  templateUrl: './cranleaseagreementtemplate.component.html',
  styleUrls: ['./cranleaseagreementtemplate.component.css']
})
export class CranleaseagreementtemplateComponent implements OnInit {

  componentlist: any = [];
  data: any;
  applicantList: any = [];
  useOfProperty: any = {};
  yesNo: any = {
    "Y": "Yes",
    "N": "No"
  };
  monthYear: any = {
    "M": "Month",
    "Y": "Year"
  };


  constructor(private cranleaseagreementtemplateService: CranleaseagreementtemplateService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CranLeaseagreementComponent'
      },
    ];
    this.cranleaseagreementtemplateService.getDataForCranList(this.componentlist).subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.applicantList = this.data.responseData.applicantList;
          this.useOfProperty = this.data.responseData.useOfProperty;
          this.applicantList.forEach(element => {
            let applicant = element;
            applicant.leaseAgreement.forEach(element1 => {
              if (element1.llaLeaseRental)
                element1.llaLeaseRental = parseFloat(element1.llaLeaseRental).toFixed(2);
              if (element1.llaSecurityDeposit)
                element1.llaSecurityDeposit = parseFloat(element1.llaSecurityDeposit).toFixed(2);
              if (element1.llaMaintainExpn)
                element1.llaMaintainExpn = parseFloat(element1.llaMaintainExpn).toFixed(2);
              if (element1.llaTax)
                element1.llaTax = parseFloat(element1.llaTax).toFixed(2);
              if (element1.llaProviReceipt)
                element1.llaProviReceipt = parseFloat(element1.llaProviReceipt).toFixed(2);
            });
          });
        }
      },
      error => {
      }
    );
  }
}
