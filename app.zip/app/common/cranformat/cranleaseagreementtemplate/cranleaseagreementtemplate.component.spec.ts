import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranleaseagreementtemplateComponent } from './cranleaseagreementtemplate.component';

describe('CranleaseagreementtemplateComponent', () => {
  let component: CranleaseagreementtemplateComponent;
  let fixture: ComponentFixture<CranleaseagreementtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranleaseagreementtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranleaseagreementtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
