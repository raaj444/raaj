import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranborrgrpwithlastsanctionComponent } from './cranborrgrpwithlastsanction.component';

describe('CranborrgrpwithlastsanctionComponent', () => {
  let component: CranborrgrpwithlastsanctionComponent;
  let fixture: ComponentFixture<CranborrgrpwithlastsanctionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranborrgrpwithlastsanctionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranborrgrpwithlastsanctionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
