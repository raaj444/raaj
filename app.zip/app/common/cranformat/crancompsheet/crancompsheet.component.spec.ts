import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrancompsheetComponent } from './crancompsheet.component';

describe('CrancompsheetComponent', () => {
  let component: CrancompsheetComponent;
  let fixture: ComponentFixture<CrancompsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrancompsheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrancompsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
