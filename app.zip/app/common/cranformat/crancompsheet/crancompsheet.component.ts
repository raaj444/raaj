import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crancompsheet',
  templateUrl: './crancompsheet.component.html',
  styleUrls: ['./crancompsheet.component.css']
})
export class CrancompsheetComponent  implements OnInit {   data:any; 
  componentlist:any=[];
  compsheetMapList:any=[];
    compheadView:boolean=true;
    @Input()
    cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }
  ngOnInit() {
  
    this.componentlist = [
      {
        name:'CrancompsheetComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
     this.compsheetMapList= this.data.responseData.compsheetMapList;
     if(this.compsheetMapList != undefined && this.compsheetMapList.length >0)
     {
      this.compheadView=true;
      this.compsheetMapList.forEach(element1 => {
        element1.compSheetHeadingList=[];
        element1.compSheetContentListObject=[];
        if(element1.compSheetList != undefined && element1.compSheetList.length >0)
        {
          element1.compSheetList.forEach(annx => {
          if (annx.lcsaParentId == 0)
          element1.compSheetHeadingList.push({ lcsaDesc: annx.lcsaDesc, lcsaAdherence: annx.lcsaAdherence, lcsaExposure: annx.lcsaExposure, lcsaNorms: annx.lcsaNorms, lcsaParentId: annx.lcsaParentId, lcsaOrderNo: annx.lcsaOrderNo, lcsaRowId: annx.lcsaRowId });

          else {
            if (element1.compSheetContentListObject[annx.lcsaParentId] == undefined) {
              element1.compSheetContentListObject[annx.lcsaParentId] = [];
              element1.compSheetContentListObject[annx.lcsaParentId].push({ lcsaDesc: annx.lcsaDesc, lcsaAdherence: annx.lcsaAdherence, lcsaExposure: annx.lcsaExposure, lcsaNorms: annx.lcsaNorms, lcsaParentId: annx.lcsaParentId, lcsaOrderNo: annx.lcsaOrderNo, lcsaRowId: annx.lcsaRowId });
            }
            else {
              element1.compSheetContentListObject[annx.lcsaParentId].push({ lcsaDesc: annx.lcsaDesc, lcsaAdherence: annx.lcsaAdherence, lcsaExposure: annx.lcsaExposure, lcsaNorms: annx.lcsaNorms, lcsaParentId: annx.lcsaParentId, lcsaOrderNo: annx.lcsaOrderNo, lcsaRowId: annx.lcsaRowId });
            }
          }

        });
      }
    });
  }
    else{
      this.compheadView=false;
    }
},
error => {
  this.compheadView=false;           
});
 
       }
      }