import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrankmplrefchkComponent } from './crankmplrefchk.component';

describe('CrankmplrefchkComponent', () => {
  let component: CrankmplrefchkComponent;
  let fixture: ComponentFixture<CrankmplrefchkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrankmplrefchkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrankmplrefchkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
