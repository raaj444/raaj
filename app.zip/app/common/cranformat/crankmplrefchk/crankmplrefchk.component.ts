import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crankmplrefchk',
  templateUrl: './crankmplrefchk.component.html',
  styleUrls: ['./crankmplrefchk.component.css']
})
export class CrankmplrefchkComponent  implements OnInit {   data:any; 
  kmplrefView:boolean=true;
  kmplrefence:any;
  componentlist=[];
  @Input()
cranTypeFromResolver :string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
   
    this.componentlist = [
      {
        name: 'CrankmplrefchkComponent', cranType:this.cranTypeFromResolver
      }, 
    ];
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
           this.kmplrefence=this.data.responseData.kmplrefenceList;
           if(this.kmplrefence!=undefined && this.kmplrefence.length>0)
            {
              this.kmplrefView=true;
              // $("#kmplrefence").html(this.kmplrefence);
            }else{
               this.kmplrefView=false;
             }
          }
          else{
            this.kmplrefView=false;
        }
         },error =>{
          this.kmplrefView=false;
         });
  }

}

