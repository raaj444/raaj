import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranborrdetails',
  templateUrl: './cranborrdetails.component.html',
  styleUrls: ['./cranborrdetails.component.css']
})
export class CranborrdetailsComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  @Input()
  cranTypeFromResolver :string;
  model:any={};
  
    constructor(private cranService: CranService) { }
  ngOnInit() {
    this.model.response={};
    this.componentlist = [
      {
        name: 'CranborrdetailsComponent', cranType:this.cranTypeFromResolver
      },
    ];
  this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
    data => { this.data=data;
      if(this.data.success)
      {
        this.model.response=this.data.responseData;
        $("#nature").html(this.model.response.Nature);
      }
    },
    error => {
    });

  }

}
