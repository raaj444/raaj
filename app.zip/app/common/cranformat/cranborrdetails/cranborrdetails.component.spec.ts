import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranborrdetailsComponent } from './cranborrdetails.component';

describe('CranborrdetailsComponent', () => {
  let component: CranborrdetailsComponent;
  let fixture: ComponentFixture<CranborrdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranborrdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranborrdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
