import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
import { element } from 'protractor';
declare var $: any;
@Component({
  selector: 'lp-cranaccconductanalysis',
  templateUrl: './cranaccconductanalysis.component.html',
  styleUrls: ['./cranaccconductanalysis.component.css']
})
export class CranaccconductanalysisComponent implements OnInit {
  avg: any;
  lacaChurnRealizationvalue: any;
  lacaChurnKmblvalue: any;
  lacaDebtRealizationvalue: any;
  lacaTotalChurnvalue: any;
  lacaNetCreditOthervalue: any;
  lacaNetCreditKmblvalue: any;
  data: any;
  aluTot: any;
  churnListView: boolean = true;
  componentlist: any = [];
  model: any = {};
  @Input()
  cranTypeFromResolver: string;
  finalAccconductanalysisList: any = [];
  accountBasedList: any = [];
  accountBasedTotAvgList: any = [];
  monthForCRANTemp: any = [];
  monthForTotAvg: any = [];
  bankNameList: any = [];
  facList: any = [];
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.accountBasedList = [];
    this.model.LpcorpReferenceDetlist = [];
    this.bankNameList = [];
    this.facList = [];
    this.aluTot = 0;
    this.avg = 0;
    this.componentlist = [
      {
        name: 'CranaccconductanalysisComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success) {
            this.finalAccconductanalysisList = this.data.responseData.finalAcct1AnalysisMapList;
            this.bankNameList = this.data.responseData.bankNameList;
            this.facList = this.data.responseData.facList;
            if (this.finalAccconductanalysisList != undefined && this.finalAccconductanalysisList.length > 0) {
              if (this.finalAccconductanalysisList[0].churnAnalysis.length == 0) {
                this.churnListView = false;
              }
              this.finalAccconductanalysisList.forEach((element, index) => {
                var tempList = [];
                element.churnAnalysis.forEach(acctData => {
                  tempList.push({ lacaMonth: acctData.lacaMonth, lacaNetCreditKmbl: this.parseFloatForData(acctData.lacaNetCreditKmbl), lacaNetCreditOther: this.parseFloatForData(acctData.lacaNetCreditOther), lacaTotalChurn: this.parseFloatForData(acctData.lacaTotalChurn), lacaDebtRealization: this.parseFloatForData(acctData.lacaDebtRealization), lacaChurnRealization: this.parseFloatForData(acctData.lacaChurnRealization), lacaChurnKmbl: this.parseFloatForData(acctData.lacaChurnKmbl) });
                });
                this.finalAccconductanalysisList[index].churnAnalysis = tempList;

                element.accountwiseList.forEach(acctDetList => {
                  this.aluTot = 0;
                  acctDetList.forEach(accDet => {
                    this.aluTot = this.aluTot + accDet.lacardNetCreditKmbl;
                  });
                  var tot = parseFloat(this.aluTot).toFixed(2);
                  this.avg = this.aluTot / (acctDetList.length);

                  acctDetList.push({ lacardAccNo: '', lacardBankName: '', lacardCustId: '', lacardDebtRealization: '', lacardFacilityName: '', lacardMannualEntry: '', lacardMonth: 'Grand Total', lacardMonthCounter: '98', lacardNetCreditKmbl: tot, lacardRowId: '', lacardVersionNo: '' })
                  acctDetList.push({ lacardAccNo: '', lacardBankName: '', lacardCustId: '', lacardDebtRealization: '', lacardFacilityName: '', lacardMannualEntry: '', lacardMonth: 'Average of above Months', lacardMonthCounter: '99', lacardNetCreditKmbl: parseFloat(this.avg).toFixed(2), lacardRowId: '', lacardVersionNo: '' })
                });
                if(element.accountwiseList.length > 0)
                {
                  element.monthForCRANTemp.push({ monthName: "Grand Total", monthid: '98' });
                  element.monthForCRANTemp.push({ monthName: "Average of above Months", monthid: '99' });
                }
              });
            }
            else {
              this.churnListView = false;
            }
          }
          else {
            this.churnListView = false;
          }
        },
        error => {
          this.churnListView = false;
        });
  }

  parseFloatForData(det) {
    if (det != null && det != undefined && det != "")
      return parseFloat(det).toFixed(2);
    else
      return parseFloat("0.00");
  }
}