import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranaccconductanalysisComponent } from './cranaccconductanalysis.component';

describe('CranaccconductanalysisComponent', () => {
  let component: CranaccconductanalysisComponent;
  let fixture: ComponentFixture<CranaccconductanalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranaccconductanalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranaccconductanalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
