import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranaccountconductreportComponent } from './cranaccountconductreport.component';

describe('CranaccountconductreportComponent', () => {
  let component: CranaccountconductreportComponent;
  let fixture: ComponentFixture<CranaccountconductreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranaccountconductreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranaccountconductreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
