import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranaccountconductreport',
  templateUrl: './cranaccountconductreport.component.html',
  styleUrls: ['./cranaccountconductreport.component.css']
})
export class CranaccountconductreportComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  accAnnexHeadingList: any = [];
  tempaccAnnexHeadingList:any=[];
  constructor(private cranService: CranService) { }
  accAnnexContentListObject: any = {};
  accListView: boolean = true;
  accountconductList: any = [];
  masterlist: any = [];
  @Input()
  cranTypeFromResolver:string;
  ngOnInit() {

    this.componentlist = [
      {
        name: 'CranaccountconductreportComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)

      .subscribe(
        data => { this.data=data;
          if(this.data.success){
          this.masterlist=this.data.responseData.masterlist;
          this.accountconductList=this.data.responseData.accountconductList;
          if ( this.accountconductList != undefined &&  this.accountconductList.length > 0) {
            this.accListView = true;

            //  this.accountconductList.forEach(element1 => {
            //   element1.accAnnexHeadingList=[];
            //   element1.accAnnexContentListObject=[];
            //   if ( element1.accCondCmtsAnnexList != undefined &&  element1.accCondCmtsAnnexList.length > 0) {
            //     element1.accCondCmtsAnnexList.forEach(annx => {
            //   if (annx.laccParentId == 0)
            //   element1.accAnnexHeadingList.push({ laccDesc: annx.laccDesc, laccRemarks: " ", laccParentId: annx.laccParentId, laccOrderNo: annx.laccOrderNo, laccAccId: 1, laccRowId: annx.laccRowId });
            //             else {
            //               if (element1.accAnnexContentListObject[annx.laccParentId] == undefined) {
            //                 element1.accAnnexContentListObject[annx.laccParentId] = [];
            //                 element1.accAnnexContentListObject[annx.laccParentId].push({ laccDesc: annx.laccDesc, laccRemarks: annx.laccRemarks, laccParentId: annx.laccParentId, laccOrderNo: annx.laccOrderNo, laccAccId: 1, laccRowId: annx.laccRowId });
            //               }
            //               else {
            //                 element1.accAnnexContentListObject[annx.laccParentId].push({ laccDesc: annx.laccDesc, laccRemarks: annx.laccRemarks, laccParentId: annx.laccParentId, laccOrderNo: annx.laccOrderNo, laccAccId: 1, laccRowId: annx.laccRowId });
            //               }
            //             }
            //           });
            //           }
            // });
          }
          else{
            this.accListView = false;
          }
        }  
else{
  this.accListView = false;
}
        },
        error => {
          this.accListView = false;
        });

  }
}


