import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crancompcreditpolicies',
  templateUrl: './crancompcreditpolicies.component.html',
  styleUrls: ['./crancompcreditpolicies.component.css']
})
export class CrancompcreditpoliciesComponent  implements OnInit {   data:any; 
  compcreditview:boolean=true;
  componentlist :any=[];
  CompCpAnnexList:any=[];
  @Input()
  cranTypeFromResolver:string;
  constructor(private cran: CranService) { }
 
  ngOnInit() {
    this.compcreditview=false;
    this.componentlist = [
      {
        name: 'CrancompcreditpoliciesComponent', cranType:this.cranTypeFromResolver
      },
    ];
   
    this.cran.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
            this.CompCpAnnexList= this.data.responseData.CompCpAnnexList;
            if( this.CompCpAnnexList!=undefined &&  this.CompCpAnnexList.length>0){
              this.compcreditview=true;  
            this.CompCpAnnexList.forEach(element1 => {
              element1.compCpHeadingList=[];
              element1.compCpContentListObject=[];
              if( element1.compcreditListForCust!=undefined &&  element1.compcreditListForCust.length>0){
                element1.compcreditListForCust.forEach(annx => {
              if (annx.lccaParentId == 0)
               element1.compCpHeadingList.push({ lccaDesc: annx.lccaDesc, lccaRemarks: "", lccaProvided: "Y", lccaParentId: annx.lccaParentId, lccaOrderNo: annx.lccaOrderNo, lccaRowId: annx.lccaRowId });
              else {
                if (element1.compCpContentListObject[annx.lccaParentId] == undefined) {
                 element1.compCpContentListObject[annx.lccaParentId] = [];
                 element1.compCpContentListObject[annx.lccaParentId].push({ lccaDesc: annx.lccaDesc, lccaRemarks: annx.lccaRemarks, lccaProvided: annx.lccaProvided, lccaParentId: annx.lccaParentId, lccaOrderNo: annx.lccaOrderNo, lccaRowId: annx.lccaRowId });
                }
                else {
                 element1.compCpContentListObject[annx.lccaParentId].push({ lccaDesc: annx.lccaDesc, lccaRemarks: annx.lccaRemarks, lccaProvided: annx.lccaProvided, lccaParentId: annx.lccaParentId, lccaOrderNo: annx.lccaOrderNo, lccaRowId: annx.lccaRowId });
                }
              }
            });
            }
            });
          }
          else{
            this.compcreditview=false;
          }
          }
          else{
            this.compcreditview=false;
          }
         },error =>{
          this.compcreditview=false;
         });
  }

}

