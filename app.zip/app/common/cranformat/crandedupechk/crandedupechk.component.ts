import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-crandedupechk',
  templateUrl: './crandedupechk.component.html',
  styleUrls: ['./crandedupechk.component.css']
})
export class CrandedupechkComponent implements OnInit {
    data: any;
  componentlist: any = [];
  hygienelist: any = [];
  BorrowerList: any = [];
  dedupeList: boolean = false;
  dedupeheadView: boolean = false;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name: 'CrandedupechkComponent'
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
      this.data = data;
        if (this.data.success == true) {
          this.hygienelist = this.data.responseData.lpcomHygeineChkList;
          if (this.hygienelist != undefined && this.hygienelist.length > 0) {
            this.dedupeList = true;
            this.dedupeheadView = true;
          }
        }
      },
      error => {
      });
  }
}
