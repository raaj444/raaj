import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandedupechkComponent } from './crandedupechk.component';

describe('CrandedupechkComponent', () => {
  let component: CrandedupechkComponent;
  let fixture: ComponentFixture<CrandedupechkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandedupechkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandedupechkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
