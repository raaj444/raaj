import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cranintrating2Component } from './cranintrating2.component';

describe('Cranintrating2Component', () => {
  let component: Cranintrating2Component;
  let fixture: ComponentFixture<Cranintrating2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cranintrating2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cranintrating2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
