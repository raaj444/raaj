import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-cranintrating2',
  templateUrl: './cranintrating2.component.html',
  styleUrls: ['./cranintrating2.component.css']
})
export class Cranintrating2Component implements OnInit {
    data: any;
  intratingView: boolean = false;
  lpdate: any;
  Currentyear: any;
  componentlist: any = [];
  internalRating: any = [];
  businessRisk: any;
  financialRisk: any;
  managementRisk: any;
  industryRisk: any;

  constructor(private cranService: CranService) { }

  ngOnInit() {

    this.componentlist = [
      {
        name: 'Cranintrating1Component'
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
      this.data = data;
        if (this.data.success == true) {
          this.businessRisk = this.data.responseData.businessListMap;
          this.financialRisk = this.data.responseData.financialListMap;
          this.managementRisk = this.data.responseData.managementListMap;
          this.industryRisk = this.data.responseData.industryListMap;
          this.internalRating = this.data.responseData.lpcomIntRating;
          if (this.internalRating != undefined && this.internalRating != "") {
            this.intratingView = true;
          }
          else {
            this.intratingView = false;
          }
          this.lpdate = this.data.lpDate;
          if (this.lpdate) {
            var dataarry = this.lpdate.split("-");
            this.Currentyear = dataarry[0];
          }
        }
        else {
          this.intratingView = false;
        }
      },
      error => {
        this.intratingView = false;
      });

  }

}
