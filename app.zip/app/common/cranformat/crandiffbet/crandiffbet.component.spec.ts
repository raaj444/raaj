import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandiffbetComponent } from './crandiffbet.component';

describe('CrandiffbetComponent', () => {
  let component: CrandiffbetComponent;
  let fixture: ComponentFixture<CrandiffbetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandiffbetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandiffbetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
