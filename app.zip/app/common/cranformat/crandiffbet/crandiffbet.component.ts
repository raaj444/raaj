import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
  declare var $:any;
@Component({
  selector: 'lp-crandiffbet',
  templateUrl: './crandiffbet.component.html',
  styleUrls: ['./crandiffbet.component.css']
})
export class CrandiffbetComponent implements OnInit {
  data:any;
    componentlist :any=[];
    diffbetcreditCmts: any=[] ;
    diffbetcreditCmtsView:boolean=true;
    @Input()
    cranTypeFromResolver :string;
    constructor(private cran: CranService) { }
   
    ngOnInit() {
      this.diffbetcreditCmts=[];
      this.diffbetcreditCmtsView=false;
      this.componentlist = [
        {
          name: 'CrandiffbetComponent', cranType:this.cranTypeFromResolver
        },
      ];
      this.cran.getDataForCranList(this.componentlist)
      .subscribe(
         data => { this.data=data; 
            if (this.data.success == true) {
             this.diffbetcreditCmts=this.data.responseData.diffbetMapList;
             if(this.diffbetcreditCmts!=undefined && this.diffbetcreditCmts.length>0)
              {
                this.diffbetcreditCmtsView=true;
               
              }else{
                 this.diffbetcreditCmtsView=false;
               }
            }
            else{
              this.diffbetcreditCmtsView=false;
            }
           },error =>{
            this.diffbetcreditCmtsView=false;
           });
    }
  
  }
  
  