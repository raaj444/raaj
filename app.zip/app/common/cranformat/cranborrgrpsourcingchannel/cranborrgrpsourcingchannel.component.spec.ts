import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranborrgrpsourcingchannelComponent } from './cranborrgrpsourcingchannel.component';

describe('CranborrgrpsourcingchannelComponent', () => {
  let component: CranborrgrpsourcingchannelComponent;
  let fixture: ComponentFixture<CranborrgrpsourcingchannelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranborrgrpsourcingchannelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranborrgrpsourcingchannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
