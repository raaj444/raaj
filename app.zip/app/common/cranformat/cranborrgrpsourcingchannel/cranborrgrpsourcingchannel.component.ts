import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranborrgrpsourcingchannel',
  templateUrl: './cranborrgrpsourcingchannel.component.html',
  styleUrls: ['./cranborrgrpsourcingchannel.component.css']
})
export class CranborrgrpsourcingchannelComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  model:any={};
    constructor(private cranService: CranService) { }

  ngOnInit() {
    this.model.response={};
    
    this.componentlist = [
      {
        name: 'CranborrgrpsourcingchannelComponent'
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
    data => { this.data=data;
      if(this.data.success)
      {
        this.model.response=this.data.responseData;
      }
    },
    error => {
    });
}

}

 