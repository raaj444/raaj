import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
  declare var $:any;
@Component({
  selector: 'lp-crancontinplan',
  templateUrl: './crancontinplan.component.html',
  styleUrls: ['./crancontinplan.component.css']
})
export class CrancontinplanComponent implements OnInit {
    data:any;
      componentlist :any=[];
      continplanMapList: any=[] ;
      continPlanCmtsView:boolean=true;
      @Input()
      cranTypeFromResolver :string;
      constructor(private cran: CranService) { }
     
      ngOnInit() {
        this.continPlanCmtsView=false;
        this.componentlist = [
          {
            name: 'CrancontinplanComponent', cranType:this.cranTypeFromResolver
          },
        ];
        this.cran.getDataForCranList(this.componentlist)
        .subscribe(
           data => { this.data=data; 
              if (this.data.success == true) {
               this.continplanMapList=this.data.responseData.continplanMapList;
               if(this.continplanMapList!=undefined && this.continplanMapList.length>0)
                {
                  this.continPlanCmtsView=true;
              
                }else{
                   this.continPlanCmtsView=false;
                 }
              }
              else{
                this.continPlanCmtsView=false;
              }
             },error =>{
              this.continPlanCmtsView=false;
             });
      }
    
    }
    
    