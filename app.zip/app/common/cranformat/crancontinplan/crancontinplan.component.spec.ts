import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrancontinplanComponent } from './crancontinplan.component';

describe('CrancontinplanComponent', () => {
  let component: CrancontinplanComponent;
  let fixture: ComponentFixture<CrancontinplanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrancontinplanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrancontinplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
