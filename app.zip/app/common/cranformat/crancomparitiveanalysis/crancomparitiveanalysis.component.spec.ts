import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrancomparitiveanalysisComponent } from './crancomparitiveanalysis.component';

describe('CrancomparitiveanalysisComponent', () => {
  let component: CrancomparitiveanalysisComponent;
  let fixture: ComponentFixture<CrancomparitiveanalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrancomparitiveanalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrancomparitiveanalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
