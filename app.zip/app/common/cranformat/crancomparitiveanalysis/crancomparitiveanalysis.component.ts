import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';

@Component({
  selector: 'lp-crancomparitiveanalysis',
  templateUrl: './crancomparitiveanalysis.component.html',
  styleUrls: ['./crancomparitiveanalysis.component.css']
})
export class CrancomparitiveanalysisComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  WcdebtorList: any = [];
  finalWcAnalysisMapList: any = [];
  accView: boolean = true;
  @Input()
  cranTypeFromResolver :string;
  wcCmtsView: boolean = true;
  propDenom: any;
  comments: any;
  sales:any;
  purchasesvalue:any;
  stockvalue:any;
            deb90_180:any;
            deb180:any;
            totaldeb:any;
            deptadvan:any;
            creditors:any;
            drawpower:any;
            holdperiod:any;
            collperiod:any;
            payperiod:any;
            netwccycle:any;
  constructor(private cran: CranService) { }

  ngOnInit() {

    this.componentlist = [
      {
        name: 'CranwcanalysisComponent', cranType:this.cranTypeFromResolver
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.finalWcAnalysisMapList = this.data.responseData.finalWcAnalysisMapList;
          this.propDenom = this.data.propDenom;
          if (this.finalWcAnalysisMapList != undefined && this.finalWcAnalysisMapList.length > 0) {
            this.accView = true;
            this.finalWcAnalysisMapList.forEach(element1 => {
            if (element1.dataValueList!=undefined && element1.dataValueList.length > 0) {
              this.sales = 0;
              this.purchasesvalue = 0;
              this.stockvalue = 0;
              this.deb90_180 = 0;
              this.deb180 = 0;
              this.totaldeb = 0;
              this.deptadvan = 0;
              this.creditors = 0;
              this.drawpower=0;
              this.holdperiod=0;
              this.collperiod=0;
              this.payperiod=0;
              this.netwccycle=0;
              let totalindex=(element1.dataValueList.length-2);
              let avgindex=(element1.dataValueList.length-2)+1;
              for (let i = 0; i <element1.dataValueList.length-2; i++) {
                if(element1.dataValueList[i].lacaMonthOrder !=13 && element1.dataValueList[i].lacaMonthOrder !=14){
                if (element1.dataValueList[i].sales != null && element1.dataValueList[i].sales != '' && element1.dataValueList[i].sales != undefined && element1.dataValueList[i].sales != NaN)
                  this.sales += parseInt(element1.dataValueList[i].sales);
                if (element1.dataValueList[i].purchases != null && element1.dataValueList[i].purchases != '' && element1.dataValueList[i].purchases != undefined && element1.dataValueList[i].purchases != NaN)
                  this.purchasesvalue += parseInt(element1.dataValueList[i].purchases);
                if (element1.dataValueList[i].stock != null && element1.dataValueList[i].stock != '' && element1.dataValueList[i].stock != undefined && element1.dataValueList[i].stock != NaN)
                  this.stockvalue += parseInt(element1.dataValueList[i].stock);
                if (element1.dataValueList[i].deb90_180 != null && element1.dataValueList[i].deb90_180 != '' && element1.dataValueList[i].deb90_180 != undefined && element1.dataValueList[i].deb90_180 != NaN)
                  this.deb90_180 += parseInt(element1.dataValueList[i].deb90_180);
                if (element1.dataValueList[i].deb180 != null && element1.dataValueList[i].deb180 != '' && element1.dataValueList[i].deb180 != undefined && element1.dataValueList[i].deb180 != NaN)
                  this.deb180 += parseInt(element1.dataValueList[i].deb180);
                if (element1.dataValueList[i].totaldeb != null && element1.dataValueList[i].totaldeb != '' && element1.dataValueList[i].totaldeb != undefined && element1.dataValueList[i].totaldeb != NaN)
                  this.totaldeb += parseInt(element1.dataValueList[i].totaldeb);
                if (element1.dataValueList[i].deptadvan != null && element1.dataValueList[i].deptadvan != '' && element1.dataValueList[i].deptadvan != undefined && element1.dataValueList[i].deptadvan != NaN)
                  this.deptadvan += parseInt(element1.dataValueList[i].deptadvan);
                if (element1.dataValueList[i].creditors != null && element1.dataValueList[i].creditors != '' && element1.dataValueList[i].creditors != undefined && element1.dataValueList[i].creditors != NaN)
                  this.creditors += parseInt(element1.dataValueList[i].creditors);
        
                if (element1.dataValueList[i].drawpower != null && element1.dataValueList[i].drawpower != '' && element1.dataValueList[i].drawpower != undefined && element1.dataValueList[i].drawpower != NaN)
                  this.drawpower += parseInt(element1.dataValueList[i].drawpower);
                if (element1.dataValueList[i].holdperiod != null && element1.dataValueList[i].holdperiod != '' && element1.dataValueList[i].holdperiod != undefined && element1.dataValueList[i].holdperiod != NaN)
                  this.holdperiod += parseInt(element1.dataValueList[i].holdperiod);
                if (element1.dataValueList[i].collperiod != null && element1.dataValueList[i].collperiod != '' && element1.dataValueList[i].collperiod != undefined && element1.dataValueList[i].collperiod != NaN)
                  this.collperiod += parseInt(element1.dataValueList[i].collperiod);
                  if (element1.dataValueList[i].payperiod != null && element1.dataValueList[i].payperiod != '' && element1.dataValueList[i].payperiod != undefined && element1.dataValueList[i].payperiod != NaN)
                  this.payperiod += parseInt(element1.dataValueList[i].payperiod);
                  if (element1.dataValueList[i].netwccycle != null && element1.dataValueList[i].netwccycle != '' && element1.dataValueList[i].netwccycle != undefined && element1.dataValueList[i].netwccycle != NaN)
                  this.netwccycle += parseInt(element1.dataValueList[i].netwccycle);
                  
                  
                }
              }
              element1.dataValueList[totalindex].sales = parseInt(this.sales).toFixed(2);
    element1.dataValueList[totalindex].purchases = parseInt(this.purchasesvalue).toFixed(2);
    element1.dataValueList[totalindex].stock = parseInt(this.stockvalue).toFixed(2);
    element1.dataValueList[totalindex].deb90_180 = parseInt(this.deb90_180).toFixed(2);
    element1.dataValueList[totalindex].deb180 = parseInt(this.deb180).toFixed(2);
    element1.dataValueList[totalindex].totaldeb = parseInt(this.totaldeb).toFixed(2);
    element1.dataValueList[totalindex].deptadvan = parseInt(this.deptadvan).toFixed(2);
    element1.dataValueList[totalindex].creditors = parseInt(this.creditors).toFixed(2);
    element1.dataValueList[totalindex].drawpower = parseInt(this.drawpower).toFixed(2);
    element1.dataValueList[totalindex].holdperiod =parseInt(this.holdperiod);
    element1.dataValueList[totalindex].collperiod = parseInt(this.collperiod);
    element1.dataValueList[totalindex].payperiod =parseInt(this.payperiod);
    element1.dataValueList[totalindex].netwccycle = parseInt(this.netwccycle).toFixed(2);


    element1.dataValueList[avgindex].sales =(parseInt(this.sales)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].purchases =(parseInt(this.purchasesvalue)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].stock =(parseInt(this.stockvalue)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].deb90_180 =(parseInt(this.deb90_180)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].deb180 =(parseInt(this.deb180)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].totaldeb =(parseInt(this.totaldeb)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].deptadvan =(parseInt(this.deptadvan)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].creditors =(parseInt(this.creditors)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].drawpower =(parseInt(this.drawpower)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].holdperiod =(parseInt(this.holdperiod)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].collperiod =(parseInt(this.collperiod)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].payperiod =(parseInt(this.payperiod)/totalindex).toFixed(2);
    element1.dataValueList[avgindex].netwccycle =(parseInt(this.netwccycle)/totalindex).toFixed(2);
    element1.WcdebtorList=[];
    element1.dataValueList.forEach(element => {
      element1.WcdebtorList.push(
       {monthcounter:element.lpwcMonthCounter,monthValue: element.lpwcMonth,
       sales:this.parseEmptytoInt(element.sales),purchases:this.parseEmptytoInt(element.purchases),
       stock:this.parseEmptytoInt(element.stock),
       deb90_180:this.parseEmptytoInt(element.deb90_180),deb180:this.parseEmptytoInt(element.deb180),
       totaldeb:this.parseEmptytoInt(element.totaldeb),
       deptadvan: this.parseEmptytoInt(element.deptadvan),
       creditors:this.parseEmptytoInt(element.creditors),
       drawpower:this.parseEmptytoInt(element.drawpower),
    
        holdperiod: (element.holdperiod),
        collperiod: (element.collperiod),
        payperiod: (element.payperiod),
        netwccycle: (element.netwccycle),             
       });
    });
             
             
        
            }
          });
          }
          else {
            this.accView = false;
          }
        }
        else {
          this.accView = false;
          this.wcCmtsView = false;
        }
      },
      error => {
        this.accView = false;
        this.wcCmtsView = false;
      });
  }
  parseEmptytoInt(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return '';
    } else {
      return value1.toFixed(2);
    }
}
  

}
