import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanywiseconsolidateformatComponent } from './companywiseconsolidateformat.component';

describe('CompanywiseconsolidateformatComponent', () => {
  let component: CompanywiseconsolidateformatComponent;
  let fixture: ComponentFixture<CompanywiseconsolidateformatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanywiseconsolidateformatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanywiseconsolidateformatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
