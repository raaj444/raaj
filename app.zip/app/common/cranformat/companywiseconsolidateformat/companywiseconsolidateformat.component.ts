import { Component, OnInit ,Input} from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-companywiseconsolidateformat',
  templateUrl: './companywiseconsolidateformat.component.html',
  styleUrls: ['./companywiseconsolidateformat.component.css']
})
export class CompanywiseconsolidateformatComponent implements OnInit {
data:any; 
componentlist :any=[];
financialDetails: any = [];
finYrandTypeList:any=[];
yearSize :any=[];
finheadView:boolean=false;
finListView:boolean=true;
customerDetailAray = [];
allRowOfParentDataArry =[];
allRowOfParentDetailArry = [];
allRowOfDetailArry = [];
finTextDataArry = [];
dateValidateParentList=[];
ilterateArryofData = [];
allDataShow:boolean=false;
propDenom:string="A";
gblYearCount:any=[];
ilteratFinNameArry:any=[];
ilteratFinNameArryUnq:any=[];
ilteratArryofYear:any=[];
forLoopRunner:any=[];
ilterateArryofDetail:any=[];
propNum:any=[];
@Input()
  cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }
 
  ngOnInit() {
    this.finListView=false;
    this.allDataShow=false;
this.propDenom="A";
this.gblYearCount="-1";
this.propNum=null;
this.componentlist = [
      {
        name: 'companywiseconsolidateformatComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => {
         this.data=data;
         
        console.clear();
          this.customerDetailAray = [];
          this.allRowOfParentDataArry =[];
          this.allRowOfParentDetailArry = [];
          this.allRowOfDetailArry = [];
          this.finTextDataArry = [];
          this.dateValidateParentList=[];
          this.ilterateArryofData = [];
          this.ilteratFinNameArry=[];
          this.ilteratFinNameArryUnq=[];
          this.forLoopRunner=[];
          this.ilteratArryofYear=[];
          this.ilterateArryofDetail=[];
   if (this.data.success == true) {
          this.customerDetailAray = this.data.listOfLpcomCustInfo;
          this.allRowOfParentDataArry = this.data.allRowOfParentData;
          this.allRowOfParentDetailArry = this.data.allRowOfParentDetail;
          this.allRowOfDetailArry = this.data.allRowOfDetail;
          this.finTextDataArry = this.data.finmasterDataBypageId;
          this.dateValidateParentList=this.data.dateValidateParentList;
          console.clear();
          if (this.allRowOfParentDetailArry.length > 0 && this.allRowOfParentDataArry.length > 0) {
            this.allDataShow = false;
            this.propDenom = this.data.propDenom;
            this.gblYearCount= this.data.gblYearCount;
            if(this.gblYearCount>0){
            this.createModelandArryforDetailandData();
            }

          } else {
            this.allDataShow = false;
          }

        }
        else {
          if (this.data.success == false) {
          }
        }
      },
      error => {
        this.finListView=false;
      });
        
      }   
      parseEmptytoFloat(value: any) {
        let value1 = parseFloat(value);
        if (isNaN(value1)) {
          return 0;
        } else {
          return value1;
        }
      }
      createModelandArryforDetailandData() {

    var tempArray: any = [];
    var parentTempArray: any = [];
    let tempcma: any = [], tempdetail: any = [], tempData: any = [];
    let tempYearValue: any = [];
    let tempRowidOfdata: any = [];
    let yearCounter = 0;
    this.ilterateArryofData = [];
    let parentTempDetailArray = [];
     console.clear();
    parentTempDetailArray = [];
    for (var k = 0; k < this.allRowOfParentDetailArry.length; k++) {
      parentTempDetailArray = this.allRowOfParentDetailArry[k];
      parentTempArray = [];
      for (var i = 0; i < parentTempDetailArray.length; i++) {
        parentTempArray = this.allRowOfParentDataArry[k];
        tempData = [];
        for (var j = 0; j < parentTempArray.length; j++) {
          tempArray = [];
          tempArray = this.finTextDataArry.filter((finItem) => finItem.finRowid == parentTempArray[j].lfdFinRowId);
          if (tempArray.length > 0) {
            switch (parentTempDetailArray[i].lfdYearSeqNo) {
              case 1:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear1),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 2:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear2),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 3:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear3),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 4:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear4),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 5:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear5),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 6:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: parentTempArray[j].lfdYear6,
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 7:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear7),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 8:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear8),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 9:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear9),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 10:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear10),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 11:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear11),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 12:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear12),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 13:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear13),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 14:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear14),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 15:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear15),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 16:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear16),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 17:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear17),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 18:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear18),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 19:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear19),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 20:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear20),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 21:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear21),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 22:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear22),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 23:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear23),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 24:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear24),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 25:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear25),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 26:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear26),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 27:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear27),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 28:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear28),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 29:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear29),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;
              case 30:
                tempData.push({
                  lfdRowIdData: parentTempArray[j].lfdRowId, finRowId: parentTempArray[j].lfdFinRowId, lfdPropNo: parentTempArray[j].lfdPropNo,
                  y1: this.actualsToUnits(this.propDenom, parentTempArray[j].lfdYear30),
                  finRowdesc: tempArray[0].finRowdesc,
                  finRowtype: tempArray[0].finRowtype
                });
                break;

            }
            this.ilteratFinNameArry.push({ finRowdesc: tempArray[0].finRowdesc, finRowtype: tempArray[0].finRowtype });
          }
          //});

        }

        this.ilterateArryofData.push(tempData);
      }
    }// forLoop parentTempArrayDetail && allRowOfDetailArry ;
    //console.clear();
    //parentTempArray = this.allRowOfParentDataArry[0];
    //  for(var i=0;i<parentTempArray.length;i++){
    // tempArray=[];
    // tempArray = this.finTextDataArry.filter((finItem) => finItem.finRowid ==parentTempArray[i].lfdFinRowId);

    // this.ilteratFinNameArryUnq.push({ finRowdesc:tempArray[0].finRowdesc,finRowtype:tempArray[0].finRowtype });
    // }
    this.ilteratFinNameArryUnq = this.finTextDataArry;


    //

    let tempYearValueArray: any = [];

    // for(var i =0; i<tempData.length;i++){
    // tempYearValue=[];
    //      tempYearValue.push(tempData[i].y1);
    //      tempYearValueArray.push(tempYearValue);
    // }
    // this.ilteratArryofYear=[];
    // this.ilteratArryofYear=tempYearValueArray;

    tempArray = [];
    this.forLoopRunner = [];
    let strName = "";
    let tempParentDetail = [];
    let tempParentDetailConsolidate = [];
    parentTempDetailArray = [];
    for (var k = 0; k < this.allRowOfParentDetailArry.length; k++) {
      parentTempDetailArray = this.allRowOfParentDetailArry[k];
      for (var i = 0; i < parentTempDetailArray.length; i++) {
        tempArray = this.customerDetailAray.filter((custItem) => custItem.lciCustId == parentTempDetailArray[i].lfdCustNewId);
        if (tempArray != null && tempArray.length > 0) {
          strName = tempArray[0].lciCustName;
        } else {
          strName = "Name not Found";
        }

        tempdetail.push({
          lfdRowIdDetail: parentTempDetailArray[i].lfdRowId, lfdAuditType: this.checkedNull(parentTempDetailArray[i].lfdAuditType),
          lfdPropNo: parentTempDetailArray[i].lfdPropNo, lfdStartDate: this.formateDateByValue2(parentTempDetailArray[i].lfdStartDate),
          lfdEndDate: this.formateDateByValue2(parentTempDetailArray[i].lfdEndDate),
          lfdYearSeqNo: parentTempDetailArray[i].lfdYearSeqNo,
          customerName: strName
        });
        this.forLoopRunner.push("");
      }
      tempParentDetail.push(tempdetail);
    }// parentTempDetailArray
    //if(tempData.length>0){
    //this.ilterateArryofData=[];
    // /this.ilterateArryofData= tempData;
    //}
    tempData = [];
    this.ilteratArryofYear = this.ilterateArryofData;
    let sumOfyear: number;

    tempData = [];
    // let yearCount = parseInt($("#sel_yearCount").val());
    
    let yearCount = parseInt(this.gblYearCount.toString());
    let indexCounter = 0;
    let xCount: number = 0;
    tempParentDetailConsolidate = [];
    //for(var j=0;j<this.allRowOfParentDataArry[0].length;j++){
     // console.clear()
    
    if (this.finTextDataArry.length == this.ilteratArryofYear[0].length) {
      //if(true){
      // for(var j=0;j<this.finTextDataArry.length;j++){
      // yearCount=1 conditions
      
      
      if (yearCount == 1 || yearCount == 2 || yearCount == 3) {
        // for(var m=0;m<this.allRowOfParentDetailArry.length;m++){
        // parentTempDetailArray=this.allRowOfParentDetailArry[m];
        // for(var n=0;n<parentTempDetailArray.length;n++){
       let previousCounter=0;
          for (var j = 0; j < yearCount; j++) {
        indexCounter = 0
        ;
          // xCount=0;
          tempData = [];
          if (this.allRowOfParentDetailArry.length > 1) {
            xCount++;
          }
        
          for (var i = 0; i < this.finTextDataArry.length; i++) {
          // for(var k=0;k<parentTempDetailArray.length;k++){
        

            //for(var i=0;i<this.allRowOfDetailArry.length;i++){
            sumOfyear = 0;
            for (var x = 0; x < this.allRowOfParentDetailArry.length; x++) {
              //  for(var z=0;z<yearCount;z++){
              indexCounter = 0;
              if (xCount > 0) {
                if (x > 0) {
                  // indexCounter = x + yearCount - 1;
                  if (j == 0) {
                      if(yearCount==2){
                      if( x==1){ 
                      indexCounter =  x + yearCount - 1; 
                      }else{
                      indexCounter =  x + yearCount;
                      }                  
                      }
                      if(yearCount==3){
                      if( x>1){ 
                      indexCounter = previousCounter+yearCount; 
                      }else{
                        if(x!==0 && x!==1){
                      indexCounter =  previousCounter+yearCount;
                       }else{
                         indexCounter =  previousCounter+yearCount;
                       }
                      }                  
                      }
                    if(yearCount==1){
                      if( x>1){ 
                      indexCounter = previousCounter+yearCount; 
                      }else{
                        if(x!==0 && x!==1){
                      indexCounter =  previousCounter+yearCount;
                       }else{
                         indexCounter =  previousCounter+yearCount;
                       }
                      }                 
                      }

                }
                 if (j == 1) {
                                 
                  if(yearCount==2){
                      if( x>1){  indexCounter =  x + yearCount +1; 
                  }else{indexCounter =  x + yearCount;  }                
                 }
                 if(yearCount==1){
                      if( x>1){  indexCounter =  x + yearCount +1; 
                  }else{indexCounter =  x + yearCount;  }                
                 }
                 if(yearCount==3){
                     if( x>1){ 
                      indexCounter = previousCounter+yearCount; 
                      }else{
                        if(x!==0 && x!==1){
                      indexCounter =  previousCounter+yearCount;
                       }else{
                         indexCounter =  previousCounter+yearCount;
                       }
                      }              
                 }
                }
                  if (j == 2) {
                if(yearCount==1){ if( x==1){  indexCounter =  x + yearCount ; }else{indexCounter =  x + yearCount;  } } 
                  if(yearCount==2){ if( x==1){  indexCounter =  x + yearCount +1; }else{indexCounter =  x + yearCount;  } }
               if(yearCount==3){
                     if( x>1){ 
                      indexCounter = previousCounter+yearCount; 
                      }else{
                        if(x!==0 && x!==1){
                      indexCounter =  previousCounter+yearCount;
                       }else{
                         indexCounter =  previousCounter+yearCount;
                       }
                      }              
                 }
              }


                } else {
                  // indexCounter=x;
                  if (j == 0) {
                    indexCounter = x + j;
                  }
                  if (j == 1) {
                    indexCounter = j + x;
                  }
                  if (j == 2) {
                    indexCounter = j + x;
                  }

                }
                //  } 
              } else {
               if (j == 0) {
                    indexCounter = x + j;
                  }
                  if (j == 1) {
                    indexCounter = j + x;
                  }
                  if (j == 2) {
                    indexCounter = j + x;
                  }


                // }
              }
              previousCounter=indexCounter;
              // this.dateValidateParentList[j][xCount],this.allRowOfParentDetailArry[j][xCount].lfdCustNewId,this.checkedNullNum(this.ilteratArryofYear[indexCounter][i].y1));
              // if(this.dateValidateParentList[j][xCount]=="Y"){
              sumOfyear += this.checkedNullNum(this.ilteratArryofYear[indexCounter][i].y1);
              // }
            }
            if (sumOfyear == 0) {
              tempData.push({
                lfdRowIdData: 0, finRowId: 0, lfdPropNo: 0,
                y1: this.roundOfValueWithDefulatValue(sumOfyear),
                finRowdesc: "Total Consolidation",
                finRowtype: this.ilteratArryofYear[indexCounter][i].finRowtype
              });
            } else {
              tempData.push({
                lfdRowIdData: 0, finRowId: 0, lfdPropNo: 0,
                y1: this.roundOfValueWithDefulatValue(sumOfyear),
                finRowdesc: "Total Consolidation",
                finRowtype: this.ilteratArryofYear[indexCounter][i].finRowtype
              });
            }
          }
          tempParentDetailConsolidate.push(tempData);
          tempData = [];
          // for(var x=0;x<this.allRowOfParentDetailArry.length;x++){

          // }//parentTempDetailArray =>K loop 
        }
        
        
        //parentTempDetailArray =>n loop
        // } //allRowOfParentDetailArry
      }

      for (var j = 0; j < yearCount; j++) {
        this.ilteratFinNameArry.push({ finRowdesc: "Total Consolidation", finRowtype: "C" });
      }

    } else {
      tempData = [];
      //  this.ilterateArryofData=[];
      for (var j = 0; j < this.finTextDataArry.length; j++) {
        sumOfyear = 0;
        if (sumOfyear == 0) {
          tempData.push({
            lfdRowIdData: 0, finRowId: 0, lfdPropNo: 0,
            y1: this.roundOfValueWithDefulatValue(sumOfyear),
            finRowdesc: "Total Consolidation ",
            finRowtype: this.finTextDataArry[j].finRowtype
          });
        } else {
          tempData.push({
            lfdRowIdData: 0, finRowId: 0, lfdPropNo: 0,
            y1: this.roundOfValueWithDefulatValue(sumOfyear),
            finRowdesc: "Total Consolidation ",
            finRowtype: this.finTextDataArry[j].finRowtype
          });
        }

        this.ilteratFinNameArry.push({ finRowdesc: "Total Consolidation ", finRowtype: "C" });
      }
    }
    // this.ilterateArryofData.push(tempData);
    // this.ilterateArryofData.push(tempData);
    for (var index = 0; index < tempParentDetailConsolidate.length; index++) {
      this.ilterateArryofData.push(tempParentDetailConsolidate[index]);

    }
    //  tempdetail.push({
    //                 lfdRowIdDetail:0,lfdAuditType:"",
    //                 lfdPropNo:this.allRowOfDetailArry[0].lfdPropNo,lfdStartDate:"",
    //                 lfdEndDate:"",
    //                 lfdYearSeqNo:"",
    //                 customerName:"Total Consolidation"
    //                 });
    for (var j = 0; j < yearCount; j++) {
      //sumOfyear+=this.checkedNullNum(this.ilteratArryofYear[j][i].y1);
      tempdetail.push({
        lfdRowIdDetail: 0, lfdAuditType: "",
        lfdPropNo: this.allRowOfParentDetailArry[0][j].lfdPropNo, 
        lfdStartDate:this.formateDateByValue2(this.allRowOfParentDetailArry[0][j].lfdStartDate),
        lfdEndDate:this.formateDateByValue2(this.allRowOfParentDetailArry[0][j].lfdEndDate),
        lfdYearSeqNo: "",
        customerName: "Total Consolidation ",

      });
    }
    let tempIlterateArryofData = this.ilterateArryofData;

    let tempLen: number = 0
    tempData = [];
    let tempParentIlterateArryofData = [];
    for (var index = 0; index < tempIlterateArryofData.length; index++) {
      tempLen = tempIlterateArryofData[index].length;

      //tempIlterateArryofData[tempIlterateArryofData.length-1].length-1
      tempData = [];
      if (tempLen == 0) {
        for (var i = 0; i < this.ilteratFinNameArryUnq.length; i++) {
          tempData.push({
            lfdRowIdData: 0, finRowId: 0, lfdPropNo: this.propNum,
            y1: 0,
            finRowdesc: "",
            finRowtype: "H"
          });

        }
      } else {
        tempParentIlterateArryofData.push(tempIlterateArryofData[index]);
      }
      if (tempData.length > 0) {

        tempParentIlterateArryofData.push(tempData);
      }

    }

    this.ilterateArryofData = [];
    this.ilterateArryofData = tempParentIlterateArryofData;
    // for(var k=0;k<this.allRowOfParentDetailArry[0].length;k++){\
    for (var k = 0; k < yearCount; k++) {
      this.forLoopRunner.push("");
    }
    this.ilterateArryofDetail = [];
    this.ilterateArryofDetail = tempdetail;
    this.allDataShow = true;
    





  }

public actualsToUnits(propDenom: any, actualValue) {

    let value = "";

    if (propDenom == "L") {
      if (actualValue != null && !(actualValue === "")) {
        value = (parseFloat(actualValue) / 100000).toString();
      } else {
        value = "";
      }
    }

    else if (propDenom == "C") {
      if (actualValue != null && !(actualValue === "")) {
        value = (parseFloat(actualValue) / 10000000).toString()
      } else {
        value = "";
      }

    }

    else if (propDenom == "A") {

      if (actualValue != null && !(actualValue === "")) {
        value = parseFloat(actualValue).toString()
      } else {
        value = "";
      }
    }
    value = this.roundOfValue(value).toString();
    return value;
  }
   roundOfValue(value) {

    if (isNaN(parseFloat(value))) {
      value = "";

    } else {
      value = Math.floor(parseFloat(value) * 100) / 100;
    }
    return value;
  }
  checkedNull(value) {
    if (value == null) {
      value = "";
    }
    return value;
  }
formateDateByValue2(DateValue) {
    var todayDate = "";
    if (DateValue != "" && DateValue != null) {

      var today = new Date(DateValue);
      var dd = today.getDate().toString();
      var mm = (today.getMonth() + 1).toString(); //January is 0!

      var yyyy = today.getFullYear();
      if (parseInt(dd) < 10) {
        dd = '0' + dd;
      }
      if (parseInt(mm) < 10) {
        mm = '0' + mm;
      }
      todayDate = dd + '/' + mm + '/' + yyyy;

    } else {
      todayDate = "";
    }
    return todayDate;
  }
  roundOfValueWithDefulatValue(value) {

    if (isNaN(parseFloat(value))) {
      value = 0;

    } else {
      value = Math.floor(parseFloat(value) * 100) / 100;
    }
    return value;
  }  
checkedNullNum(value) {
    if (value == null || value == "") {
      value = 0.00;
    }
    return parseFloat(value);
  }

}

