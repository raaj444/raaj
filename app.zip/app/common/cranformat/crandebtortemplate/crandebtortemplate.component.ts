import { Component, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $ :any;

@Component({
  selector: 'lp-crandebtortemplate',
  templateUrl: './crandebtortemplate.component.html',
  styleUrls: ['./crandebtortemplate.component.css']
})
export class CrandebtortemplateComponent  implements OnInit {   data:any; 
  componentlist :any=[];
  WcdebtorList:any=[];
  churnAnalysis:any=[];
  bankingQuality:any=[];
  totallist:any=[];
  model:any={};
  dataValues:any=[];
  AccountList:any=[];
  propDenom:any;
  comments:any;
bankbehaviour="";
accountconduct="";
wcCmtsView:boolean=false;
accView:boolean=true;
bankingView:boolean=true;
churnList:boolean=true;
behaviourView:boolean=false;
accountconductView:boolean=true;

  constructor(private cran: CranService) { }

  ngOnInit() {
    this.comments="";
    this.accountconduct="";
    this.bankbehaviour="";
this.churnAnalysis=[];
this.bankingQuality=[];
    this.componentlist = [
      {
        name: 'CrandebtortemplateComponent'
      },
    ];

    this.cran.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
            this.dataValues=this.data.responseData.allWCAnalysisDataList;
            this.model=this.data.responseData;
            this.bankingQuality=this.data.responseData.bankingQuality;
            this.propDenom=this.data.propDenom;
            if(this.data.responseData.comments!=undefined && this.data.responseData.comments!="")
            {
              this.wcCmtsView=false;
            $("#wcCmts").html(this.data.responseData.comments);
            }else{
          this.wcCmtsView=true;
        }
            if(this.data.responseData.bankingBehaviour!=undefined && this.data.responseData.bankingBehaviour!="")
            {
              this.behaviourView=false;
              $("#bankbehaviour").html(this.data.responseData.bankingBehaviour);
            }else{
          this.behaviourView=true;
        }
            if( this.model.churnAnalysis!=undefined && this.model.churnAnalysis.length>0)
            {
              this.churnList=false;
            }
            if( this.model.bankingQuality!=undefined && this.model.bankingQuality.length>0)
             {
              this.bankingView=false;
            }
            if (this.dataValues!=undefined && this.dataValues.length > 0) {
              this.accView=false;
              this.dataValues.forEach(element => {
                this.WcdebtorList.push(
                 {monthcounter:this.checkNull(element.lpwcMonthCounter),monthValue: this.checkNull(element.lpwcMonth),
                 sales:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcSales)),purchases:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcPurchases)),
                 stock:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcStock)),
                 deb90_180:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcDebtForDp)),deb180:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcDbtAbv180d)),
                 totaldeb:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcTotalDtr)),creditors:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcCreditors)),
                   net_wc:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcNetWorkingCapital)),drawpower:this.actualsToUnits(this.propDenom,this.checkNull(element.lpwcDrawPower)),
                             
                 });
              });
           }
  }

});
  }
  checkNull(value){
    if(value==null){
    value="";
    }
    return value;
    }
    public   actualsToUnits(propDenom:any , actualValue) {
		
      let value="";
      
      if(propDenom=="L")
      {
      if(actualValue!=null && actualValue!=""){
        value = (parseFloat(actualValue)/100000).toString();
      }else{
      value="";
      }
      }
  
      else if(propDenom=="C")
      {
        if(actualValue!=null && actualValue!=""){
        value =  (parseFloat(actualValue)/10000000).toString()
      }else{
      value="";
      }
      
      }
  
      else if(propDenom=="A")
      {
        
        if(actualValue!=null && actualValue!=""){
        value =  parseFloat(actualValue).toString()
      }else{
      value="";
      }
      }
    value=	this.roundOfValue(value).toString();
      return  value ;
    }     
    roundOfValue(value){

      if(isNaN(parseFloat(value))){
      value="";
      
      }else{
      value=Math.floor (parseFloat(value) * 100)/100 ;
      }
      return value;
      }  
}
