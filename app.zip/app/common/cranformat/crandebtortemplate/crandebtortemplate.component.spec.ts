import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandebtortemplateComponent } from './crandebtortemplate.component';

describe('CrandebtortemplateComponent', () => {
  let component: CrandebtortemplateComponent;
  let fixture: ComponentFixture<CrandebtortemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandebtortemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandebtortemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
