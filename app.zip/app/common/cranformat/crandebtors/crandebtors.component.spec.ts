import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrandebtorsComponent } from './crandebtors.component';

describe('CrandebtorsComponent', () => {
  let component: CrandebtorsComponent;
  let fixture: ComponentFixture<CrandebtorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrandebtorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrandebtorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
