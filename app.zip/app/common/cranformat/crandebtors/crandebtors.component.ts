import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-crandebtors',
  templateUrl: './crandebtors.component.html',
  styleUrls: ['./crandebtors.component.css']
})
export class CrandebtorsComponent  implements OnInit {   data:any; 
  componentlist=[];
  debtorsdetailsList=[];
  debtorView:boolean=true;
  @Input()
  cranTypeFromResolver:string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.componentlist = [
      {
        name:'CrandebtorsComponent', cranType:this.cranTypeFromResolver
      },
    ];
    this.cranService.getDataForCranList(this.componentlist)
    
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
         this.debtorsdetailsList=this.data.responseData.debtorsdetailsList;
         if(this.debtorsdetailsList !=undefined && this.debtorsdetailsList.length>0 ){
           this.debtorView=true;
          // this.modelper = this.data.responseData.debtortotper;
          // this.modeltot = this.data.responseData.debtortot;
            this.debtorsdetailsList.forEach(element1 => {
              if(element1.debtorSaleList !=undefined && element1.debtorSaleList.length>0 ){
                element1.debtorSaleList.forEach(element => {
              element.lpds0to30Days = this.parseEmptytoInt(element.lpds0to30Days).toFixed(2);
              element.lpds30to90Days = this.parseEmptytoInt(element.lpds30to90Days).toFixed(2);
              element.lpds90to120Days = this.parseEmptytoInt(element.lpds90to120Days).toFixed(2);
              element.lpds90to180Days = this.parseEmptytoInt(element.lpds90to180Days).toFixed(2);
              element.lpds180aboveDays = this.parseEmptytoInt(element.lpds180aboveDays).toFixed(2);
              element.lpdsTotal = this.parseEmptytoInt(element.lpdsTotal).toFixed(2);
                });
              }
              element1.modeltot={'total':"Grand Total",'lpds0to30Days0' :0,'lpds30to90Days0': 0,'lpds90to120Days0':0,'lpds90to180Days0':0,'lpds180aboveDays0':0,'lpdsTotal0':0};
              element1.modelper={'average':"% TO TOTAL DEBTORS",'lpds0to30Days1' :0,'lpds30to90Days1': 0,'lpds90to120Days1':0,'lpds90to180Days1':0,'lpds180aboveDays1':0,'lpdsTotal1':0};
              element1.debtorSaleList.forEach(field => {
                element1.modeltot.lpds0to30Days0 += parseFloat(this.parseEmptytoInt(field.lpds0to30Days));

                element1.modeltot.lpds30to90Days0 += parseFloat(this.parseEmptytoInt(field.lpds30to90Days));

                element1.modeltot.lpds90to120Days0 += parseFloat(this.parseEmptytoInt(field.lpds90to120Days));

                element1.modeltot.lpds90to180Days0 += parseFloat(this.parseEmptytoInt(field.lpds90to180Days));

                element1.modeltot.lpds180aboveDays0 += parseFloat(this.parseEmptytoInt(field.lpds180aboveDays));

                element1.modeltot.lpdsTotal0 += parseFloat(this.parseEmptytoInt(field.lpdsTotal));


  });
  element1.modelper.lpds0to30Days1 = (element1.modeltot.lpds0to30Days0 / element1.modeltot.lpdsTotal0)*100;
  element1.modeltot.lpds0to30Days0 = element1.modeltot.lpds0to30Days0.toFixed(2);
  element1.modelper.lpds30to90Days1 = (element1.modeltot.lpds30to90Days0 / element1.modeltot.lpdsTotal0)*100;
  element1.modeltot.lpds30to90Days0 = element1.modeltot.lpds30to90Days0.toFixed(2);
  element1.modelper.lpds90to120Days1 = (element1.modeltot.lpds90to120Days0 / element1.modeltot.lpdsTotal0)*100;
  element1.modeltot.lpds90to120Days0 = element1.modeltot.lpds90to120Days0.toFixed(2);
  element1.modelper.lpds90to180Days1 = (element1.modeltot.lpds90to180Days0 / element1.modeltot.lpdsTotal0)*100;
  element1.modeltot.lpds90to180Days0 = element1.modeltot.lpds90to180Days0.toFixed(2);
  element1.modelper.lpds180aboveDays1 = (element1.modeltot.lpds180aboveDays0 / element1.modeltot.lpdsTotal0)*100;
  element1.modeltot.lpds180aboveDays0 = element1.modeltot.lpds180aboveDays0.toFixed(2);
  element1.modelper.lpdsTotal1 = (element1.modelper.lpds0to30Days1+element1.modelper.lpds30to90Days1+ 
  element1.modelper.lpds90to120Days1+element1.modelper.lpds90to180Days1+element1.modelper.lpds180aboveDays1).toFixed(2);
  element1.modeltot.lpdsTotal0 = element1.modeltot.lpdsTotal0.toFixed(2);
  element1.modelper.lpds0to30Days1=element1.modelper.lpds0to30Days1.toFixed(2);
  element1.modelper.lpds30to90Days1=element1.modelper.lpds30to90Days1.toFixed(2);
  element1.modelper.lpds90to120Days1=element1.modelper.lpds90to120Days1.toFixed(2);
  element1.modelper.lpds90to180Days1=element1.modelper.lpds90to180Days1.toFixed(2);
  element1.modelper.lpds180aboveDays1=element1.modelper.lpds180aboveDays1.toFixed(2);
            });
           
         }
         else{
          this.debtorView=false;
         }
          }
          else{
         this.debtorView=false;
          }
         },
       error => {
        this.debtorView=false;     
       });
 }
 calcTotalAndPercentage() {
 

}
 parseEmptytoInt(value: any) {
  if (value == null || value == "" || value == undefined || value == NaN) {
    return 0;
  }
  else {
    return value;
  }
}
}
