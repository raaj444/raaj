import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cranintrating1Component } from './cranintrating1.component';

describe('Cranintrating1Component', () => {
  let component: Cranintrating1Component;
  let fixture: ComponentFixture<Cranintrating1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cranintrating1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cranintrating1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
