import { Component,Input, OnInit } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranintrating1',
  templateUrl: './cranintrating1.component.html',
  styleUrls: ['./cranintrating1.component.css']
})
export class Cranintrating1Component  implements OnInit {   data:any; 
  crannonIndivView:boolean=false;
  cranIndivView:boolean=false;
   componentlist :any=[];
  internalRating :any=[];
  finalInternalRatingList:any=[];
  @Input()
  cranTypeFromResolver :string;
  businessRisk: any;
  financialRisk: any;
  managementRisk: any;
  industryRisk: any;
  constructor(private cranService: CranService) { }

  ngOnInit() {
   
 this.componentlist = [
      {
        name: 'Cranintrating1Component', cranType:this.cranTypeFromResolver
      }
     
    ];
    let cran={}
    this.cranService.getDataForCranList(this.componentlist)
    .subscribe(
       data => { this.data=data; 
          if (this.data.success == true) {
            this.businessRisk = this.data.responseData.businessListMap;
           this.financialRisk = this.data.responseData.financialListMap;
           this.managementRisk = this.data.responseData.managementListMap;
           this.industryRisk = this.data.responseData.industryListMap;
            if( this.cranTypeFromResolver=="I")
            {
              this.internalRating=this.data.responseData.lpcomIntRating;
              if( this.internalRating !=undefined &&  this.internalRating.length>0)
              {
                this.cranIndivView=true;
                this.crannonIndivView=false;
              }
              else{
                this.crannonIndivView=false;
                this.cranIndivView=false;
              }
            }
           else if( this.cranTypeFromResolver=="G")
            {
              this.finalInternalRatingList=this.data.responseData.finalInternalRatingList;
           if( this.finalInternalRatingList!=undefined && this.finalInternalRatingList.length>0){
            this.crannonIndivView=true;
              this.cranIndivView=false;
           }
           else{
            this.crannonIndivView=false;
            this.cranIndivView=false;
           }
            }
          }
          else{
            this.crannonIndivView=false;
            this.cranIndivView=false;
           }
         },
       error => {
        this.crannonIndivView=false;
        this.cranIndivView=false;
       }); 
    
  }

}
