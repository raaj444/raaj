import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cirannxtemplate',
  templateUrl: './cirannxtemplate.component.html',
  styleUrls: ['./cirannxtemplate.component.css']
})
export class CirannxtemplateComponent  implements OnInit {   data:any; 
  componentlist: any = [];
  constructor(private cranService: CranService) { }
  model: any = {};
  cirAnnxList: any =[];
  @Input()
  cranTypeFromResolver:string;
  cirAnnxHead:boolean=true;
  mascirAnnxList: any =[];
  ngOnInit() {
   
    this.componentlist = [
      {
        name: 'CirannxtemplateComponent', cranType:this.cranTypeFromResolver
      },
    ];

    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
         this.mascirAnnxList=this.data.responseData.mastCirAnnxList;
         this.cirAnnxList = this.data.responseData.cirAnnxList;
      if(this.mascirAnnxList!=undefined  && this.mascirAnnxList.length >0)
          {
            this.cirAnnxHead=true;
          }
      
        }
        else{
          this.cirAnnxHead=false;
        }
},
error => {
  this.cirAnnxHead=false;
});
 
    }
}
