import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CirannxtemplateComponent } from './cirannxtemplate.component';

describe('CirannxtemplateComponent', () => {
  let component: CirannxtemplateComponent;
  let fixture: ComponentFixture<CirannxtemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CirannxtemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CirannxtemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
