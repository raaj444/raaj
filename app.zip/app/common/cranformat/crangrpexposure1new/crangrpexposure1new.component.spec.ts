import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Crangrpexposure1newComponent } from './crangrpexposure1new.component';

describe('Crangrpexposure1newComponent', () => {
  let component: Crangrpexposure1newComponent;
  let fixture: ComponentFixture<Crangrpexposure1newComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Crangrpexposure1newComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Crangrpexposure1newComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
