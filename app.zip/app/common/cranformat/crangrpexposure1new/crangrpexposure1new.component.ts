import { Component, OnInit, Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $: any;
@Component({
  selector: 'lp-crangrpexposure1new',
  templateUrl: './crangrpexposure1new.component.html',
  styleUrls: ['./crangrpexposure1new.component.css']
})
export class Crangrpexposure1newComponent implements OnInit {
  data: any;
  componentlist: any = [];
  finalGrpExposureList: any = [];
  grpExpView: boolean = true;
  outstandingDate: any;
  constructor(private cranService: CranService) { }

  @Input()
  cranTypeFromResolver: string;
  ngOnInit() {
    this.componentlist = [
      {
        name: 'Crangrpexposure1newComponent', cranType: this.cranTypeFromResolver
      },
    ];
    this.finalGrpExposureList = [];
    this.cranService.getDataForCranList(this.componentlist)
      .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.outstandingDate = this.data.responseData.OsDate;
            this.finalGrpExposureList = this.data.responseData.finalGrpExposureList;
            this.finalGrpExposureList.forEach(element => {
              if (element.exposureList != undefined && element.exposureList.length > 0) {
                element.exposureList.forEach(element2 => {
                  element2.sancLimit = this.parseEmptytoFloat(element2.sancLimit).toFixed(2);
                  element2.OSLimit = this.parseEmptytoFloat(element2.OSLimit).toFixed(2);
                });
              }
            });
          }

        },
        error => {
          this.grpExpView = false;
        });
  }
  parseEmptytoFloat(value: any) {
    let value1 = parseFloat(value);
    if (isNaN(value1)) {
      return 0;
    } else {
      return value1;
    }
  }
}

