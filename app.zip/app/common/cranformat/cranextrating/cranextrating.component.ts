import { Component, OnInit,Input } from '@angular/core';
import { CranService } from '../../../util/service/commonservices/cran.service';
declare var $:any;
@Component({
  selector: 'lp-cranextrating',
  templateUrl: './cranextrating.component.html',
  styleUrls: ['./cranextrating.component.css']
})
export class CranextratingComponent  implements OnInit {   data:any; 
   componentlist :any=[];
  externalRatingList :any=[];
  finalExternalRatingList:any=[];
  ratingCmts:boolean=false;
extratingView:boolean=false;
crannonIndivView:boolean=false;
cranIndivView:boolean=false;
modelcmt:any={};
@Input()
cranTypeFromResolver :string;
  constructor(private cranService: CranService) { }

  ngOnInit() {
    this.modelcmt={ lerCmtKmblFac:"",lerCmtIntAgency:"",lerCmtExtAgency:""};
 this.componentlist = [
      {
        name: 'CranextratingComponent',cranType:this.cranTypeFromResolver
      }
    ];
  this.cranService.getDataForCranList(this.componentlist)
     .subscribe(
        data => { this.data=data; 
           if (this.data.success == true) {
             if(this.cranTypeFromResolver=='I'){
               this.cranIndivView=true;
              this.externalRatingList=this.data.responseData.externalRating;
              if( this.externalRatingList !=undefined &&  this.externalRatingList.length > 0)
              {
                this.extratingView=true;
                  this.modelcmt.lerCmtKmblFac =  this.externalRatingList[0].lerCmtKmblFac;
                  this.modelcmt.lerCmtIntAgency =  this.externalRatingList[0].lerCmtIntAgency;
                  this.modelcmt.lerCmtExtAgency =  this.externalRatingList[0].lerCmtExtAgency;
              }
              else{
                this.extratingView=false;
              }
            }
         else if(this.cranTypeFromResolver=='G'){
                this.crannonIndivView=true;
                this.finalExternalRatingList=this.data.responseData.finalExternalRatingList;
               if(this.finalExternalRatingList != undefined && this.finalExternalRatingList.length >0)
               {
           this.extratingView=true;
               }
               else{
                 this.extratingView=false;  
               }
              }
              if(this.data.responseData.comments!=undefined && this.data.responseData.comments!=""){
                this.ratingCmts=false;
                $("#ratingCmts").html(this.data.responseData.comments);
              }else{
            this.ratingCmts=true;
          }
            }
           else{
            this.extratingView=false;
           }
           
           
          },
        error => {
          this.extratingView=false;
          this.ratingCmts=true;
        }); 
  }

}
