import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CranextratingComponent } from './cranextrating.component';

describe('CranextratingComponent', () => {
  let component: CranextratingComponent;
  let fixture: ComponentFixture<CranextratingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CranextratingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CranextratingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
