import { Component, OnInit, ViewChild } from '@angular/core';
import { CasedetailrmService } from "../../util/service/commonservices/casedetailrm.service";
import { Router } from '@angular/router';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { debuglog } from 'util';
import { HomeComponent } from '../home/home.component';
import { Validator } from '../../util/helper/validator';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { ChangenoteComponent } from '../changenote/changenote.component';
import { ProposaldetailsComponent } from '../proposaldetails/proposaldetails.component';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'lp-casedetailsrm',
  templateUrl: './casedetailsrm.component.html',
  styleUrls: ['./casedetailsrm.component.css']
})
export class CasedetailsrmComponent extends Validator implements OnInit {
  data: any;
  refid: any;
  cropButton: boolean;
  hideManufacturer: boolean;
  hideDealerShipName: boolean;
  vertical: any;
  verticalType: any;
  BankingArrangement: any = [];
  TypeofCase: any = [];
  model: any = {};
  modelRef: any = {};
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  txt_Scheme_Id: boolean
  fieldDisable: boolean;
  placeholder: string;
  // fieldDisablecrop: boolean = false;
  flag: boolean;
  idvalueList: any = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate'];
  fieldValue: string;
  schemeTypeList: any = [];
  purposeOfLoanList: any = [];
  pageAccess: any;
  todayDate: any;
  d: any
  m: any
  modelForChngNote: any;
  sysDate: boolean
  dept: any
  auditList: any = []
  auditData: any = []
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  @ViewChild(ProposaldetailsComponent) propDet: ProposaldetailsComponent;
  maxDate: Date; minDate: Date; verifmaxDate: Date;
  @ViewChild(SearchComponent)
  Searchpop: SearchComponent
  constructor(private casedetailrmService: CasedetailrmService, private router: Router,
    private fieldvalidation: Fieldvalidation, private homeComponent: HomeComponent
    , private changenoteService: ChangenoteService) {
    super();
    this.maxDate = new Date();
    this.minDate = new Date(1899, 12, 1);
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());
    this.verifmaxDate = new Date();
    this.verifmaxDate.setDate(this.maxDate.getDate());

  }

  ngOnInit() {
    this.purposeOfLoanList = [];
    $("input[type=radio]").attr('disabled', true);
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.d = ""
    this.m = ""
    this.validators();
    this.cropButton = true;
    this.hideDealerShipName = true;
    this.hideManufacturer = true;
    // this.fieldDisablecrop = true;
    for (var i = 0; i < this.idvalueList.length; i++)
      $('#' + this.idvalueList[i]).removeClass("has-error");
    this.disableButton(true, true, false, true)
    this.txt_Scheme_Id = true
    this.model = { 'lpcdsCaseType': "s", 'lpcdsBankArgmt': "s", 'lsSchemeId': "s", 'lpcdsTakeover': "N", 'lpcdsFiStatus': "s", 'lpcdsBranchRef': "s", 'lpcdsLoanPurpose': "s" }
    this.modelRef = { 'lpcdsRBMName': '', 'lpcdsABMName': '', 'lpcdsZBMName': '', 'lpcdsCSOName': '' }
    loadingStatus()
    this.casedetailrmService.getSchemeName()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.purposeOfLoanList = this.data.purposeOfLoanList;
          this.schemeTypeList = this.data.schemeTypeList;
          this.TypeofCase = this.data.TypeofCase;
          this.BankingArrangement = this.data.BankingArrangement;
          this.pageAccess = this.data.pageAccess;
          this.verticalType = this.data.verticaltype;
          this.vertical = this.data.vertical;
          this.dept = this.data.Dept;
          if (this.dept == "S")
            this.sysDate = false
          else
            this.sysDate = true
          if (this.vertical == '4')
            this.hideDealerShipName = false;
          if (this.vertical == '3')
            this.hideManufacturer = false;
          if (this.pageAccess == "R")
            this.disableButton(true, true, true, true);
          if (this.verticalType == '7')
            this.cropButton = false;
        }
        if (this.modelForChngNote.changeMode == "Y") {
          this.changenoteComponent.onload(this.pageAccess);
        }
      },
      error => {
      });
    this.casedetailrmService.getCaseDetailrm1()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {

          this.model.lpcdsFiDoneBy = this.data.responseData.Fiuser;
          if (this.data.responseData.RbmCode != " ") {
            this.model.lpcdsRbmCode = this.data.responseData.RbmCode;
            this.modelRef.lpcdsRBMName = this.data.responseData.RBMName
          }
          if (this.data.responseData.ABMCode != " ") {
            this.model.lpcdsAbmCode = this.data.responseData.ABMCode;
            this.modelRef.lpcdsABMName = this.data.responseData.ABMName;
          }
          if (this.data.responseData.ZbmCode != " ") {
            this.model.lpcdsZbmCode = this.data.responseData.ZbmCode;
            this.modelRef.lpcdsZBMName = this.data.responseData.ZBMName;
          }
          // if(this.data.responseData.RbmCode != " " && this.data.responseData.ABMCode != " ")
          // this.fieldDisablecrop = true;
          // else
          // this.fieldDisablecrop = false;

        }
      });

    this.casedetailrmService.getCaseDetailrm()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          this.model = this.data.responseData.CaseDetailrm;
          this.model.lsSchemeId = this.data.responseData.lsSchemeId;
          this.txt_Scheme_Id = this.data.schemeId;
          if (this.data.responseData.abmname != " ")
            this.modelRef.lpcdsABMName = this.data.responseData.abmname;
          if (this.data.responseData.rbmname != " ")
            this.modelRef.lpcdsRBMName = this.data.responseData.rbmname;
          if (this.data.responseData.zbmname != " ")
            this.modelRef.lpcdsZBMName = this.data.responseData.zbmname;
          if (this.data.responseData.csoname != " ")
            this.modelRef.lpcdsCSOName = this.data.responseData.csoname;
        }
        else {
          this.editCasedetailsrm();
          this.txt_Scheme_Id = false
          var date = new Date();
          this.d = date.getDate();
          this.m = date.getMonth() + 1;
          if (parseInt(this.d) < 9)
            this.d = "0" + date.getDate();
          if (parseInt(this.m) < 9)
            this.m = "0" + (date.getMonth() + 1)
          this.todayDate = this.d + '/' + this.m + '/' + date.getFullYear();
          this.model.lpcdsRecvdDate = this.todayDate;
          this.model.lpcdsCaseType = this.data.type;
        }
      },
      error => {
      });


    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });
    hide();

    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    hide();
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onload(this.pageAccess);
    }
  }

  dosearch(id: any) {
    this.refid = id;
    if (this.verticalType == '7') {
      this.modelRef.pageid = "casedetailsrm";
      if (this.refid == 'lpcdsCsoCode') {
        this.modelRef.pageid = "csoSearch";
      }
      $('#name').text("User Name");
      $('#code').text("User Id");
      $('#header').text("User Search");
      $('#vertical').val(this.verticalType)
      $('#txt_pageid').val(this.modelRef.pageid);
      this.Searchpop.ngOnInit();
      $('#Search').modal('show');
    }
    else
      alert("Please select the Vertical")
  }
  modalClosed() {
    if ((document.getElementById("txt_Searchcode") as any).value && (document.getElementById("txt-Searchname") as any).value) {
      if (this.refid == 'lpcdsAbmCode') {
        this.model.lpcdsAbmCode = $('#txt_Searchcode').val();
        this.modelRef.lpcdsABMName = $('#txt-Searchname').val();
      }
      if (this.refid == 'lpcdsRbmCode') {
        this.model.lpcdsRbmCode = $('#txt_Searchcode').val();
        this.modelRef.lpcdsRBMName = $('#txt-Searchname').val();
      }
      if (this.refid == 'lpcdsZbmCode') {
        this.model.lpcdsZbmCode = $('#txt_Searchcode').val();
        this.modelRef.lpcdsZBMName = $('#txt-Searchname').val();
      }
      if (this.refid == 'lpcdsCsoCode') {
        this.model.lpcdsCsoCode = $('#txt_Searchcode').val();
        this.modelRef.lpcdsCSOName = $('#txt-Searchname').val();
      }
      if (this.refid == 'lpcdsFiDoneBy') {
        //  (document.getElementById("lpcdsFiDoneBy") as any).value=$('#txt-Searchname').val() + ' ' + '-' + ' ' + $('#txt_Searchcode').val();
        this.model.lpcdsFiDoneBy = $('#txt-Searchname').val() + ' ' + '-' + ' ' + $('#txt_Searchcode').val();
      }
    }
  }

  saveCasedetailsrm() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      // if (this.model.lpcdsCaseType != '1') {
      //   this.idvalueList = []
      //   if(this.verticalType=="7")
      //   this.idvalueList = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate','lpcdsAppFormNum'];
      //   else
      //   this.idvalueList = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate'];
      // }else {
      //   this.idvalueList = []
      //   this.idvalueList = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate'];
      // }

      if (this.verticalType == "7")
        this.idvalueList = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate', 'lpcdsAppFormNum', 'lpcdsCsoCode'];
      else
        this.idvalueList = ['lpstpScheme', 'lpcdsLoanPurpose', 'lpcdsCaseType', 'lpcdsBankArgmt', 'lpcdsRecvdDate'];


      this.flag = this.fieldvalidation.validateField(this.idvalueList)
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.flag) {
        this.changenoteComponent.onSave();
      }
      if (this.flag == true) {
        progressStatus()
        this.model.lpcdsRecvdDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdsRecvdDate);
        this.model.lpcdsFiVerifyDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdsFiVerifyDate);
        this.casedetailrmService.saveCaseDetailrm(this.model)
          .subscribe(
          data => {
            this.data = data;
            if (this.data.success == true) {
              this.ngOnInit();
              this.homeComponent.fromCaseDetail = true;
              this.homeComponent.ngOnInit();

              this.propDet.ngOnInit();
              this.disableButton(true, true, false, true)
              successStatus()
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
            }
            else
              failedStatus()
          },
          error => {
          });

      }
    }
  }
  cancelButton() {

    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;

  }

  editCasedetailsrm() {
    this.disableButton(false, false, true, false)
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
    $("input[type=radio]").attr('disabled', false);
  }
  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.savebuttonDisable = true;
      this.editbuttonDisable = true;
      this.cancelbuttonDisable = true;
    }
    else {
      this.fieldDisable = fieldDisable;
      this.savebuttonDisable = savebuttonDisable;
      this.editbuttonDisable = editbuttonDisable;
      this.cancelbuttonDisable = cancelbuttonDisable;
    }
  }

  // validateDate(val) {
  //   if (val != '' && val != null) {
  //     let date = val.split("/");
  //     return date[2] + "-" + date[1] + "-" + date[0];
  //   }
  // }
  // validatedate(eventId) {
  //   this.fieldvalidation.validatedate(eventId);
  // }
  // validatefuturedate(eventId) {
  //   this.fieldvalidation.validatefuturedate(eventId);
  // }

  checkManualEntry(event) {
    sessionStorage.setItem("editMode", "Y");
    if (event != "" && event != null) {
      let blFlag = this.fieldvalidation.validatedate(event.target.id);
      if (blFlag) {
        this.fieldvalidation.validatefuturedate(event.target.id);
      }
    }
  }
  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }


  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }
    else {
      if (this.futureDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).attr("placeholder", "Future date not allowed here");
      }
    }

  }

  auditTrial() {
    $('#auditTrialcaserm').modal('show');
    this.getAuditData()
  }
  close() {
    $('#auditTrialcaserm').modal('hide');
  }

  getAuditData() {
    this.casedetailrmService.getAuditData()
      .subscribe(
      data => {
        this.data = data;
        this.auditList = [];
        this.auditData = [];
        this.auditList = this.data.caseRmList;
        this.auditData = this.data.auditData;
        this.auditData.forEach(element => {
          element.AuditData = JSON.parse(element.AuditData)
        });
        var oldId;
        var color, oldColor;
        this.auditData.forEach((element, index) => {
          var sesId = element.sessionId
          if (index == 0) {
            color = 'Blue'
            this.auditData.forEach((element1, index) => {
              if (element1.sessionId == sesId) {
                element1.color = color;
                oldId = sesId
                oldColor = color
              }
            })
          }
          if (oldColor == 'Blue' && index != 0)
            color = 'Grey'
          else
            color = 'Blue'
          if (sesId != oldId && index != 0) {
            this.auditData.forEach((element, index) => {
              if (element.sessionId == sesId) {
                element.color = color;
                oldId = sesId
                oldColor = color
              }
            })
            color = 'Grey'
          }
        })
      },
      error => {
      });
  }


}



