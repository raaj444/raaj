import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CasedetailsrmComponent } from './casedetailsrm.component';

describe('CasedetailsrmComponent', () => {
  let component: CasedetailsrmComponent;
  let fixture: ComponentFixture<CasedetailsrmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CasedetailsrmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CasedetailsrmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
