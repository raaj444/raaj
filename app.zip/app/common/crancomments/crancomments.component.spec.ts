import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrancommentsComponent } from './crancomments.component';

describe('CrancommentsComponent', () => {
  let component: CrancommentsComponent;
  let fixture: ComponentFixture<CrancommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrancommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrancommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
