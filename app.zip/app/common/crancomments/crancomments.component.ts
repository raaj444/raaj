import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Validator } from "../../util/helper/validator";
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { HomeService } from "../../util/service/commonservices/home.service";
import { CrancommentsService } from "../../util/service/commonservices/crancomments.service";
declare var $: any;
declare var callEditorbyId: any;



@Component({
  selector: 'lp-crancomments',
  templateUrl: './crancomments.component.html',
  styleUrls: ['./crancomments.component.css']
})
export class CrancommentsComponent  implements OnInit {   data:any; 
  pageAccess: any;
  editbuttonDisable: boolean;
  savebuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  fieldDisable: boolean;
  private cranHeaderArray: Array<any> = [];
  private cranCommentArray: Array<any> = [];
  model: any = {};
  constructor(private crancommentsService: CrancommentsService,
    private router: Router, private fieldvalidation: Fieldvalidation, private homeService: HomeService) { }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });

    this.fieldDisable = true;
    callEditorbyId('txtEditor_crancomment');
    $("#txtEditor_crancomment").Editor("setEnable", false);
    this.model.crancommentsData = { lpaiCmtHeading: "", lpaiComments: "", lpaiCmtFor: "CP", lpaiRowId: "", lpaiCreatedBy: "", lpaiCreatedOn: "", lpaiCmtId: "" };
    this.getCrancomments();
  }

  getCrancomments() {
    this.model.cranHeaderArray = [];
    this.model.cranCommentArray = [];
    this.disableButton(true, true, true);
    $("#txtEditor_crancomment").Editor("setText", " ");
    this.crancommentsService.getCrancomments()
      .subscribe(
        data => { this.data=data;

          if (this.data.success) {
            this.pageAccess = this.data.pageAccess;
            if (this.pageAccess == "R") {
              this.disableButton(true, true, true);
              $("#txtEditor_crancomment").Editor("setEnable", false);
            }
            this.model.cranHeaderArray = this.data.responseData.StQualitativeList;
            this.model.cranCommentArray = this.data.responseData.lpcomPropAddInfolist;
            this.model.cranHeaderArray.forEach(element => {
              element.color = "white";
            });
          }
          error => {
            // this.alertService.error(error);

          }
        });
  }

  getCommentsValue(field, i) {
    this.disableButton(false, true, true);
    $("#txtEditor_crancomment").Editor("setEnable", false);
    this.model.cranHeaderArray.forEach(element => {
      element.color = "white";
    });
    this.model.crancommentsData = [];
    this.model.cranHeaderArray[i].color = "Pink";
    this.model.cranCommentArray.forEach(elementAll => {
      if (field.sqmRowId == elementAll.lpaiCmtId) {
        this.model.crancommentsData = elementAll;
        $("#txtEditor_crancomment").Editor("setText", this.model.crancommentsData.lpaiComments);
      }
    });
    if (this.model.crancommentsData.length == 0) {
      this.model.crancommentsData = { lpaiCmtHeading: field.sqmCommentHeader, lpaiComments: "", lpaiCmtFor: "CP", lpaiRowId: "", lpaiCreatedBy: "", lpaiCreatedOn: "", lpaiCmtId: field.sqmRowId };
      $("#txtEditor_crancomment").Editor("setText", "");
    }
  }
  editComments() {
    this.disableButton(true, false, false);
    $("#txtEditor_crancomment").Editor("setEnable", true);

  }
  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.getCrancomments();
    }
    else {
      return false;
    }
  }


  saveCrancomments() {
    this.model.crancommentsData.lpaiComments = $("#txtEditor_crancomment").Editor("getText");
    if (this.model.crancommentsData.lpaiCmtHeading != "" && this.model.crancommentsData.lpaiComments != "") {
      this.crancommentsService.saveCrancomments(this.model.crancommentsData)
        .subscribe(
          data => { this.data=data;
            if (this.data.success) {
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');

              $("#txtEditor_crancomment").Editor("setText", " ");
              $("#txtEditor_crancomment").Editor("setEnable", false);

              this.getCrancomments();
            }
       
          },
          error => {
            // this.alertService.error(error);
          });
    }
    else {
      if (this.model.crancommentsData.lpaiCmtHeading == "")
        alert("Header should not be empty");
      else if (this.model.crancommentsData.lpaiComments == "")
        alert("Comments should not be empty");
    }
  }


  disableButton(edit: boolean, save: boolean, cancel: boolean) {

    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.editbuttonDisable = true;
      this.savebuttonDisable = true;
      this.cancelbuttonDisable = true;
    }
    else {
      this.editbuttonDisable = edit;
      this.savebuttonDisable = save;
      this.cancelbuttonDisable = cancel;
    }
  }
}
