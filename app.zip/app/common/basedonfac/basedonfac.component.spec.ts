import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasedonfacComponent } from './basedonfac.component';

describe('BasedonfacComponent', () => {
  let component: BasedonfacComponent;
  let fixture: ComponentFixture<BasedonfacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasedonfacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasedonfacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
