import { Component, OnInit } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { BasedonfacService } from '../../util/service/commonservices/basedonfac.service';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any

@Component({
  selector: 'lp-basedonfac',
  templateUrl: './basedonfac.component.html',
  styleUrls: ['./basedonfac.component.css']
})
export class BasedonfacComponent extends Validator  implements OnInit {   data:any; 

  model: any = {};
  editDisabled: boolean = true;
  saveDisabled: boolean = true;
  cancelDisabled: boolean = false;
  deleteDisabled: boolean = true;
  facilitylist: any = [];
  assessmentlist: any = [];
  getvalues: any = [];
  listHeader: any = [];
  disableFields: boolean = true;
  disabledropdown: boolean = false;
  disabletxt: boolean = true;

  validation: boolean;
  ControllList: any = ['sel_lfaFacNo', 'sel_lfaAssessmntId'];
  pageAccess: any;
  type: any;
  uniqueBorrowerList:any=[]
  constructor(private facilityassessment: BasedonfacService, private fieldvalidation: Fieldvalidation) { super(); }

  ngOnInit() {
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });

    this.validators();
    this.resetAllFileds();
    this.facilitylist = [];
    this.assessmentlist = [];
    loadingStatus()
    this.facilityassessment.getCustlist().subscribe(
      data => { this.data=data;
        this.pageAccess = this.data.pageAccess;
        this.uniqueBorrowerList = this.data.uniqueBorrowerList;
        if( this.uniqueBorrowerList.length==1)
        {
        this.model.lfaCustId=this.uniqueBorrowerList[0][0]
        this.getFacility()
        }
      },
      error => {
      });

    this.disableButton(false, true, true, false);
    this.resetAllFileds();
    hide()
  }
  disableButton(edit: boolean, save: boolean, btndelete: boolean, cancel: boolean) {
    if (this.pageAccess == "R") {
      this.editDisabled = true;
      this.saveDisabled = true;
      this.deleteDisabled = true;
      this.cancelDisabled = true;
    }
    else {
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.deleteDisabled = btndelete;
      this.cancelDisabled = cancel;
    }
  }
  doedit() {
    this.disableButton(true, false, false, false);
    this.disableFields = false;
    this.disabletxt = false;
  }
  dosave() {
    this.validation = this.fieldvalidation.validateField(this.ControllList);
    if (this.validation == true) {
      progressStatus()
      this.facilityassessment.savefacilityassessment(this.model).subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            sessionStorage.setItem("editMode", "N");
            $('input,select,textarea').removeClass('ng-dirty');

            successStatus()
            this.disabletxt = true;
            this.model.listHeader = [];

            this.facilityassessment.getoveralllist(this.model).subscribe(
              data => { this.data=data;
                this.model.listHeader = this.data.responseData.listHeader;
                if (this.model.listHeader.length < 1) {
                  this.facilityassessment.getHeadeList(this.model).subscribe(
                    data => { this.data=data;
                      this.model.listHeader = this.data.responseData.listHeader;
                    });
                }
              });
            this.disableButton(false, true, true, false);
            this.disabletxt = true;
          }

          else {
            failedStatus()
          }
        }
        ,
        error => {
        });
      this.disableButton(false, true, true, false);
      //  this.resetAllFileds();
    }
  }
  dodelete() {
    if (confirm("Do you want to delete?")) {
      this.model.RowId = this.model.lymRowId;
      this.facilityassessment.deletefacilityassessment(this.model)
        .subscribe(
          data => { this.data=data;
          },
          error => {
          });
      this.disableButton(false, true, true, false);
      this.resetAllFileds();
    }
  }
  docancel() {
    if (confirm("Do you want to cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      this.disableFields = true;
      this.disableButton(false, true, true, false);
      this.resetAllFileds();
    } else {
      return false;
    }
  }

  getAssessment() {
    loadingStatus()
    this.assessmentlist = [];
    var index = $('#sel_lfaFacNo option:selected').val();
    this.facilitylist.forEach(element => {
      if (element.lsfFacId == this.model.lfaFacNo)
        this.model.prd_id = element.lfProdId;
    });

    if (this.model.finid != '') {
      this.facilityassessment.getAssessmentList(this.model).subscribe(
        data => { this.data=data;
          this.assessmentlist = this.data.responseData.assessmentlist;
          this.type = this.data.type;
          if(this.uniqueBorrowerList.length===1)
        this.model.lfaAssessmntId=this.assessmentlist[0].lpaAssmntId
        this.getHeader(this.model.lfaAssessmntId)
        });
    }
    else {
      alert("Choose The Facility Name");
    }
    hide()
  }
  getHeader(value) {
    loadingStatus()
    this.disabletxt = true;
    this.model.listHeader = [];

    this.facilityassessment.getoveralllist(this.model).subscribe(
      data => { this.data=data;
        this.model.listHeader = this.data.responseData.listHeader;
        if (this.model.listHeader.length < 1) {
          this.facilityassessment.getHeadeList(this.model).subscribe(
            data => { this.data=data;
              this.model.listHeader = this.data.responseData.listHeader;
            });
        }
      });

    this.disableButton(false, true, true, false);
    hide()
  }
  resetAllFileds() {
    this.model.lfaCustId = 's';
    this.model.lfaFacNo = 's';
    this.model.lfaAssessmntId = 's';
    this.model.listHeader = [];
    this.assessmentlist = [];
  }


getFacility(){
  if(this.model.lfaCustId=="s")
  this.resetAllFileds()
  this.model.lfaFacNo = 's';
    this.model.lfaAssessmntId = 's';
  this.facilitylist=[]
  this.assessmentlist=[]
  this.model.listHeader = [];
  this.facilityassessment.getfacilitylist(this.model).subscribe(
    data => { this.data=data;
      this.facilitylist = this.data.responseData.facilitylist;
      if(this.uniqueBorrowerList.length===1){
        this.model.lfaFacNo=this.facilitylist[0].lsfFacId
        this.getAssessment()
      }
      this.pageAccess = this.data.pageAccess;
    },
    error => {
    });
  }
}

