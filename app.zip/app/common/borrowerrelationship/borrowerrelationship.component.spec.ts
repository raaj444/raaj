import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BorrowerrelationshipComponent } from './borrowerrelationship.component';

describe('BorrowerrelationshipComponent', () => {
  let component: BorrowerrelationshipComponent;
  let fixture: ComponentFixture<BorrowerrelationshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BorrowerrelationshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BorrowerrelationshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
