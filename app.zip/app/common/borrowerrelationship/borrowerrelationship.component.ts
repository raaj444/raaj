import { Component, OnInit, ViewChild } from '@angular/core';
import { BorrowerrelationshipService } from "../../util/service/commonservices/borrowerrelationship.service";
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
declare var $: any;
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { ChangenoteComponent } from '../changenote/changenote.component';

@Component({
  selector: 'lp-borrowerrelationship',
  templateUrl: './borrowerrelationship.component.html',
  styleUrls: ['./borrowerrelationship.component.css']
})
export class BorrowerrelationshipComponent  implements OnInit {   data:any; 
  pageAccess: string;
  nonIndList: any = [];
  propNo: any;
  custInfoList: any = [];
  masterList: any = [];
  relationList: any = [];
  saveDisabled: boolean;
  cancelDisabled: boolean;
  editDisabled: boolean;
  fieldDisable: boolean;
  model: any = {};
  nIndPartyDisable: boolean;
  partyList: any = [];
  IndList: any = [];
  NIndList: any = [];
  relTypeList: any = [];
  relationShipList: any = [];
  modelForChngNote: any;
  valFlag: boolean;

  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;

  constructor(private borrowerrelationshipService: BorrowerrelationshipService, private fieldvalidation: Fieldvalidation, private changenoteService: ChangenoteService) { }

  ngOnInit() {
    this.NIndList = [];
    this.IndList = [];
    this.model.partyList = [];
    this.relTypeList = [];
    this.custInfoList = [];
    this.nonIndList = [];
    this.relationShipList = [];
    this.nIndPartyDisable = false;
    this.modelForChngNote = "";
    this.model.lprCustId = "s";
    loadingStatus()
    this.borrowerrelationshipService.getPropNo()
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.propNo = this.data.responseData[0];
            this.pageAccess = this.data.pageAccess;
            if (this.pageAccess == "R")
              this.disableButton(true, true, true, true);

            this.NIndList = [];
            this.IndList = [];
            this.borrowerrelationshipService.getPartyList()
              .subscribe(
                data => { this.data=data;
                  if (this.data.success == true) {
                    this.NIndList = this.data.responseData.listOfNInd;
                    this.IndList = this.data.responseData.listOfInd;
                    if(this.NIndList.length===1){
                      this.model.lprCustId=this.NIndList[0].lciCustId
                      this.NIndPartiesChange(this.model.lprCustId)
                    }
                  }
                },
                error => {
                });

          }
        },
        error => {
        });



    this.borrowerrelationshipService.getMasterList()
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.masterList = this.data.responseData.IndmasterList;
            this.relationList = this.data.responseData.NIndmasterList;
          }
        },
        error => {
        });
    hide()
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onload(this.pageAccess);
    }
    this.disableButton(true, true, true, true);

    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
  }

  edit() {
    this.nIndPartyDisable = true;
    this.disableButton(false, true, false, false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }

  savePage() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
      this.relTypeList = [];
      this.custInfoList = [];

      this.model.partyList.forEach(element => {
        this.relTypeList.push({
          lprEmployeeStrength: element.lprEmployeeStrength, lprBusinessCycle: element.lprBusinessCycle, lprGeographicalPresence: element.lprGeographicalPresence, lprLineBusiness: element.lprLineBusiness, lprRelType: element.lprRelType, lprRowId: element.lprRowId,
          lprCreatedBy: element.lprCreatedBy, lprCreatedOn: element.lprCreatedOn, lprModifiedBy: element.lprModifiedBy,lprDinNo:element.lprDinNo,
          lprModifiedOn: element.lprModifiedOn
        });
      });

      this.model.partyList.forEach(element => {
        this.custInfoList.push({ lciCustId: element.lciCustId, lciCustName: element.lciCustName, lciCustType: element.lciCustType });
      });


      this.valFlag = true;
      this.model.partyList.forEach((element, index) => {
        $('#parties' + index).removeClass("has-error");
      });

      this.model.partyList.forEach((element, index) => {
        if (((element.lprLineBusiness != null && element.lprLineBusiness != "") || (element.lprGeographicalPresence != null && element.lprGeographicalPresence != "") || (element.lprBusinessCycle != null && element.lprBusinessCycle != "") || (element.lprEmployeeStrength != null && element.lprEmployeeStrength != "")) && element.lprRelType == 's') {
          $('#parties' + index).addClass("has-error");
          this.valFlag = false;
        }
      });

      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.valFlag) {
        this.changenoteComponent.onSave();
      }
      if (this.valFlag) {
        this.borrowerrelationshipService.saveBorrowerRelationship({ custInfoList: this.custInfoList, relTypeList: this.relTypeList }, this.model.lprCustId)
          .subscribe(
            data => { this.data=data;
              progressStatus()
              if (this.data.success == true) {

                this.relTypeList = [];
                this.custInfoList = [];
                this.model.partyList = [];

                this.data.responseData.custInfoList.forEach((element, index) => {
                  this.model.partyList.push({
                    lciCustId: element.lciCustId, lciCustName: element.lciCustName,
                    lciCustType: element.lciCustType, lprCreatedBy: this.data.responseData.partyRelationList[index].lprCreatedBy,
                    lprCreatedOn: this.data.responseData.partyRelationList[index].lprCreatedOn,
                    lprModifiedBy: this.data.responseData.partyRelationList[index].lprModifiedBy,
                    lprModifiedOn: this.data.responseData.partyRelationList[index].lprModifiedOn,
                    lprRelType: this.data.responseData.partyRelationList[index].lprRelType,
                    lprEmployeeStrength: this.data.responseData.partyRelationList[index].lprEmployeeStrength,
                    lprBusinessCycle: this.data.responseData.partyRelationList[index].lprBusinessCycle,
                    lprGeographicalPresence: this.data.responseData.partyRelationList[index].lprGeographicalPresence,
                    lprLineBusiness: this.data.responseData.partyRelationList[index].lprLineBusiness,
                    lprRowId: this.data.responseData.partyRelationList[index].lprRowId,
                    lprDinNo:this.data.responseData.partyRelationList[index].lprDinNo
                  });
                });
                successStatus()

                sessionStorage.setItem("editMode", "N");
                $('input,select,textarea').removeClass('ng-dirty');
              }
              else
                failedStatus()
            },
            error => {
            });
        this.disableButton(true, false, true, true);
        this.nIndPartyDisable = false;
      }

    }
  }


  cancelButton() {
    if (confirm("Do you want to cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
    }
    this.ngOnInit();
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.ngOnInit();
    }
    else
      return false;
  }

  NIndPartiesChange(oldId: any) {
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific="Y";
    this.modelForChngNote.lcmCustId=oldId;
    this.disableButton(true, false, true, true);

    if (oldId != 's') {
      this.model.partyList = [];

      this.IndList.forEach(element => {
        this.model.partyList.push({ lciCustId: element.lciCustId, lciCustName: element.lciCustName, lciCustType: element.lciCustType, lprRelType: 's' });
      });

      this.NIndList.forEach(element => {
        if (element.lciCustId != oldId)
          this.model.partyList.push({ lciCustId: element.lciCustId, lciCustName: element.lciCustName, lciCustType: element.lciCustType, lprRelType: 's' });
      });

      this.borrowerrelationshipService.getSavedDetails(oldId)
        .subscribe(
          data => { this.data=data;
            if (this.data.success == true) {
              if (this.data.responseData.partyRelationList.length != 0) {
                this.relationShipList = this.data.responseData.partyRelationList;

                this.model.lprCustId = oldId;
                this.relationShipList.forEach(rel => {
                  this.model.partyList.forEach(party => {
                    if (rel.lprRelCustId == party.lciCustId) {
                      party.lprRelType = rel.lprRelType;
                      party.lprRowId = rel.lprRowId;
                      party.lprCreatedBy = rel.lprCreatedBy;
                      party.lprCreatedOn = rel.lprCreatedOn;
                      party.lprEmployeeStrength = rel.lprEmployeeStrength;
                      party.lprBusinessCycle = rel.lprBusinessCycle;
                      party.lprGeographicalPresence = rel.lprGeographicalPresence;
                      party.lprLineBusiness = rel.lprLineBusiness;
                      party.lprDinNo = rel.lprDinNo;
                    }
                  });
                });
              }
            }
          },
          error => {
          });
    }
    else if (oldId == 's')
    {
      this.NIndList = [];
      this.IndList = [];
      this.model.partyList = [];
      this.relTypeList = [];
      this.custInfoList = [];
      this.nonIndList = [];
      this.relationShipList = [];
      this.nIndPartyDisable = false;
      this.modelForChngNote = "";
      this.model.lprCustId = "s";
      loadingStatus()
      this.borrowerrelationshipService.getPropNo()
        .subscribe(
          data => { this.data=data;
            if (this.data.success == true) {
              this.propNo = this.data.responseData[0];
              this.pageAccess = this.data.pageAccess;
              if (this.pageAccess == "R")
                this.disableButton(true, true, true, true);
  
              this.NIndList = [];
              this.IndList = [];
              this.borrowerrelationshipService.getPartyList()
                .subscribe(
                  data => { this.data=data;
                    if (this.data.success == true) {
                      this.NIndList = this.data.responseData.listOfNInd;
                      this.IndList = this.data.responseData.listOfInd;
                    }
                  },
                  error => {
                  });
  
            }
          },
          error => {
          });
  
  
  
      this.borrowerrelationshipService.getMasterList()
        .subscribe(
          data => { this.data=data;
            if (this.data.success == true) {
              this.masterList = this.data.responseData.IndmasterList;
              this.relationList = this.data.responseData.NIndmasterList;
            }
          },
          error => {
          });
      hide()
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onload(this.pageAccess);
      }
      this.disableButton(true, true, true, true);
  
      $(document).ready(function () {
        $("form").change(function () {
          sessionStorage.setItem("editMode", "Y");
        });
      });
    }
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.ngOnInit();
    }
  }


  disableButton(field: boolean, edit: boolean, save: boolean, cancel: boolean) {

    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.editDisabled = true;
      this.saveDisabled = true;
      this.cancelDisabled = true;
    }
    else {
      this.fieldDisable = field;
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.cancelDisabled = cancel;
    }
  }
}

