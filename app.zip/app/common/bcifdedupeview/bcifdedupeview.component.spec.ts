import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BcifdedupeviewComponent } from './bcifdedupeview.component';

describe('BcifdedupeviewComponent', () => {
  let component: BcifdedupeviewComponent;
  let fixture: ComponentFixture<BcifdedupeviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BcifdedupeviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BcifdedupeviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
