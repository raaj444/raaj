import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { Validator } from "../../util/helper/validator";
import { NgForm } from '@angular/forms';
import { BcifdedupeviewService } from '../../util/service/commonservices/bcifdedupeview.service';
import { IndividualappdetService } from '../../util/service/corporateservices/individualappdet.service';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";

declare var $: any;
@Component({
  selector: 'lp-bcifdedupeview',
  templateUrl: './bcifdedupeview.component.html',
  styleUrls: ['./bcifdedupeview.component.css']
})
export class BcifdedupeviewComponent extends Validator implements OnInit {
    data: any;
  Pancheck: string;
  PanChk: boolean;
  @Output() childEvent: EventEmitter<any> = new EventEmitter();

  panstatus: string;
  PanCustName: string;
  panCheckSymbol: string;
  panChkFlag: boolean = false;
  model: any = {};
  listOfValues: any = [];
  save: boolean = false;
  dedupeResult: boolean = true;
  dedupeCRN: boolean = true;
  dedupeDetails: boolean = false;
  titleDisable: boolean;
  interfaceData: any;
  crnErr: boolean;
  DBsearch: any;
  disableCustType: boolean = false;
  dedupList: any = [];
  indivList = ['indivFirst', 'indivLast', 'indivPanNo', 'indivBcifTitle', 'indivDob'];
  nonIndivList = ['business', 'nonIndivBcifTitle', 'nonIndivPanNo', 'nonIndivItType', 'regdate'];
  kleadlist: any = []; maxDate: Date; minDate: Date;
  indivDobFlg: boolean = false; bizVertical: any;
  reasonlist: any = [];
  constructor(private BcifdedupeviewService: BcifdedupeviewService, private individualappdetService: IndividualappdetService,
    private fieldvalidation: Fieldvalidation) {
    super();
    this.maxDate = new Date();
    this.minDate = new Date(1900, 12, 1);
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());

  }

  ngOnInit() {

    $('input,select,textarea').removeClass('ng-dirty');
    for (var i = 0; i < this.indivList.length; i++) {
      var id = '#' + this.indivList[i];
      $(id).removeClass("has-error");
    }
    for (var i = 0; i < this.nonIndivList.length; i++) {
      var id = '#' + this.nonIndivList[i];
      $(id).removeClass("has-error");
    }

    this.model = { name: "I", BcifTitle: "", FirstName: "", LastName: "", business: "", BcifNo: "", itType: "", Shortname: "", lciContPersonName: "", phoneno: "", crn: "", addr1: "", addr2: "", add3: "", pincode: "", state: "", city: "", statename: "", cityname: "", panno: "", panstatus: '', PanCustName: '', statusflg: '' };

    this.model.panno = "";
    this.model.PanCustName = "";
    this.model.PanStatus = "";
    this.Pancheck = "";
    this.model.override = "";
    $('#dedupenewid').val("");
    this.disableCustType = false;
    $('#progressbar').hide();
    this.dedupeResult = true;
    this.dedupeCRN = true;
    this.dedupeDetails = false;
    this.crnErr = false;
    this.reasonlist = [];
    this.BcifdedupeviewService.getMasterData()
      .subscribe(
      data => {
      this.data = data;
        if (this.data.success) {
          this.listOfValues = this.data.responseData;
          this.bizVertical = this.data.bizVertical;
          this.reasonlist = this.data.reasonList;
          if (this.model.name == "C") {
            this.model.BcifTitle = "4";
          }
        }
      },
    );
    //klead id include by dhanam
    this.BcifdedupeviewService.getKleadinfo()
      .subscribe(
      data => {
      this.data = data;
        this.kleadlist = JSON.parse(JSON.stringify(this.data.responseData));


        if (this.kleadlist.length < 1) { this.model = { name: "I", BcifTitle: "", FirstName: "", LastName: "", business: "", BcifNo: "", itType: "", Shortname: "", lciContPersonName: "", phoneno: "", crn: "", addr1: "", addr2: "", add3: "", pincode: "", state: "", city: "", statename: "", cityname: "", panno: "", panstatus: '', PanCustName: '', statusflg: '' }; }
        else {
          this.model = JSON.parse(JSON.stringify(this.kleadlist[0]));
          this.model.BcifTitle = "";
          this.model.itType = "";
          this.model.Shortname = "";

        }
      });
    this.model.override = "";
  }
  callClose() {
    this.individualappdetService.setDataForNewParty(this.model);
    this.model = {};
    this.model.panno = "";
    this.model.PanCustName = "";
    this.model.PanStatus = "";
    this.Pancheck = "";
    $('#BcifDedupeView').modal('hide');
    this.dedupList = [];
    this.model.dedupeInfoList = [];
    $('#dedupetype').val('new');
    this.ngOnInit();

  }

  bcifdedupcheck() {

    this.model.fetchid = "";
    this.model.checkcrn = "N";
    this.model.checklos = "N";
    this.model.losid = "";
    $('#dedupenewid').val("");
    this.disableCustType = true;
    var flag = true;
    var count = 0;

    if (this.model.name == "I") {
      if (this.bizVertical == "7") {
        this.indivList = ['indivFirst', 'indivLast','indivBcifTitle', 'indivDob', 'indivMaiden'];

      }

      for (var i = 0; i < this.indivList.length; i++) {
        var id = '#' + this.indivList[i];
        if ($(id).val() == "") {
          $(id).addClass("has-error");
          flag = false;
        }
      }
    }

    else if (this.model.name == "C") {

      if (this.bizVertical == "7") {
        this.nonIndivList = ['business', 'nonIndivBcifTitle','nonIndivItType', 'regdate'];
      }

      for (var i = 0; i < this.nonIndivList.length; i++) {
        var id = '#' + this.nonIndivList[i];
        if ($(id).val() == "") {
          $(id).addClass("has-error");
          flag = false;
        }
      }

    }
    if (flag) {

    if (!(this.bizVertical=='7' && (this.model.PanNo==""|| this.model.PanNo==null || this.model.PanNo==undefined)) || (this.model.statusflg == 'Y' || this.model.statusflg == "NA")) {

      this.model.regdate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.regdate);
      this.model.Dob = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.Dob);
      this.BcifdedupeviewService.saveBcifDedupeViewDet(this.model)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success) {
            this.dedupList = [];

            this.dedupeResult = false;
            this.dedupeDetails = true;
            this.dedupList = this.data.responseData.dedupeListNew;
            this.DBsearch = this.data.DBsearch;
            this.model.bcifrowid=this.data.Rowidhistory;
            $('#bcifrowid').val(this.data.Rowidhistory)
            this.model.SourceAppCode = this.data.responseData.SourceAppCode;
            this.dedupeResult = false;
            this.dedupeCRN = false;
            this.model.dedupeInfoList = [];
            this.model.dedupeInfoList = this.data.responseData.dedupeInfoList;
            if (this.model.dedupeInfoList.length == 0) {
              this.crnErr = false;
            }
            this.model.override = "";

            // if (this.DBsearch == "dedupeResult") {
            //   this.dedupeResult = false;
            //   this.dedupeCRN = true;
            // }
            // else if (this.DBsearch == "dedupeCRN") { 

            //   this.dedupList = [];
            //   this.dedupeResult = true;
            //   this.dedupeCRN = false;
            //   this.model.dedupeInfoList = [];
            //   this.model.dedupeInfoList = this.data.responseData.dedupeInfoList;

            //   this.crnErr = false;
            // }
            // else  if(this.DBsearch=="BCIFfetch")
            // {
            //   this.dedupList=[];
            //   this.model.BcifNo=this.data.responseData.BcifNo;
            //   this.model.dedupeInfoList = this.data.responseData.dedupeInfoList;
            //   this.BcifdedupeviewService.FetchExistingCustdet(this.model)
            //   .subscribe(
            //     data => { this.data=data;
            //       if (this.data.success) {
            //         this.dedupeResult = false;
            //         this.interfaceData=this.data.responseData;
            //         this.individualappdetService.setDataFromInterface(this.interfaceData);
            //         // this.callCustomerDetails();
            //         $('#dedupetype').val('CRN');
            //         $('#BcifDedupeView').modal('hide');
            //         this.dedupList=[];
            //         this.dedupeResult = true;
            //         this.crnErr=false;
            //       }
            //       else
            //      {
            //       this.crnErr=true;
            //       this.dedupeResult = false;
            //      }

            //     },
            //     error => {
            //       this.crnErr=true;
            //       this.dedupeResult = false;
            //     }
            //     );
            // }
            var bcifNAstatus = this.data.responseData.fetchNAstatus;
            var ErrDesc = this.data.responseData.strErrDesc;
            if (this.DBsearch == "dedupeCRN" && bcifNAstatus == "NA") {
              alert("Interface Not Available");
            }
            else if (bcifNAstatus == "F") {
              alert(ErrDesc);
            }
          }
          else {
            this.DBsearch = this.data.DBsearch;
            var bcifNAstatus = this.data.responseData.fetchNAstatus;
            var ErrDesc = this.data.responseData.strErrDesc;
            if (this.DBsearch == "dedupeCRN" && bcifNAstatus == "NA") {
              alert("Interface Not Available");
            }
            else if (bcifNAstatus == "F") {
              alert(ErrDesc);
            }
          }
        },
        error => {
          alert("BCIF Dedupe Failed.");
          this.dedupeResult = false;
          this.dedupList = [];
          this.model.dedupeInfoList = [];
          this.model.bcifrowid=0;
        }
        );
     }
      else
        alert("Invalid PAN");
    }
  }

  getCustomerData(newid: any,type) {
    if(type=='Y')
    {
      if (this.model.override == "" || this.model.override == "s" || this.model.override == undefined) {
        alert("Please select the Overriding Reason");
        return;
      }
      $('#reason').val(this.model.override);
    }
    this.disableCustType = false;
    $('#BcifDedupeView').modal('hide');
    this.individualappdetService.setDataForNewParty(this.model);
    this.dedupList = [];
    $('#dedupetype').val('Dedupe');
    $('#dedupenewid').val(newid);
    this.model = { name: "I", BcifTitle: "", FirstName: "", LastName: "", business: "", itType: "", Shortname: "", lciContPersonName: "", phoneno: "", crn: "", addr1: "", addr2: "", add3: "", pincode: "", state: "", city: "", statename: "", cityname: "", panno: "", panstatus: '', PanCustName: '', statusflg: '' };
    this.dedupeResult = true;
    this.dedupeDetails = false;
    if (this.model.name == "C") {
      this.model.BcifTitle = "4";
    }
  }
  FetchBcifCustomerdet(BcifNo: any, type: any) {
    if (BcifNo == "") {
      alert("Enter the CRN No");
    }
    else {
      if(type != 'F')
      {
        // if (this.model.override == "" || this.model.override == "s" || this.model.override == undefined) {
        //   alert("Please select the Overriding Reason");
        //   return;
        // }
      }
      this.model.BcifNo = BcifNo;

      this.BcifdedupeviewService.FetchExistingCustdet(this.model)
        // this.model.id="10000171";
        // this.individualappdetService.getcustomerDataForDedupe(this.model.id)
        .subscribe(
        data => {
        this.data = data;
          if (this.data.success) {
            if(type == 'F')
            {
              this.Pancheck = "";
             this. dedupList=[];
             this.model.dedupeInfoList=[];
            this.model.FirstName = "";
                  this.model.MiddleName = "";
                  this.model.LastName = "";
                  this.model.Shortname = "";
                  this.model.MaidenName = "";
                  this.model.MobileNumer = "";
                  this.model.BcifTitle = "";
                  this.model.EmailId = "";
                  this.model.Dob = "";
                  this.model.DlNo = "";
                  this.model.PanNo = "";
                  this.model.PanCustName = "";
                  this.model.PassportNo = "";
                  this.model.AadharNo ="";
                  this.model.VoterId = "";
				        this.model.PCRN = "";
				         this.model.business= "";
                  this.model.regdate ="";
                  this.model.CinNo = "";
            }
            this.interfaceData = this.data.responseData;
            this.individualappdetService.setDataFromInterface(this.interfaceData);
           
            if(type != 'F')
            {
            this.model.bcifrowid=this.data.Rowidhistory;
            $('#bcifrowid').val(this.data.Rowidhistory);
            // this.callCustomerDetails();
            $('#dedupetype').val('CRN');
            $('#reason').val(this.model.override);
            
            $('#BcifDedupeView').modal('hide');
            }
            else{
              this. dedupList=[];
              this.model.dedupeInfoList=[];
              var custtype =this.interfaceData.CustType;
              if (custtype == "I") {
                if(this.interfaceData.LpcomCustDataInd!=null|| this.interfaceData.LpcomCustDataInd!=undefined)
                {
                var partydata= this.interfaceData.LpcomCustDataInd;
                var Dob=this.interfaceData.DOB;
                this.model.name="I";
                if (partydata.lciFirstName != "" && partydata.lciFirstName != null) {
                  this.model.FirstName = partydata.lciFirstName;
                 }
                 else{
                  this.model.FirstName = "";
                 }
                if (partydata.lciMiddleName != "" && partydata.lciMiddleName != null) {
                  this.model.MiddleName = partydata.lciMiddleName;
                 }
                 else
                 {
                  this.model.MiddleName ="";
                 }
                if (partydata.lciLastName != "" && partydata.lciLastName!=null) {
                  this.model.LastName = partydata.lciLastName;
                 }
                 else{
                  this.model.LastName ="";
                 }
                if (partydata.lciShortName != "" && partydata.lciShortName !=null) {
                  this.model.Shortname = partydata.lciShortName;
                }
                if (partydata.lciShortName == "" && partydata.lciShortName ==null) {
                  this.model.Shortname = partydata.lciFirstName;
                }
                if (partydata.lciMotherName != "" && partydata.lciMotherName != null ) {
                  this.model.MaidenName = partydata.lciMotherName;
                }
                else{
                  this.model.MaidenName ="";
                }
                if (partydata.lciCpMobNo != "" && partydata.lciCpMobNo != null)
                {
                  this.model.MobileNumer = partydata.lciCpMobNo;
                }
                else{
                  this.model.MobileNumer ="";
                }
                if (partydata.lciTitle != "" && partydata.lciTitle != null) {
                  this.model.BcifTitle = partydata.lciTitle;
                }
                else{
                  this.model.BcifTitle ="";
                }
                if (partydata.lciCpEmail != "" && partydata.lciCpEmail !=null) {
                  this.model.EmailId = partydata.lciCpEmail;
                }
                else
                {
                  this.model.EmailId = "";
                }
                if (partydata.lciDob != "" && partydata.lciDob !=null) {
                  this.model.Dob =Dob;
                }
                else{
                  this.model.Dob ="";
                }
                if (partydata.lciDlNo != "")
                  this.model.DlNo = partydata.lciDlNo;
        
                if (partydata.lciPanNo != "" && partydata.lciPanNo != null) {
                  this.model.PanNo = partydata.lciPanNo;
                  if(this.interfaceData.LpcomCustInfoObj!=null||this.interfaceData.LpcomCustInfoObj!=undefined)
                  {
                    var custobj=this.interfaceData.LpcomCustInfoObj;
                   
                  this.model.PanCustName = custobj.lciNsdlCustname;
                  }
                }
                else{
                  this.model.PanNo="";
                  this.model.PanCustName="";

                }
        
                if (partydata.lciPassportNo != "" && partydata.lciPassportNo !=null) {
                  this.model.PassportNo = partydata.lciPassportNo;
                }
                else{
                  this.model.PassportNo ="";
                }
                if (partydata.lciAadharId != "" && partydata.lciAadharId != null) {
                  this.model.AadharNo = partydata.lciAadharId;
                }
                else
                {
                  this.model.AadharNo ="";
                }
                if (partydata.lciVoterId != "" && partydata.lciVoterId != null) {
                  this.model.VoterId = partydata.lciVoterId;
                }
                else
                {
                  this.model.VoterId ="";
                }
                   if(this.interfaceData.LpcomCustInfoObj!=null||this.interfaceData.LpcomCustInfoObj!=undefined)
                  {
                    var custobj=this.interfaceData.LpcomCustInfoObj;
                    this.model.PCRN = custobj.lciPsblBcifNo;
                  }
                  else{
                    this.model.PCRN ="";
                  }
                 
                
              }
              }
              else if(custtype == "N")
              {
                if(this.interfaceData.LpcomCustDataNind!=null|| this.interfaceData.LpcomCustDataNind!=undefined)
                {
                var partydata= this.interfaceData.LpcomCustDataNind;
                var regdate=this.interfaceData.RegDate;
                this.model.name='C';
                this.model.BcifTitle = "4";
                if (partydata.lcnBussName != "" || partydata.lcnBussName != null) {
                  this.model.business= partydata.lcnBussName;
                }
                else{
                  this.model.business="";
                }
        
                if (partydata.lcnShortName != "" && partydata.lcnShortName !=null) {
                  this.model.Shortname = partydata.lcnShortName;
                }
                else{
                  this.model.Shortname ="";
                }
                if (partydata.lcnShortName == "" && partydata.lcnShortName !=null) {
                  this.model.Shortname = partydata.lcnBussName;
                }
                else{
                  this.model.Shortname ="";
                }
                if (partydata.lcnCpMobNo != "" && partydata.lcnCpMobNo !=null) {
                  this.model.MobileNumer = partydata.lcnCpMobNo;
                }
                else{
                  this.model.MobileNumer ="";
                }
                if (partydata.lcnCpEmail != "" && partydata.lcnCpEmail != null) {
                  this.model.EmailId = partydata.lcnCpEmail;
                }
                else{
                  this.model.EmailId ="";
                }
                if (regdate != "" && regdate != null) {

                  this.model.regdate =regdate;
                }
                if (partydata.lcnPanNo != "" && partydata.lcnPanNo !=null) {
                  this.model.PanNo = partydata.lcnPanNo;
                  if(this.interfaceData.LpcomCustInfoObj!=null||this.interfaceData.LpcomCustInfoObj!=undefined)
                  {
                    var custobj=this.interfaceData.LpcomCustInfoObj;
                   
                  this.model.PanCustName = custobj.lciNsdlCustname;
                  }
        
                }
                else{
                  this.model.PanCustName ="";
                }
                if (partydata.lcnCinNo != "" && partydata.lcnCinNo !=null)
                {
                  this.model.CinNo = partydata.lcnCinNo;
                }
                else{
                  this.model.CinNo ="";
                }
              
                  if(this.interfaceData.LpcomCustInfoObj!=null||this.interfaceData.LpcomCustInfoObj!=undefined)
                  {
                    var custobj=this.interfaceData.LpcomCustInfoObj;
                    this.model.PCRN = custobj.lciPsblBcifNo;
                  }
                  else
                  {
                    this.model.PCRN ="";
                  }
                
              }
              }

              
            }
            this.crnErr = false;
          }
          else {
            if(type == 'F')
            {
              this.Pancheck = "";
              this. dedupList=[];
              this.model.dedupeInfoList=[];
            this.model.FirstName = "";
                  this.model.MiddleName = "";
                  this.model.LastName = "";
                  this.model.Shortname = "";
                  this.model.MaidenName = "";
                  this.model.MobileNumer = "";
                  this.model.BcifTitle = "";
                  this.model.EmailId = "";
                  this.model.Dob = "";
                  this.model.DlNo = "";
                  this.model.PanNo = "";
                  this.model.PanCustName = "";
                  this.model.PassportNo = "";
                  this.model.AadharNo ="";
                  this.model.VoterId = "";
				        this.model.PCRN = "";
				         this.model.business= "";
                  this.model.regdate ="";
                  this.model.CinNo = "";
            }
            var fetchstatus = this.data.responseData.strfetchresponse;
            var ErrDesc = this.data.responseData.strErrDesc;
            if (fetchstatus == "NA") {
              alert("Interface Not Available");
            }
            else if (fetchstatus == "F") {
              alert(ErrDesc);
            }
            else
              this.crnErr = true;
          }

        },
        error => {
          this.crnErr = true;
          if(type == 'F')
            {
              this.Pancheck = "";
              this. dedupList=[];
              this.model.dedupeInfoList=[];
            this.model.FirstName = "";
                  this.model.MiddleName = "";
                  this.model.LastName = "";
                  this.model.Shortname = "";
                  this.model.MaidenName = "";
                  this.model.MobileNumer = "";
                  this.model.BcifTitle = "";
                  this.model.EmailId = "";
                  this.model.Dob = "";
                  this.model.DlNo = "";
                  this.model.PanNo = "";
                  this.model.PanCustName = "";
                  this.model.PassportNo = "";
                  this.model.AadharNo ="";
                  this.model.VoterId = "";
				        this.model.PCRN = "";
				         this.model.business= "";
                  this.model.regdate ="";
                  this.model.CinNo = "";
            }
        }
        );
    }
    $('#progressbar').hide();
  }
  // callCustomerDetails()
  // {   
  //   this.childEvent.emit();
  // }
  newParty(type) {
    if (type == 'Y') {
      if (this.model.override == "" || this.model.override == "s" || this.model.override == undefined) {
        alert("Please select the Overriding Reason");
        return;
      }
    }
    this.disableCustType = false;
    this.individualappdetService.setDataForNewParty(this.model);
    $('#reason').val(this.model.override);
    $('#dedupetype').val('newParty');
    $('#BcifDedupeView').modal('hide');
    this.dedupList = [];
    this.model = { name: "I", BcifTitle: "", FirstName: "", LastName: "", business: "", Shortname: "", lciContPersonName: "", phoneno: "", crn: "", addr1: "", addr2: "", add3: "", pincode: "", state: "", city: "", statename: "", cityname: "", panno: "", panstatus: '', PanCustName: '', statusflg: '' };
    this.dedupeResult = true;
    this.dedupeDetails = false;
    if (this.model.name == "C") {
      this.model.BcifTitle = "4";
    }
  }

  validatefuturedate(event) {
    this.fieldvalidation.isValidDOB(event.target.id);
  }

  setTitle() {

    this.model.panno = "";
    this.model.PanCustName = "";
    this.model.PanStatus = "";
    this.Pancheck = "";

    if (this.model.name == "C")
      this.model.BcifTitle = "4";
    else
      this.model.BcifTitle = "";
  }

  futRestrict(e: any) {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.futureDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).attr("placeholder", "Future date not allowed here");
      }
    }
  }

  rmvErrClass(id: string, value) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
    if (id == "indivDob" && value != undefined && value != "") {
      this.indivDobFlg = this.fieldvalidation.isValidDOBFrmDP(id, value);
    }
  }

  onInputChanged(event) {
    if (!this.indivDobFlg) {
      this.model.Dob = "";
      $("#indivDob").val(" ");
    }

  }
  getShortName(e: any, label: any) {

    if (label == 'I') {
      if (this.model.FirstName != "" && this.model.FirstName != undefined) {

        $('#indivShort').val(this.model.FirstName);
        this.model.Shortname = JSON.parse(JSON.stringify(this.model.FirstName));
      }
    }
    else if (label == 'N') {
      if (this.model.business != "" && this.model.business != undefined) {
        $('#nonIndivShort').val(this.model.business);
        this.model.Shortname = JSON.parse(JSON.stringify(this.model.business));
      }
    }
  }

  PANValidator(id, value) {

    if (value == "" || value == undefined) {
      $('#' + id).addClass("has-error");
      $('#' + id).attr("placeholder", "Enter valid PAN Number");
    }
    else {
      var panVal = value;
      this.model.panno = $("#" + id).val().toUpperCase();
      this.panCheck();
    }
  }

  panCheck() {
    var statusflg = "";
    this.individualappdetService.PanVerificationRequest(this.model).subscribe(
      data => {
      this.data = data;
        if (this.data.success == true) {

          this.model.panstatus = this.data.responseData.PanStatus;
          this.model.statusflg = this.data.responseData.statusflg;
          this.model.PanCustName = this.data.responseData.PanCustName;

          if (this.model.statusflg == 'Y') {
            this.Pancheck = "fa fa-check-circle text-green f20";
          }
          else if (this.model.statusflg == "N") {
            alert("Invalid PAN");
            this.Pancheck = "fa fa-times-circle text-red f20";
          }

        }
        else {
          this.model.statusflg = this.data.responseData.statusflg;
          if (this.model.statusflg == "NA") {
            alert("No Interface Available");
          }
        }
      }
      ,
      error => {
      });

  }

  checkPANUpdation() {
    this.model.statusflg = 'N';
    this.Pancheck = "";
    this.model.PanCustName = "";
    this.dedupeResult = true;
  }

  docheck(val,index,type)
  {
    if(type=='L')
    {
    if(val=='N' || val==undefined || val==null || val=="")
    {
  this.dedupList[index].chklosra='Y';
  this.model.checklos='Y'
  this.model.losid=index;
    }
    else
    {
      this.dedupList[index].chklosra='N';
      this.model.checklos='N'
      this.model.losid="";
    }
  }
  else{
    if(val=='N' || val==undefined || val==null || val=="")
    {
      this.model.dedupeInfoList[index].checkcrn_r='Y';
      this.model.checkcrn='Y'
      this.model.fetchid=index;
       this.model.override="";
    }
    else
    {
      this.model.dedupeInfoList[index].checkcrn_r='N';
      this.model.checkcrn='N'
      this.model.fetchid="";
    }
  }
  }

}


