import { Component, OnInit } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { ChangenotechecklistService } from '../../util/service/commonservices/changenotechecklist.service';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any

@Component({
  selector: 'lp-changenotechecklist',
  templateUrl: './changenotechecklist.component.html',
  styleUrls: ['./changenotechecklist.component.css']
})
export class ChangenotechecklistComponent extends Validator implements OnInit {
  uniqueBorrowerList: any=[];
  data: any;
model: any = {};
editDisabled: boolean = false;
saveDisabled: boolean = true;
cancelDisabled: boolean = true;
disableFields: boolean = true;
validation: boolean;
ControllList: any = ['txt_lccPropTerms','txt_lccCreditView'];
borrowerList:any=[];
pageAccess: any;
  constructor(private chgchkservice:ChangenotechecklistService, private fieldvalidation: Fieldvalidation) 
  { super(); }

  ngOnInit() {
    this.model.chgchklist=[];
    this.chgchkservice.getborrowerList().subscribe(
      data => {
      this.data = data;
      this.pageAccess = this.data.pageAccess;
        this.borrowerList = this.data.responseData.BorrowerList;
        this.uniqueBorrowerList = this.data.responseData.uniqueBorrowerList;
        if(this.uniqueBorrowerList.length ==1)
        {
        this.model.lccCustId =this.uniqueBorrowerList[0][0];
        this.getchecklist();
        this.disableButton(false, true, true);
        }
        else{
          this.model.lccCustId = "s";
          this.disableButton(true, true, true);
        }
      });

    $(document).ready(function () {
      $("form").change(function () { 
        sessionStorage.setItem("editMode", "Y");
      });
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean)
  {
    if (this.pageAccess != "R") {
    this.editDisabled = edit;
    this.saveDisabled = save;
    this.cancelDisabled = cancel;
    }
    else{
    this.editDisabled = true;
    this.saveDisabled = true;
    this.cancelDisabled = true;
    }
  }
  doedit() {
    this.disableButton(true, false, false);
    this.disableFields = false;
  }
  docancel() {
    sessionStorage.setItem("editMode", "N");
    $('input,select,textarea').removeClass('ng-dirty');
    this.ngOnInit();
    this.disableFields = true;
  }
  dosave() {
  this.validation = this.fieldvalidation.multipleFieldValidation(this.model.chgchklist.length, this.ControllList);
    if (this.validation) {
      progressStatus()
      this.chgchkservice.savechecklist(this.model).subscribe(
        data => {
        this.data = data;
          if (this.data.success == true) {
            successStatus()
            this.getchecklist();
            sessionStorage.setItem("editMode", "N");
            $('input,select,textarea').removeClass('ng-dirty');
          }
          else {
            failedStatus()
          }
        });

      this.disableButton(false, true, true);
      $("#Editor").Editor("setEnable", false);
    }
  }
  getchecklist()
  {
    this.model.chgchklist=[];
    this.chgchkservice.getchecklist(this.model).subscribe(
      data => {
        this.data = data;
        this.model.chgchklist=this.data.responseData.chgchklist;
      });
      this.disableButton(false, true, true);
      this.disableFields = true;
  }
 
}
