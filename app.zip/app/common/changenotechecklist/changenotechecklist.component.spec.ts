import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangenotechecklistComponent } from './changenotechecklist.component';

describe('ChangenotechecklistComponent', () => {
  let component: ChangenotechecklistComponent;
  let fixture: ComponentFixture<ChangenotechecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangenotechecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangenotechecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
