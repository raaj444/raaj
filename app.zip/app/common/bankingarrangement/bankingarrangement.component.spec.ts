import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingarrangementComponent } from './bankingarrangement.component';

describe('BankingarrangementComponent', () => {
  let component: BankingarrangementComponent;
  let fixture: ComponentFixture<BankingarrangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingarrangementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingarrangementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
