import { Component, OnInit } from '@angular/core';
import { BankingarrangementService } from '../../util/service/commonservices/bankingarrangement.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { Validator } from '../../util/helper/validator';
declare var $: any;
@Component({
  selector: 'lp-bankingarrangement',
  templateUrl: './bankingarrangement.component.html',
  styleUrls: ['./bankingarrangement.component.css']
})
export class BankingarrangementComponent extends Validator implements OnInit {
  customerDisable: boolean;
  uniqueBorrowerList: any = [];
  totY5: any = 0;
  totY6: any = 0;
  data: any;
  dateStr: string;
  currentYear1: any;
  currentYear2: any;
  currentYear3: any;
  currentYear4: any;
  currentYear5: any;
  currentYear6: any;
  table1: boolean = true;
  masterList: any = [];
  bankingArrangement: any;
  grandTotal: any;
  pgrandTotal: any;
  model: any = [];
  termLoanDetails: any = {};
  private details: Array<any> = [];
  bankNames = [];
  ourBankWCTotal: any;
  ourBankTLTotal: any;
  ourBankNFBTotal: any;
  fbwcTotal: any;
  fbtlTotal: any;
  nfbTotal: any;
  pfbwcTotal: any;
  pfbtlTotal: any;
  pnfbTotal: any;
  totLeeSancAmt: any = 0;
  totLeeOsAmt: any = 0;
  totLeeOverdue: any = 0;
  totROI: any = 0;
  totY1: any = 0;
  totY2: any = 0;
  totY3: any = 0;
  totY4: any = 0;
  exposure: any = [];
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  pageAccess: any;
  commentsModel: any = {}
  facilityList: any = []
  exposureList: any = []
  kotakgroupentityname: any = []
  pgrandshare: any = 0;
  templateDisable: boolean
  repaymentList: any = {}
  constructor(private bankingarrangementService: BankingarrangementService, private router: Router, private fieldvalidation: Fieldvalidation) { super(); }

  ngOnInit() {
    // callEditorbyId('txtEditor1')
    // callEditorbyId('txtEditor')
    // callEditorbyId('txtEditor2')
    // callEditorbyId('txtEditor3')

    this.model = [];
    this.exposure = [];
    this.facilityList = []
    this.exposureList = []
    this.termLoanDetails.details = [];
    this.fbwcTotal = 0;
    this.fbtlTotal = 0;
    this.nfbTotal = 0;
    this.pfbwcTotal = 0;
    this.pfbtlTotal = 0;
    this.pnfbTotal = 0;
    this.uniqueBorrowerList = [];
    this.commentsModel = { lpcComments: '', lpcComments1: '', lpcComments2: '', lpcComments3: '' };
    this.model.ltacCustId = "";
    this.disableButton(true, true, true, true);
    this.customerDisable = false;

    // $("#txtEditor").Editor("setEnable", false);
    // $("#txtEditor1").Editor("setEnable", false);
    // $("#txtEditor2").Editor("setEnable", false);
    // $("#txtEditor3").Editor("setEnable", false);
    this.templateDisable = true
    this.bankingarrangementService.getBank()
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {

          this.uniqueBorrowerList = this.data.uniqueBorrowerList;
          if (this.uniqueBorrowerList.length == 1) {
            this.model.ltacCustId = this.uniqueBorrowerList[0][0];
            this.proposedExposure();
            this.getComments();
            this.disableButton(true, true, false, true);
            this.customerDisable = true;
          }

          this.bankNames = this.data.responseData.bankNames;

          this.data.responseData.bankingmasterList.forEach(element => {
            if (element.llvOptionVal == this.data.responseData.bankingArrangement.lpcdsBankArgmt)
              this.bankingArrangement = element.llvOptionDesc;
          });


          //  this.proposedExposure();

        }
      },
      error => {
      });

  }

  customerChange(custId) {
    if (this.model.ltacCustId != "") {
      this.disableButton(true, true, false, true);
      this.customerDisable = false;
      this.model = [];
      this.exposure = [];
      this.facilityList = []
      this.exposureList = []
      this.termLoanDetails.details = [];
      this.model.ltacCustId = custId;
      this.proposedExposure();
      this.getComments();
    }
    else {
      this.disableButton(true, true, true, true);
      this.customerDisable = false;
      this.model = [];
      this.exposure = [];
      this.facilityList = []
      this.exposureList = []
      this.termLoanDetails.details = [];
      //this.commentsModel=[];
      this.commentsModel = { lpcComments: '', lpcComments1: '', lpcComments2: '', lpcComments3: '' };
      this.model.ltacCustId = "";
    }
  }

  getComments() {
    this.bankingarrangementService.getComments(this.model.ltacCustId)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          this.commentsModel.lpcComments = this.data.lpcomPageComment.lpcComments
          this.commentsModel.lpcComments1 = this.data.lpcomPageComment1.lpcComments
          this.commentsModel.lpcComments2 = this.data.lpcomPageComment2.lpcComments
          this.commentsModel.lpcComments3 = this.data.lpcomPageComment3.lpcComments
          // $("#txtEditor").Editor("setText", this.data.lpcomPageComment.lpcComments);
          // $("#txtEditor1").Editor("setText", this.data.lpcomPageComment1.lpcComments);
          // $("#txtEditor2").Editor("setText", this.data.lpcomPageComment2.lpcComments);
          // $("#txtEditor3").Editor("setText", this.data.lpcomPageComment3.lpcComments);
        }

      },
      error => {
      });

  }

  proposedExposure() {
    this.pfbwcTotal = 0;
    this.pfbtlTotal = 0;
    this.pnfbTotal = 0;
    this.fbwcTotal = 0;
    this.fbtlTotal = 0;
    this.nfbTotal = 0;
    //KMBL Details
    this.bankingarrangementService.getBankingArrangements(this.model.ltacCustId)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success == true) {
          var currentExposure = this.data.responseData.proposedExposure.currentExposure;
          var proposedExposure = this.data.responseData.proposedExposure.proposedExposure;
          var bankingarrangement = this.data.responseData.bankingarrangement;
          this.repaymentList = this.data.repaymentList;
          if (this.repaymentList == undefined)
            this.repaymentList = { leeSeqNo: '0', leeOurBank: '', leeBankName: '', leeOtherBankName: "", leePartyId: '', leeFacType: '', leeFacNature: '', leeFacilityDesc: '', leeSancAmt: '', leeOsAmt: '', leeOsDate: '', leeEmiPaid: '', leeTenor: '', leeMargin: '', leeSancDate: '', leeOverdue: '', leeRoi: '', leeRepayType: '', leeRepayY1: '', leeRepayY2: '', leeRepayY3: '', leeRepayY4: '', leeRepayY5: '', leeRepayY6: '', leeRemarks: '', leeCreatedBy: '', leeCreatedOn: '', leeModifiedBy: '', leeModifiedOn: '', lpexProposedLimit: '', lpexSecured: '', lpexColDet: '', leeRepayYear1: '', leeRepayYear2: '', leeRepayYear3: '', leeRepayYear4: '', leeRepayYear5: '', leeRepayYear6: '', leeLevel: '0', leeParentId: '0', leeFacno: '', leeLvlOrder: '', leeLoanAccno: '', leeRepayTerms: '' }

          var name;
          var i = 0;
          this.exposure.push(currentExposure[0]);
          this.exposure.push(currentExposure[1]);
          this.exposure.push(currentExposure[2]);
          this.exposure.push(proposedExposure[3]);
          this.exposure.push(proposedExposure[4]);
          this.exposure.push(proposedExposure[5]);

          var total = this.exposure[0] + this.exposure[1] + this.exposure[2];
          var ptotal = this.exposure[3] + this.exposure[4] + this.exposure[5];

          var val0 = "0", val1 = "0", val2 = "0", val3 = "0", val4 = "0", val5 = "0";

          val0 = parseFloat(this.exposure[0]).toFixed(2);
          val1 = parseFloat(this.exposure[1]).toFixed(2);
          val2 = parseFloat(this.exposure[2]).toFixed(2);
          val3 = parseFloat(this.exposure[3]).toFixed(2);
          val4 = parseFloat(this.exposure[4]).toFixed(2);
          val5 = parseFloat(this.exposure[5]).toFixed(2);

          this.exposure = [];
          this.exposure.push(val0);
          this.exposure.push(val1);
          this.exposure.push(val2);
          this.exposure.push(val3);
          this.exposure.push(val4);
          this.exposure.push(val5);

          this.pfbwcTotal = this.pfbwcTotal + this.exposure[3];
          this.pfbtlTotal = this.pfbtlTotal + this.exposure[4];
          this.pnfbTotal = this.pnfbTotal + this.exposure[5];


          this.pfbwcTotal = parseFloat(this.pfbwcTotal).toFixed(2);
          this.pfbtlTotal = parseFloat(this.pfbtlTotal).toFixed(2);
          this.pnfbTotal = parseFloat(this.pnfbTotal).toFixed(2);
          this.pgrandTotal = parseFloat(this.pfbwcTotal) + parseFloat(this.pfbtlTotal) + parseFloat(this.pnfbTotal);
          this.pgrandTotal = parseFloat(this.pgrandTotal).toFixed(2);

          if (this.pgrandTotal != 0)
            this.pgrandshare = ((parseFloat(this.pgrandTotal) / parseFloat(this.pgrandTotal)) * 100).toFixed(2);

          this.model.push({ bankName: "KMBL", data: this.exposure, total: parseFloat(total).toFixed(2), ptotal: parseFloat(ptotal).toFixed(2), share: this.pgrandTotal != 0 && ptotal != 0 ? ((parseFloat(this.pgrandTotal) / parseFloat(ptotal)) * 100).toFixed(2) : 0 });


          var name;
          var i = 0;

          for (var prop in bankingarrangement) {
            name = prop;

            var value = bankingarrangement[prop];
            var total = value[0] + value[1] + value[2];

            var temp = bankingarrangement[prop];
            this.fbwcTotal = this.fbwcTotal + temp[0];
            this.fbtlTotal = this.fbtlTotal + temp[1];
            this.nfbTotal = this.nfbTotal + temp[2];

            var val1 = "0", val2 = "0", val3 = "0";
            val1 = parseFloat(temp[0]).toFixed(2);
            val2 = parseFloat(temp[1]).toFixed(2);
            val3 = parseFloat(temp[2]).toFixed(2);

            bankingarrangement[prop] = [];
            bankingarrangement[prop].push(val1);
            bankingarrangement[prop].push(val2);
            bankingarrangement[prop].push(val3);
            bankingarrangement[prop].push("0.00");
            bankingarrangement[prop].push("0.00");
            bankingarrangement[prop].push("0.00");


            this.model.push({ bankName: name, data: bankingarrangement[prop], total: parseFloat(total).toFixed(2), ptotal: '0.00', share: "0.00" });
          }

          this.fbwcTotal = parseFloat(this.fbwcTotal) + parseFloat(this.exposure[0]);
          this.fbtlTotal = parseFloat(this.fbtlTotal) + parseFloat(this.exposure[1]);
          this.nfbTotal = parseFloat(this.nfbTotal) + parseFloat(this.exposure[2]);

          this.fbwcTotal = parseFloat(this.fbwcTotal).toFixed(2);
          this.fbtlTotal = parseFloat(this.fbtlTotal).toFixed(2);
          this.nfbTotal = parseFloat(this.nfbTotal).toFixed(2);

          this.grandTotal = parseFloat(this.fbwcTotal) + parseFloat(this.fbtlTotal) + parseFloat(this.nfbTotal);
          this.grandTotal = parseFloat(this.grandTotal).toFixed(2);

          //Term Loan Details
          this.bankingarrangementService.getTermLoanDetails(this.model.ltacCustId)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success == true) {
                this.termLoanDetails.details = this.data.termLoanDetailsList;
                this.exposureList = this.data.exposureDet;
                this.facilityList = this.data.facility;
                this.totLeeSancAmt = 0;
                this.totLeeOsAmt = 0;
                this.totLeeOverdue = 0;
                this.totY1 = 0;
                this.totY2 = 0;
                this.totY3 = 0;
                this.totY4 = 0;
                this.totY5 = 0;
                this.totY6 = 0;

                this.exposureList.forEach(element => {
                  if (element.ledOsAmt != "NaN")
                    this.totLeeSancAmt = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeSancAmt)) + parseFloat(this.roundOfValueWithDefulatValue(element.ledSancLimit));
                  this.totLeeOsAmt = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeOsAmt)) + parseFloat(this.roundOfValueWithDefulatValue(element.ledOsAmt));
                })

                this.facilityList.forEach(element => {
                  if (element.lfOsLimit != "NaN")
                    this.totLeeSancAmt = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeSancAmt)) + parseFloat(this.roundOfValueWithDefulatValue(element.lfSancLimit));
                  this.totLeeOsAmt = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeOsAmt)) + parseFloat(this.roundOfValueWithDefulatValue(element.lfOsLimit));
                })
                this.kotakgroupentityname = this.data.kotakgroupentityname;
                this.exposureList.forEach(detail => {
                  this.kotakgroupentityname.forEach(element => {
                    if (detail.ledKotakGrpName == element.llvOptionVal)
                      detail.ledKotakGrpName = element.llvOptionDesc;
                  });
                });
                this.termLoanDetails.details.forEach(element => {
                  this.totLeeSancAmt = this.totLeeSancAmt + parseFloat(element.leeSancAmt);
                  this.totLeeOsAmt = this.totLeeOsAmt + parseFloat(element.leeOsAmt);
                  this.totLeeOverdue = this.totLeeOverdue + parseFloat(element.leeOverdue);

                  element.leeSancAmt = parseFloat(element.leeSancAmt).toFixed(2);
                  element.leeOsAmt = parseFloat(element.leeOsAmt).toFixed(2);
                  element.leeOverdue = parseFloat(element.leeOverdue).toFixed(2);
                  element.leeRoi = parseFloat(element.leeRoi).toFixed(2);
                  element.leeRepayY1 = parseFloat(element.leeRepayY1).toFixed(2);
                  element.leeRepayY2 = parseFloat(element.leeRepayY2).toFixed(2);
                  element.leeRepayY3 = parseFloat(element.leeRepayY3).toFixed(2);
                  element.leeRepayY4 = parseFloat(element.leeRepayY4).toFixed(2);
                  element.leeRepayY5 = parseFloat(element.leeRepayY5).toFixed(2);
                  element.leeRepayY6 = parseFloat(element.leeRepayY6).toFixed(2);

                  if (element.leeRoi != null && element.leeRoi != "NaN") {
                    this.totROI = parseFloat(this.totROI) + parseFloat(element.leeRoi);
                  }
                  else
                    element.leeRoi = "0.00";
                  this.totY1 = parseFloat(this.totY1) + parseFloat(element.leeRepayY1);
                  this.totY2 = parseFloat(this.totY2) + parseFloat(element.leeRepayY2);
                  this.totY3 = parseFloat(this.totY3) + parseFloat(element.leeRepayY3);
                  this.totY4 = parseFloat(this.totY4) + parseFloat(element.leeRepayY4);
                  this.totY5 = parseFloat(this.totY5) + parseFloat(element.leeRepayY5);
                  this.totY6 = parseFloat(this.totY6) + parseFloat(element.leeRepayY6);

                  this.totROI = parseFloat(this.totROI).toFixed(2);
                  this.totY1 = parseFloat(this.totY1).toFixed(2);
                  this.totY2 = parseFloat(this.totY2).toFixed(2);
                  this.totY3 = parseFloat(this.totY3).toFixed(2);
                  this.totY4 = parseFloat(this.totY4).toFixed(2);
                  this.totY5 = parseFloat(this.totY5).toFixed(2);
                  this.totY6 = parseFloat(this.totY6).toFixed(2);


                });

                this.totLeeSancAmt = parseFloat(this.totLeeSancAmt).toFixed(2);
                this.totLeeOsAmt = parseFloat(this.totLeeOsAmt).toFixed(2);
                this.totLeeOverdue = parseFloat(this.totLeeOverdue).toFixed(2);

                this.termLoanDetails.details.forEach(detail => {
                  if (detail.leeBankName == "0") {
                    detail.leeBankName = detail.leeOtherBankName;
                  }
                  else {
                    this.bankNames.forEach(element => {
                      if (detail.leeBankName == element.llvOptionVal)
                        detail.leeBankName = element.llvOptionDesc;
                    });
                  }
                });
                this.calculateOverDue()
                this.calculateRepayY1()
                this.calculateRepayY2()
                this.calculateRepayY3()
                this.calculateRepayY4()
                this.calculateRepayY5()
                this.calculateRepayY6()
              }

            },
            error => {
              // this.alertService.error(error);
            });


        }
      },
      error => {
        // this.alertService.error(error);
      });
  }

  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.savebuttonDisable = true;
      this.editbuttonDisable = true;
      this.cancelbuttonDisable = true;
    }
    else {
      this.fieldDisable = fieldDisable;
      this.savebuttonDisable = savebuttonDisable;
      this.editbuttonDisable = editbuttonDisable;
      this.cancelbuttonDisable = cancelbuttonDisable;
    }
  }
  editBankingArg() {
    this.disableButton(false, false, true, false)
    // $("#txtEditor").Editor("setEnable", true);
    // $("#txtEditor1").Editor("setEnable", true);
    // $("#txtEditor2").Editor("setEnable", true);
    // $("#txtEditor3").Editor("setEnable", true);
    this.templateDisable = false
    this.customerDisable = true;
  }
  saveBankingArg() {
    // this.commentsModel.lpcComments = $("#txtEditor").Editor("getText");
    // this.commentsModel.lpcComments1 = $("#txtEditor1").Editor("getText");
    // this.commentsModel.lpcComments2= $("#txtEditor2").Editor("getText");
    // this.commentsModel.lpcComments3 = $("#txtEditor3").Editor("getText");
    this.exposureList.forEach(detail => {
      this.kotakgroupentityname.forEach(element => {
        if (detail.ledKotakGrpName == element.llvOptionDesc)
          detail.ledKotakGrpName = element.llvOptionVal;
      });
    });

    this.bankingarrangementService.saveBankingArrangement(this.exposureList, this.facilityList, this.repaymentList)
      .subscribe(
      data => {
        this.data = data;
        if (this.data.success) {
          let comments = { 'comments': this.commentsModel.lpcComments, 'comments1': this.commentsModel.lpcComments1, 'comments2': this.commentsModel.lpcComments2, 'comments3': this.commentsModel.lpcComments3, 'custId': this.model.ltacCustId };
          this.repaymentList = this.data.repaymentList;
          this.bankingarrangementService.saveBankingComments(comments)
            .subscribe(
            data => {
              this.data = data;
              if (this.data.success) {
                this.disableButton(true, true, false, true)
                // $("#txtEditor").Editor("setText", this.data.lpcomPageComment.lpcComments);
                // $("#txtEditor1").Editor("setText", this.data.lpcomPageComment1.lpcComments);
                // $("#txtEditor2").Editor("setText", this.data.lpcomPageComment2.lpcComments);
                // $("#txtEditor3").Editor("setText", this.data.lpcomPageComment3.lpcComments);
                // $("#txtEditor").Editor("setEnable", false);
                // $("#txtEditor1").Editor("setEnable", false);
                // $("#txtEditor2").Editor("setEnable", false);
                // $("#txtEditor3").Editor("setEnable", false);
                this.templateDisable = true;
                this.customerDisable = false;

                this.exposureList.forEach(detail => {
                  this.kotakgroupentityname.forEach(element => {
                    if (detail.ledKotakGrpName == element.llvOptionVal)
                      detail.ledKotakGrpName = element.llvOptionDesc;
                  });
                });

                sessionStorage.setItem("editMode", "N");
                $('input,select,textarea').removeClass('ng-dirty');
              }
            },
          )
          error => {
          }
        }
      },
    )
    error => {
    }

  }
  cancelButton() {
    if (confirm("Do you want to cancel?")) {
      this.disableButton(true, true, false, true)
      this.model = [];
      this.exposure = [];
      this.termLoanDetails.details = [];
      this.fbwcTotal = 0;
      this.fbtlTotal = 0;
      this.nfbTotal = 0;
      this.pfbwcTotal = 0;
      this.pfbtlTotal = 0;
      this.pnfbTotal = 0;
      // $("#txtEditor").Editor("setEnable", false);
      // $("#txtEditor1").Editor("setEnable", false);
      // $("#txtEditor2").Editor("setEnable", false);
      // $("#txtEditor3").Editor("setEnable", false);
      this.templateDisable = true
      // $("#txtEditor").Editor("setText", " ");
      // $("#txtEditor1").Editor("setText", " ");
      // $("#txtEditor2").Editor("setText", " ");
      // $("#txtEditor3").Editor("setText", " ");
      var date1 = new Date();

      this.bankingarrangementService.getBank()
        .subscribe(
        data => {
          this.data = data;
          if (this.data.success == true) {
            this.bankNames = this.data.responseData.bankNames;

            this.data.responseData.bankingmasterList.forEach(element => {
              if (element.llvOptionVal == this.data.responseData.bankingArrangement.lpcdsBankArgmt)
                this.bankingArrangement = element.llvOptionDesc;
            });

            if (this.uniqueBorrowerList.length == 1) {
              this.model.ltacCustId = this.uniqueBorrowerList[0][0];
              this.proposedExposure();
              this.getComments();
              this.disableButton(true, true, false, true);
              this.customerDisable = true;
            }
            else {
              this.model.ltacCustId = "";
              this.disableButton(true, true, false, true);
              this.customerDisable = false;
              this.commentsModel = { lpcComments: '', lpcComments1: '', lpcComments2: '', lpcComments3: '' };

            }

          }
        },
        error => {
          // this.alertService.error(error);
        });
      // this.bankingarrangementService.getComments()
      //   .subscribe(
      //   data => {
      //     this.data = data;
      //     if (this.data.success == true) {
      //       // $("#txtEditor").Editor("setText", this.data.lpcomPageComment.lpcComments);
      //       // $("#txtEditor1").Editor("setText", this.data.lpcomPageComment1.lpcComments);
      //       // $("#txtEditor2").Editor("setText", this.data.lpcomPageComment2.lpcComments);
      //       // $("#txtEditor3").Editor("setText", this.data.lpcomPageComment3.lpcComments);
      //     }

      //   },
      //   error => {
      //   });
    }
    else
      return false;
  }
  calculateOverDue() {
    this.totLeeOverdue = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totLeeOverdue = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeOverdue)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeOverdue))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totLeeOverdue = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeOverdue)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledOverdue))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totLeeOverdue = parseFloat(this.roundOfValueWithDefulatValue(this.totLeeOverdue)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfOverdue))
    }
  }


  calculateRepayY1() {
    this.totY1 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY1 = parseFloat(this.roundOfValueWithDefulatValue(this.totY1)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY1))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY1 = parseFloat(this.roundOfValueWithDefulatValue(this.totY1)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY1))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY1 = parseFloat(this.roundOfValueWithDefulatValue(this.totY1)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY1))

    }
  }
  calculateRepayY2() {
    this.totY2 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY2 = parseFloat(this.roundOfValueWithDefulatValue(this.totY2)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY2))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY2 = parseFloat(this.roundOfValueWithDefulatValue(this.totY2)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY2))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY2 = parseFloat(this.roundOfValueWithDefulatValue(this.totY2)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY2))
    }
  }

  calculateRepayY3() {
    this.totY3 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY3 = parseFloat(this.roundOfValueWithDefulatValue(this.totY3)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY3))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY3 = parseFloat(this.roundOfValueWithDefulatValue(this.totY3)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY3))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY3 = parseFloat(this.roundOfValueWithDefulatValue(this.totY3)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY3))
    }
  }

  calculateRepayY4() {
    this.totY4 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY4 = parseFloat(this.roundOfValueWithDefulatValue(this.totY4)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY4))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY4 = parseFloat(this.roundOfValueWithDefulatValue(this.totY4)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY4))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY4 = parseFloat(this.roundOfValueWithDefulatValue(this.totY4)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY4))
    }
  }

  calculateRepayY5() {
    this.totY5 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY5 = parseFloat(this.roundOfValueWithDefulatValue(this.totY5)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY5))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY5 = parseFloat(this.roundOfValueWithDefulatValue(this.totY5)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY5))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY5 = parseFloat(this.roundOfValueWithDefulatValue(this.totY5)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY5))
    }
  }
  calculateRepayY6() {
    this.totY6 = 0;
    for (let i = 0; i < this.termLoanDetails.details.length; i++) {
      this.totY6 = parseFloat(this.roundOfValueWithDefulatValue(this.totY6)) + parseFloat(this.roundOfValueWithDefulatValue(this.termLoanDetails.details[i].leeRepayY6))
    }
    for (let i = 0; i < this.exposureList.length; i++) {
      this.totY6 = parseFloat(this.roundOfValueWithDefulatValue(this.totY6)) + parseFloat(this.roundOfValueWithDefulatValue(this.exposureList[i].ledRepayY6))
    }
    for (let i = 0; i < this.facilityList.length; i++) {
      this.totY6 = parseFloat(this.roundOfValueWithDefulatValue(this.totY6)) + parseFloat(this.roundOfValueWithDefulatValue(this.facilityList[i].lfRepayY6))
    }
  }
}