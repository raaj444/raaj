import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddendumslComponent } from './addendumsl.component';

describe('AddendumslComponent', () => {
  let component: AddendumslComponent;
  let fixture: ComponentFixture<AddendumslComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddendumslComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddendumslComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
