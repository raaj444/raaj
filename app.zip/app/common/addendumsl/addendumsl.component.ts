import { Component, OnInit } from '@angular/core';
import { SltemplateService } from '../../util/service/commonservices/sltemplate.service';
import { NgForm } from '@angular/forms';
declare var $: any;
import { CranService } from '../../util/service/commonservices/cran.service';
declare var $: any;
import * as jsPDF from 'jspdf';
declare let html2pdf;
declare let html2canvas;
declare var jQuery: any;
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';

@Component({
  selector: 'lp-addendumsl',
  templateUrl: './addendumsl.component.html',
  styleUrls: ['./addendumsl.component.css']
})
export class AddendumslComponent  implements OnInit {   data:any; 
  ackPortion: any;
  section2: any;
  section1: any;
  model: any = {};
  changenodeList: any = [];
  counter = 0;
  modelForChngNote: any;

  constructor(private Addendumservice: SltemplateService, private pdfdownloadservice: CranService,private changenoteService:ChangenoteService) { }

  ngOnInit() {
    this.counter = 0;
    this.changenodeList = [];
    this.model = {};
    if ($('#txt_custId').val() == "") {
      this.model.custId = 0;
    }
    else {
      this.model.custId = $('#txt_custId').val();
    }
    this.modelForChngNote=this.changenoteService.getProposalData();
    this.model.currentversion=this.modelForChngNote.lcmVersion;
    this.Addendumservice.getaddendumSanctionletter(this.model).subscribe(
      data => { this.data=data;
        this.model= this.data;
        this.model.name = this.data.custname;
        this.model.addr1 = this.data.address2;
        this.model.addr2 = this.data.address3;
        this.changenodeList = this.data.responseData.changenoteList;
        this.section1 = this.data.responseData.section1;
        this.section2 = this.data.responseData.section2;
        this.ackPortion = this.data.responseData.ackPortion;

        $("#section1").html(this.section1);
        $("#section2").html(this.section2);
        $("#ackPortionAdden").html(this.ackPortion);

        // for (var i = 0; i < this.changenodeList.length; i++) {
        //   this.counter = i + 1;
        //   $("#existing" + i).html(this.changenodeList[i].existing);
        //   $("#revised" + i).html(this.changenodeList[i].revised);
        // }

        this.counter = 0;
      });
  }
  pdfdownload() {
    var html = "<html><head></head>" + $("#pdf_div2").html() + "</html>";
    var jHtmlObject = $("#pdf_div2").clone();
    // jHtmlObject.find("#tableimg tr:first").remove();
    // jHtmlObject.find("#tableimg tr:last").remove();
    // jHtmlObject.find("#tableimg").remove();
    var htmlString = "<html><head></head>" + jHtmlObject.html() + "</html>";

    var borrDet = { custId: this.model.custId.toString(), attachType: '6' };
    this.pdfdownloadservice.downloadOutputFormat(htmlString, borrDet)
      .subscribe(
        data => { this.data=data;
          var link = document.createElement('a');
          link.href = this.data.responseData.data;
          var fileName = this.data.responseData.filename;
          link.download = fileName;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        },
        error => {
        });

  }
}
