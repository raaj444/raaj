import { Component, OnInit } from '@angular/core';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
declare var $: any;

@Component({
  selector: 'lp-changenotepopup',
  templateUrl: './changenotepopup.component.html',
  styleUrls: ['./changenotepopup.component.css']
})
export class ChangenotepopupComponent implements OnInit {
  data:any;
  changetermsList=[];
  chgtermmodel:any;
  modelForChngNote: any;
  constructor(private changenoteService: ChangenoteService) { }

  ngOnInit() {
    this.chgtermmodel={lcmVersion:'0'};
    this.modelForChngNote=this.changenoteService.getProposalData();
    this.chgtermmodel.lcmVersion=this.modelForChngNote.currentversion;
    this.changetermsList=[];
    this.changenoteService.getoverallchangemode(this.chgtermmodel).subscribe(
      data =>   {
        this.data = data;
        this.changetermsList = this.data.changetermsList;
      });
  }
  closechgterms()
  {
    this.changetermsList=[];
    $('#chgterms').modal('hide')
  }

}
