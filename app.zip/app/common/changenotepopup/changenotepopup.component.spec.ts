import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangenotepopupComponent } from './changenotepopup.component';

describe('ChangenotepopupComponent', () => {
  let component: ChangenotepopupComponent;
  let fixture: ComponentFixture<ChangenotepopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangenotepopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangenotepopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
