import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CasedetailcreditComponent } from './casedetailcredit.component';

describe('CasedetailcreditComponent', () => {
  let component: CasedetailcreditComponent;
  let fixture: ComponentFixture<CasedetailcreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CasedetailcreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CasedetailcreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
