import { Component, OnInit, ViewChild } from '@angular/core';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { CasedetailrmService } from "../../util/service/commonservices/casedetailrm.service";
import { Router } from '@angular/router';
import { CasedetailcreditService } from "../../util/service/commonservices/casedetailcredit.service";
import { Validator } from '../../util/helper/validator';
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { ChangenoteComponent } from '../changenote/changenote.component';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'lp-casedetailcredit',
  templateUrl: './casedetailcredit.component.html',
  styleUrls: ['./casedetailcredit.component.css']
})
export class CasedetailcreditComponent extends Validator  implements OnInit {   data:any; 
  pageAccess: any;
  IndustryActivity: any = [];
  IndustryCode: any = [];
  IndustrySubActivity: any = []
  model: any = {};
  newbuttonDisable: boolean;
  editbuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  savebuttonDisable: boolean;
  fieldDisable: boolean;
  placeholder: string;
  flag: boolean;
  bizVertical: any;
  idvalueList: any = ['lpcdcIndCode', 'lpcdcIndAct', 'lpcdcSecured', 'lpcdcRealEstateExp', 'lpcdcSustainability', 'lpcdcIndSubact', 'lpcdcSancdDate'];
  fieldValue: string;
  modelForChngNote: any;
  yearList:any=[];
  auditList:any=[]
  auditData:any=[]
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  maxDate: Date; minDate: Date;
  typeofcase:any;
  modelsearch:any;
  @ViewChild(SearchComponent) Searchpop: SearchComponent;
  constructor(private casedetailcreditService: CasedetailcreditService, private router: Router,
    private fieldvalidation: Fieldvalidation, private changenoteService: ChangenoteService) {
    super();

    this.minDate = new Date(); this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate.setDate(this.minDate.getDate());

  }

  ngOnInit() {
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific = "N";
    this.model = { 'lpcdcIndCode': "s", 'lpcdcIndAct': "s", 'lpcdcSecured': "Y", 'lpcdcRealEstateExp': "Y", 'lpcdcTakeover': "Y",'lpcdcIndSubact':"s" ,'lpcdcAudName':"",'lpcdcAudChange':"Y",'lpcdcAudChangeReason':"",'lpcdcBorrRlnWithBank':'','lpcdcBankingSince':'','lpcdcInfra':"N",'lpcdcRemarks':""}
    this.disableButton(true, true, false, true);
    $("input[type=radio]").attr('disabled', true);
    loadingStatus()
    this.casedetailcreditService.getMasterData()
      .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            this.IndustryCode = this.data.IndustryCode
            this.IndustryActivity = this.data.IndustryActivity
            this.yearList = this.data.yearList
            this.pageAccess = this.data.pageAccess;
            this.typeofcase=this.data.typeofcase
            if (this.pageAccess == "R")
              this.disableButton(true, true, true, true)
          }
          else
            this.editCasedetailsCredit()
          if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
        },
        error => {
        });
    this.casedetailcreditService.getBusinessVertical()
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.bizVertical = this.data.bizVertical;

            if (this.bizVertical != "" && this.bizVertical == '3') {
              this.model.lpcdcIndCode = 1;
              this.model.lpcdcIndSubact = "Wholesale Trade of Agricultural machinery and equipment";
              this.model.lpcdcSecured = 'N';
              this.model.lpcdcRealEstateExp = 'N';
              this.model.lpcdcSustainability = "No";
            }
          }
        },
        error => {
        });

    this.casedetailcreditService.getCaseDetailCredit()
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            
            this.model = this.data.responseData;
            this.getSubActivity1();
            this.model.lpcdcIndSubact=this.model.lpcdcIndSubact
            if (this.model.lpcdcSancdDate != "" && this.model.lpcdcSancdDate != null && this.model.lpcdcSancdDate != undefined) {
              var sancdate = this.model.lpcdcSancdDate;
              var datearray = sancdate.split("-");    // var sancdate = this.model.lpcdcSancdDate;
              var datearray = sancdate.split("-");
              this.model.lpcdcSancdDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
            }
            if (this.model.lpcdcLimitExpdate != "" && this.model.lpcdcLimitExpdate != null && this.model.lpcdcLimitExpdate != undefined) {
              var lpcdcLimit = this.model.lpcdcLimitExpdate;
              var lpcdcLimitarray = lpcdcLimit.split("-");
              this.model.lpcdcLimitExpdate = lpcdcLimitarray[2] + '/' + lpcdcLimitarray[1] + '/' + lpcdcLimitarray[0];
            }
            if (this.model.lpcdcLimitEffdate != "" && this.model.lpcdcLimitEffdate != null && this.model.lpcdcLimitEffdate != undefined) {
              var lpcdcLimitEff = this.model.lpcdcLimitEffdate;
              var lpcdcLimitEffarray = lpcdcLimitEff.split("-");
              this.model.lpcdcLimitEffdate = lpcdcLimitEffarray[2] + '/' + lpcdcLimitEffarray[1] + '/' + lpcdcLimitEffarray[0];
            }
            if (this.model.lpcdcOrgRenewDate != "" && this.model.lpcdcOrgRenewDate != null && this.model.lpcdcOrgRenewDate != undefined) {
              var lpcdcOrgRenew = this.model.lpcdcOrgRenewDate;
              var lpcdcOrgRenewarray = lpcdcOrgRenew.split("-");
              this.model.lpcdcOrgRenewDate = lpcdcOrgRenewarray[2] + '/' + lpcdcOrgRenewarray[1] + '/' + lpcdcOrgRenewarray[0];
            }
            //this.casedetailcreditService.saveCaseDetailCredit(this.model)
          }
          else
          {
            if (this.data.userId.trim()!= "" && this.data.userId.trim()!= null && this.data.userId.trim()!= undefined) {
              this.model.lpcdcCmEmpid = this.data.userId;
              this.model.lpcdcCmName = this.data.userName;
              this.model.lpcdcCmEmpcode = this.data.userempcode;
            }
            this.editCasedetailsCredit()
          }
        },
        error => {
        });
    hide()
 if (this.modelForChngNote.changeMode == "Y") {
            this.changenoteComponent.onload(this.pageAccess);
          }
    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
    $('#Search').on('hidden.bs.modal', () => {
      this.modalClosed();
    });
  }

  saveCasedetailsCredit() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if (flagCM) {
        if (this.typeofcase=="1")
      {
        this.idvalueList = []
       this.idvalueList = ['lpcdcIndCode', 'lpcdcIndAct', 'lpcdcSecured', 'lpcdcRealEstateExp', 'lpcdcSustainability', 'lpcdcIndSubact','lpcdcCmEmpid','lpcdcCmName'];
      }
      else if(this.bizVertical=="3" && this.typeofcase=="1")
      {
       this.idvalueList = []
       this.idvalueList = ['lpcdcIndCode', 'lpcdcIndAct', 'lpcdcSecured', 'lpcdcRealEstateExp', 'lpcdcSustainability', 'lpcdcIndSubact','lpcdcCmEmpid','lpcdcCmName'];
      }
      else
      {
        this.idvalueList = []
       this.idvalueList = ['lpcdcIndCode', 'lpcdcIndAct', 'lpcdcSecured', 'lpcdcRealEstateExp', 'lpcdcSustainability', 'lpcdcIndSubact' ,'lpcdcSancdDate','lpcdcGrpName','lpcdcGrpId','lpcdcCmEmpid','lpcdcCmName'];

      }
      this.flag = this.fieldvalidation.validateField(this.idvalueList)
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.flag) {
        this.changenoteComponent.onSave();
      }
      if (this.flag == true) {
        progressStatus()
        if (this.model.lpcdcSancdDate != "" && this.model.lpcdcSancdDate != undefined) {
          this.model.lpcdcSancdDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdcSancdDate);

        }

        if (this.model.lpcdcLimitExpdate != "" && this.model.lpcdcLimitExpdate != undefined) {

          this.model.lpcdcLimitExpdate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdcLimitExpdate);
        }

        if (this.model.lpcdcLimitEffdate != "" && this.model.lpcdcLimitEffdate != undefined) {
          this.model.lpcdcLimitEffdate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdcLimitEffdate);
        }
        if (this.model.lpcdcOrgRenewDate != "" && this.model.lpcdcOrgRenewDate != undefined) {
          this.model.lpcdcOrgRenewDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.lpcdcOrgRenewDate);
        }

        this.casedetailcreditService.saveCaseDetailCredit(this.model)
          .subscribe(
            data => { this.data=data;
              if (this.data.success) {
                this.ngOnInit()
                this.disableButton(true, true, false, true)
                successStatus()

                sessionStorage.setItem("editMode", "N");
                $('input,select,textarea').removeClass('ng-dirty');
              }
              else
                failedStatus()
            },
            error => {
            });

      }
    }
  }
  cancelButton() {

    if (confirm("Do you want to Cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    }
    else
      return false;
  }

  editCasedetailsCredit() {
    this.disableButton(false, false, true, false);
    $("input[type=radio]").attr('disabled', false);
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  disableButton(fieldDisable: boolean, savebuttonDisable: boolean, editbuttonDisable: boolean, cancelbuttonDisable: boolean) {
    if (this.pageAccess == "R") {
      this.fieldDisable = true;
      this.savebuttonDisable = true;
      this.editbuttonDisable = true;
      this.cancelbuttonDisable = true;
    }
    else {
      this.fieldDisable = fieldDisable;
      this.savebuttonDisable = savebuttonDisable;
      this.editbuttonDisable = editbuttonDisable;
      this.cancelbuttonDisable = cancelbuttonDisable;
    }
  }
  // validatedate(eventId) {
  //   this.fieldvalidation.validatedate(eventId);
  // }

  validatefuturedate(event) {
    if (event != null && event != "") {
      this.fieldvalidation.validatefuturedate(event.target.id);
    }
  }

  futRestrict(e: any) {
    if (e != null && e != "") {
      if (!this.daterestrict(e)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Enter valid date");
      }

      else {
        if (this.effDateRes(e.target.value)) {
          e.target.value = "";
          $('#' + e.target.id).addClass("has-error");
          $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
        }
      }
    }
  }

  rmvErrClass(id: string) {
    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }

  getSubActivity(){
    this.model.lpcdcIndSubact = "s"
    this.casedetailcreditService.getSubActivity(this.model.lpcdcIndAct)
      .subscribe(
        data => { this.data=data;
          if (this.data.success) {
    this.IndustrySubActivity = this.data.IndustrySubActivity
          }
        })
  }

  getSubActivity1(){
    this.casedetailcreditService.getSubActivity(this.model.lpcdcIndAct)
      .subscribe(
        data => { this.data=data;
          if (this.data.success) {
    this.IndustrySubActivity = this.data.IndustrySubActivity
          }
        })
  }

  dosearch() {
    this.modelsearch={};
      this.modelsearch.pageid = "cmusersearch";
      $('#name').text("User Name");
      $('#code').text("User Id");
      $('#header').text("User Search");
      $('#txt_pageid').val(this.modelsearch.pageid);
      this.Searchpop.ngOnInit();
      $('#Search').modal('show');
  }
  modalClosed() {
      if ($('#txt-Searchname').val() != "")
      this.model.lpcdcCmName = $('#txt-Searchname').val();
     if ($('#txt_Searchcode').val() != "")
      this.model.lpcdcCmEmpid = $('#txt_Searchcode').val();
      if ($('#txt_cmcode').val() != "")
      this.model.lpcdcCmEmpcode = $('#txt_cmcode').val();
  }

  auditTrial(){
    $('#auditTrialcasecred').modal('show');
    this.getAuditData()
  }
  close(){
    $('#auditTrialcasecred').modal('hide');
  }

  getAuditData()
  {
    this.casedetailcreditService.getAuditData()
    .subscribe(
      data => {
        this.data = data;
        this.auditList=[];
        this.auditData=[];
          this.auditList=this.data.caseCrList;
          this.auditData= this.data.auditData ;
          this.auditData.forEach(element => 
            {
            element.AuditData=JSON.parse(element.AuditData)
          });
         var oldId;
          var color,oldColor;
          this.auditData.forEach((element,index) => 
            {
              var sesId=element.sessionId
              if(index==0)
              {
              color='Blue'
              this.auditData.forEach((element1,index) => 
              {
                if(element1.sessionId==sesId)
                {
                  element1.color = color;
                oldId=sesId
                oldColor=color
                }
              })
            }
            if(oldColor=='Blue' &&index!=0)
              color='Grey'
              else
              color='Blue'
              if(sesId!=oldId && index!=0)
              {
              this.auditData.forEach((element,index) => 
              {
                if(element.sessionId==sesId)
                {
                element.color = color;
                oldId=sesId
                oldColor=color
                }
              })
              color='Grey'
            }
            })
      },
      error => {
      });
  }


}




