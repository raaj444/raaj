import { Component, OnInit } from '@angular/core';
import { PropassignedmeService } from '../../util/service/commonservices/propassignedme.service';
import { Router } from '@angular/router';
import { AssignedtogroupService } from '../../util/service/commonservices/assignedtogroup.service';
import { HomeComponent } from '../home/home.component';
import { HomeService } from '../../util/service/commonservices/home.service';
import { HeaderpagenavComponent } from '../headerpagenav/headerpagenav.component';
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';

@Component({
  selector: 'lp-assignedtogroup',
  templateUrl: './assignedtogroup.component.html',
  styleUrls: ['./assignedtogroup.component.css']
})

export class AssignedtogroupComponent  implements OnInit {   data:any; 
  groupList: Array<any> = [];
  constructor(private propassignedmeService: PropassignedmeService, private homeService: HomeService, private headerpagenavComponent: HeaderpagenavComponent,
    private homeComponent: HomeComponent,private changenoteService:ChangenoteService,
    private router: Router) { }
  load: boolean;
  flowType: any;
  secFlag: boolean;
  secId: any;
  model: any = {};
  vertical: any;
  ngOnInit() {

    this.groupList = [];
    this.load = true
    var model = "group";
    this.propassignedmeService.getMyInboxDetails(model)
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.load = false
            this.flowType = this.data.flowType;
            this.changenoteService.setFlowType( this.flowType);
            this.vertical=this.data.vertical;
            this.changenoteService.setVertical( this.vertical);
              if (this.flowType == "P" || this.flowType == "R") {
                this.secFlag = false;
                this.groupList=this.data.lpcomProposalList;
              }
              else {
                this.secFlag = true;
                this.groupList=this.data.lpcomProposalList;
              }

          }
         },
      )
  
  }
  getSourcingDetails(proposalNo, SecId,docid) {
    this.secId = SecId
    this.propassignedmeService.getSourcingDetails(proposalNo)
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            var pageId = 0;
            this.flowType = this.data.flowtype;
            if (this.flowType == "P")
              pageId = 801;
            else if (this.flowType == "T")
              pageId = 2201;
            else if (this.flowType == "L")
              pageId = 2301;
            this.homeService.setSessioVariable(pageId)
              .subscribe(
                data => { this.data=data;
                  if (this.data.success == true) {
                    //this.headerpagenavComponent.checkProposalFromPanel();
                    if (this.flowType == "P") {
                      this.router.navigate(['/home/parties/sourcingdetails']);
                    }
                    else if (this.flowType == "R") {
                      this.homeComponent.ngOnInit();
                      this.model.docsetid=docid;
                      this.propassignedmeService.getpagename(this.model.docsetid)
                        .subscribe(
                          data => { this.data=data;
                            let pagename = this.data.lpmPageName;
                            let pagechid = this.data.pageid;
                            let parentid = 2100;
                            this.router.navigate(['/home/pagename']);
                            this.homeComponent.ngOnInit();
                            this.homeComponent.currentPageChildId = pagechid;
                            this.homeComponent.currentPageParentId = parentid;
                            this.homeComponent.headerpagenavComponent.childClickedInMenuBar(pagechid, parentid, 0, 0);
                          });
                    }
                    else if (this.flowType == "T") {
                      this.propassignedmeService.setSecId(this.secId)
                        .subscribe(
                          data => { this.data=data;
                            if (this.data.success == true) {
                              this.homeComponent.headerpagenavComponent.getDenomType(this.data.propDenom, false);
                              this.router.navigate(['/home/technicalvaluation'])
                              this.homeComponent.ngOnInit();
                              this.homeComponent.currentPageChildId = 2201;
                              this.homeComponent.currentPageParentId = 2200;
                              this.homeComponent.headerpagenavComponent.childClickedInMenuBar(2201, 2200, 0, 0);
                            }
                          });
                    }
                    else if (this.flowType == "L") {
                      this.propassignedmeService.setSecId(this.secId)
                        .subscribe(
                          data => { this.data=data;
                            if (this.data.success == true) {
                              this.homeComponent.headerpagenavComponent.getDenomType(this.data.propDenom, false);
                              this.router.navigate(['/home/legalverification'])
                              this.homeComponent.ngOnInit();
                              this.homeComponent.currentPageChildId = 2301;
                              this.homeComponent.currentPageParentId = 2300;
                              this.homeComponent.headerpagenavComponent.childClickedInMenuBar(2301, 2300, 0, 0);
                            }
                          });
                    }
                  }
                });
          }
        })
  }


  receive(proposalNo, secId,docid) {
    this.secId = secId
    if (this.flowType == "T" || this.flowType == "L") {
      this.propassignedmeService.getSourcingDetails(proposalNo)
        .subscribe(
          data => { this.data=data;
            if (this.data.success == true) {
              this.propassignedmeService.setSecId(this.secId)
                .subscribe(
                  data => { this.data=data;
                    if (this.data.success == true) {
                    }
                  });
            }
          });
    }
    this.propassignedmeService.receiveProposal(proposalNo,docid)
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.ngOnInit();
          }
          else {
            if (this.data.success == false) {
            }
          }
        },
        error => {
        });
  }

}
