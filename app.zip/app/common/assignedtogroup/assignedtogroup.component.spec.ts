import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedtogroupComponent } from './assignedtogroup.component';

describe('AssignedtogroupComponent', () => {
  let component: AssignedtogroupComponent;
  let fixture: ComponentFixture<AssignedtogroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignedtogroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedtogroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
