import { Component, OnInit } from '@angular/core';
import { NewproposalService } from "../../util/service/commonservices/newproposal.service";
import { HomeService } from "../../util/service/commonservices/home.service";
import { PropassignedmeService } from "../../util/service/commonservices/propassignedme.service";
import { HomeComponent } from "../home/home.component";
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
import { Router } from '@angular/router';
import { ProposalrenewalService } from "../../util/service/commonservices/proposalrenewal.service";
declare var $: any;
declare var successStatus: any
declare var failedStatus: any
declare var loadingStatus: any
declare var progressStatus: any
declare var hide: any

@Component({
  selector: 'lp-copyproposal',
  templateUrl: './copyproposal.component.html',
  styleUrls: ['./copyproposal.component.css']
})
export class CopyproposalComponent  implements OnInit {   data:any; 

  [x: string]: any;
  homeBranch: any;
  Description: boolean;
  rbgver: boolean;
  Vertical: boolean = false;
  proposalList: any = [];
  borrowerName: string;
  borrowerList: any = [];
  gridValueList: any = [];
  model: any = {};
  verticalList: any = [];
  custSearchList: any = [];
  dataFound: boolean = false;
  idvalueList: any = ['borrowerName'];
  minDate: Date;
  disableSearch: boolean = false;
  constructor(private newproposalService: NewproposalService, private homeService: HomeService,
    private router: Router, private propassignedmeService: PropassignedmeService,
    private homeComponent: HomeComponent, private fieldvalidation: Fieldvalidation, private proposalrenewalService: ProposalrenewalService) {

    this.minDate = new Date(1899, 12, 1);
    this.minDate.setDate(this.minDate.getDate());
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
  }

  ngOnInit() {
    this.disableSearch = false;
    loadingStatus()
    this.dataFound = false;
    this.model = { crnNo: '', proposalNo: '', customerName: '', panNo: '', location: '', businessName: "", businessDesc: "", prospectAmtFrom: '', prospectAmtTo: '', createdBy: '', holder: '' };

    this.pageId = 504;

    this.newproposalService.getBizVerticalForCopy()
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {

            this.verticalList = this.data.responseData.lpmasBizVerticalList;
          }
        },
        error => {
        });


    this.newproposalService.getHomeBranchForCopy()
      .subscribe(
        data => { this.data=data;
          if (this.data.success) {
            this.homeBranch = this.data.responseData.homeBranch;
          }
        },
        error => {
        });
    hide()
  }

  disableBtn() {
    var btn = <HTMLButtonElement>document.getElementById("searchBtn");
    btn.disabled = true;
  }

  enableBtn() {
    var btn = <HTMLButtonElement>document.getElementById("searchBtn");
    btn.disabled = false;
  }
  proposalSearch() {
    this.dataFound = false;

   if (this.model.proposalNo != "" || this.model.crnNo != "" || this.model.businessName != "" || (this.model.customerName != "" && this.model.location != "" || this.model.panNo != "") || this.model.holder != "" || this.model.createdBy != "") {
  //  if (this.model.proposalNo != "") {
      this.disableSearch = true;
      this.gridValueList = [];
      this.borrowerName = "";
      //this.disableBtn();
      this.load = true;

      this.newproposalService.proposalSearchForCopy(this.model)
        .subscribe(
          data => { this.data=data;
            loadingStatus()
            if (this.data.success == true) {

              this.load = false;
              this.disableSearch = false;
              this.dataFound = true;
              // this.data.responseData.lpcomCustInfoListForCustName.forEach(element => {
              //   this.borrowerName = this.borrowerName + element.lciCustName + ",";
              // });
              // this.borrowerName = this.borrowerName.substring(0, this.borrowerName.length - 1);

                this.gridValueList = this.data.responseData.proposalList;

            //  this.gridValueList.push({ proposalNo: this.data.responseData.lpcomProposal.lpPropNo, createdOn: this.data.responseData.lpCreatedOn, holder: this.data.responseData.lpPropHolder, status: this.data.responseData.status, borrowerName: this.borrowerName });

            }
            else {
              this.dataFound = false;
              this.load = false;
            }
          },
          error => {
            this.disableSearch = false;
            this.dataFound = false;
            this.load = false;
          });
      // this.enableBtn();
      hide()
    }

   
    else if (this.model.prospectAmtFrom != "" && this.model.prospectAmtTo != "") {

      this.gridValueList = [];
      this.borrowerName = "";

      loadingStatus()
      //   this.disableBtn();
      this.load = true;
      this.model.prospectAmtFrom = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.prospectAmtFrom);
      this.model.prospectAmtTo = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.prospectAmtTo);
      this.newproposalService.proposalSearchForCopy(this.model)
        .subscribe(
          data => { this.data=data;
            loadingStatus()
            if (this.data.success == true) {

              this.load = false;
              this.dataFound = true;

               this.gridValueList = this.data.responseData.proposalList;

              // this.data.responseData.lpcomProposalList.forEach((element, index) => {
              //   this.gridValueList.push({ proposalNo: this.data.responseData.proposalList[index].lpPropNo, createdOn: element.lpCreatedOn, holder: element.lpPropHolder, status: element.status, borrowerName: element.lciCustName });
              // });
            }
            else {
              this.dataFound = false;
              this.load = false;
            }
          },
          error => {
            this.dataFound = false;
            this.load = false;
          });
      this.enableBtn();
      hide()
    }
    else {

      alert("Please Enter Search Parameter");
    }
  }


  getSourcingDetails(proposalNo) {

    if (confirm("The data from Current Proposal will be copied to the new proposal. Do you want to continue? ")) {

      this.proposalrenewalService.copyProposal(proposalNo)
        .subscribe(
          data => { this.data=data;
            loadingStatus()
            if (this.data.success) {
              this.router.navigate(['/home/parties/sourcingdetails']);
              this.homeComponent.ngOnInit();
              this.homeComponent.currentPageChildId = 801;
              this.homeComponent.currentPageParentId = 800;
              this.homeComponent.headerpagenavComponent.childClickedInMenuBar(801, 800, 0, 0);


            }
          },
          error => {
          });
      hide()
    }
    else
      return false;
  }

  vertical(value) {

    if (value == "1" || value == "4" || value == "5") {
      this.Vertical = true;
    }
    else {
      this.Vertical = false;
    }
    if (value == "5") {
      this.model.businessDesc = "1"
      this.Description = true
    }
    else if (value == "4") {
      this.model.businessDesc = "2"
      this.Description = true
    }
    else {
      this.model.businessDesc = this.model.businessDesc
      this.rbgver = true;
      this.Description = false
    }

  }

  verticalChange() {
    this.model.businessDesc = ""
    this.Vertical = false;
  }

  cancelButton() {
    if (confirm("Do you want to cancel?")) {
      this.gridValueList = [];
      this.ngOnInit();
    }
    else
      return false;
  }

  resetFields() {
    this.gridValueList = [];
    this.Vertical = false;
    this.ngOnInit();
  }


  checkManualEntry(event: any) {
    sessionStorage.setItem("editMode", "Y");
    let blFlag = this.fieldvalidation.validatedate(event.target.id);
  }
  
  rmvErrClass(id: string) {

    if ($('#' + id).hasClass("has-error")) {
      $('#' + id).removeClass("has-error");
      $('#' + id).attr("placeholder", "");
    }
  }

}
