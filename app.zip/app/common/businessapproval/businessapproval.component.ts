import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectorContext } from '@angular/compiler';
import { BusinessapprovalService } from '../../util/service/commonservices/businessapproval.service';
import { NgForm } from '@angular/forms';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from "../../util/helper/fieldvalidation";
declare var $: any;
import { ChangenoteService } from '../../util/service/commonservices/changenote.service';
import { ChangenoteComponent } from '../changenote/changenote.component';
import { ConsEligibilityComponent } from '../../cons/conseligibility/conseligibility.component';

@Component({
  selector: 'lp-businessapproval',
  templateUrl: './businessapproval.component.html',
  styleUrls: ['./businessapproval.component.css']
})
export class BusinessapprovalComponent extends Validator implements OnInit {
  data: any;
  model: any = {};
  editDisabled: boolean = false;
  saveDisabled: boolean = true;
  cancelDisabled: boolean = false;
  disableFields: boolean = true;
  validation: boolean;
  inttot: number = 0;
  ControllList: any = ['txt_lbaRecmdValue', 'txt_lbaApprovalAuthority'];
  validation1: boolean;
  ControllList1: any = ['txt_chpamt', 'txt_chpper'];
  validation2: boolean;
  ControllList2: any = ['txt_lbaRecmdValue_', 'txt_lbaChargesAmt_', 'txt_lbaApprovalAuthority_'];
  validation3: boolean;
  ControllList3: any = ['txt_lbaRecmdValue_0', 'txt_lbaChargesAmt_0', 'txt_lbaChargesAmt_0'];
  validation4: boolean;
  ControllList4: any = ['txt_chdamt', 'txt_chdper'];
  mclrlist: any = {};
  pageAccess: any;
  disableFields1: boolean = true;
  totalproposedamt: any;
  userid: String;
  prdflag: boolean = true;
  docflag: boolean = true;
  msg: String;
  msg1: String;
  inttemplist: any = [];
  prdtemplist: any = [];
  doctemplist: any = [];
  approvalDisabled: boolean = true;
  flag: String;
  inttemplist1: any = [];
  prdtemplist1: any = [];
  doctemplist1: any = [];
  modelForChngNote: any;
  vertical: any;
  sublist:any;
  disableremark: boolean = true;
  remarklist:any=[];
  @ViewChild(ChangenoteComponent) changenoteComponent: ChangenoteComponent;
  constructor(private approveservice: BusinessapprovalService, private fieldvalidation: Fieldvalidation
    , private changenoteService: ChangenoteService) { super(); }

  ngOnInit() {
    this.modelForChngNote = this.changenoteService.getProposalData();
    this.modelForChngNote.lcmCustSpecific="N";
    this.validators();
    this.disableFields = true;
    this.model.accesstype = "oi";
    this.model.intusrlist = [];
    this.model.prdusrlist = [];
    this.model.docusrlist = [];
    this.inttemplist = [];
    this.prdtemplist = [];
    this.doctemplist = [];
    this.inttemplist1 = [];
    this.prdtemplist1 = [];
    this.doctemplist1 = [];
    this.model.IntapproveList = [];
    this.model.PrdapproveList = [];
    this.model.docapproveList = [];
    this.model.lbaRemark="";
    this.remarklist=[];
    
    this.approveservice.getBorrowerList().subscribe(
      data => {
        this.data = data;
        this.mclrlist = this.data.responseData.mclrList;
        this.pageAccess = this.data.pageAccess;
        this.userid = this.data.userid;
        this.vertical = this.data.vertical;
        this.disableButton(false, true, true);
      });
    this.approveservice.getBusinessapprove(this.model).subscribe(data => {
      this.data = data;
      this.inttemplist = this.data.responseData.BussApprovalintlist;
      this.prdtemplist = this.data.responseData.BussApprovalprdlist;
      this.doctemplist = this.data.responseData.BussApprovaldoclist;
      this.inttemplist1 = this.data.responseData.BussApprovalintlist;
      this.prdtemplist1 = this.data.responseData.BussApprovalprdlist;
      this.doctemplist1 = this.data.responseData.BussApprovaldoclist;
      this.remarklist = this.data.lpcomBussapprRemarklist;
      this.flag = this.data.flag;

      this.inttemplist.forEach((element, index) => {
        this.model.accesstype = "oi";
        this.model.Authority = element.lbaApprovalAuthority;
        this.model.intusrlist[index] = [];
        this.approveservice.getdefaultauthority(this.model).subscribe(data => {
          this.data = data;
          this.model.IntapproveList.push(element);
          this.model.intusrlist[index] = this.data.responseData.userList;
          this.getview(index, 'I');

          let intnewlist=[];
           intnewlist = this.model.IntapproveList.sort((a:any, b:any) => {
            let a1 = parseInt(a.order);
            let b1 =parseInt( b.order);
            if (a1 < b1)
              return -1;
            if (a1 > b1)
              return 1;
            return 0;
          });
          this.model.IntapproveList= JSON.parse(JSON.stringify(intnewlist));

         });
      });
      this.model.chpamt = this.data.responseData.processfee;
      this.model.chpamt = parseFloat(this.model.chpamt).toFixed(2);
      this.model.chpper = this.data.responseData.processper;
      this.model.chpper = parseFloat(this.model.chpper).toFixed(2);
      this.prdtemplist.forEach((element, index) => {
        this.model.accesstype = "oi";
        this.model.Authority = element.lbaApprovalAuthority;
        this.model.prdusrlist[index] = [];
        this.approveservice.getdefaultauthority(this.model).subscribe(data => {
          this.data = data;
          this.model.PrdapproveList.push(element);
          this.model.prdusrlist[index] = this.data.responseData.userList;
          this.getview(index, 'P');
          let prdnewlist =[];
          prdnewlist = this.model.PrdapproveList.sort((a:any, b:any) => {
            let a1 = parseInt(a.lbaFacId);
            let b1 = parseInt(b.lbaFacId);
            if (a1 < b1)
              return -1;
            if (a1 > b1)
              return 1;
            return 0;
          });
          this.model.PrdapproveList= JSON.parse(JSON.stringify(prdnewlist));
        });
      });
      this.model.chdamt = this.data.responseData.docfee;
      this.model.chdamt =parseFloat(this.model.chdamt).toFixed(2);
      this.model.chdper = this.data.responseData.docper;
      this.model.chdper =parseFloat(this.model.chdper).toFixed(2);
      this.doctemplist.forEach((element, index) => {
        this.model.accesstype = "oi";
        this.model.Authority = element.lbaApprovalAuthority;
        this.model.docusrlist[index] = [];
        this.approveservice.getdefaultauthority(this.model).subscribe(data => {
          this.data = data;
          this.model.docapproveList.push(element);
          this.model.docusrlist[index] = this.data.responseData.userList;
          this.getview(index, 'D');

          let docnewlist =[]; 
          docnewlist=this.model.docapproveList.sort((a:any, b:any) => {
            let a1 = parseInt(a.lbaFacId);
            let b1 = parseInt(b.lbaFacId);
            if (a1 < b1)
              return -1;
            if (a1 > b1)
              return 1;
            return 0;
          });
          this.model.docapproveList= JSON.parse(JSON.stringify(docnewlist));
        });
      });

      this.totalproposedamt = this.data.responseData.totalamount;
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.onload(this.pageAccess);
      }

     
    });
    this.disableButton(false, true, true);

    $(document).ready(function () {
      $("form").change(function () {
        sessionStorage.setItem("editMode", "Y");
      });
    });
  }
  disableButton(edit: boolean, save: boolean, cancel: boolean) {
    if (this.pageAccess != "R") {
      this.editDisabled = edit;
      this.saveDisabled = save;
      this.cancelDisabled = cancel;
      if (this.flag == "false") {
        this.approvalDisabled = false;
      }
      else {
        this.approvalDisabled = true;
      }
    }
    else {
      this.editDisabled = true;
      this.saveDisabled = true;
      this.cancelDisabled = true;
      this.approvalDisabled = true;
    }

  }
  doedit() {
    this.disableButton(true, false, false);
    this.disableFields = false;
    this.statusdisable();
    if (this.modelForChngNote.changeMode == "Y") {
      this.changenoteComponent.onEdit(false);
    }
  }
  dosave() {
    let flagCM = true;
    //check on changeMode
    if (this.modelForChngNote.changeMode == "Y") {
      flagCM = this.changenoteComponent.onValidate();
    }
    if(this.disableremark==false)
    {
      var regex = /&nbsp;/gi;
      var temp = this.model.lbaRemark;
      temp = temp.replace(regex, " ");
      if (temp.trim() == "" || temp == null || temp == undefined)
      {
         alert("please enter the Remark");
         return;
      }
    }
    if (flagCM) {

      this.prdflag = true;
      this.docflag = true;
      this.validation = this.fieldvalidation.multipleFieldValidation(this.model.IntapproveList.length, this.ControllList);
      //this.validation1 = this.fieldvalidation.validateField(this.ControllList1);
      //this.validation2 = this.fieldvalidation.multipleFieldValidation(this.model.PrdapproveList.length, this.ControllList2);
      //this.validation3 = this.fieldvalidation.multipleFieldValidation(this.model.docapproveList.length, this.ControllList3);
      //this.validation4 = this.fieldvalidation.validateField(this.ControllList4);
      //Save on changeMode
      if (this.modelForChngNote.changeMode == "Y" && flagCM && this.validation == true) {  //&& this.validation1 == true && this.validation2 == true && this.validation3 == true && this.validation4 == true
        this.changenoteComponent.onSave();
      }
      if (this.validation == true) {  //&& this.validation1 == true && this.validation2 == true && this.validation3 == true && this.validation4 == true
        let prdpertot = 0.00;
        let docpertot = 0.00;
        this.msg1 = "";
        this.msg = "";
        this.model.PrdapproveList.forEach(element => {
          prdpertot += parseFloat(element.lbaRecmdValue);
        });
        this.model.docapproveList.forEach(element => {
          docpertot += parseFloat(element.lbaRecmdValue);
        });
        if (prdpertot > 100) {
          this.prdflag = false;
          this.msg = "processing charges percentage should not be greater than 100 ";
        }
        if (docpertot > 100) {
          this.docflag = false;
          this.msg1 = "document charges percentage should not be greater than 100 ";
        }
        if (this.prdflag == true && this.docflag == true) {
          if (this.model.chpamt == undefined || this.model.chpamt.trim() == "" || this.model.chpamt=="NaN") {
            this.model.chpamt = "0";
            this.model.chpper = "0";
            this.model.PrdapproveList.forEach(element => {
              if (element.lbaRecmdValue == undefined || element.lbaRecmdValue.trim() == "" || isNaN(element.lbaRecmdValue)) { element.lbaRecmdValue = "0.00"; }
              if (element.lbaApprovalAuthority == undefined || element.lbaApprovalAuthority == null || element.lbaApprovalAuthority.trim() == "" ) {
                element.lbaApprovalAuthority = " ";
              }
              if (isNaN(element.lbaChargesAmt)) {
                element.lbaChargesAmt = "0.00";
              }

            });

          }else{
            this.model.PrdapproveList.forEach(element => {
              if (element.lbaRecmdValue == undefined || element.lbaRecmdValue == "" || isNaN(element.lbaRecmdValue)) { element.lbaRecmdValue = "0.00"; }
              if (element.lbaApprovalAuthority == undefined || element.lbaApprovalAuthority == null || element.lbaApprovalAuthority.trim() == "" ) {
                element.lbaApprovalAuthority = " ";
              }
              if (isNaN(element.lbaChargesAmt)) {
                element.lbaChargesAmt = "0.00";
              }

            });
          }
          if (this.model.chdamt == undefined || this.model.chdamt.trim() == "" ||this.model.chdamt=="NaN") {
            this.model.chdamt = "0";
            this.model.chdper = "0";
            this.model.docapproveList.forEach(element => {
              if (element.lbaRecmdValue == undefined || element.lbaRecmdValue.trim() == "" || isNaN(element.lbaRecmdValue)) { element.lbaRecmdValue = "0.00"; }
              if (element.lbaApprovalAuthority == undefined || element.lbaApprovalAuthority == null || element.lbaApprovalAuthority.trim() == "") {
                element.lbaApprovalAuthority = " ";
              }
              if (isNaN(element.lbaChargesAmt)) {
                element.lbaChargesAmt = "0.00";
              }
            });
          }else{
            this.model.docapproveList.forEach(element => {
              if (element.lbaRecmdValue == undefined || element.lbaRecmdValue  == "" || isNaN(element.lbaRecmdValue)) { element.lbaRecmdValue = "0.00"; }
              if (element.lbaApprovalAuthority == undefined || element.lbaApprovalAuthority == null || element.lbaApprovalAuthority.trim() == "") {
                element.lbaApprovalAuthority = " ";
              }
              if (isNaN(element.lbaChargesAmt)) {
                element.lbaChargesAmt = "0.00";
              }
            });
            
          }
          this.approveservice.saveBusinessapprove(this.model).subscribe(
            data => {
              this.data = data;
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.ngOnInit();
            });
          this.disableButton(false, true, true);
          this.resetAllFileds();
        }
        else {
          alert(this.msg + "  " + this.msg1);
        }
      }
    }
  }
  docancel() {
    if (confirm("Do you want cancel?")) {
      sessionStorage.setItem("editMode", "N");
      $('input,select,textarea').removeClass('ng-dirty');
      this.disableFields = true;
      this.disableButton(false, true, true);
      this.resetAllFileds();
      this.ngOnInit();
      if (this.modelForChngNote.changeMode == "Y") {
        this.changenoteComponent.ngOnInit();
      }
    } else {
      return false;
    }

  }
  resetAllFileds() {
    this.model.IntapproveList = [];
    this.model.PrdapproveList = [];
    this.model.docapproveList = [];
  }
  getinttotal(rowid: number, event) {
    this.inttot = 0;
    if(event.target.value!="s"){
    this.mclrlist.forEach(element => {
      if (event.target.value == element.RATE_CD) {
        this.model.IntapproveList[rowid].lbaMclrRate = element.RATE;
      }

    });
    if(this.model.IntapproveList[rowid].lbaPrdDefined)
    this.inttot = parseFloat(this.model.IntapproveList[rowid].lbaMclrRate) + parseFloat(this.model.IntapproveList[rowid].lbaPrdDefined);
    else
    this.inttot = parseFloat(this.model.IntapproveList[rowid].lbaMclrRate);
    
    this.model.IntapproveList[rowid].lbaIntTotal = this.inttot;
    if(this.vertical=='7')
    {
      this.model.IntapproveList[rowid].lbaRecmdValue = this.inttot;
    }
  }else{
    this.model.IntapproveList[rowid].lbaIntTotal="";
    this.model.IntapproveList[rowid].lbaRecmdValue ="";
    this.model.IntapproveList[rowid].lbaMclrRate ="";
    this.model.IntapproveList[rowid].lbaApprovalAuthority =""; 
    this.model.IntapproveList[rowid].lbaUserId ="s"; 
    
  }
  }
  getdefaultauthority(index, type) {
    this.model.accesstype = "ob";
    if(this.model.IntapproveList[index].lbaMclrType!="s"){
     if (type == "I") {
      this.model.intusrlist[index] = [];
      this.model.inttype = "I";
      this.model.prdtype = "S";
      this.model.doctype = "S";
      if(this.model.IntapproveList[index].lbaRecmdValue)
      this.model.intrecvalue = (parseFloat(this.model.IntapproveList[index].lbaRecmdValue) - parseFloat(this.model.IntapproveList[index].lbaMclrRate)).toFixed(2);
      else
      this.model.intrecvalue =0;
     
      
      this.approveservice.getdefaultauthority(this.model).subscribe(data => {
        this.data = data;
        this.model.IntapproveList[index].lbaApprovalAuthority = this.data.responseData.intAuthority;
        this.model.intusrlist[index] = this.data.responseData.intuserList;
      });

    }
    if (type == "P") {
      this.model.prdusrlist[index] = [];
      this.model.inttype = "S";
      this.model.prdtype = "P";
      this.model.doctype = "S";
      this.model.prdrecvalue = this.model.PrdapproveList[index].lbaRecmdValue;
      this.approveservice.getdefaultauthority(this.model).subscribe(data => {
        this.data = data;
        this.model.PrdapproveList[index].lbaApprovalAuthority = this.data.responseData.prdtAuthority;
        this.model.prdusrlist[index] = this.data.responseData.prduserList;
      });
    }
    if (type == "D") {

      this.model.docusrlist[index] = [];
      this.model.inttype = "S";
      this.model.prdtype = "S";
      this.model.doctype = "D";
      this.model.docrecvalue = this.model.docapproveList[index].lbaRecmdValue;
      this.approveservice.getdefaultauthority(this.model).subscribe(data => {
        this.data = data;
        this.model.docapproveList[index].lbaApprovalAuthority = this.data.responseData.docAuthority;
        this.model.docusrlist[index] = this.data.responseData.docuserList;
      });
    }
  }
  }
  getmaxvalue(id: number) {
    if(this.model.IntapproveList[id].lbaMclrType!="s"){
    if (parseFloat(this.model.IntapproveList[id].lbaMclrRate) > parseFloat(this.model.IntapproveList[id].lbaRecmdValue)) {
      alert("Recommended value should not be less than the MCLR rate");
      this.model.IntapproveList[id].lbaRecmdValue = 0;
       (<HTMLInputElement>document.getElementById("sel_lbaUserId"+id)).focus();
      return false;
    }
  }
  }
  getdocchargesamt(index: number) {
    this.model.docapproveList[index].lbaChargesAmt = ((parseFloat(this.model.docapproveList[index].lbaProposalLimit) * parseFloat(this.model.docapproveList[index].lbaRecmdValue)) / 100);
    this.model.docapproveList[index].lbaChargesAmt = parseFloat(this.model.docapproveList[index].lbaChargesAmt).toFixed(2);
    this.getdefaultauthority(index, 'D');
  }
  getdocper(index: number) {
    this.model.docapproveList[index].lbaRecmdValue = ((parseFloat(this.model.docapproveList[index].lbaChargesAmt) * 100) / parseFloat(this.model.docapproveList[index].lbaProposalLimit));
    this.model.docapproveList[index].lbaRecmdValue = parseFloat(this.model.docapproveList[index].lbaRecmdValue).toFixed(2);
    this.getdefaultauthority(index, 'D');
    this.changestatus(index, 'D', this.model.docapproveList[index].lbaMailStatus);
  }
  getchptotper() {
    let z = 0;
    this.model.chpper = ((parseFloat(this.model.chpamt) / parseFloat(this.totalproposedamt)) * 100);
    this.model.chpper = parseFloat(this.model.chpper).toFixed(2);
    this.model.PrdapproveList.forEach(element => {
      element.lbaRecmdValue = this.model.chpper;
      element.lbaRecmdValue = parseFloat(element.lbaRecmdValue).toFixed(2);
      element.lbaChargesAmt = ((parseFloat(element.lbaProposalLimit) * parseFloat(element.lbaRecmdValue)) / 100);
      element.lbaChargesAmt = parseFloat(element.lbaChargesAmt).toFixed(2);
      this.changestatus(z, 'P', element.lbaMailStatus);
      this.getdefaultauthority(z++, 'P');

    });


  }
  getchptotamt(e) {
    if (e.target.value > 100) {
      e.target.value = '';
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Enter Valid Percentage");
      this.model.chpamt = "";
    }
    else {
      $("#" + e.target.id).removeClass("has-error");
      e.target.value = parseFloat(e.target.value).toFixed(2);
      let z = 0;
      this.model.chpamt = ((parseFloat(this.model.chpper) * parseFloat(this.totalproposedamt)) / 100);
      this.model.chpamt = parseFloat(this.model.chpamt).toFixed(2);
      this.model.PrdapproveList.forEach(element => {
        element.lbaRecmdValue = this.model.chpper;
        element.lbaRecmdValue = parseFloat(element.lbaRecmdValue).toFixed(2);
        element.lbaChargesAmt = ((parseFloat(element.lbaProposalLimit) * parseFloat(element.lbaRecmdValue)) / 100);
        element.lbaChargesAmt = parseFloat(element.lbaChargesAmt).toFixed(2);
        this.changestatus(z, 'P', element.lbaMailStatus);
        this.getdefaultauthority(z++, 'P');
      });
    }
  }
  getprochargesamt(index: number) {
    this.model.PrdapproveList[index].lbaChargesAmt = ((parseFloat(this.model.PrdapproveList[index].lbaProposalLimit) * parseFloat(this.model.PrdapproveList[index].lbaRecmdValue)) / 100);
    this.model.PrdapproveList[index].lbaChargesAmt = parseFloat(this.model.PrdapproveList[index].lbaChargesAmt).toFixed(2);
    this.getdefaultauthority(index, 'P');
  }
  getproper(index: number) {
    this.model.PrdapproveList[index].lbaRecmdValue = ((parseFloat(this.model.PrdapproveList[index].lbaChargesAmt) * 100) / parseFloat(this.model.PrdapproveList[index].lbaProposalLimit));
    this.model.PrdapproveList[index].lbaRecmdValue = parseFloat(this.model.PrdapproveList[index].lbaRecmdValue).toFixed(2);
    this.getdefaultauthority(index, 'P');
    this.changestatus(index, 'P', this.model.PrdapproveList[index].lbaMailStatus);
  }
  getview(id, type) {
    
    if (type == "I") {
      var intid = "sel_lbaStatus" + id;
      if (this.userid == $('#sel_lbaUserId' + id).val()) {
        if((<HTMLInputElement>document.getElementById(intid)) != null)
          (<HTMLInputElement>document.getElementById(intid)).disabled = false;
      }
      else {
        if((<HTMLInputElement>document.getElementById(intid)) != null)
          (<HTMLInputElement>document.getElementById(intid)).disabled = true;
          this.model.IntapproveList[id].lbaStatus="s";
      }
      if($('#sel_lbaUserId' + id).val()=='s')
      {
        this.model.IntapproveList[id].lbaStatus="s";
      }
    }
    if (type == "P") {
      var prdid = "sel_lbaStatus_" + id;
      if (this.userid == $('#sel_lbaUserId_' + id).val()) {
        if((<HTMLInputElement>document.getElementById(prdid)) != null)
          (<HTMLInputElement>document.getElementById(prdid)).disabled = false;
      }
      else {
        if((<HTMLInputElement>document.getElementById(prdid)) != null)
          (<HTMLInputElement>document.getElementById(prdid)).disabled = true;
          this.model.PrdapproveList[id].lbaStatus="s";
      }
      if($('#sel_lbaUserId_' + id).val()=='s')
      {
        this.model.PrdapproveList[id].lbaStatus="s";
      }
    }
    if (type == "D") {
      var docid = "sel_lbaStatus_0" + id;
      if (this.userid == $('#sel_lbaUserId_0' + id).val()) {
        if((<HTMLInputElement>document.getElementById(docid)) != null)
          (<HTMLInputElement>document.getElementById(docid)).disabled = false;
      }
      else {
        if((<HTMLInputElement>document.getElementById(docid)) != null)
          (<HTMLInputElement>document.getElementById(docid)).disabled = true;
          this.model.docapproveList[id].lbaStatus="s";
      }
      if($('#sel_lbaUserId_0' + id).val()=='s')
      {
        this.model.docapproveList[id].lbaStatus="s";
      }
    }
    this.dispremark();
  }
  getuserlist() {
    let i = 0, j = 0, k = 0;
    this.model.IntapproveList.forEach(element => {
      this.model.accesstype = "oi";
      this.model.Authority = element.lbaApprovalAuthority;
      this.model.intusrlist[i] = [];
      this.approveservice.getdefaultauthority(this.model).subscribe(data => {
        this.data = data;
        this.model.intusrlist[i] = this.data.responseData.userList;
      });
      i++;
    });
  }

  getchdtotper() {
    let w = 0;
    this.model.chdper = ((parseFloat(this.model.chdamt) / parseFloat(this.totalproposedamt)) * 100);
    this.model.chdper = parseFloat(this.model.chdper).toFixed(2);
    this.model.docapproveList.forEach(element => {
      element.lbaRecmdValue = this.model.chdper;
      element.lbaRecmdValue = parseFloat(element.lbaRecmdValue).toFixed(2);
      element.lbaChargesAmt = ((parseFloat(element.lbaProposalLimit) * parseFloat(element.lbaRecmdValue)) / 100);
      element.lbaChargesAmt = parseFloat(element.lbaChargesAmt).toFixed(2);
      this.changestatus(w, 'D', element.lbaMailStatus);
      this.getdefaultauthority(w++, 'D');
    });


  }
  getchdtotamt(e) {
    if (e.target.value > 100) {
      e.target.value = '';
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Enter Valid Percentage");
      this.model.chdamt = "";
    }
    else {
      $("#" + e.target.id).removeClass("has-error");
      e.target.value = parseFloat(e.target.value).toFixed(2);
      let w = 0;
      this.model.chdamt = ((parseFloat(this.model.chdper) * parseFloat(this.totalproposedamt)) / 100);
      this.model.chdamt = parseFloat(this.model.chdamt).toFixed(2);
      this.model.docapproveList.forEach(element => {
        element.lbaRecmdValue = this.model.chdper;
        element.lbaRecmdValue = parseFloat(element.lbaRecmdValue).toFixed(2);
        element.lbaChargesAmt = ((parseFloat(element.lbaProposalLimit) * parseFloat(element.lbaRecmdValue)) / 100);
        element.lbaChargesAmt = parseFloat(element.lbaChargesAmt).toFixed(2);
        this.changestatus(w, 'D', element.lbaMailStatus);
        this.getdefaultauthority(w++, 'D');
      });
    }
  }
  requestapproval() {
    this.approveservice.sendmail(this.model).subscribe(data => {
      this.data = data;
      if (this.data.success == true) {
        alert("Approval request sent successfully");
      }
      else {
        alert("Approval Request Failed Try Again.");
      }
      this.ngOnInit();
    });
  }
  changestatus(id, type, mail) {
    if(this.model.IntapproveList[id].lbaMclrType!="s"){
    if (type == "I" && mail == "Y") {
      if (parseFloat(this.inttemplist1[id].lbaRecmdValue) != parseFloat(this.model.IntapproveList[id].lbaRecmdValue)) {
        this.model.IntapproveList[id].lbaStatus = "s";
        this.model.IntapproveList[id].lbaMailStatus = "N";
      }
    }
    if (type == "P" && mail == "Y") {
      if (parseFloat(this.prdtemplist1[id].lbaRecmdValue) != parseFloat(this.model.PrdapproveList[id].lbaRecmdValue)) {
        this.model.PrdapproveList[id].lbaStatus = "s";
        this.model.PrdapproveList[id].lbaMailStatus = "N";
      }
    }
    if (type == "D" && mail == "Y") {
      if (parseFloat(this.doctemplist1[id].lbaRecmdValue) != parseFloat(this.model.docapproveList[id].lbaRecmdValue)) {
        this.model.docapproveList[id].lbaStatus = "s";
        this.model.docapproveList[id].lbaMailStatus = "N";
      }
    }
  }
  }
  statusdisable() {
    this.inttemplist.forEach((element, index) => {
      this.getview(index, 'I');
    });
    this.prdtemplist.forEach((element, index) => {
      this.getview(index, 'P');
    });
    this.doctemplist.forEach((element, index) => {
      this.getview(index, 'D');
    });
  }

  percentageValidation(e, type, id) {
    if(e.target.value!="s"){
    if (e.target.value > 100) {
      e.target.value = '';
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Enter Valid Percentage");
      if (type == "P") {
        this.model.PrdapproveList[id].lbaRecmdValue = "";
      }
      else if (type == "D") {
        this.model.docapproveList[id].lbaRecmdValue = "";
      }
      else if (type == "I") {
        this.model.docapproveList[id].lbaRecmdValue = "";
      }
    }
    else if (e.target.value <= 100) {
      $("#" + e.target.id).removeClass("has-error");
      e.target.value = parseFloat(e.target.value).toFixed(2);
    }
  }
  }
  approvestatus(id, type, mail) {
    if (type == "I" && mail == "Y") {
      if (this.inttemplist1[id].lbaStatus != this.model.IntapproveList[id].lbaStatus) {
        this.model.IntapproveList[id].lbaMailRmFlag = "N";
      }
    }
    if (type == "P" && mail == "Y") {
      if (this.prdtemplist1[id].lbaStatus != this.model.PrdapproveList[id].lbaStatus) {
        this.model.PrdapproveList[id].lbaMailRmFlag = "N";
      }
    }
    if (type == "D" && mail == "Y") {
      if (this.doctemplist1[id].lbaStatus != this.model.docapproveList[id].lbaStatus) {
        this.model.docapproveList[id].lbaMailRmFlag = "N";
      }
    }
  }
  setvalue(field)
  {
    this.model.lbaRemark=field.lbaRecommend;
  }
  dispremark()
  {
    this.disableremark= true;
    this.model.IntapproveList.forEach(element => {
      if (this.userid == element.lbaUserId) {
        this.disableremark= false;
      }
     });
     this.model.PrdapproveList.forEach(element1 => {
      if (this.userid == element1.lbaUserId) {
        this.disableremark= false;
      }
     });
     this.model.docapproveList.forEach(element2 => {
      if (this.userid == element2.lbaUserId) {
        this.disableremark= false;
      }
     });
     if(this.disableremark==true)
     {
      this.model.lbaRemark="";
     }
  }

}
