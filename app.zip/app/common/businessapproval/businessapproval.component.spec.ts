import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessapprovalComponent } from './businessapproval.component';

describe('BusinessapprovalComponent', () => {
  let component: BusinessapprovalComponent;
  let fixture: ComponentFixture<BusinessapprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessapprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessapprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
