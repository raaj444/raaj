import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankdepositsComponent } from './bankdeposits.component';

describe('BankdepositsComponent', () => {
  let component: BankdepositsComponent;
  let fixture: ComponentFixture<BankdepositsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankdepositsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankdepositsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
