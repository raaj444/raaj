import { Component, OnInit } from '@angular/core';
import { BankdepositsService } from "../../util/service/commonservices/bankdeposits.service";
import { Router } from '@angular/router';
import { Validator } from '../../util/helper/validator';
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
declare var $: any;

@Component({
  selector: 'lp-bankdeposits',
  templateUrl: './bankdeposits.component.html',
  styleUrls: ['./bankdeposits.component.css']
})
export class BankdepositsComponent extends Validator  implements OnInit {   data:any; 
  pageAccess: any;
  model: any = {};
  disableFields: boolean;
  disableEditButton: boolean;
  disableSaveButton: boolean;
  disableCancelButton: boolean;
  idvalueList = ['lsbdBank', 'lsbdDateOfIssue', 'lsbdAcctNo', 'lsbdPrincipleValue', 'lsbdBookValue', 'lsbdMaturityValue', 'lsbdDueDate'];
  maxDate:Date;
  minDate:Date;
  constructor(private bankdepositsService: BankdepositsService, private router: Router, private fieldvalidation: Fieldvalidation) {
    super();
    this.maxDate =new Date();
    this.maxDate .setDate(this.maxDate.getDate());
    this.minDate =new Date();
    this.minDate .setDate(this.minDate.getDate());
  }

  ngOnInit() {
    this.pageAccess = $('#pageAccess').val();
    this.validators();
    this.model = {};
    this.model.bankDepositDetails = { "lsbdRowId": '', "lsbdAcctNo": '', "lsbdBank": 's', "lsbdBookValue": '', "lsbdBranchName": '', "lsbdCreatedBy": '', "lsbdCreatedOn": '', "lsbdDateOfIssue": '', "lsbdDueDate": '', "lsbdMaturityValue": '', "lsbdModifiedBy": '', "lsbdModifiedOn": '', "lsbdPrincipleValue": '', "lsbdRoi": '',lsbdValuationDate:'',lsbdDemant:'s',lsbdReinvestUnit:'s' }
    this.disableFields = true;
    this.disableButtons(false, true, true);

    this.model.secId = $('#bankDepositSecId').val();

    for (var i = 0; i < this.idvalueList.length; i++)
      $('#' + this.idvalueList[i]).removeClass("has-error");

    this.bankdepositsService.getBankdeposits(this.model.secId)
      .subscribe(
        data => { this.data=data;
          if (this.data.success == true) {
            this.model.bankDepositDetails = this.data.responseData;
            this.model.bankDepositDetails.lsbdPrincipleValue = parseFloat(this.model.bankDepositDetails.lsbdPrincipleValue).toFixed(2);
            this.model.bankDepositDetails.lsbdBookValue = parseFloat(this.model.bankDepositDetails.lsbdBookValue).toFixed(2);
            this.model.bankDepositDetails.lsbdMaturityValue = parseFloat(this.model.bankDepositDetails.lsbdMaturityValue).toFixed(2);
          }

        },
        error => {
          // this.alertService.error(error);
        });
  }

  saveBankdeposits() {
    if (this.fieldvalidation.validateField(this.idvalueList)) {
      this.model.bankDepositDetails.lsbdDateOfIssue = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.bankDepositDetails.lsbdDateOfIssue);
      this.model.bankDepositDetails.lsbdDueDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.bankDepositDetails.lsbdDueDate);
      if(this.model.bankDepositDetails.lsbdValuationDate)
      this.model.bankDepositDetails.lsbdValuationDate = this.fieldvalidation.dPDateConversionFromIndianStd(this.model.bankDepositDetails.lsbdValuationDate);
      this.bankdepositsService.saveBankdeposits(this.model)
        .subscribe(
          data => { this.data=data;
            if (this.data.success == true) {
              sessionStorage.setItem("editMode", "N");
              $('input,select,textarea').removeClass('ng-dirty');
              this.ngOnInit();
              this.disableFields = true;
              this.disableButtons(false, true, true);
            }

          },
          error => {
            // this.alertService.error(error);
          });
    }
  }

  editBankdeposits() {
    this.disableFields = false;
    this.disableButtons(true, false, false);
  }

  cancelBankdeposits() {
    if (confirm("Do you want to Cancel?")) {
      this.ngOnInit();
    }
    else {
      return false;
    }
  }

  validateDate(val) {
    if (val != '' && val != null) {
      let date = val.split("/");
      return date[2] + "-" + date[1] + "-" + date[0];
    }
  }

  validatefuturedate(event) {
    if(event!=null && event !=""){
    this.fieldvalidation.validatefuturedate(event.target.id);
    }
  }

  allowFutureDate(e: any)
  {
    if (!this.daterestrict(e)) {
      e.target.value = "";
      $('#' + e.target.id).addClass("has-error");
      $('#' + e.target.id).attr("placeholder", "Enter valid date");
    }

    else {
      if (this.effDateRes(e.target.value)) {
        e.target.value = "";
        $('#' + e.target.id).addClass("has-error");
        $('#' + e.target.id).attr("placeholder", "Past date not allowed here");
      }
    }
  }

  disableButtons(edit, save, cancel)
  {
    if(this.pageAccess == 'R')
    {
      this.disableEditButton = true;
      this.disableSaveButton = true;
      this.disableCancelButton = true;
    }
    else{
      this.disableEditButton = edit;
      this.disableSaveButton = save;
      this.disableCancelButton = cancel;
    }
  }
  rmvErrClass(id:string)
  {
   if($('#' +id).hasClass("has-error"))
    {
    $('#' +id).removeClass("has-error");
    $('#' + id).attr("placeholder", "");
    }
  }


  roiValidation(e) {
    if (e.target.value > 100) {
      e.target.value = '';
      $("#" + e.target.id).addClass("has-error");
      $("#" + e.target.id).attr("placeholder", "Enter Valid ROI");
    }
    else if (e.target.value <= 100) {
      $("#" + e.target.id).removeClass("has-error");
      e.target.value = parseFloat(e.target.value).toFixed(2);
    }
  }
}
