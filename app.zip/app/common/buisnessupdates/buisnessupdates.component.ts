import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validator } from "../../util/helper/validator";
import { Fieldvalidation } from '../../util/helper/fieldvalidation';
import { AdditionalinfoService } from '../../util/service/commonservices/additionalinfo.service';
declare var $: any;
declare var successStatus:any
declare var failedStatus:any
declare var loadingStatus:any
declare var progressStatus:any
declare var hide:any

@Component({
  selector: 'lp-buisnessupdates',
  templateUrl: './buisnessupdates.component.html',
  styleUrls: ['./buisnessupdates.component.css']
})
export class BuisnessupdatesComponent extends Validator  implements OnInit {   data:any; 
  ngAfterViewInit(): void {
    $($('.fr-wrapper').children('div')[0]).hide();
  }

  model: any = {};
  editbuttonDisable: boolean;
  savebuttonDisable: boolean;
  cancelbuttonDisable: boolean;
  loadTemplateDisable: boolean;
  newheaderDisable: boolean;
  pageAccess: string;
  private businessUpdatesArray: Array<any> = [];
  save: string;
  headerDisable: boolean;
  constructor(private additionalinfoService: AdditionalinfoService,
    private router: Router, private fieldvalidation: Fieldvalidation) {
    super();
  }

  ngOnInit() {
    this.headerDisable = true;
    this.buttonAccess(true, true, true, true);
    this.model.StQualitativeTemplateList = [];
    this.model.businessUpdatesArray = [];
   
    // $("#txtEditor").Editor("setText", " ");
    // $("#txtEditor").Editor("setEnable", false);
    this.getQualitativeMaster();
  }
  getQualitativeMaster()
  {
    loadingStatus
    let custId=""
  this.additionalinfoService.getQualitativeMasterForBU(custId)
      .subscribe(
      data => { this.data=data;
        if (this.data.success) {
          this.pageAccess = this.data.pageAccess;
          if (this.pageAccess == "R")
            this.newheaderDisable = true;
          else
            this.newheaderDisable = false;
          this.model.businessUpdatesArray = this.data.responseData.headerDataList;
          this.model.businessUpdatesArray.forEach(element => {
            element.color = "white";

          });
          this.model.StQualitativeTemplateList = this.data.responseData.StQualitativeList;
        }
      },
      error => {
        // this.alertService.error(error);
      });
      hide()
    }
  getContent(i: any) {
    if (this.pageAccess == "R")
      this.buttonAccess(true, true, true, true);
    else
      this.buttonAccess(false, true, true, false);

    this.model.businessUpdatesArray.forEach(element => {
      element.color = 'white';
    });
    // $("#txtEditor").Editor("setText", this.model.businessUpdatesArray[i].lpaiComments);
    this.model.businessUpdatesArray[i].color = "Pink";
    this.model.index = i;
    this.save = "update";
    this.model.lpaiRowId = this.model.businessUpdatesArray[i].lpaiRowId;
    this.model.lpaiCmtHeading = this.model.businessUpdatesArray[i].sqmCommentHeader;
    this.model.lpaiComments = this.model.businessUpdatesArray[i].lpaiComments
  }
  saveBusinessUpdates() {

    // this.model.lpaiComments = $("#txtEditor").Editor("getText");
    if (this.save == "Insert")
      this.model.BusinessUpdates = { lpaiComments: this.model.lpaiComments, lpaiCmtFor: "FI", lpaiCmtId: 0, lpaiCmtHeading: this.model.Heading, lpaiRowId: 0 };
    if (this.save == "update")
      this.model.BusinessUpdates = { lpaiComments: this.model.lpaiComments, lpaiCmtFor: "FI", lpaiCmtId: this.model.businessUpdatesArray[this.model.index].sqmRowId, lpaiRowId: this.model.lpaiRowId, lpaiCmtHeading: this.model.lpaiCmtHeading };
    if (this.model.BusinessUpdates.lpaiCmtHeading == "")
      alert("Heading should not be empty");
    else if (this.model.BusinessUpdates.lpaiComments == "")
      alert("Comments should not be empty");
      else{
        
    this.additionalinfoService.saveBusinessUpdates(this.model.BusinessUpdates)
      .subscribe(
      data => { this.data=data;
        progressStatus()
        if (this.data.success) {
          this.buttonAccess(true,true,true,true);
          let custId="";
          this.additionalinfoService.getQualitativeMasterForBU(custId)
            .subscribe(
            data => { this.data=data;
              if (this.data.success) {
                this.model.businessUpdatesArray = this.data.responseData.headerDataList;
                this.model.businessUpdatesArray.forEach(element => {
                  element.color = "white";
                });
                // this.model.StQualitativeTemplateList=this.data.responseData.StQualitativeList;
                this.model.sqmTemplate =""
                // $("#txtEditor").Editor("setEnable", false);
                this.model.Heading="";
                this.headerDisable=true;
                this.buttonAccess(true,true,false,true);
              }
            },
            error => {
              // this.alertService.error(error);
            });
            successStatus();
        }
        else
          failedStatus()
      },
      error => {
        // this.alertService.error(error);
      });
    }
  }
  loadTemplate() {
    var i = 0;
    this.model.StQualitativeTemplateList.forEach(element => {
      if (element.sqmRowId == this.model.businessUpdatesArray[this.model.index].sqmRowId) {
        this.model.lpaiComments=element.sqmTemplate;
        // $("#txtEditor").Editor("setText", element.sqmTemplate);
        i++;
      }
    });
    if (i == 0)
      // $("#txtEditor").Editor("setText", "");
      this.model.lpaiComments=''
  }
  editAddinfoDetail() {
    this.buttonAccess(true, false, false, false);
    // $("#txtEditor").Editor("setEnable", true);
  }

  addCommentheader() {
    this.model.Heading = "";
    this.save = "Insert";
    this.buttonAccess(true, false, false, true);
    this.headerDisable = false;
    // $("#txtEditor").Editor("setText", "");
    // $("#txtEditor").Editor("setEnable", true);
  }
  cancelButton() {
    if (confirm("Do you want to Cancel?")) {
      this.headerDisable = true;
      this.buttonAccess(true, true, true, true);
      this.model.StQualitativeTemplateList = [];
      this.model.businessUpdatesArray = [];
      // $("#txtEditor").Editor("setText", " ");
      // $("#txtEditor").Editor("setEnable", false);
      this.getQualitativeMaster();
    }
    else
      return false;
  }
  buttonAccess(val1: boolean, val2: boolean, val3: boolean, val4: boolean) {
    this.editbuttonDisable = val1;
    this.savebuttonDisable = val2;
    this.cancelbuttonDisable = val3;
    this.loadTemplateDisable = val4;
  }
}

