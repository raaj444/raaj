import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuisnessupdatesComponent } from './buisnessupdates.component';

describe('BuisnessupdatesComponent', () => {
  let component: BuisnessupdatesComponent;
  let fixture: ComponentFixture<BuisnessupdatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuisnessupdatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuisnessupdatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
