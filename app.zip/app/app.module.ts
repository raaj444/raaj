import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApproutingModule } from './approuting.module';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './common/login/login.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { LoginService } from './util/service/commonservices/login.service';
import { Fieldvalidation } from './util/helper/fieldvalidation';
import { ChangenoteService } from './util/service/commonservices/changenote.service';
import { LoaderComponent } from './util/selector/loader/loader.component';
import { APIInterceptor } from './util/helper/APIInterceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { SecuresessionService } from "./util/service/commonservices/securesession.service";
import { IplettermailformatComponent } from "./corporate/iplettermailformat/iplettermailformat.component";
import { SlmailformatComponent } from "./common/slmailformat/slmailformat.component";
import { AddendumslmailformatComponent } from './common/slmailformat/addendumslmailformat/addendumslmailformat.component';
import { FileattachmentService } from './util/service/commonservices/fileattachment.service';
import { CranmailformatComponent } from './common/slmailformat/cranmailformat/cranmailformat.component';
import { CranModule } from './cran.module';
import { CustomTagModule } from "./customtags/custom-tag.module";




@NgModule({
  imports: [
    CommonModule,
    ApproutingModule,
    FormsModule,
    BrowserModule,
    HttpClientModule,
    CranModule,
   CustomTagModule
  ],
  declarations: [LoginComponent, AppComponent, LoaderComponent, IplettermailformatComponent, SlmailformatComponent, AddendumslmailformatComponent, CranmailformatComponent],
  bootstrap: [AppComponent],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: APIInterceptor,
    multi: true,
  }, Fieldvalidation, LoginService, ChangenoteService,SecuresessionService, FileattachmentService, LoginComponent]
})
export class AppModule { }
