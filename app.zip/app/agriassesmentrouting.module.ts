import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { KccassessmentComponent } from './agri/kccassessment/kccassessment.component';
import { AgritermloanComponent } from './agri/agritermloan/agritermloan.component';
import { ValuationandcollateralComponent } from "./agri/valuationandcollateral/valuationandcollateral.component";
import { CropsurrogatetermComponent } from './agri/cropsurrogateterm/cropsurrogateterm.component';
import { KccacuntmaturityComponent } from './agri/kccacuntmaturity/kccacuntmaturity.component';
import { DscrassessmentComponent } from './agri/dscrassessment/dscrassessment.component';
@NgModule({
  imports: [RouterModule.forChild([
    { path: 'kccassessment', component: KccassessmentComponent},
    { path: 'agritermloan', component: AgritermloanComponent },
    { path: 'valuation', component: ValuationandcollateralComponent },
    { path: 'cropsurrogatetermloan', component: CropsurrogatetermComponent},
    { path: 'kccacuntmaturity', component: KccacuntmaturityComponent },
    { path: 'dscrassessment', component: DscrassessmentComponent },

  ])
  ],
 
  exports:[RouterModule]

})
export class AgriassesmentroutingModule { }
