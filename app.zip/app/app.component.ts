import { Component, OnInit } from '@angular/core';
import { Router, RouteConfigLoadStart, RouteConfigLoadEnd} from '@angular/router';
import { LoginComponent } from "./common/login/login.component";
declare var $: any;
@Component({
  selector: 'lp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  constructor(private router:Router, private loginComponent: LoginComponent)
  {

  }
  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof RouteConfigLoadStart) {
        $('#loader').show();
      } else if (event instanceof RouteConfigLoadEnd) {
        $('#loader').hide();
      }
  });
  }
  title = 'Lendperfect';

  closeModals()
  {
    $('.modal.in').modal('hide');
    if (this.router.routerState.snapshot.url.includes('/login')) {
      this.loginComponent.ngOnInit();
    } else
      this.router.navigate(['/login']);    
  }
}
