package JdbcBackend;
import java.sql.*;
import JdbcBackend.BackendUser;
public class JdbcConnection {

	public static Connection DBConnect()
	{
		Connection con = null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.26:1521:DBORCL12C", "TRAINEE", "trainee");
			System.out.println("connected");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch(SQLException r){
			System.out.println(r);
		}
		return con;
	}
	
		public static void main(String[] args) {
		
		
		
	}
}