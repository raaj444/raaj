import { Component, OnInit } from '@angular/core';
import { AssignService } from '../assign.service';
export class taskModel
{
    constructor(
      public id:number,
      public projectname:string,
      public projectmodule:string,
    public submodule:string,
    public description:string,
    public assign:string,
    public duration:string,
    public start1:string,
    public end1:string
    ){}
}
@Component({
  selector: 'app-retrieve',
  templateUrl: './retrieve.component.html',
  styleUrls: ['./retrieve.component.css']
})
export class RetrieveComponent implements OnInit {

  tModel : taskModel[]
  id:number;
  filteredList:any;

    
  constructor(private retservice: AssignService) { }

  ngOnInit() {
    
    this.retrivedata();
  }
  retrivedata(){
    this.retservice.retrieve().subscribe(
      data=>{
        this.tModel=data;
        this.filteredList = this.tModel;
        console.log(this.tModel);
      }
    )
  }
  getFilteredList( filterTCMaster ) {
    if ( filterTCMaster ) {
        this.tModel = this.filteredList.filter( function( data ) {
          console.log(data);
            return data.projectname.toLowerCase().indexOf( filterTCMaster.trim().toLowerCase() ) > -1;
        } );
    } else {
        this.tModel = this.filteredList;
    }
}
}
 