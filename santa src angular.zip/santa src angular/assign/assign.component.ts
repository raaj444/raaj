import { Component, OnInit } from '@angular/core';
import { AssignService } from '../assign.service';

export class taskModel
{
    constructor(
      public id:number,
      public projectname:string,
      public projectmodule:string,
    public submodule:string,
    public description:string,
    public assign:string,
    public duration:string,
    public start1:string,
    public end1:string
    ){}
}

@Component({
  selector: 'app-assign',
  templateUrl: './assign.component.html',
  styleUrls: ['./assign.component.css']
})
export class AssignComponent implements OnInit {
  tModel : taskModel;
  id:number;
  constructor( private assignservice: AssignService ) {
      
  }
  ngOnInit() {
   
    this.tModel=new taskModel(this.id,'','','','','','','','')
    
  }
  assignTask()
    {
      console.log('called')
      this.assignservice.getRegisterData(this.tModel).subscribe(
        data=>{

      });
    }
}
