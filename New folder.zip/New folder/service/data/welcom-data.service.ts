
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


export  class HelloWorldBean{
  constructor(public message:string){}
}
@Injectable({
  providedIn: 'root'
})
export class WelcomDataService {

  constructor(private http:HttpClient) { }

  executeHelloWorldBeanService()
  {
    console.log("Execute Hello World Bean Service")
    return this.http.get<HelloWorldBean>('http://localhost:7072/hello-world-bean');
    console.log("Execute Hello World Bean Service")
  }
  executeHelloWorldBeanServiceWithPathVariable(name)
  { 
    let basicAuthHeaderString=this.createBaisicAuthenticationHttpHeader();
    let headers=new HttpHeaders({
      Authorization:basicAuthHeaderString
    })
    console.log("Execute Hello World Bean Service")
    return this.http.get<HelloWorldBean>(`http://localhost:7072/hello-world/path-variable/${name}`,
    {headers});
   // console.log("Execute Hello World Bean Service")
  }
createBaisicAuthenticationHttpHeader()
{
  let username='sam'
  let password='dummy'
  let basicAuthHeaderString='Basic'+window.btoa(username+':'+password);
  return basicAuthHeaderString;
}
}
