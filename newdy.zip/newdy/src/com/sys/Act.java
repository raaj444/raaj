package com.sys;

import java.io.*;

import javax.servlet.http.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
/**
 * Servlet implementation class Act
 */
@WebServlet("/Act")
public class Act extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Act() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
		
		String Bikename=request.getParameter("Bikename");
		String bikemodel=request.getParameter("bikemodel");
		String bikecolor=request.getParameter("bikecolor");
		String bikeversion=request.getParameter("bikeversion");
		PrintWriter pw=response.getWriter();
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		try{
			
			con=DriverManager.getConnection("jdbc:oracle:tihn:@localhost:1521:xe","trainee","trainee");
		    pw.println("connecton established"+con);
		    System.out.println("connecton established"+con);
		
		}
		
		catch(SQLException e)
		{
			pw.println(e);
		}
		
		}
		catch(Exception e)
		{
			pw.print(e);
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
