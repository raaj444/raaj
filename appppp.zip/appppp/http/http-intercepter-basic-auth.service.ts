import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { nextContext } from '@angular/core/src/render3';

@Injectable({
  providedIn: 'root'
})
export class HttpIntercepterBasicAuthService implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<any>, next: HttpHandler)
  {
    let username='mani'
  let password='dummy'
  let basicAuthHeaderString='Basic'+window.btoa(username+':'+password);
  request=request.clone(
    {
      setHeaders:{
        Authorization: basicAuthHeaderString
      }
    }
  )
  return next.handle(request);
  }
  
}
