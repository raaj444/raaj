import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Bike } from './bikedetails/bikedetails.component';


@Injectable({
  providedIn: 'root'
})
export class BikeService {
   
  constructor(private http:HttpClient) { }

  retrieveAll(username)
  {
    console.log("Execute Hello World Bean Service")
    return this.http.get<Bike[]>(`http://localhost:7072/jpa/users/${username}/bikes`);
   
  }
  delete(username,id)
  {
    return this.http.delete(`http://localhost:7072/jpa/users/${username}/bikes/${id}`)
  }
  retreive(username,id)
  {
    return this.http.get<Bike>(`http://localhost:7072/jpa/users/${username}/bikes/${id}`)
  }
  update(username,id,bike)
  {
    return this.http.put(`http://localhost:7072/jpa/users/${username}/bikes/${id}`,bike)
  }
  create(username,bike)
  {
    return this.http.post(`http://localhost:7072/jpa/users/${username }/bikes`,bike)
  }
}
