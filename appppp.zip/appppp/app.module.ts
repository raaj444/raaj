import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { WelcomeComponent } from './welcome/welcome.component';
import { MenuComponent } from './menu/menu.component';
import { RouterModule } from '@angular/router';
import { LogoutComponent } from './logout/logout.component';
import { BikeComponent } from './bike/bike.component';
import { BikedetailsComponent } from './bikedetails/bikedetails.component';

import { RouteGuardService } from './route-guard.service';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeComponent,
    MenuComponent,
    LogoutComponent,
    BikeComponent,
    BikedetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'login',component:LoginComponent},
      {path: 'welcome',component:WelcomeComponent},
      {path: 'logout',component:LogoutComponent},
      {path: 'bikes',component:BikeComponent,canActivate:[RouteGuardService]},
      {path: 'logout',component:LogoutComponent,canActivate:[RouteGuardService]},
      {path: 'bikes/:id',component:BikeComponent,canActivate:[RouteGuardService]},
      
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
