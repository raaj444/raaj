import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  
  constructor() { }

  authenticate(username,password)
  {
    console.log("hi");
    if(username==='admin' && password==='admin')
    {
      sessionStorage.setItem('authenticaterUser',username);
     console.log("valid");
    return true;
    }
    else
    return false;

  }
  isUserLoggedIn()
  {
    let user=sessionStorage.getItem('authenticaterUser')
    console.log(user)
    return !(user===null)
  }
  logout()
  {
    sessionStorage.removeItem('authenticaterUser')
  }
}