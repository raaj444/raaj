import { Component, OnInit } from '@angular/core';
import { Bike } from '../bikedetails/bikedetails.component';
import { BikeService } from '../bike.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-bike',
  templateUrl: './bike.component.html',
  styleUrls: ['./bike.component.css']
})
export class BikeComponent implements OnInit {

  id:number;
  bike:Bike;
  constructor(private bikeService: BikeService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.id=this.route.snapshot.params['id'];
    this.bike=new Bike(this.id,'',false,new Date())
    if(this.id!=-1)
    {
    this.bikeService.retreive('mani',this.id).subscribe(
      data=>this.bike=data
    )
    }
  }
  save()
  {
    if(this.id==-1)
    {
      this.bikeService.create('mani',this.bike).
      subscribe(
        data=>{
          console.log(data)
        this.router.navigate(['bikes'])
        }
      )
    }
    else
    {
    this.bikeService.update('mani',this.id,this.bike).
    subscribe(
      data=>{
        console.log(data)
      this.router.navigate(['bikes'])
      }
    )
    }
  }

}
