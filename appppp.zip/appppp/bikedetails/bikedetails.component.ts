import { Component, OnInit } from '@angular/core';
import { BikeService } from '../bike.service';
import { Router } from '@angular/router';


export class Bike{
  constructor(
    public id:number,
    public bikename:string,
    public Model:boolean,
    public Manufacture_Date:Date) { }
}

@Component({
  selector: 'app-bikedetails',
  templateUrl: './bikedetails.component.html',
  styleUrls: ['./bikedetails.component.css']
})
export class BikedetailsComponent implements OnInit {

  bikes : Bike[]
  
  
  constructor(private bikeService: BikeService,private router:Router) { }

  ngOnInit() {

   this.refresh();
   
  }

  refresh()
  {
    this.bikeService.retrieveAll('mani').subscribe(
      response => {
        this.bikes = response;
      }
    )
  }
  delete(id)
  {
    console.log(id);
    this.bikeService.delete('mani',id).subscribe(
      response=>{
        this.refresh();
      }
    )
  }
  update(id)
  {
    console.log(`update ${id}`)
    this.router.navigate(['bikes',id])
  }

  add()
  {
    this.router.navigate(['bikes',-1])
  }

}
