import { Component, OnInit } from '@angular/core';
import { LeadService } from '../lead.service';
import { ActivatedRoute } from '@angular/router';

export class taskModel
{
    constructor(
      public id:number,
      public projectname:string,
      public projectmodule:string,
    public submodule:string,
    public description:string,
    public assign:string,
    public duration:string,
    public start1:string,
    public end1:string
    ){}
}

@Component({
  selector: 'app-lead',
  templateUrl: './lead.component.html',
  styleUrls: ['./lead.component.css']
})
export class LeadComponent implements OnInit {
  tModel : taskModel;
  id:number;
  constructor( private service: LeadService ) {
      
  }
  ngOnInit() {
   
    this.tModel=new taskModel(this.id,'','','','','','','','')
    
  }
  assignTask()
    {
      console.log('called')
      this.service.getRegisterData(this.tModel).subscribe(
        data=>{

      });
    }
}
