import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LeadService {

  constructor( private http:HttpClient) { }
  getRegisterData(tModel)
    {
      console.log('task')
      return this.http.post('http://localhost:7082/assigndata',tModel);
    }
   
    retrieve() :any
   {
    console.log('retrived')
    return this.http.post('http://localhost:7082/retrivedata','');
     }
}
